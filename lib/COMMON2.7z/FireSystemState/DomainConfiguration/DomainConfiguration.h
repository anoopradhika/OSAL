/******************************************************************************//**
*
* @file   DomainConfiguration.h
* @brief  DomainConfiguration file operation handles here
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_DOMIAN_CONFIGURATION_HANDLE_H
#define FIRESYSTEM_DOMIAN_CONFIGURATION_HANDLE_H

#include "tinyxml2.h"
#include "tixml2ex.h"

#include "Communicator/Communicator.hpp"
#include "Mol/Events/InformationEvent.h"
#include "Mol/DataType/ObjectReference.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DEBUGPRINT/DEBUGPRINT.h"
#include "Utility.h"
#include <limits.h>

namespace fireSystemState
{
    /**
      @brief: Data structure representing all the logical Hierarchy of the site
      */
    struct LogicalHierarchy
    {
        struct Zone
        {
            Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::INVALID;
            uint32_t id = 0;
            std::shared_ptr<std::list<std::shared_ptr<Mol::DataType::ObjectReference>>> logicalPoints;
            Zone(){
                logicalPoints = std::make_shared<std::list<std::shared_ptr<Mol::DataType::ObjectReference>>>();
            };
            Zone(Dol::DOMAIN_OBJECT_TYPE type_, uint32_t id_):Zone()
            {
                type = type_;
                id = id_;
            }
        };
        struct ManagedArea
        {
            Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA;
            uint32_t id = 0;
            std::shared_ptr<std::list<std::shared_ptr<Mol::DataType::ObjectReference>>> physicalPoints;;
            std::shared_ptr<std::list<std::shared_ptr<Zone>>> zones;
            ManagedArea(){
                physicalPoints = std::make_shared<std::list<std::shared_ptr<Mol::DataType::ObjectReference>>>();
                zones = std::make_shared<std::list<std::shared_ptr<Zone>>>();
            };
            ManagedArea(uint32_t id_, Dol::DOMAIN_OBJECT_TYPE type_ = Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA) : ManagedArea()
            {
                type = type_;
                id = id_;
            }
        };
        struct Building
        {
            Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::BUILDING;
            uint32_t id = 0;
            std::shared_ptr<std::list<std::shared_ptr<ManagedArea>>> managedAreas;
            Building(){
                managedAreas = std::make_shared<std::list<std::shared_ptr<ManagedArea>>>();
            };
            Building(uint32_t id_, Dol::DOMAIN_OBJECT_TYPE type_ = Dol::DOMAIN_OBJECT_TYPE::BUILDING): Building()
            {
                type = type_;
                id = id_;
            }
        };
        struct Site
        {
            Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::SITE;
            uint32_t id = 1;
            std::shared_ptr<std::list<std::shared_ptr<Building>>> buildings;
            Site(){
                buildings = std::make_shared<std::list<std::shared_ptr<Building>>>();
            };
        };
        std::shared_ptr<Site> site = nullptr;
    };
/**
* @brief Create xml handle for Domain configuration file
*/
class DomainConfigurationHandle
{
public:
    static DomainConfigurationHandle& GetInstance()
    {
        static DomainConfigurationHandle handle;
        return handle;
    }
    tinyxml2::XMLDocument& GetHandle()
    {
        return m_doc;
    }
private:
    DomainConfigurationHandle()
    {
        try
        {
            std::string configFile = Utility::GetActiveConfigLocation();
            configFile.append("configuration.xml");

            // Check for Symlink or Hardlink
            if (Utility::IsSymlinkOrHardlink(configFile))
            {
                DEBUGPRINT(DEBUG_ERROR, "DomainConfigurationHandle: [{0}] is a Symlink or Hardlink", configFile);
            }
            else
            {
                m_doc.LoadFile( configFile.c_str() );
            }
        }
        catch( tinyxml2::XmlException &e )
        {
			DEBUGPRINT(DEBUG_ERROR, "DomainConfigurationHandle: Tinyxml Exception thrown - {}", e.what());
			return;
        }
        catch(...)
        {
			DEBUGPRINT(DEBUG_ERROR, "DomainConfigurationHandle: Unknown exception while reading the xml file ");
			return;
        }
    }

    ~DomainConfigurationHandle() = default;

private:
    tinyxml2::XMLDocument m_doc;
};


/**
* Helper class to parse the Domain configuration file
*/
class DomainConfiguration
{
public:
    DomainConfiguration() = default;
    LogicalHierarchy& GetLogicalHierarchyInstance()
    {
        static LogicalHierarchy logicalHierarchy;
        if(!logicalHierarchy.site)
        {
            logicalHierarchy.site = PopulateLogicalHierarchy();
        };
        return logicalHierarchy;
    }
    ~DomainConfiguration() = default;
    /**
      @brief Get NoResound option from config file
      @retval the value found in the "NoResound" element if present, if not empty string
      */
    std::string GetResoundOption()
    {
        auto elements = selection( m_doc, "/configuration/site/" );

        for(auto element : elements  )
        {
            const char* name = element->Name();
            const char* text = element->GetText();

            if ( name && text )
            {
                if ( name == std::string("ResoundOption") )
                {
                    return text;
                }
            }
        }

        return "";
    }

    /**
      @brief Read building config from XML file
      @param[out]  configs  table to store XML configuration in native c++ representation
      */
    void BuildingConfig(std::vector<XmlElementConfig>& configs )
    {
        auto elements = selection( m_doc, "/configuration/site/building" );
        for(auto element : elements  )
        {
            XmlElementConfig type;
            Assign( type.id,  attribute_value(element, "id"));
            DEBUGPRINT(DEBUG_INFO,"building Id {}",type.id);
            type.pointType = Dol::DOMAIN_OBJECT_TYPE::BUILDING;
            configs.push_back(type);
        }
    }


    /**
      @brief Read managedArea config from XML file

      @param[out]  configs  table to store XML configuration in native c++ representation
      */
    void ManagedAreaConfig( std::vector<XmlElementConfig>& configs )
    {
        std::string key = "/configuration/site/building/managed_area";
        auto elements = selection( m_doc, key);

        for(auto element : elements  )
        {
            XmlElementConfig type;
            Assign( type.id,  attribute_value(element, "id"));
            Assign(type.pointType,"MANAGED_AREA");
            type.key = key + "[@id=" + std::to_string(type.id) + "]";
            DEBUGPRINT(DEBUG_INFO,"DomainConfiguration: ManagedAreaConfig() MANAGED_AREA id[{0}], MANAGED_AREA key[{1}]",type.id, type.key);
            configs.push_back(type);
        }
    }

	/**
      @brief Read fire panels managed in this panel

      @return  return the fire panels managed by this panel
      */
    std::vector<uint64_t> GetPanelsManaged()
    {
		static std::vector<uint64_t> panels_managed;

		if(panels_managed.empty())
		{
		    std::string key = "/configuration/site/building/managed_area/fire_panel[@id=";
            auto elements = selection( m_doc, key);
            for(auto element : elements  )
            {
                XmlElementConfig type;
				Assign( type.id,  attribute_value(element, "id"));
				uint64_t id = static_cast<uint64_t>(type.id);
				panels_managed.push_back(id);
            }
		}

		return panels_managed;
    }
	
	/**
      @brief Read fire panels managed in this panel

      @return  return the fire panels managed by this panel
      */
    std::vector<uint64_t> GetFreList()
    {
		
		std::string configFile = Utility::GetActiveConfigLocation();
        configFile += "configuration.xml";
		tinyxml2::XMLDocument doc;
		static std::vector<uint64_t> frelist;
		
        if (Utility::IsSymlinkOrHardlink(configFile))
		{
            DEBUGPRINT(DEBUG_ERROR, "GetFreList: [{0}] is a Symlink or Hardlink", configFile);
            return frelist;        
		}

        doc.LoadFile(configFile.c_str());
		
		if(frelist.empty())
		{
		    std::string key = "/configuration/site/building/managed_area/fre_output[@id=";
            auto elements = selection( doc, key);
            for(auto element : elements  )
            {
                XmlElementConfig type;
				Assign( type.id,  attribute_value(element, "id"));
				uint64_t id = static_cast<uint64_t>(type.id);
				frelist.push_back(id);
            }
		}

		return frelist;
    }

    /**
      @brief Read zone config from XML file

      @param[in]    parent      parent key to process
      @param[out]   configs     table to store XML configuration in native c++ representation
      */
    void ZoneConfig( XmlElementConfig& parent , std::vector<XmlElementConfig>& configs )
    {
        auto elements = selection( m_doc, parent.key+"/[@zone=" );
        for(auto element : elements  )
        {
            XmlElementConfig type;
            Assign( type.id,  attribute_value(element, "zone_id"));
            if(type.id != 0)
            {
                if(element->FirstChildElement("zone_type"))
                {
                    Assign(type.pointType,element->FirstChildElement("zone_type")->GetText());
                }
                type.key = parent.key+"/zone[@zone_id="+std::to_string(static_cast<uint32_t>(type.id))+"]";
                configs.push_back(type);
            }
        }
    }

    /**
      @brief Read point config from XML file

      @param[in]    parent      parent key to process
      @param[out]   configs     table to store XML configuration in native c++ representation
      */
    void PointConfig( XmlElementConfig& parent, std::vector<XmlElementConfig>& configs, Dol::DOMAIN_OBJECT_TYPE *control_zone_type = nullptr)
    {
		DEBUGPRINT(DEBUG_INFO,"key is {}", parent.key);
        auto parentElements = selection( m_doc, parent.key);
        for(auto parentElement : parentElements  )
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }

            auto child = parentElement->FirstChildElement("zone_type");
            if(nullptr == child)
            {
                DEBUGPRINT(DEBUG_ERROR,"No parent type available");
                return;
            }
            Dol::DOMAIN_OBJECT_TYPE parentType;
            Assign(parentType, child );
            if(parentType == parent.pointType)
            {
                auto sibling = child->NextSiblingElement("point_ref");
                while(nullptr != sibling)
                {
                    if(Utility::TimeElapsed(40))
                    {
                       Utility::IamAlive();
                    }
                    
                    auto children = sibling->FirstChildElement();
                    XmlElementConfig type;
                    for( ;children && (strcmp( children->Name(), "point_id" ) == 0);children = children->NextSiblingElement())
                    {
                        if(Utility::TimeElapsed(40))
                        {
                            Utility::IamAlive();
                        }

                        Assign(type.id, children );
                        type.key = parent.key+"/point_ref[@point_id="+std::to_string(type.id)+"]"; // to think about it
                        children = children->NextSiblingElement();
                        if ( children && (strcmp( children->Name(), "point_type" ) == 0))
                        {
                            Assign(type.pointType, children);
                            DEBUGPRINT(DEBUG_INFO,"point Id {0:#x}  point type {1} name {2}",type.id, (uint32_t)type.pointType, std::string{children->GetText()});
                            configs.push_back(type);

                            if((nullptr != control_zone_type) && (*control_zone_type == Dol::DOMAIN_OBJECT_TYPE::INVALID))
                            {
                                if((type.pointType == Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT) || 
                                   (type.pointType == Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT))
                                {
                                    *control_zone_type = type.pointType;
                                }
                            }
                        }
                    }
                    sibling = sibling->NextSiblingElement("point_ref");
                }
                break; //As intended zone found
            }
        }
    }

    /**
      @brief parse of Aspiration Devices

      @param[in]    parent      parent key to process
      @param[out]   configs     table to store XML configuration in native c++ representation
      */
    std::list<uint64_t> ParseAspirationDevices(uint64_t id, std::string ASDname)
    {
        std::string key = "/configuration/site/GLSS_panel/modules/fire_loop_module/user_settings/loop[@id=";
        std::list<uint64_t> sensor_ref_list;
        bool found = false;
        for (int i = 1; i <= 4; i++) {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }

            auto loopKey = key + std::to_string(i) + "]/devices/module";
            auto modules = selection( m_doc, loopKey);
            for (auto module_lcl : modules)
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }

                auto elements = selection(module_lcl, ASDname);
                    for (auto element : elements)//NFXI-ASD22 has 2 elements
                    {
                        if(Utility::TimeElapsed(40))
                        {
                            Utility::IamAlive();
                        }

                        element = element->FirstChildElement();
                        found = false;
                        while(nullptr != element)
                        {
                            if(Utility::TimeElapsed(40))
                            {
                               Utility::IamAlive();
                            }
                            if(element->Name() && (std::string(element->Name()).find("fault_input") != std::string::npos))
                            {
                                auto val = attribute_value(element, "p4:id");
                                if(val == std::to_string(id))
                                {
                                    //it make it order independent in the loop
                                    found = true;
                                }
                            }
                            if(element->Name() && (std::string(element->Name()).find("sensor_ref") != std::string::npos))
                            {
                                char *endptr;
                                errno = 0;
                                auto text = element->GetText();
                                uint64_t id = strtoul(text, &endptr,10);
                                if(0 != id && errno == 0 && endptr != text)
                                {
                                    sensor_ref_list.push_back(id);
                                }

                            }
                            element = element->NextSiblingElement();
                        }
                        if(!found)
                        {
                            sensor_ref_list.clear();
                        }
                        else
                        {
                            return sensor_ref_list;;
                        }
                    }
            }
        }
        return sensor_ref_list;
    }
    /**
         @brief Read point config from XML file

         @param[out]  configs  table to store XML configuration in native c++ representation
         */
    void MangedAreaPointConfig( XmlElementConfig& parent, std::vector<XmlElementConfig>& configs )
    {
		DEBUGPRINT(DEBUG_INFO,"key is {}", parent.key+"/point_ref");
        auto elements = selection( m_doc, parent.key+"/point_ref" );
        for(auto element : elements  )
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            auto children = element->FirstChildElement();
            XmlElementConfig type;

            for( ;children && (strcmp( children->Name(), "point_id" ) == 0);children = children->NextSiblingElement())
            {
		if(Utility::TimeElapsed(40))
		{
		     Utility::IamAlive();
		}
                
                Assign(type.id, children );
                type.key = parent.key+"/point_ref[@point_id="+std::to_string(type.id)+"]"; // to think about it
                children = children->NextSiblingElement();
                if ( children && (strcmp( children->Name(), "point_type" ) == 0))
                {
                    Assign(type.pointType, children );
                    DEBUGPRINT(DEBUG_INFO,"point Id {0:#x}  point type {1} name {2}",type.id, (uint32_t)type.pointType, std::string{children->GetText()});
                    configs.push_back(type);
                }

            }
        }
    }

    /**
      @brief Read fire panel config from XML file

      @param[out]  configs  table to store XML configuration in native c++ representation
      */
    void FirePanelConfig( std::vector<XmlElementConfig>& configs )
    {
        std::string key = "/configuration/site/fire_panel[@panel_id=";
        
        auto elements = selection( m_doc, key);
        for(auto element : elements  )
        {
            XmlElementConfig type;
            Assign( type.id,  attribute_value(element, "panel_id"));

            Assign(type.pointType,"FIRE_PANEL");
            //type.key = key;
            type.key = key+std::to_string(static_cast<uint64_t>(type.id))+"]";
                        DEBUGPRINT(DEBUG_INFO,"DomainConfiguration: FirePanelConfig() fire_panel id[{0}], fire_panel key[{1}]",type.id, type.key);
            configs.push_back(type);
        }
    }

    /**
      @brief Read point config from XML file

      @param[in]    parent      parent key to process
      @param[out]   configs     table to store XML configuration in native c++ representation
      */
    void ModuleConfig( XmlElementConfig& parent, std::vector<XmlElementConfig>& configs )
    {
        std::string localKey = parent.key+"/modules";
        DEBUGPRINT(DEBUG_INFO,"ModuleConfig key is {}", localKey);
        auto elements = selection( m_doc, localKey);
        for(auto element : elements  )
        {
            if(Utility::TimeElapsed(40))
            {
                 Utility::IamAlive();
            }
            DEBUGPRINT(DEBUG_INFO,"DomainConfiguration: ModuleConfig()");

            XmlElementConfig type;
            auto children = element->FirstChildElement();
            for( ; children ;children = children->NextSiblingElement())
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                if(std::string{children->Name()}.find("_module") != std::string::npos)
                {
                    Assign(type.id, attribute_value(children, "id") );
                    Assign(type.pointType,children->Name());
                    type.key = localKey+"/"+children->Name()+"[@id="+std::to_string(static_cast<uint64_t>(type.id))+"]";
                    DEBUGPRINT(DEBUG_INFO,"DomainConfiguration: ModuleConfig() "
                            "name[{0}]\n, id[{1}]\n,  type.key[{2}]\n, type.pointType[{3}]\n, MODULE[{4}]\n",
                            std::string{children->Name()},
                            type.id,
                            type.key,
                            (uint32_t)type.pointType,
                            (uint32_t)Dol::DOMAIN_OBJECT_TYPE::MODULE);
                    configs.push_back(type);
                }

            }
        }
    }

    /**
      @brief physical Group config from XML file

      @param[in]    parent      parent key to process
      @param[out]   configs     table to store XML configuration in native c++ representation
      */
    void ModuleChildrenConfig( XmlElementConfig& parent, std::vector<XmlElementConfig>& configs )
    {
        DEBUGPRINT(DEBUG_INFO,"ModuleChildrenConfig key is {0}", parent.key);
        auto elements = selection( m_doc, parent.key );
        for(auto element : elements  )
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            auto children = element->FirstChildElement();
            DEBUGPRINT(DEBUG_INFO,"DomainConfigurationHandle: ModuleChildrenConfig() Find children[{0}]", children->Name());
            XmlElementConfig type;

            for( ;children ;children = children->NextSiblingElement())
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                if(m_physicalGroup.find(children->Name())!= m_physicalGroup.end())
                {	
                    Assign(type.id,  attribute_value(children, "id") );
                    type.key = parent.key+children->Name()+"/[@point_id="+std::to_string(type.id)+"]"; // to think about it
                    Assign(type.pointType, children->Name() );					
                    DEBUGPRINT(DEBUG_INFO,"get new point Id {0}  point type {1}  point name {2}",type.id, (uint32_t)type.pointType, children->Name());
                    configs.push_back(type);
                }

            }
        }
    }

    /**
      @brief loop config from XML file

      @param[in]    parent      parent key to process
      @param[out]   configs  table to store XML configuration in native c++ representation
      */
    void LoopConfig( XmlElementConfig& parent, std::vector<XmlElementConfig>& configs )
    {
        DEBUGPRINT(DEBUG_INFO,"loop key is {}", parent.key);
        auto elements = selection( m_doc, parent.key );
        for(auto element : elements  )
        {
            if(Utility::TimeElapsed(40))
            {
                 Utility::IamAlive();
            }
            auto children = element->FirstChildElement();
            DEBUGPRINT(DEBUG_INFO,"DomainConfigurationHandle: LoopConfig() Find children[{0}]", children->Name());
            XmlElementConfig type;

            for( ;children ;children = children->NextSiblingElement())
            {
                if(Utility::TimeElapsed(40))
                {
                      Utility::IamAlive();
                }
                if(strcmp(children->Name(),"loop") == 0)//if is equal to loop
                {
                    Assign(type.id,  attribute_value(children, "id") );
                    type.key = parent.key+children->Name()+"/[@id="+std::to_string(type.id)+"]"; // to think about it
                    Assign(type.pointType, children->Name() );
                    DEBUGPRINT(DEBUG_INFO,"get new loop Id {0}  point type {1}  point name {2}",type.id, (uint32_t)type.pointType, children->Name());
                    configs.push_back(type);
                }
            }
        }
    }

    uint64_t FindManagedAreaIdForAll(uint64_t pointId)
    {
        auto id = FindManagedAreaId(pointId);
        if(0 == id)
        {
            return FindManagedAreaIdForPointOrZone(pointId);
        }
        return id;
    }

    uint64_t FindManagedAreaId(uint64_t pointId)
    {
        std::string key = "/configuration/site/building/managed_area";
        auto elements = selection( m_doc, key );
        for(auto element : elements  )
        {
            uint64_t id = 0;
            if(Utility::TimeElapsed(40))
            {
                 Utility::IamAlive();
            }
            Assign( id,  attribute_value(element, "id"));
            auto children = element->FirstChildElement();
            for( ;children ;children = children->NextSiblingElement())
            {
                uint64_t childId;
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                Assign(childId,  attribute_value(children, "id") );
                if(pointId == childId)
                {
                    DEBUGPRINT(DEBUG_INFO,"DomainConfigurationHandle: FindManagedAreaId() Find some thing childId[{0}]  pointId[{1}]",childId, pointId);
                    return id;
                }
            }
        }
        return 0;
    }

    /**
      @brief Find the Parent DETECTION zone of any point inside

      @param[in]    uint64_t pointID      point id to find the parent
      @param[out]   ObjectReference  the ObjectReference of the parent DETECTION zone
      */
    Mol::DataType::ObjectReference FindParent(uint64_t PointID)
    {
        std::string key = "/configuration/site/building/managed_area";
        auto elements = selection( m_doc, key );
        Mol::DataType::ObjectReference local_point;

        int zoneID = -1;
        for(auto element : elements  )
        {
            uint64_t id = 0;
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            Assign( id,  attribute_value(element, "id"));
            auto children = element->FirstChildElement();
            for( ;children ;children = children->NextSiblingElement())
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                std::string name = children->Name();
                std::string attribute = attribute_value(children, "zone_id");
                zoneID = atoi( attribute.c_str() );
                if(name.find("zone") != std::string::npos)
                {
                    auto zone_children = children->FirstChildElement();
                    std::string zone_type = (nullptr != zone_children)?zone_children->Name():"";
                    std::string zone_name = (nullptr != zone_children)?zone_children->GetText():"";
                    if( (zone_type.find("type") != std::string::npos) && (zone_name.find("DETECTION") != std::string::npos))
                    {
                        element = zone_children->NextSiblingElement();
                        while(nullptr != element)
                        {
                            if(Utility::TimeElapsed(40))
                            {
                                Utility::IamAlive();
                            }
                            std::string point_ref = element->Name();
                            if((point_ref.find("point_ref") != std::string::npos))
                            {
                                auto point_id = element->FirstChildElement();
                                std::string id = (nullptr != point_id)?point_id->GetText():"";
                                if((id == std::to_string(PointID)) && zoneID > 0)
                                {

                                    return Mol::DataType::ObjectReference{static_cast<uint64_t>(zoneID),Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
                                }
                            }
                            element = element->NextSiblingElement();
                        }
                    }
                    DEBUGPRINT(DEBUG_INFO,"DomainConfigurationHandle: FindManagedAreaId() Find some thing childId[{0}]  pointId[{1}]",name, attribute);
                    //return id;
                }
            }
        }
        return Mol::DataType::ObjectReference{0,Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST};
    }

    /**
      @brief parse configuration file and create logical hierarchy in memory so that it can be used later for parents search
      @param[out]   LogicalHierarchy object holding the complete structure of the logical hierarchy
      */
    std::shared_ptr<LogicalHierarchy::Site> PopulateLogicalHierarchy()
    {
        std::string key = "/configuration/site/building";
        auto elements = selection( m_doc, key );
        uint64_t id = 0;
        Dol::DOMAIN_OBJECT_TYPE pointType;
        auto site = std::make_shared<LogicalHierarchy::Site>();
        for(auto element : elements  )//building 1 2 3 ...
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            Assign(id,  attribute_value(element, "id"));
            auto building = std::make_shared<LogicalHierarchy::Building>(id);
            if(!building)
            {
                DEBUGPRINT(DEBUG_INFO, "PopulateLogicalHierarchy error memory allocation");
                return site;
            }
            //lHierarchy.site.buildings.push_back(building);
            for(auto building_sibling = element->FirstChildElement();building_sibling ;building_sibling = building_sibling->NextSiblingElement())//building child
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                std::string name = building_sibling->Name();
                if (name.find("managed_area") != std::string::npos) //managed area 1 2 3 ..
                {
                    Assign(id,  attribute_value(building_sibling, "id"));
                    auto managedArea = std::make_shared<LogicalHierarchy::ManagedArea>(id);
                    if(!managedArea)
                    {
                        DEBUGPRINT(DEBUG_INFO, "PopulateLogicalHierarchy error memory allocation");
                        return site;
                    }
                    for(auto managed_children = building_sibling->FirstChildElement();managed_children ;managed_children = managed_children->NextSiblingElement())//
                    {
                        if(Utility::TimeElapsed(40))
                        {
                            Utility::IamAlive();
                        }
                        std::string name = managed_children->Name();
                        if (name.find("zone") != std::string::npos) //zone 1 2 3 ..
                        {
                            auto zone = std::make_shared<LogicalHierarchy::Zone>();
                            if(!zone)
                            {
                                DEBUGPRINT(DEBUG_INFO, "PopulateLogicalHierarchy error memory allocation");
                                return site;
                            }
                            std::string attribute = attribute_value(managed_children, "zone_id");
                            id = atoi(attribute.c_str());
                            auto sibling = managed_children->FirstChildElement();
                            while (nullptr != sibling)
                            {
                                if(Utility::TimeElapsed(40))
                                {
                                    Utility::IamAlive();
                                }
                                std::string zone_type = sibling->Name();
                                if(zone_type.find("type") != std::string::npos)
                                {
                                    std::string zone_name = sibling->GetText();
                                    if(!zone_name.empty())
                                    {
                                        pointType = Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;
                                        Assign(zone->type, zone_name.c_str());
                                        zone->id = id;
                                    }
                                }
                                auto children = sibling->FirstChildElement();
                                XmlElementConfig type;
                                for (; children && (strcmp(children->Name(), "point_id") == 0); children = children->NextSiblingElement())
                                {
                                    if(Utility::TimeElapsed(40))
                                    {
                                       Utility::IamAlive();
                                    }
                                    Assign(id, children);
                                    children = children->NextSiblingElement();
                                    if (children && (strcmp(children->Name(), "point_type") == 0))
                                    {
                                        pointType = Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;
                                        Assign(pointType, children);
                                        auto point = std::make_shared<Mol::DataType::ObjectReference>(id, pointType);
                                        if(zone->logicalPoints)
                                        {
                                            zone->logicalPoints->push_back(point);
                                        }
                                    }
                                }
                                sibling = sibling->NextSiblingElement();
                            }
                            if(managedArea->zones)
                            {
                                managedArea->zones->push_back(zone);
                            }
                        }
                        else if(name.find("point_ref") != std::string::npos) //for FIELD DEVICE
                        {
                            auto id_element = managed_children->FirstChildElement("point_id");
                            auto type_element = managed_children->FirstChildElement("point_type");
                            if(id_element && type_element)
                            {
                                Assign(id, id_element);
                                pointType = Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;
                                Assign(pointType, type_element);
                                auto point = std::make_shared<Mol::DataType::ObjectReference>(id, pointType);
                                if(managedArea->physicalPoints)
                                {
                                    managedArea->physicalPoints->push_back(point);
                                }
                            }
                        }
                        else
                        {
                            pointType = Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;
                            Assign(pointType, name.c_str());
                            std::string idStr;
                            Assign( idStr,  attribute_value(managed_children, "id"));
                            auto point = std::make_shared<Mol::DataType::ObjectReference>(std::stoll(idStr), pointType);
                            if(managedArea->physicalPoints)
                            {
                                managedArea->physicalPoints->push_back(point);
                            }
                        }
                    }
                    if(building->managedAreas)
                    {
                        building->managedAreas->push_back(managedArea);
                    }

                }
            }
            if(site->buildings)
            {
                site->buildings->push_back(building);
            }
        }
        return site;
    }

    /**
    * @brief return all parents for a given child
    * @param child to search the parents
    * @retval list of parents
    */
    std::list<Mol::DataType::ObjectReference> GetAllParents(const Mol::DataType::ObjectReference child)
    {
        std::list<Mol::DataType::ObjectReference> parents;
        auto logicalData = GetLogicalHierarchyInstance();
        auto site = logicalData.site;
        if(site && site->buildings)
        {
            for(auto building : *site->buildings)
            {
                if(Utility::TimeElapsed(40))
                {
                   Utility::IamAlive();
                }
                if(building)
                {
                    if(building->managedAreas)
                    {
                        for(auto managedArea : *building->managedAreas)
                        {
                            if(Utility::TimeElapsed(40))
                            {
                               Utility::IamAlive();
                            }
                            if(managedArea)
                            {
                                if(Mol::DataType::ObjectReference(managedArea->id, managedArea->type) == child)
                                {
                                    parents.clear();
                                    //@NOTE building we my need in the future
                                    //parents.push_back(Mol::DataType::ObjectReference(building->id, building->type));
                                    return parents;
                                }
                                parents.push_back(Mol::DataType::ObjectReference(managedArea->id, managedArea->type));
                                if(managedArea->zones)
                                {
                                    for(auto zone : *managedArea->zones)
                                    {
                                        if(Utility::TimeElapsed(40))
                                        {
                                            Utility::IamAlive();
                                        }
                                        if(zone)
                                        {
                                            if(Mol::DataType::ObjectReference(zone->id, zone->type) == child)
                                            {
                                                parents.clear();
                                                //@NOTE building we my need in the future
                                                //parents.push_back(Mol::DataType::ObjectReference(building->id, building->type));
                                                parents.push_back(Mol::DataType::ObjectReference(managedArea->id, managedArea->type));
                                                return parents;
                                            }
                                            if(zone->logicalPoints)
                                            {
                                                for(auto point : *zone->logicalPoints)
                                                {
                                                    if(Utility::TimeElapsed(40))
                                                    {
                                                         Utility::IamAlive();
                                                    }
                                                    if(point && child == *point)
                                                    {
                                                        parents.clear();
                                                        //@NOTE building we my need in the future
                                                        //parents.push_back(Mol::DataType::ObjectReference(building->id, building->type));
                                                        parents.push_back(Mol::DataType::ObjectReference(managedArea->id, managedArea->type));
                                                        parents.push_back(Mol::DataType::ObjectReference(zone->id, zone->type));
                                                        return parents;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if(managedArea->physicalPoints)
                                {
                                    for(auto physicalPoint : *managedArea->physicalPoints)
                                    {
                                        if(Utility::TimeElapsed(40))
                                        {
                                            Utility::IamAlive();
                                        }
                                        if(physicalPoint && child == *physicalPoint)
                                        {
                                            parents.clear();
                                            //@NOTE building we my need in the future
                                            //parents.push_back(Mol::DataType::ObjectReference(building->id, building->type));
                                            parents.push_back(Mol::DataType::ObjectReference(managedArea->id, managedArea->type));
                                            return parents;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        parents.clear();
        return parents;
    }

    uint64_t FindManagedAreaIdForPointOrZone(uint64_t id)
    {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
	    }
                    
        std::vector<XmlElementConfig> managedAreaConfigs;
        std::vector<XmlElementConfig> zoneConfigs;
        std::vector<XmlElementConfig> pointConfigs;
        ManagedAreaConfig(managedAreaConfigs);
        for (auto mgdAreaCfg : managedAreaConfigs)
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            zoneConfigs.clear();
            ZoneConfig(mgdAreaCfg,zoneConfigs);
            for(auto zcfg: zoneConfigs)
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                if(zcfg.id == id)
                {
                    DEBUGPRINT(DEBUG_INFO,"DomainConfigurationHandle: FindManagedAreaIdForPoint() Found managed area ManagedAreaId[{0}] zone[{1}]",mgdAreaCfg.id,id);
                    return mgdAreaCfg.id;
                }
                pointConfigs.clear();
                PointConfig(zcfg,pointConfigs);
                for(auto ptCfg: pointConfigs)
                {
                    if(Utility::TimeElapsed(40))
                    {
                         Utility::IamAlive();
                    }
                    if(ptCfg.id == id)
                    {
                        DEBUGPRINT(DEBUG_INFO,"DomainConfigurationHandle: FindManagedAreaIdForPoint() Found managed area ManagedAreaId[{0}] point[{1}]",mgdAreaCfg.id,id);
                        return mgdAreaCfg.id;
                    }
                }
            }
        }
        return 0;
    }

    Dol::DOMAIN_OBJECT_TYPE FindModuleObjectType(uint64_t pointId)
    {
        std::string key = "/configuration/site/fire_panel";
        std::string val;
        auto elements = selection(m_doc, key);
        uint64_t moduleID = 0;
        Dol::DOMAIN_OBJECT_TYPE moduleType = Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;      //!< DOL point type
        for (auto element : elements)
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            auto modules = element->FirstChildElement();
            for (auto module_lcl : modules)
            {
                if(Utility::TimeElapsed(40))
                {
                    Utility::IamAlive();
                }
                if (std::string { module_lcl->Name() }.find("_module") != std::string::npos)
                {
                    Assign(moduleID, attribute_value(module_lcl, "id"));
                    if(pointId == moduleID)
                    {
                        Assign(moduleType,module_lcl->Name());
                        return moduleType;
                    }
                }
            }
        }
        return moduleType;
    }

    /*
     * isFaultHandledByReset read EVENT_RESET_MODE element form config file, ID3k panel support only fault cleared by reset command
    * @retval bool false if EVENT_RESET_MODE is INSPIRE_RESET_MODE_TYPE, true if  LEGACY_NOTIFIER_HBS_MODE_TYPE(the one to match the ID3K behavior).
    */
    bool isFaultHandledByReset( )
    {
        //avoid reading form xml file multiple time for all points in the config file
        if(resetEventModeFromConfigFile.empty())
        {
            auto element = find_element(m_doc, "/configuration/site/" + std::string { EVENT_RESET_MODE });
            resetEventModeFromConfigFile = std::string(INSPIRE_RESET_MODE);//default mode
            if (nullptr != element)
            {
                const char* value = element->GetText();
                //if null value or random string keep default mode
                if (nullptr != value &&
                        (std::string(value) == std::string(INSPIRE_RESET_MODE)
                        || std::string(value) == std::string(LEGACY_RESET_MODE)))
                {
                    resetEventModeFromConfigFile = value;
                }
            }
        }
        //if not legacy, certainly inspire mode
        m_faultHandledByReset = (resetEventModeFromConfigFile == std::string(LEGACY_RESET_MODE)) ? true : false;
        return m_faultHandledByReset;
    }

#ifdef UT_TARGET
    /**
      @brief Set Fault Handling By Reset
      @param state the new state to set
      */
    void SetFaultHandledByReset(bool state)
    {
        resetEventModeFromConfigFile = state? std::string(LEGACY_RESET_MODE) : std::string(INSPIRE_RESET_MODE);
    }
#endif

    bool IsUEIndicatorActivationOnConfirmation()
    {
        auto elements = selection( m_doc, "/configuration/site/ue_activation" );
        for(auto element : elements  )
        {
            std::string operation;
            Assign(operation, element );
            DEBUGPRINT(DEBUG_INFO,"IsUEIndicatorActivationOnConfirmation operation {}",operation);
            if(operation.compare("confirmation") == 0)
            {
                return true;
            }
            else if(operation.compare("activation") == 0)
            {
                return false;
            }

        }
        // default operation ue indicator on confirmation
        return true;
    }

    /**
      @brief Get number of loops currently configured in panel
      @param[out] numberOfLoops number of loops configured
      @param[out] numberOfRepeatPanels number of repeaters
      */
    void GetNumberOfLoops(uint8_t &numberOfLoops, uint8_t &numberOfRepeaters)
    {
        numberOfLoops = 0u;
        numberOfRepeaters  = 0u;

        auto elements = selection(m_doc, "/configuration/site/GLSS_panel/modules/fire_loop_module");
        for(auto element : elements)
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
	    	auto user_setting = element->FirstChildElement("user_settings");
	    	if(nullptr ==user_setting)
			{
		    	continue;
			}
			auto loop=user_setting->FirstChildElement("loop");
            while(nullptr!=loop)
            {
                if(Utility::TimeElapsed(40))
                {
                   Utility::IamAlive();
                }
                auto devices = loop->FirstChildElement("devices");
                for(auto modules : devices)
                {
                    if(Utility::TimeElapsed(40))
                    {
                        Utility::IamAlive();
                    }
                    if(0 == std::string(modules->FirstChildElement("type_code")->GetText()).compare( "NRX_REP"))
                    {
                        numberOfRepeaters++;
                    }
                }
                numberOfLoops++;
				loop=loop->NextSiblingElement("loop");
            }
        }
    }

    /**
      @brief Get current language from config file
      @retval the value found in the "language" element if present, if not empty string
      */
    std::string GetCurrentLanguage() const
    {
        auto elements = selection(m_doc, "/configuration/site/GLSS_panel/hmi_configuration/local_override/locale");

        for(auto element : elements)
        {
            if(element->FirstChildElement("language"))
            {
                return(element->FirstChildElement("language")->GetText());
            }
        }
         return "";
    }

    /**
      @brief Get Configuration Version from config file
      @retval the value found in the "configuration_version" element if present, if not empty string
      */
    std::string GetConfigurationVersion() const
    {
        auto configuration = m_doc.FirstChildElement();

        if ((nullptr != configuration) && (std::string(configuration->Name()) == "configuration"))
        {
            return attribute_value(configuration, "configuration_version");;
        }
        return "";
    }

    /**
      @brief Read point config from XML file

      @param[in]    parent      parent key to process
      @param[out]   configs     table to store XML configuration in native c++ representation
      */
    uint64_t GetCPUModuleIDFromPanelID( uint64_t nodeID )
    {
        std::string localKey = "configuration/site/fire_panel[@panel_id=" + std::to_string(nodeID)+"]" + "/modules";
        DEBUGPRINT(DEBUG_INFO,"ModuleConfig key is {}", localKey);
        auto elements = selection( m_doc, localKey);
        uint64_t cpuID = 0;
        for(auto element : elements  )
        {
            if(Utility::TimeElapsed(40))
            {
                Utility::IamAlive();
            }
            XmlElementConfig type;
            auto children = element->FirstChildElement();
            for( ; children ;children = children->NextSiblingElement())
            {
                if(Utility::TimeElapsed(40))
                {
                   Utility::IamAlive();
                }
                if(std::string{children->Name()}.find("cpu") != std::string::npos)//main_cpu_module
                {
                    Assign(cpuID, attribute_value(children, "id") );
                    break;
                }

            }
        }
        return cpuID;
    }
private:
    //we should never edit this from external world, only in UT
    std::string resetEventModeFromConfigFile = "";
    bool m_faultHandledByReset = false;
    std::set<std::string> m_physicalGroup{"fare_output","fre_output"
                                            ,"backup_power_source","battery_set","external_PSU"
                                            ,"aux_dc_output", "serial_port","common_fire_output"
                                            ,"common_fault_output", "keysafe", "charger"};

protected:

    tinyxml2::XMLDocument& m_doc = DomainConfigurationHandle::GetInstance().GetHandle();
    LogicalHierarchy& logicalHierarchy = DomainConfiguration::GetLogicalHierarchyInstance();

    //as par the schema:
    //https://bitbucket.honeywell.com/projects/FCONF/repos/configfiles/browse/Fire_Domain_Types.xsd#1335
    //https://bitbucket.honeywell.com/projects/FCONF/repos/configfiles/browse/MainCPU_Module/FirePanel.xsd#248
    static constexpr const char* INSPIRE_RESET_MODE = "INSPIRE_RESET_MODE_TYPE";
    static constexpr const char* LEGACY_RESET_MODE = "LEGACY_NOTIFIER_HBS_MODE_TYPE";
    static constexpr const char* EVENT_RESET_MODE = "event_reset_mode";
};
}

#endif //FIRESYSTEM_DOMIAN_CONFIGURATION_HANDLE_H
