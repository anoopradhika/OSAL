/*****************************************************************//**
 *
 * @file    ZoneStateSetup.h
 * @brief   Disaptch mol events
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_ZONE_HANDLER_SETUP_H
#define FIRESYSTEM_STATE_ZONE_HANDLER_SETUP_H

// framework
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "StateObjectFactory/ZoneStateObjectList.h"
#include "Helper/SateHandlerDowncastAdapter.h"


#include <chrono>
#include <ctime>

namespace fireSystemState {

using ZoneStateCaster = Platform::CastAndCall< SateHandlerDowncastAdapter,  Dol::Entities::Zone, ZoneStateObjectTypes >;

/**
* @brief Prepare and setup Entities
*/

auto ZoneStatePrepare = [](auto stateHandler)
{
    ZoneStateCaster::Do<Dol::DomainObject>(stateHandler,PrepareOperation{});
};

auto ZoneSignalSetup = [](auto stateHandler)
{
    ZoneStateCaster::Do<Dol::DomainObject>(stateHandler,SetupSignalOperation{});
};


} // end namespace fireSystemState

#endif //FIRESYSTEM_STATE_ZONE_HANDLER_SETUP_H
