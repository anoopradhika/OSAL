/*****************************************************************//**
 *
 * @file    ModuleStateSetup.h
 * @brief   Disaptch mol events
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_MODULE_HANDLER_SETUP_H
#define FIRESYSTEM_STATE_MODULE_HANDLER_SETUP_H

// framework
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "StateObjectFactory/ModuleStateObjectList.h"
#include "Helper/SateHandlerDowncastAdapter.h"

#include <ctime>

namespace fireSystemState {

using ModuleStateCaster = Platform::CastAndCall< SateHandlerDowncastAdapter,  Dol::Entities::Module, ModuleStateObjectTypes >;

/**
* @brief Prepare and setup Entities
*/

auto ModuleStatePrepare = [](auto stateHandler)
{
    ModuleStateCaster::Do<Dol::DomainObject>(stateHandler,PrepareOperation{});
};

auto ModuleSignalSetup = [](auto stateHandler)
{
    ModuleStateCaster::Do<Dol::DomainObject>(stateHandler,SetupSignalOperation{});
};


} // end namespace fireSystemState

#endif //FIRESYSTEM_STATE_MODULE_HANDLER_SETUP_H
