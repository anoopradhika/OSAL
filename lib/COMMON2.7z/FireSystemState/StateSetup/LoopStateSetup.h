/*****************************************************************//**
 *
 * @file    LoopStateSetup.h
 * @brief   Disaptch Loop and operations
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_Loop_HANDLER_SETUP_H
#define FIRESYSTEM_STATE_Loop_HANDLER_SETUP_H

// framework
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "StateObjectFactory/LoopStateObjectList.h"
#include "Helper/SateHandlerDowncastAdapter.h"
#include "StateSetup/SetupOperations.h"


#include <ctime>

namespace fireSystemState {


// using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;
using LoopStateCaster = Platform::CastAndCall< SateHandlerDowncastAdapter,  Dol::Entities::Loop, LoopStateObjectTypes >;

/**
* @brief Prepare and setup Entities
*/
auto LoopStatePrepare = [](auto stateHandler)
{
    LoopStateCaster::Do<Dol::DomainObject>(stateHandler,PrepareOperation{});
};

auto LoopSignalSetup = [](auto stateHandler)
{
    LoopStateCaster::Do<Dol::DomainObject>(stateHandler,SetupSignalOperation{});
};

} // end namespace fireSystemState

#endif //FIRESYSTEM_STATE_Loop_HANDLER_SETUP_H
