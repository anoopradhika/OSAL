/*****************************************************************//**
 *
 * @file    SetupOperations.h
 * @brief   Disaptch mol events
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_HANDLER_SETUP_H
#define FIRESYSTEM_STATE_HANDLER_SETUP_H

// framework


namespace fireSystemState {

/**
* @brief it find the registered Entities for the event and forward
* the event to it
*/
struct PrepareOperation {
    PrepareOperation() = default;
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> point)
    {
        point->Prepare();
    }
};

struct SetupSignalOperation {
    SetupSignalOperation() = default;
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> point)
    {
        point->SetupSignal();
    }
};
} // end namespace fireSystemState

#endif //FIRESYSTEM_STATE_HANDLER_SETUP_H
