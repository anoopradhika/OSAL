/******************************************************************************//**
*
* @file   MessageCommunicator.h
* @brief  Class provides the interface Mol
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#include "Signal/Signal.h"
#include "Communicator/Communicator.hpp"

#ifndef FIRESYSTEM_MESSAGE_COMMUNICATOR_H
#define FIRESYSTEM_MESSAGE_COMMUNICATOR_H

namespace fireSystemState
{

/**
* @brief Communicator to send/subscribe Mol
*/
class MessageCommunicator
{
public:
    MessageCommunicator() = default;
    ~MessageCommunicator() = default;

    /**
    * @brief Interface to send Mol event
    * @param[in] event: Event to send
    * @param[in] address: Application to send
    * @param[in] internalMessage: if false and address PROC_ADDRESS::CMCAPP, send to module
    *                             else send internally to moudle
    * @param[in] dnm: If 0 then broadcast to all modules else send to specific module
    */
    template<typename EventType>
    void SendEvent(EventType event, PROC_ADDRESS address, bool internalMessage = false, uint64_t dnm = 0)
    {
        if(internalMessage)
        {
            m_communicator.m_event.Send(event,address,0);
        }
        else if(dnm > 0)
        {
            m_communicator.m_event.Send(event,address,dnm);
        }
        else
        {
            auto source = event->GetSource();
            m_communicator.m_event.Send(event,address,GetDestinationId(source));
        }
        DEBUGPRINT(DEBUG_INFO, "event is send");
    }

    /**
    * @brief Interface to send Mol command
    * @param[in] command: Command to send
    * @param[in] address: Application to send
    * @param[in] internalMessage: if false and address PROC_ADDRESS::CMCAPP, send to module
    *                             else send internally to moudle
    * @param[in] dnm: If 0 then broadcast to all modules else send to specific module
    */
    template<typename CommandType>
    void SendCommand(CommandType command, PROC_ADDRESS address, bool internalMessage = false, uint64_t dnm = 0)
    {
        if(internalMessage)
        {
            m_communicator.m_command.Send(command,address,0);
        }
        else if(dnm > 0)
        {
            m_communicator.m_command.Send(command,address,dnm);
        }
        else
        {
            auto source = command->GetCommandTarget();
            m_communicator.m_command.Send(command,address,GetDestinationId(source));
        }
        DEBUGPRINT(DEBUG_INFO, "command is send");
    }

    /**
    * @brief Interface to send Mol request
    * @param[in] request: request to send
    * @param[in] address: Application to send
    * @param[in] internalMessage: if false and address PROC_ADDRESS::CMCAPP, send to module
    *                             else send internally to moudle
    * @param[in] dnm: If 0 then broadcast to all modules else send to specific module
    */
    template<typename RequestType>
    void SendRequest(RequestType request, PROC_ADDRESS address, bool internalMessage = false, uint64_t dnm = 0)
    {
        if(internalMessage)
        {
            m_communicator.m_request.Send(request,address,0);
        }
        else if(dnm > 0)
        {
             m_communicator.m_request.Send(request,address,dnm);
        }
        else
        {
            auto source = request->GetSourceTarget();
            m_communicator.m_request.Send(request,address,GetDestinationId(source));
        }
        DEBUGPRINT(DEBUG_INFO, "request is send");
    }

	/**
    * @brief Interface to send Mol response
    * @param[in] request: Response to send
    * @param[in] address: Application to send
    * @param[in] internalMessage: if false and address PROC_ADDRESS::CMCAPP, send to module
    *                             else send internally to moudle
    * @param[in] dnm: If 0 then broadcast to all modules else send to specific module
    */
    template<typename ResponseType>
    void SendResponse(ResponseType response, PROC_ADDRESS address, bool internalMessage = false, uint64_t dnm = 0)
    {
        if(internalMessage)
        {
            m_communicator.m_response.Send(response,address,0);
        }
        else if(dnm > 0)
        {
            m_communicator.m_response.Send(response,address,dnm);
        }
        else
        {
		    auto source = response->GetTarget();
    		auto deviceUniqueId = Mol::DeviceUniqueID{source.GetObjectId()};
	    	uint64_t dnmNum = deviceUniqueId.GetDNM64Bit();
            m_communicator.m_response.Send(response,address,dnmNum);
        }
        DEBUGPRINT(DEBUG_INFO, "response is send");
	}

    /**
    * @brief Interface to send Domain Object element
    * @param[in] dol: Domain Object element to send
    * @param[in] address: Application to send
    */
    template<typename DolType>
    void SendDol(DolType dol, PROC_ADDRESS address)
    {
            m_communicator.m_dol.Send(dol,address);
    }

#ifdef UT_TARGET
    //we don't need this functions normally in the other apps
    auto GetListOfEventSignals()
    {
        return  m_signal.EventSignalExtended;
    }

    auto GetListOfCommandSignals()
    {
        return  m_signal.CommandSignalExtended;
    }

    void ClearAllSignals()
    {
        m_signal.EventSignalExtended.clear();
        m_signal.CommandSignalExtended.clear();
    }
#endif

protected:
    Signal& m_signal = Signal::GetSignal();
    Platform::Communicator m_communicator;

    /**
    * @brief Destination ID for sending message
    * @param[in] reference: source reference
    * @return  DNM based on reference
    */
    uint64_t GetDestinationId(Mol::DataType::ObjectReference& reference)
    {
        reference.PrepareDeviceUniqueID();
        if(reference.GetDNM() != 0)
        {
            DEBUGPRINT(DEBUG_INFO, "FSS: GetDestinationId dnm id {}",reference.GetDNM64Bit());
            return reference.GetDNM64Bit();
        }
        else
        {
            auto multicastId = Mol::DeviceUniqueID{reference.GetObjectId()};
            DEBUGPRINT(DEBUG_INFO, "FSS: GetDestinationId MC id {}",multicastId.GetModuleMultCastId());
            return multicastId.GetModuleMultCastId();
        }
    }

};
}
#endif //FIRESYSTEM_MESSAGE_COMMUNICATOR_H
