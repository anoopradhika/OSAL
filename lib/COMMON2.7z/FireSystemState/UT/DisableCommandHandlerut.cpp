#include "gmock/gmock.h"
#include "DisableCommandHandlerut.h"
#include "Utility.h"
#include "StateHandler/FaultInputStateHandler.h"
#include "StateHandler/FaultInputStateHandler.h"
#include "StateHandler/FPOStateHandler.h"
#include "StateHandler/AlarmZoneStateHandler.h"
#include "StateHandler/AlarmDeviceStateHandler.h"
#include "StateHandler/AlarmOutputStateHandler.h"
#include "StateHandler/ControlOutputStateHandler.h"
#include "StateHandler/ControlZoneStateHandler.h"
#include "StateHandler/FireRoutingOutputStateHandler.h"
#include "StateHandler/DetectionZoneStateHandler.h"

#include "StateHandler/SerialCommsStateHandler.h"
#include "StateHandler/FieldDeviceStateHandler.h"
#include "StateHandler/BatteryPointStateHandler.h"
#include "StateHandler/ChargerPointStateHandler.h"
#include "StateHandler/ControlInputStateHandler.h"
#include "StateHandler/FaultRoutingOutputStateHandler.h"
#include "StateHandler/TechnicalAlarmInputStateHandler.h"
#include "StateHandler/BaseFireDetectionPointStateHandler.h"

TEST(DisableCommandHandlerTest, SetupTest)
{
	Utility::RunShellCommand( "mkdir /config/config1/");
	Utility::RunShellCommand( "touch /config/config1/active");
	Utility::RunShellCommand( "cp ../LIBRARIES/COMMON/FireSystemState/UT/configuration.xml /config/config1/configuration.xml");
	Utility::RunShellCommand( "sync");


    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};
    fireSystemState::DisableCommandHandlerTest<fireSystemState::FaultInputStateHandler>  testobject(handler);
    testobject.RcvReceiveDisableCommand();
    testobject.RcvReceiveEnableCommand();

	fireSystemState::FPOStateHandler handler1{72058719336268548, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::FPOStateHandler>  testobject1(handler1);
	testobject1.RcvReceiveDisableCommand();
	testobject1.RcvReceiveEnableCommand();

	fireSystemState::AlarmZoneStateHandler handler2{72058719336268549, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::AlarmZoneStateHandler>  testobject2(handler2);
	testobject2.RcvReceiveDisableCommand();
	testobject2.RcvReceiveEnableCommand();


	fireSystemState::AlarmDeviceStateHandler handler3{72058719336268550, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::AlarmDeviceStateHandler>  testobject3(handler3);
	testobject3.RcvReceiveDisableCommand();
	testobject3.RcvReceiveEnableCommand();

	fireSystemState::AlarmOutputStateHandler handler4{72058719336268551, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::AlarmOutputStateHandler>  testobject4(handler4);
	testobject4.RcvReceiveDisableCommand();
	testobject4.RcvReceiveEnableCommand();

	fireSystemState::ControlZoneStateHandler handler5{72058719336268552, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::ControlZoneStateHandler>  testobject5(handler5);
	testobject5.RcvReceiveDisableCommand();
	testobject5.RcvReceiveEnableCommand();

	fireSystemState::FireRoutingOutputStateHandler handler6{72058719336268553, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::FireRoutingOutputStateHandler>  testobject6(handler6);
	testobject6.RcvReceiveDisableCommand();
	testobject6.RcvReceiveEnableCommand();

	fireSystemState::ControlOutputStateHandler handler7{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::ControlOutputStateHandler>  testobject7(handler7);
	testobject7.RcvReceiveDisableCommand();
	testobject7.RcvReceiveEnableCommand();

	fireSystemState::SerialCommsStateHandler handler8{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::SerialCommsStateHandler>  testobject8(handler8);
	//testobject8.RcvReceiveDisableCommand();
	//testobject8.RcvReceiveEnableCommand();

	fireSystemState::FieldDeviceStateHandler handler9{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::FieldDeviceStateHandler>  testobject9(handler9);
	testobject9.RcvReceiveDisableCommand();
	testobject9.RcvReceiveEnableCommand();

	fireSystemState::BatteryPointStateHandler handler10{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::BatteryPointStateHandler>  testobject10(handler10);
	testobject10.RcvReceiveDisableCommand();
	testobject10.RcvReceiveEnableCommand();

	fireSystemState::ChargerPointStateHandler handler11{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::ChargerPointStateHandler>  testobject11(handler11);
	testobject11.RcvReceiveDisableCommand();
	testobject11.RcvReceiveEnableCommand();

	fireSystemState::ControlInputStateHandler handler12{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::ControlInputStateHandler>  testobject12(handler12);
	testobject12.RcvReceiveDisableCommand();
	testobject12.RcvReceiveEnableCommand();

	fireSystemState::DetectionZoneStateHandler handler13{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::DetectionZoneStateHandler>  testobject13(handler13);
	testobject13.RcvReceiveDisableCommand();
	testobject13.RcvReceiveEnableCommand();

	fireSystemState::FaultRoutingOutputStateHandler handler14{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::FaultRoutingOutputStateHandler>  testobject14(handler14);
	testobject14.RcvReceiveDisableCommand();
	testobject14.RcvReceiveEnableCommand();

	fireSystemState::TechnicalAlarmInputStateHandler handler15{72058719336268554, config};
	fireSystemState::DisableCommandHandlerTest<fireSystemState::TechnicalAlarmInputStateHandler>  testobject15(handler15);
	testobject15.RcvReceiveDisableCommand();
	testobject15.RcvReceiveEnableCommand();

}


