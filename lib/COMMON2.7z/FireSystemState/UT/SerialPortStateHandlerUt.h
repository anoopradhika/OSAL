#ifndef SERIAL_PORT_STATE_HANDLER_UT_H
#define SERIAL_PORT_STATE_HANDLER_UT_H

#include "StateHandler/SerialPortStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class SerialPortStateHandlerTest : public SerialPortStateHandler
    {
    public:
        SerialPortStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            SerialPortStateHandler(id, element)
        {
        }
        ~SerialPortStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvDisablementEvent()
		{
			auto disableEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
			disableEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(disableEvent, 0, PROC_ADDRESS::END_OF_LIST);

			disableEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
			disableEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);

			ReceiveDisablementEvent(disableEvent, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvActivationEvent()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationEventNoFDA()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationEventDeactivateNoFDA()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::CMCAPP);
		}

        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }


    };
}

#endif //SERIAL_PORT_STATE_HANDLER_UT_H
