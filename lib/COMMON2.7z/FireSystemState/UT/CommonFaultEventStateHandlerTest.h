/******************************************************************************//**
* @file CommonFaultEventStateHandlerTest.h
* @brief Test case verify CommonFaultEventStateHandler Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef UT_COMMON_FAULT_EVENT_STATE_HANDLER_H
#define UT_COMMON_FAULT_EVENT_STATE_HANDLER_H

#include "StateHandler/CommonFaultEventStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DummyStateHandler.h"
#include "Mol/Events/DisablementEvent.h"
#include "Helper/FSHelper.h"
#include "StateHandler/FPOStateHandler.h"
#include "StateHandler/LoopStateHandler.h"
#include "StateHandler/ModuleStateHandler.h"
#include "StateHandler/FirePanelStateHandler.h"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/SerialPortStateHandler.h"
#include "StateHandler/ControlInputStateHandler.h"


namespace fireSystemState
{
    template<typename HANDLER>
    class CommonFaultEventStateHandlerTest : public fireSystemState::CommonFaultEventStateHandler<HANDLER>
    {
    public:
        using NAME = fireSystemState::CommonFaultEventStateHandler<HANDLER>;
        CommonFaultEventStateHandlerTest(HANDLER handler):
            CommonFaultEventStateHandler<HANDLER>(handler)
        {
        }
        ~CommonFaultEventStateHandlerTest() = default;

        bool SetupSignalCommonTestHandledNotByReset()
        {
            auto reference = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::ID,fireSystemState::DummyStateHandler::myType};
            NAME::SetupSignalCommon();
            auto list = CommonFaultEventStateHandler<HANDLER>::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if((category == Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED) || (category == Mol::Event::EVENT_CATEGORY::TROUBLE))
                {
                    if( ( (objref != reference) && (objref != CommonFaultEventStateHandler<HANDLER>::GetmyPanelObjectRef()) ))
                    {
                        return false;
                    }
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 2);
        }

        bool SetupSignalCommonTestHandledByReset()
        {
            auto reference = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::ID,fireSystemState::DummyStateHandler::myType};
            NAME::SetupSignalCommon();
            auto list = CommonFaultEventStateHandler<HANDLER>::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if( category == Mol::Event::EVENT_CATEGORY::TROUBLE)
                {
                        return (objref == reference);
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 1);
        }

        bool SetGetFaultTest()
        {
            NAME::SetFault(true);
            bool truetest = NAME::IsFault();
            NAME::SetFault(false);
            bool falstest = !NAME::IsFault();
            return (truetest && falstest);
        }

        bool SendFaultEventTest()
        {
            //nothing to test here, other class likeMessageCommunicator can test send events function
            auto faultEvent = std::make_shared<Mol::Event::FaultEvent>();
            NAME::SendFaultEvent(faultEvent);
            auto faultClearedEvent = std::make_shared<Mol::Event::FaultClearedEvent>();
            NAME::SendFaultClearedEvent(faultClearedEvent);
            return true;
        }

        bool GetmyPanelObjectRefTest()
        {
            return (CommonFaultEventStateHandler<HANDLER>::m_handler.myPanelObjectRef == NAME::GetmyPanelObjectRef());
        }

        bool GetmyObjectRefTest()
        {
            return (CommonFaultEventStateHandler<HANDLER>::m_handler.myObjectRef == NAME::GetmyObjectRef());
        }

        bool ReceiveFaultEventTestIgnoreFDAEvents()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            NAME::ReceiveFaultEventUT(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::IGNOR_INTERNAL_EVENT);
        }

        bool ReceiveFaultEventTest()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            NAME::ReceiveFaultEventUT(event, 1, PROC_ADDRESS::MODULE_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::NO_ERROR);
        }

        bool ReceiveFaultClearedEventTestIgnoreFDAEvents()
        {
            auto event = std::make_shared < Mol::Event::FaultClearedEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            NAME::ReceiveFaultEventUT(event, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::IGNOR_INTERNAL_EVENT);
        }

        bool ReceiveFaultClearedEventTest()
        {
            auto clearEvent = std::make_shared < Mol::Event::FaultClearedEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            clearEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            NAME::ReceiveFaultEventUT(clearEvent, 0, PROC_ADDRESS::MODULE_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::NO_ERROR);
        }

        bool ReceiveFaultEventTestINullPtr()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event = nullptr;
            NAME::ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::NULL_FAULT_EVENT);
        }

        bool ReceiveFaultClearedEventTestINullPtr()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event = nullptr;
            NAME::ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::NULL_FAULT_EVENT);
        }

        bool ReceiveResetCommandIncorrectCommandTest()
        {
            auto command = std::make_shared<Mol::Command::Deactivate>();
            NAME::ReceiveResetCommand(command, 0, PROC_ADDRESS::MODULE_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::NULL_RESET_CMD);
        }

        bool ReceiveResetCommandCorrectCommandTest()
        {
            auto command = std::make_shared < Mol::Command::Reset > (Mol::Command::RESET_TYPE_CODE::GENERAL);
            NAME::ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return (NAME::currentErrorCode == NAME::ERROR_CODE::NO_ERROR);
        }

    };

}
#endif //UT_COMMON_FAULT_EVENT_STATE_HANDLER_H
