#ifndef FPO_STATE_UT_H
#define FPO_STATE_UT_H

#include "Helper/FSHelper.h"
#include "StateHandler/FPOStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FPOStateHandlerTest : public FPOStateHandler
    {
    public:
        FPOStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FPOStateHandler(id, element)
        {
        }
        ~FPOStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
			SendActivate();
			SendDeactivate();
		}

		void RcvFunctionEnbleEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::FIRE_PROTECTION);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::FIRE_PROTECTION);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationCmd()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDeActivationCmd()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvDeActivationCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationEvent()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationEventDeactivate()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvInformationEvent()
		{
			auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::RECEIVED_CONFIRMATION_SIGNAL);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvInformationEventReset()
		{
			auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::CONFIRMATION_SIGNAL_RESET);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvInformationEventNoConfirmation()
		{
			auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::CONFIRMATION_NOT_RECEIVED);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}
    };
}
#endif //FPO_STATE_UT_H
