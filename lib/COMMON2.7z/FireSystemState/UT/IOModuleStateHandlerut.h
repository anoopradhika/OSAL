#ifndef IOMODULE_STATEHANDLER_UT_H
#define IOMODULE_STATEHANDLER_UT_H


#include "StateHandler/IOModuleStateHandler.h"
#include "StateHandler/ModuleStateHandler.h"
#include "StateHandler/NetworkModuleStateHandler.h"
#include "StateHandler/FAREFREModuleStateHandler.h"
#include "StateHandler/FATFBFModuleStateHandler.h"
//#include "StateHandler/BuildingStateHandler.h"
#include "StateHandler/CPUModuleStateHandler.h"
#include "StateHandler/SerialCommsStateHandler.h"
#include "StateHandler/ChargerModuleStateHandler.h"
#include "StateHandler/LoopModuleStateHandler.h"
#include "StateHandler/AuxDCOutputPointStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class IOModuleStateHandlerTest : public IOModuleStateHandler
	{
    public:
    	IOModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		IOModuleStateHandler(id, element)
        {
        }

        ~IOModuleStateHandlerTest() override = default;

    };
}
#endif //IOMODULE_STATEHANDLER_UT_H

#ifndef MODULE_STATEHANDLER_UT_H
#define MODULE_STATEHANDLER_UT_H
namespace fireSystemState
{
    class ModuleStateHandlerTest : public ModuleStateHandler<Dol::Entities::IOModule>
    {
    public:
    	ModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		ModuleStateHandler(id, element)
        {
        }

    	~ModuleStateHandlerTest() override = default;

    	void SetupTest()
    	{
    		Prepare();
    		SetupSignal();
    	 }

    	void RevInformationEvent()
    	{
    		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
    		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

    	}


    };

        class ModuleStateHandlerloopTest : public ModuleStateHandler<Dol::Entities::LoopModule>
        {
        public:
        	ModuleStateHandlerloopTest(const Dol::DomainObjectID id, XmlElementConfig element):
        		ModuleStateHandler(id, element)
            {
            }

        	~ModuleStateHandlerloopTest() override = default;

        	void SetupTest()
        	{
        		Prepare();
        		SetupSignal();
        	 }

        	void RevInformationEvent()
        	{
        		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
        		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

        	}


        };
    		class ModuleStateHandlercpuTest : public ModuleStateHandler<Dol::Entities::CPUModule>
            {
            public:
            	ModuleStateHandlercpuTest(const Dol::DomainObjectID id, XmlElementConfig element):
            		ModuleStateHandler(id, element)
                {
                }

            	~ModuleStateHandlercpuTest() override = default;

            	void SetupTest()
            	{
            		Prepare();
            		SetupSignal();
            	 }

            	void RevInformationEvent()
            	{
            		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
            		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

            	}


            };

    		class ModuleStateHandlerchargerTest : public ModuleStateHandler<Dol::Entities::ChargerModule>
    		{
    		    public:
    		      	ModuleStateHandlerchargerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		      		ModuleStateHandler(id, element)
    		         {
    		         }

    		      	~ModuleStateHandlerchargerTest() override = default;

    		        	void SetupTest()
    		        	{
    		        		Prepare();
    		        		SetupSignal();
    		        	 }

    		        	void RevInformationEvent()
    		        	{
    		        		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
    		        		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

    		        	}


    	   };

    	    class ModuleStateHandlerFareTest : public ModuleStateHandler<Dol::Entities::FAREFREModule>
    	    {
    	    public:
    	    	ModuleStateHandlerFareTest(const Dol::DomainObjectID id, XmlElementConfig element):
    	    		ModuleStateHandler(id, element)
    	        {
    	        }

    	    	~ModuleStateHandlerFareTest() override = default;

    	    	void SetupTest()
    	    	{
    	    		Prepare();
    	    		SetupSignal();
    	    	 }

    	    	void RevInformationEvent()
    	    	{
    	    		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
    	    		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

    	    	}


    	    };

    	    class ModuleStateHandlerfatTest : public ModuleStateHandler<Dol::Entities::FATFBFModule>
    	    {
    	    public:
    	    	ModuleStateHandlerfatTest(const Dol::DomainObjectID id, XmlElementConfig element):
    	    		ModuleStateHandler(id, element)
    	        {
    	        }

    	    	~ModuleStateHandlerfatTest() override = default;

    	    	void SetupTest()
    	    	{
    	    		Prepare();
    	    		SetupSignal();
    	    	 }

    	    	void RevInformationEvent()
    	    	{
    	    		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
    	    		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

    	    	}


    	    };

    	    class ModuleStateHandlernetworkTest : public ModuleStateHandler<Dol::Entities::NetworkModule>
    	    {
    	    public:
    	    	ModuleStateHandlernetworkTest(const Dol::DomainObjectID id, XmlElementConfig element):
    	    		ModuleStateHandler(id, element)
    	        {
    	        }

    	    	~ModuleStateHandlernetworkTest() override = default;

    	    	void SetupTest()
    	    	{
    	    		Prepare();
    	    		SetupSignal();
    	    	 }

    	    	void RevInformationEvent()
    	    	{
    	    		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
    	    		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

    	    	}


    	    };

    	    class ModuleStateHandlerserialTest : public ModuleStateHandler<Dol::Entities::SerialComms>
    	    {
    	    public:
    	    	ModuleStateHandlerserialTest(const Dol::DomainObjectID id, XmlElementConfig element):
    	    		ModuleStateHandler(id, element)
    	        {
    	        }

    	    	~ModuleStateHandlerserialTest() override = default;

    	    	void SetupTest()
    	    	{
    	    		Prepare();
    	    		SetupSignal();
    	    	 }

    	    	void RevInformationEvent()
    	    	{
    	    		auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::AUDITLOG_WARNING);
    	    		ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

    	    	}


    	    };


}
#endif //MODULE_STATEHANDLER_UT_H

#ifndef NETWORKMODULE_STATEHANDLER_UT_H
#define NETWORKMODULE_STATEHANDLER_UT_H

namespace fireSystemState
{
    class NetworkModuleStateHandlerTest : public NetworkModuleStateHandler
    {
    public:
    	NetworkModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		NetworkModuleStateHandler(id, element)
        {
        }

        ~NetworkModuleStateHandlerTest() override = default;

    };
}

#endif //NETWORKMODULE_STATEHANDLER_UT_H


#ifndef FAREFREMODULE_STATEHANDLER_UT_H
#define FAREFREMODULE_STATEHANDLER_UT_H

namespace fireSystemState
{
    class FAREFREModuleStateHandlerTest : public FAREFREModuleStateHandler
    {
    public:
    	FAREFREModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		FAREFREModuleStateHandler(id, element)
        {
        }

        ~FAREFREModuleStateHandlerTest() override = default;

    };
}

#endif //FAREFREMODULE_STATEHANDLER_UT_H



#ifndef FATFBFMODULE_STATEHANDLER_UT_H
#define FATFBFMODULE_STATEHANDLER_UT_H

namespace fireSystemState
{
    class FATFBFModuleStateHandlerTest : public FATFBFModuleStateHandler
    {
    public:
    	FATFBFModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		FATFBFModuleStateHandler(id, element)
        {
        }

        ~FATFBFModuleStateHandlerTest() override = default;

    };
}

#endif //FATFBFMODULE_STATEHANDLER_UT_H


#ifndef CPUMODULE_STATEHANDLER_UT_H
#define CPUMODULE_STATEHANDLER_UT_H

namespace fireSystemState
{
    class CPUModuleStateHandlerTest : public CPUModuleStateHandler
    {
    public:
    	CPUModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		CPUModuleStateHandler(id, element)
        {
        }

        ~CPUModuleStateHandlerTest() override = default;

    };
}

#endif //CPUMODULE_STATEHANDLER_UT_H


#ifndef SERIALCOMMS_STATEHANDLER_UT_H
#define SERIALCOMMS_STATEHANDLER_UT_H

namespace fireSystemState
{
    class SerialCommsStateHandlerTest : public SerialCommsStateHandler
    {
    public:
    	SerialCommsStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		SerialCommsStateHandler(id, element)
        {
        }

        ~SerialCommsStateHandlerTest() override = default;

    };
}

#endif //SERIALCOMMS_STATEHANDLER_UT_H




#ifndef CHARGERMODULE_STATEHANDLER_UT_H
#define CHARGERMODULE_STATEHANDLER_UT_H

namespace fireSystemState
{
    class ChargerModuleStateHandlerTest : public ChargerModuleStateHandler
    {
    public:
    	ChargerModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		ChargerModuleStateHandler(id, element)
        {
        }

        ~ChargerModuleStateHandlerTest() override = default;

    };
}

#endif //CHARGERMODULE_STATEHANDLER_UT_H


#ifndef LOOPMODULE_STATEHANDLER_UT_H
#define LOOPMODULE_STATEHANDLER_UT_H
namespace fireSystemState
{
    class LoopModuleStateHandlerTest : public LoopModuleStateHandler
    {
    public:
    	LoopModuleStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		LoopModuleStateHandler(id, element)
        {
        }

    	~LoopModuleStateHandlerTest() override = default;

    	void SetupTest()
    	{
    		Prepare();
    		SetupSignal();
    	 }

    };
}
#endif //LOOPMODULE_STATEHANDLER_UT_H



#ifndef AUZDCOUTPUT_POINT_STATEHANDLER_UT_H
#define AUZDCOUTPUT_POINT_STATEHANDLER_UT_H
namespace fireSystemState
{
    class AuxDCOutputPointStateHandlerTest : public AuxDCOutputPointStateHandler
    {
    public:
    	AuxDCOutputPointStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		AuxDCOutputPointStateHandler(id, element)
        {
        }

    	~AuxDCOutputPointStateHandlerTest() override = default;

    	void SetupTest()
    	{
    		SetupSignal();
    	 }

    };
}
#endif //AUZDCOUTPUT_POINT_STATEHANDLER_UT_H


//#ifndef BUILDING_STATEHANDLER_UT_H
//#define BUILDING_STATEHANDLER_UT_H
//namespace fireSystemState
//{
//    class BuildingStateHandlerTest : public BuildingStateHandler
//    {
//    public:
//    	BuildingStateHandlerTest(const Dol::DomainObjectID id):
//    		BuildingStateHandler(id)
//        {
//        }
//
//    	~BuildingStateHandlerTest() override = default;
//
//    	void SetupTest()
//    	{
//    		Prepare();
//
//    	 }
//
//    };
//}
//#endif //BUILDING_STATEHANDLER_UT_H

