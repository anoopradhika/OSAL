#include "gmock/gmock.h"
#include "FaultInputStateHandlerTest.h"
#include "Utility.h"

TEST(FaultInputStateHandlerUT, SetupSignalTest)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.SetupSignalTest());
}

TEST(FaultInputStateHandlerUT, ReceiveDisablementEventTest)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveDisablementEventTest());
}

TEST(FaultInputStateHandlerUT, ReceiveDisablementEventTestInvalidEvent)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveDisablementEventTestInvalidEvent());
}

TEST(FaultInputStateHandlerUT, ReceiveFaultEventTestInvalidProccessID)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveFaultEventTestInvalidProccessID());
}

TEST(FaultInputStateHandlerUT, ReceiveFaultEventTestInvalidFaultCode)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveFaultEventTestInvalidFaultCode());
}

TEST(FaultInputStateHandlerUT, ReceiveFaultEventTestValidFualtState)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveFaultEventTestValidFualtState());
}

TEST(FaultInputStateHandlerUT, ReceiveFaultEventTestValidFualClearedtState)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveFaultEventTestValidFualClearedtState());
}

TEST(FaultInputStateHandlerUT, ReceiveResetCommandTestInvalidProcessID)
{
    const Dol::DomainObjectID id = 0x100010200000001;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveResetCommandTestInvalidProcessID());
}

TEST(FaultInputStateHandlerUT, ReceiveResetCommandTestCorrectState)
{
    const Dol::DomainObjectID id = 0;
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FaultInputStateHandlerTest testobject{id, config};
    EXPECT_TRUE(testobject.ReceiveResetCommandTestCorrectState());
}
TEST(FaultInputStateHandlerUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FaultInputStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();

}

