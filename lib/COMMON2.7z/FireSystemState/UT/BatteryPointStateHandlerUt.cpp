#include "gmock/gmock.h"
#include "BatteryPointStateHandlerUt.h"
#include "Utility.h"

TEST(BatteryPointStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::BatteryPointStateHandlerTest testobject(10,config);
    testobject.Setup_Test();

    testobject.RcvDisablementEvent();
    testobject.RcvDisablementEventEnabled();
    uint64_t pointID = 0x100010200000001;
    fireSystemState::BatteryPointStateHandlerTest testobject1{pointID,config};
    EXPECT_TRUE(testobject1.ReceiveFaultEventTestInvalidProccessID());
    fireSystemState::BatteryPointStateHandlerTest testobject2{pointID,config};
    EXPECT_TRUE(testobject2.ReceiveFaultEventTestInvalidFaultCode());
    fireSystemState::BatteryPointStateHandlerTest testobject3{pointID,config};
    EXPECT_TRUE(testobject3.ReceiveFaultEventTestValidFualtState());
    fireSystemState::BatteryPointStateHandlerTest testobject4{pointID,config};
    EXPECT_TRUE(testobject4.ReceiveFaultEventTestValidFualClearedtState());
    fireSystemState::BatteryPointStateHandlerTest testobject5{pointID,config};
    EXPECT_TRUE(testobject5.ReceiveResetCommandTestInvalidProcessID());
    fireSystemState::BatteryPointStateHandlerTest testobject6{pointID,config};
}

TEST(BatteryPointStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::BatteryPointStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
	
}
