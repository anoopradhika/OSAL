#ifndef LOOP_STATE_UT_H
#define LOOP_STATE_UT_H

#include "StateHandler/LoopStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class LoopStateHandlerTest : public LoopStateHandler
    {
    public:
        LoopStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            LoopStateHandler(id, element)
        {
        }
        LoopStateHandlerTest(XmlElementConfig element):
            LoopStateHandler(element)
        {
        }
        ~LoopStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}
    };
}
#endif //LOOP_STATE_UT_H
