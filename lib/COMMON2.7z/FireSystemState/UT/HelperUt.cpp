/******************************************************************************//**
 *
 * @file   HelperUt.cpp
 * @brief  test FSHelper functions
 *
 * @copyright Copyright 2021 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#include "gmock/gmock.h"
#include "Helper/FSHelper.h"
#include "Mol/Events/EventTypeList.h"
#include "Mol/Commands/Command.h"
#include "Mol/DataType/ObjectReference.h"
#include "DOL/DomainObject/ObjectReference.h"

TEST( FS_HELPER, CreateEventFromEvent )
{
    auto inputEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);

    // add some labels to see copy of labels work
    Dol::Label l1;
    l1.SetLabel("Test1");
    inputEvent->AddLabel(l1);
    l1.SetLabel("Test2");
    inputEvent->AddLabel(l1);

    Mol::DataType::ObjectReference oref1( 0x12345678, Dol::DOMAIN_OBJECT_TYPE::BUILDING);
    inputEvent->AddParent( oref1 );

    Mol::DataType::ObjectReference oref2( 0x87654321, Dol::DOMAIN_OBJECT_TYPE::SITE);
    inputEvent->AddParent( oref2 );

    auto outputEvent = fireSystemState::CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>( inputEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);

    auto parents = outputEvent->GetParents();
    auto labels = outputEvent->GetLabels();

    // check if we have copied labels and parents
    // first check number of labels and parents
    EXPECT_EQ( parents.size(), static_cast<uint32_t>(2) );
    EXPECT_EQ( labels.size(), static_cast<uint32_t>(2) );

    uint8_t checkFlags = 0x00;

    // check we have copied content of labels
    for ( auto& label: outputEvent->GetLabels() )
    {
        if ( label.GetLabel() == "Test1" ) { checkFlags |= 0x01; }
        if ( label.GetLabel() == "Test2" ) { checkFlags |= 0x02; }
    }

    // check we have copied content of parents
    for ( auto& parent: outputEvent->GetParents() )
    {
        if ( parent.GetObjectId() == 0x12345678 ) { checkFlags |= 0x04; }
        if ( parent.GetObjectId() == 0x87654321 ) { checkFlags |= 0x08; }
    }

    // check we found all requested objects
    EXPECT_EQ( checkFlags, 0x0f );
}

