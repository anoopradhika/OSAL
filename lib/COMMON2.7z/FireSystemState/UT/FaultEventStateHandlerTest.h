/******************************************************************************//**
* @file FaultEventStateHandlerTest.h
* @brief Test case verify FaultEventStateHandler Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef UT_FAULT_EVENT_STATE_HANDLER_H_
#define UT_FAULT_EVENT_STATE_HANDLER_H_

#include "StateHandler/FaultEventStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DummyStateHandler.h"

namespace fireSystemState
{
    template<typename HANDLER>
    class FaultEventStateHandlerTest : public fireSystemState::FaultEventStateHandler<HANDLER>
    {
    public:
        using NAME = fireSystemState::FaultEventStateHandlerTest<HANDLER>;
        FaultEventStateHandlerTest(DummyStateHandler handler):
            FaultEventStateHandler<HANDLER>(handler)
        {
        }
        ~FaultEventStateHandlerTest() = default;

        bool SetupSignalTestNotByReset()
        {
            FaultEventStateHandler<HANDLER>::SetupSignal();
            return (TestResetCommand() && TestEventNotByReset());
        }

        bool SetupSignalTestByReset()
        {
            FaultEventStateHandler<HANDLER>::SetupSignal();
            return (TestResetCommand() && TestEventByReset());
        }

        bool TestResetCommand()
        {
            auto mangedAreaRef = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::myManagedAreaID,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
            auto list = FaultEventStateHandler<HANDLER>::m_handler.GetListOfCommandSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Command::COMMAND_CATEGORY category = keyVal.first.m_category;
                if(category == Mol::Command::COMMAND_CATEGORY::RESET)
                {
                    ;//just need to check if it is subscribing to reset event here
                    auto size = FaultEventStateHandler<HANDLER>::m_parentReferences.size();
                    return ((objref == mangedAreaRef) && (size > 0));
                }
                else
                {
                    ;//Don't care about others they are tested in other UTs
                }
            }
            return false;
        }

        bool TestEventNotByReset()
        {
            auto reference = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::ID,fireSystemState::DummyStateHandler::myType};
            auto list = FaultEventStateHandler<HANDLER>::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if((category == Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED) || (category == Mol::Event::EVENT_CATEGORY::TROUBLE))
                {
                    auto myPanelObjRef =  FaultEventStateHandler<HANDLER>::GetmyPanelObjectRef();
                    if( ( (objref != reference) && (objref != myPanelObjRef) ))
                    {
                        return false;
                    }
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 2);
        }

        bool TestEventByReset()
        {
            auto reference = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::ID,fireSystemState::DummyStateHandler::myType};
            auto list = FaultEventStateHandler<HANDLER>::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if( category == Mol::Event::EVENT_CATEGORY::TROUBLE)
                {
                        return (objref == reference);
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 1);
        }

    };
}
#endif //UT_FAULT_EVENT_STATE_HANDLER_H_
