#include "gmock/gmock.h"
#include "AspirationDeviceHandlerUT.h"
#include "StateHandler/FaultInputStateHandler.h"
#include "Utility.h"

TEST(AspirationDeviceHandlerUT, PrepareTest)
{
    Utility::RunShellCommand( "mkdir /config/config1/");
    Utility::RunShellCommand( "touch /config/config1/active");
    Utility::RunShellCommand( "cp ../../../LIBRARIES/COMMON/FireSystemState/UT/configuration.xml /config/config1/configuration.xml");
    Utility::RunShellCommand( "sync");
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler1{72058719336268547, config};//ASD12
    fireSystemState::FaultInputStateHandler handler2{72058719336268545, config};//ASD11
    fireSystemState::FaultInputStateHandler handler3{72058719336268549, config};//ASD22-1
    fireSystemState::FaultInputStateHandler handler4{72058719336268550, config};//ASD22-2
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest1(handler1);
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest2(handler2);
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest3(handler3);
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest4(handler4);
    EXPECT_TRUE(objectEnderTest1.PrepareTest());
    EXPECT_TRUE(objectEnderTest2.PrepareTest());
    EXPECT_TRUE(objectEnderTest3.PrepareTest());
    EXPECT_TRUE(objectEnderTest4.PrepareTest());

}


TEST(AspirationDeviceHandlerUT, SetupSignalTest)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};//ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.SetupSignalTest());
}

TEST(AspirationDeviceHandlerUT, isAspirationDeviceFaultTestTest)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};//ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.isAspirationDeviceFaultTest());
}

TEST(AspirationDeviceHandlerUT, ReceiveFaultClearedEventTestInvalidEvent)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};//ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest(handler);
    objectEnderTest.RcvReceiveFaultEvent();
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTestInvalidEvent());
}

TEST(AspirationDeviceHandlerUT, ReceiveFaultClearedEventTestInvalidProcessID)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};//ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTestInvalidProcessID());
}

TEST(AspirationDeviceHandlerUT, ReceiveFaultClearedEventTestValidFaultCode)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};//ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTestValidFaultCode());
}

TEST(AspirationDeviceHandlerUT, ReceiveFaultClearedEventTestValid)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};//ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTestValid());
}

TEST(AspirationDeviceHandlerUT, FindParentTest)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultInputStateHandler handler1{72058719336268547, config}; //ASD12
    fireSystemState::AspirationDeviceHandlerUT<fireSystemState::FaultInputStateHandler> objectEnderTest1(handler1);
    objectEnderTest1.m_handler.FindParent(72058719336268547);
}