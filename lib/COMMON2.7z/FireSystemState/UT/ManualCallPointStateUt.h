#ifndef MANUAL_CALL_POINT_STATE_UT_H
#define MANUAL_CALL_POINT_STATE_UT_H

#include "StateHandler/ManualCallPointStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class ManualCallPointStateHandlerTest : public ManualCallPointStateHandler
    {
    public:
        ManualCallPointStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            ManualCallPointStateHandler(id, element)
        {
        }
        ~ManualCallPointStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>();
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event,0,PROC_ADDRESS::MODULE_APP);
		}

		void RcvTestEvent()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvTestEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void ReceiveResetCommandTestIncorrect()
		{
			auto command = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::GENERAL);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA;
			auto managedarea = 1;
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(managedarea, type);
			command->SetCommandTarget(target);
			ReceiveResetCommand(command, 0,PROC_ADDRESS::MODULE_APP);
		}

		void RcvAlarmEvent()
		{
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058702156398848, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{1101,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent(parent);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::CMCAPP);
		}
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }

        void RcvReceiveFaultEvent()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 10, PROC_ADDRESS::FIRE_DOMAIN_APP);
        }
        void RcvReceiveTestEvent()
        {
            uint64_t point_id = 72058693549555713;
            auto event = std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT);
            event->SetSource(source);
            this->ReceiveTestEvent(event, 10, PROC_ADDRESS::FIRE_DOMAIN_APP);
            this->IsEventFromParent(source);
            this->GetmyPanelObjectRef();
        }

    };

}
#endif //MANUAL_CALL_POINT_STATE_UT_H
