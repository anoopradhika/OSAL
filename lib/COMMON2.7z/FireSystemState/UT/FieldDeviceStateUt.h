#ifndef FIELD_DEVICE_STATE_UT_H
#define FIELD_DEVICE_STATE_UT_H

#include "StateHandler/FieldDeviceStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FieldDeviceStateHandlerTest : public FieldDeviceStateHandler
    {
    public:
        FieldDeviceStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FieldDeviceStateHandler(id, element)
        {
        }
        ~FieldDeviceStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvDisablementEventNoFDAEnabled()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event, 0, PROC_ADDRESS::END_OF_LIST);
		}
    };
}
#endif //FIELD_DEVICE_STATE_UT_H
