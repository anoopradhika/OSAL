#include "gmock/gmock.h"
#include "Utility.h"
#include "StateMachine/AlarmPointStateMachine.h"
#include "StateHandler/AlarmDeviceStateHandler.h"
#include "StateHandler/AlarmOutputStateHandler.h"
#include "StateMachine/AlarmZoneStateMachine.h"
#include "StateHandler/AlarmZoneStateHandler.h"
#include "StateMachine/DetectionZoneStateMachine.h"
#include "StateHandler/DetectionZoneStateHandler.h"
#include "StateHandler/FaultInputStateHandler.h"
#include "StateMachine/FaultInputStateMachine.h"
#include "StateHandler/FireRoutingOutputStateHandler.h"
#include "StateMachine/ConfirmationStateMachine.h"
#include "StateHandler/ControlInputStateHandler.h" 
#include "StateMachine/ControlInputPointStateMachine.h"
#include "StateHandler/TechnicalAlarmInputStateHandler.h"
#include "StateMachine/TechAlarmPointStateMachine.h"
#include "StateMachine/FirePointStateMachine.h"
#include "StateHandler/BaseFireDetectionPointStateHandler.h"
#include "StateHandler/LoopStateHandler.h"
#include "StateHandler/ModuleStateHandler.h"
#include "StateHandler/LoopModuleStateHandler.h"
#include "StateHandler/FirePanelStateHandler.h"
#include "UT/DummyStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

TEST(AlarmPointStateMachine, AlarmDeviceStateHandlerTest)
{

	char source[PATH_MAX];
	realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
	std::string active = Utility::GetActiveConfigLocation();
	std::string distination = active.append("configuration.xml");
	Utility::RemoveFile(distination);
	Utility::CopyFile(source, distination);

	fireSystemState::XmlElementConfig config;
	config.id = 0x100010000000000; //72058693549555712
	config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
	config.key = "/configuration/site/building/managed_area[@id=1]/zone";

	fireSystemState::AlarmDeviceStateHandler handler{72058719336268547, config};
	fireSystemState::AlarmPointStateMachine<fireSystemState::AlarmDeviceStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::DAY_MODE_ACTIVATED);
	testobject.SwitchToOperation(event);
	testobject.NoResoundEnable();
	testobject.operator()();
	testobject.GetmyPanelObjectRef();
	testobject.ProcessClearRemoteEvents();

	auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	testobject.m_handler.m_updaterStateMachine.process_event(eventFaultEventCode);
}

TEST(AlarmPointStateMachine, AlarmOutputStateHandlerTest)
{

	char source[PATH_MAX];
	realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
	std::string active = Utility::GetActiveConfigLocation();
	std::string distination = active.append("configuration.xml");
	Utility::RemoveFile(distination);
	Utility::CopyFile(source, distination);

	fireSystemState::XmlElementConfig config;
	config.id = 0x100010000000000; //72058693549555712
	config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
	config.key = "/configuration/site/building/managed_area[@id=1]/zone";

	fireSystemState::AlarmOutputStateHandler handler{72058719336268547, config};
	fireSystemState::AlarmPointStateMachine<fireSystemState::AlarmOutputStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::AlarmSignalEvent>(1);
	auto event1 = std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::ALARMDEVICE_ENABLE);
	testobject.SendAlarmSignal(event);
	testobject.SwitchToOperation(event1);
	testobject.NoResoundEnable();
	testobject.CheckForAactivation(event);
	testobject.CheckForDeactivation(event);
	testobject.Enable();
	testobject.GetOptNoResound();
	testobject.operator()();
	testobject.GetmyPanelObjectRef();
	testobject.ProcessClearRemoteEvents();

	auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventAlarmSignalEvent = std::make_shared<Mol::Event::AlarmSignalEvent>(20);
	auto eventUserOperationEventCode = std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::DELAY_EXTENDED);

	testobject.m_handler.m_updaterStateMachine.process_event(eventFaultEventCode);
	testobject.m_handler.m_updaterStateMachine.process_event(eventAlarmSignalEvent);
	testobject.m_handler.m_updaterStateMachine.process_event(eventUserOperationEventCode);
}

TEST(AlarmZoneStateMachine, AlaramZoneStateTest)
{

	char source[PATH_MAX];
	realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
	std::string active = Utility::GetActiveConfigLocation();
	std::string distination = active.append("configuration.xml");
	Utility::RemoveFile(distination);
	Utility::CopyFile(source, distination);

	fireSystemState::XmlElementConfig config;
	config.id = 0x100010000000000; //72058693549555712
	config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
	config.key = "/configuration/site/building/managed_area[@id=1]/zone";

	fireSystemState::AlarmZoneStateHandler handler{72058719336268547, config};
	fireSystemState::AlarmZoneStateMachine<fireSystemState::AlarmZoneStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::ALARMDEVICE_ENABLE);
	testobject.NoResoundEnable();
	testobject.SwitchToOperation(event);
	auto event1 = std::make_shared<Mol::Event::AlarmSignalEvent>(1);
	testobject.CheckForDeactivation(event1);
	testobject.AlarmeZoneNeedResound(event);
	testobject.AlarmeZoneNeedEvacuation(event);
	testobject.AlarmeZoneNeedSilence(event);
	testobject.ForwardEvacuationoffSignalAction(event);
	testobject.AreChildrenDeactivated(event1);
	testobject.NoResoundEnable();
//	testobject.SwitchToSilenceOperationAfterEvacuationAction(event);

	auto eventAlarmSignalEvent = std::make_shared<Mol::Event::AlarmSignalEvent>(20);
	auto eventFunctionCodeEvent = std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
	auto eventUserOperationEventCode = std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::DAY_MODE_ACTIVATED);

	testobject.m_handler.m_updaterStateMachine.process_event(eventAlarmSignalEvent);
	testobject.m_handler.m_updaterStateMachine.process_event(eventFunctionCodeEvent);
	testobject.m_handler.m_updaterStateMachine.process_event(eventUserOperationEventCode);
}

TEST(AlaramZoneStateMachine, AlarmZoneStateHandlerTest)
{
	fireSystemState::AlarmZoneStateHandler handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::AlarmZoneStateMachine<fireSystemState::AlarmZoneStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
	testobject.Enable(event);
}

TEST(TechAlarmPointStateMachineTest, TechnicalAlarmInputStateHandlerTest)
{
	fireSystemState::TechnicalAlarmInputStateHandler handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::TechAlarmPointStateMachine<fireSystemState::TechnicalAlarmInputStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
	testobject.Enable(event);
	testobject.Disable(event);
	testobject.IsEventFromPoint(event);
	testobject.IsEventFromParent(event);
}

TEST(ControlInputPointStateMachineTest, ControlInputStateHandlerTest)
{
	fireSystemState::ControlInputStateHandler handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::ControlInputPointStateMachine<fireSystemState::ControlInputStateHandler> testobject(handler);

	auto event = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
	testobject.Deactivate();
	testobject.Enable(event);
	testobject.Disable(event);
	testobject.ClearDesiblementWhenReachable();
	testobject.ClearInputChangeEventWhenReachable();
}

TEST(DetectionZoneStateMachineTest, DetectionZoneStateHandlerTest)
{
	fireSystemState::DetectionZoneStateHandler handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::DetectionZoneStateMachine<fireSystemState::DetectionZoneStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
	testobject.ProcessAlarm(event);
	testobject.ProcessTestAlarm(event);
	testobject.IsFireAlarmNotDetected(event);
	testobject.ProcessReturnFromAlarm(event);
	testobject.IsZoneReturnFromAlarmCall(event);
	testobject.IsItMine(event);
	testobject.ClearDesiblementWhenReachable();
	testobject.ClearFireWhenReachable();
	testobject.ClearTestWhenReachable();
	testobject.OriginatedRemotePanelLost();
}

TEST(ConfirmationStateMachineTest, FireRoutingOutputStateHandlerTest)
{
	fireSystemState::FireRoutingOutputStateHandler handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::ConfirmationStateMachine<fireSystemState::FireRoutingOutputStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::FIRMWARE_UPDATE_STATUS);
	testobject.ClearConfirmation(event);
	testobject.InformationUpdate(event);
	testobject.Confirmed(event);
	testobject.CheckResetConfirmation(event);
}

TEST(FaultInputStateMachineTest, FaultInputStateHandlerTest)
{
	fireSystemState::FaultInputStateHandler handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::FaultInputStateMachine<fireSystemState::FaultInputStateHandler> testobject(handler);
	auto event = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
	testobject.CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
	testobject.Enable(event);
	testobject.Disable(event);
	testobject.IsitMine(event);
	testobject.ClearDesiblementWhenReachable();
}

TEST(FirePointStateMachine, FireSensorStateHandlerTest)
{
	auto eventAlarmEventCode = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
	auto eventDisablementEventCode = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
	auto eventTestOperationEventCode = std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);

	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensor, fireSystemState::FireSensorStateHandler> handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::FirePointStateMachine<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensor, fireSystemState::FireSensorStateHandler>> testobject(handler);

	testobject.ProcessTestEnd(eventTestOperationEventCode);
	testobject.SelfEnablement(eventDisablementEventCode);
	testobject.ProcessTestAlarm(eventAlarmEventCode);
	testobject.ProcessTestStart(eventTestOperationEventCode);
	testobject.GetmyPanelObjectRef();
	testobject.ClearFireWhenReachable();
	testobject.ClearTestWhenReachable();
	testobject.ProcessReturnFromAlarm(eventAlarmEventCode);
	testobject.ClearDesiblementWhenReachable();
	testobject.Enable(eventDisablementEventCode);
	testobject.Disable(eventDisablementEventCode);
	testobject.operator()();
	testobject.m_handler.m_updaterStateMachine.process_event(eventTestOperationEventCode);
}

TEST(FirePointStateMachine, FireSensorInputStateHandlerTest)
{
	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensorInput, fireSystemState::FireSensorInputStateHandler> handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::FirePointStateMachine<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensorInput, fireSystemState::FireSensorInputStateHandler>> testobject(handler);

	auto eventDisablementEventCode = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
	auto eventTestOperationEventCode = std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);

	testobject.SelfEnablement(eventDisablementEventCode);
	testobject.ClearFireWhenReachable();
	testobject.ClearTestWhenReachable();
	testobject.ClearDesiblementWhenReachable();
	testobject.Enable(eventDisablementEventCode);
	testobject.Disable(eventDisablementEventCode);
	testobject.IsitMine(eventDisablementEventCode);
	testobject.CreatSendEnablementEvent(eventDisablementEventCode, Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
	testobject.m_handler.m_updaterStateMachine.process_event(eventTestOperationEventCode);
}

TEST(FirePointStateMachine, ManualCallPointStateHandlerTest)
{
	auto eventAlarmEventCode = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
	auto eventTestOperationEventCode = std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);
	auto eventDisablementEventCode = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
	auto eventAlarmEventTestCode = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::TEST_ALARM);

	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::ManualCallPoint, fireSystemState::ManualCallPointStateHandler> handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::FirePointStateMachine<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::ManualCallPoint, fireSystemState::ManualCallPointStateHandler>> testobject(handler);

	testobject.ProcessAlarm(eventAlarmEventCode);
	testobject.ProcessTestEnd(eventTestOperationEventCode);
	testobject.SelfEnablement(eventDisablementEventCode);
	testobject.IsEventFromPoint(eventDisablementEventCode);
	testobject.ClearFireWhenReachable();
	testobject.ClearTestWhenReachable();
	testobject.ClearDesiblementWhenReachable();
	testobject.ProcessReturnFromAlarm(eventAlarmEventCode);
	testobject.CreatSendEnablementEvent(eventDisablementEventCode, Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
	testobject.Enable(eventDisablementEventCode);
	testobject.Disable(eventDisablementEventCode);
	testobject.IsitMine(eventDisablementEventCode);
	testobject.ProcessTestAlarm(eventAlarmEventCode);
	testobject.IsEventFromParent(eventDisablementEventCode);
	testobject.GetmyPanelObjectRef();
	testobject.m_handler.m_updaterStateMachine.process_event(eventAlarmEventTestCode);
}

TEST(FirePointStateMachine, ManualCallPointInputStateHandlerTest)
{
	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::MCPInput, fireSystemState::ManualCallPointInputStateHandler> handler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::FirePointStateMachine<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::MCPInput, fireSystemState::ManualCallPointInputStateHandler>> testobject(handler);

	auto eventAlarmEventCode = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
	auto eventTestOperationEventCode = std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);
	auto eventDisablementEventCode = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);

	testobject.ProcessAlarm(eventAlarmEventCode);
	testobject.ProcessTestEnd(eventTestOperationEventCode);
	testobject.SelfEnablement(eventDisablementEventCode);
	testobject.IsEventFromPoint(eventDisablementEventCode);
	testobject.ClearFireWhenReachable();
	testobject.ClearTestWhenReachable();
	testobject.ClearDesiblementWhenReachable();
	testobject.ProcessReturnFromAlarm(eventAlarmEventCode);
	testobject.CreatSendEnablementEvent(eventDisablementEventCode, Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
	testobject.Enable(eventDisablementEventCode);
	testobject.Disable(eventDisablementEventCode);
	testobject.IsitMine(eventDisablementEventCode);
	testobject.ProcessTestAlarm(eventAlarmEventCode);
	testobject.IsEventFromParent(eventDisablementEventCode);
	testobject.GetmyPanelObjectRef();
	testobject.ProcessReturnFromAlarm(eventAlarmEventCode);
}

TEST(FaultEventStateMachine, CommonFaultEventStateHandler_FPOStateHandler_Test)
{
	auto eventFaultEventSelfTestCode = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventResetTypeCode = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::FIRE_ALARM);
	auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventFaultClearedEventCode = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventFaultEventClockCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::CLOCK_NOT_SET);

	fireSystemState::FPOStateHandler fpoHandler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::FPOStateHandler> handler{fpoHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::FPOStateHandler>> testobject(handler);

	testobject.isAFirePanel();
	testobject.GetmyObjectRef();
	testobject.ClearAllEntityFaults(eventFaultEventSelfTestCode);
	testobject.GetmyPanelObjectRef();
	testobject.IsFaultHandledByReset();
	testobject.ClearAllEntityFaults(eventResetTypeCode);
	testobject.SetFaultAndForwardEvent(eventFaultEventCode);
	testobject.ClearAllEntityFaults(eventFaultClearedEventCode);
	testobject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventClockCode);
}

TEST(FaultEventStateMachine, CommonFaultEventStateHandler_LoopStateHandler_Test)
{
	auto event = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::FIRE_ALARM);
	auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventFaultClearedEventCode = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);

	fireSystemState::LoopStateHandler loopHandler{10, fireSystemState::XmlElementConfig{}};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::LoopStateHandler> handler{loopHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::LoopStateHandler>> testobject(handler);

	testobject.isAFirePanel();
	testobject.GetmyObjectRef();
	testobject.GetmyPanelObjectRef();
	testobject.IsFaultHandledByReset();
	testobject.ClearAllEntityFaults(event);
	testobject.SetFaultAndForwardEvent(eventFaultEventCode);
	testobject.ClearAllEntityFaults(eventFaultClearedEventCode);
//	testobject.ClearEntityFault(eventFaultClearedEventCode);
	testobject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);
}

TEST(FaultEventStateMachine, CommonFaultEventStateHandler_ModuleStateHandler_Test)
{
	auto eventResetCode = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::FIRE_ALARM);
	auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventFaultClearedEventCode = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);

	fireSystemState::XmlElementConfig config;
	fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule> ModuleStateLoopHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule>> CommonFaultLoopModuleHandler{ModuleStateLoopHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule>>> ModuleStateLoopModuleTestObject(CommonFaultLoopModuleHandler);

	ModuleStateLoopModuleTestObject.isAFirePanel();
	ModuleStateLoopModuleTestObject.IsFaultHandledByReset();
	ModuleStateLoopModuleTestObject.GetmyObjectRef();
	ModuleStateLoopModuleTestObject.GetmyPanelObjectRef();
	ModuleStateLoopModuleTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateLoopModuleTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateLoopModuleTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateLoopModuleTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms> ModuleStateSerialHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms>> CommonFaultEventSerialHandler{ModuleStateSerialHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms>>> ModuleStateSerialTestObject(CommonFaultEventSerialHandler);
	ModuleStateSerialTestObject.isAFirePanel();
	ModuleStateSerialTestObject.IsFaultHandledByReset();
	ModuleStateSerialTestObject.GetmyObjectRef();
	ModuleStateSerialTestObject.GetmyPanelObjectRef();
	ModuleStateSerialTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateSerialTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateSerialTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateSerialTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule> ModuleStateFATFBFHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule>> CommonFaultEventFATFBFHandler{ModuleStateFATFBFHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule>>> ModuleStateFATFBFTestObject(CommonFaultEventFATFBFHandler);
	ModuleStateFATFBFTestObject.isAFirePanel();
	ModuleStateFATFBFTestObject.IsFaultHandledByReset();
	ModuleStateFATFBFTestObject.GetmyObjectRef();
	ModuleStateFATFBFTestObject.GetmyPanelObjectRef();
	ModuleStateFATFBFTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateFATFBFTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateFATFBFTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateFATFBFTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule> ModuleStateChargerHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule>> CommonFaultEventChargerHandler{ModuleStateChargerHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule>>> ModuleStateChargerTestObject(CommonFaultEventChargerHandler);
	ModuleStateChargerTestObject.isAFirePanel();
	ModuleStateChargerTestObject.IsFaultHandledByReset();
	ModuleStateChargerTestObject.GetmyObjectRef();
	ModuleStateChargerTestObject.GetmyPanelObjectRef();
	ModuleStateChargerTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateChargerTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateChargerTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateChargerTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule> ModuleStateFAREFREHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule>> CommonFaultEventFAREFREHandler{ModuleStateFAREFREHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule>>> ModuleStateFAREFRETestObject(CommonFaultEventFAREFREHandler);
	ModuleStateFAREFRETestObject.isAFirePanel();
	ModuleStateFAREFRETestObject.IsFaultHandledByReset();
	ModuleStateFAREFRETestObject.GetmyObjectRef();
	ModuleStateFAREFRETestObject.GetmyPanelObjectRef();
	ModuleStateFAREFRETestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateFAREFRETestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateFAREFRETestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateFAREFRETestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule> ModuleStateNetworkHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule>> CommonFaultEventNetworkHAndler{ModuleStateNetworkHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule>>> ModuleStateNetworkTestObject(CommonFaultEventNetworkHAndler);
	ModuleStateNetworkTestObject.isAFirePanel();
	ModuleStateNetworkTestObject.IsFaultHandledByReset();
	ModuleStateNetworkTestObject.GetmyObjectRef();
	ModuleStateNetworkTestObject.GetmyPanelObjectRef();
	ModuleStateNetworkTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateNetworkTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateNetworkTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateNetworkTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::IOModule> ModuleStateIOHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::IOModule>> CommonFaultEventIOHandler{ModuleStateIOHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::IOModule>>> ModuleStateIOTestObject(CommonFaultEventIOHandler);
	ModuleStateIOTestObject.isAFirePanel();
	ModuleStateIOTestObject.IsFaultHandledByReset();
	ModuleStateIOTestObject.GetmyObjectRef();
	ModuleStateIOTestObject.GetmyPanelObjectRef();
	ModuleStateIOTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateIOTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateIOTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateIOTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule> ModuleStateCPUHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule>> CommonFaultEventCPUHandler{ModuleStateCPUHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule>>> ModuleStateCPUTestObject(CommonFaultEventCPUHandler);
	ModuleStateCPUTestObject.isAFirePanel();
	ModuleStateCPUTestObject.IsFaultHandledByReset();
	ModuleStateCPUTestObject.GetmyObjectRef();
	ModuleStateCPUTestObject.GetmyPanelObjectRef();
	ModuleStateCPUTestObject.ClearAllEntityFaults(eventResetCode);
	ModuleStateCPUTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	ModuleStateCPUTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	ModuleStateCPUTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);
}

TEST(FaultEventStateMachine, CommonFaultEventStateHandle_StateHandlerTest)
{
	auto eventResetCode = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::FIRE_ALARM);
	auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);
	auto eventFaultClearedEventCode = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::SELF_TEST_FAILED);

	fireSystemState::XmlElementConfig config;
	fireSystemState::FirePanelStateHandler FirePanelHandler{config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::FirePanelStateHandler> CommonFaultEventFirePanelStateHandler{FirePanelHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::FirePanelStateHandler>> FaultEventFirePanelTestObject(CommonFaultEventFirePanelStateHandler);

	FaultEventFirePanelTestObject.isAFirePanel();
	FaultEventFirePanelTestObject.GetmyObjectRef();
	FaultEventFirePanelTestObject.GetmyPanelObjectRef();
	FaultEventFirePanelTestObject.IsFaultHandledByReset();
	FaultEventFirePanelTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFirePanelTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFirePanelTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFirePanelTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::KeySafeStateHandler KeySafeHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::KeySafeStateHandler> CommonFaultEventKeySafeHandler{KeySafeHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::KeySafeStateHandler>> FaultEventKeySafeTestObject(CommonFaultEventKeySafeHandler);
	FaultEventKeySafeTestObject.isAFirePanel();
	FaultEventKeySafeTestObject.GetmyObjectRef();
	FaultEventKeySafeTestObject.GetmyPanelObjectRef();
	FaultEventKeySafeTestObject.IsFaultHandledByReset();
	FaultEventKeySafeTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventKeySafeTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventKeySafeTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventKeySafeTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::FaultInputStateHandler FaultInputHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultInputStateHandler> CommonFaultEventFaultInputHandler{FaultInputHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultInputStateHandler>> FaultEventFaultInputTestObject(CommonFaultEventFaultInputHandler);
	FaultEventFaultInputTestObject.isAFirePanel();
	FaultEventFaultInputTestObject.GetmyObjectRef();
	FaultEventFaultInputTestObject.GetmyPanelObjectRef();
	FaultEventFaultInputTestObject.IsFaultHandledByReset();
	FaultEventFaultInputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFaultInputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFaultInputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFaultInputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::SerialPortStateHandler SerialPortHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::SerialPortStateHandler> CommonFaultEventSerialPortHandler{SerialPortHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::SerialPortStateHandler>> FaultEventSerialPortTestObject(CommonFaultEventSerialPortHandler);
	FaultEventSerialPortTestObject.isAFirePanel();
	FaultEventSerialPortTestObject.GetmyObjectRef();
	FaultEventSerialPortTestObject.GetmyPanelObjectRef();
	FaultEventSerialPortTestObject.IsFaultHandledByReset();
	FaultEventSerialPortTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventSerialPortTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventSerialPortTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventSerialPortTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::AlarmDeviceStateHandler AlarmDeviceHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmDeviceStateHandler> CommonFaultEventAlarmDeviceHandler{AlarmDeviceHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmDeviceStateHandler>> FaultEventAlarmDeviceTestObject(CommonFaultEventAlarmDeviceHandler);
	FaultEventAlarmDeviceTestObject.isAFirePanel();
	FaultEventAlarmDeviceTestObject.GetmyObjectRef();
	FaultEventAlarmDeviceTestObject.GetmyPanelObjectRef();
	FaultEventAlarmDeviceTestObject.IsFaultHandledByReset();
	FaultEventAlarmDeviceTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventAlarmDeviceTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventAlarmDeviceTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventAlarmDeviceTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::AlarmOutputStateHandler AlarmOutputHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmOutputStateHandler> CommonFaultEventAlarmOutputHandler{AlarmOutputHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmOutputStateHandler>> FaultEvenAlarmOutputTestObject(CommonFaultEventAlarmOutputHandler);
	FaultEvenAlarmOutputTestObject.isAFirePanel();
	FaultEvenAlarmOutputTestObject.GetmyObjectRef();
	FaultEvenAlarmOutputTestObject.GetmyPanelObjectRef();
	FaultEvenAlarmOutputTestObject.IsFaultHandledByReset();
	FaultEvenAlarmOutputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEvenAlarmOutputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEvenAlarmOutputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEvenAlarmOutputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::FieldDeviceStateHandler FieldDeviceHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::FieldDeviceStateHandler> CommonFaultEventFieldDeviceHandler{FieldDeviceHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::FieldDeviceStateHandler>> FaultEventFieldDeviceTestObject(CommonFaultEventFieldDeviceHandler);
	FaultEventFieldDeviceTestObject.isAFirePanel();
	FaultEventFieldDeviceTestObject.GetmyObjectRef();
	FaultEventFieldDeviceTestObject.GetmyPanelObjectRef();
	FaultEventFieldDeviceTestObject.IsFaultHandledByReset();
	FaultEventFieldDeviceTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFieldDeviceTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFieldDeviceTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFieldDeviceTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::BatteryPointStateHandler BatteryPointHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::BatteryPointStateHandler> CommonFaultEventBatteryHandler{BatteryPointHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::BatteryPointStateHandler>> FaultEventBatteryTestObject(CommonFaultEventBatteryHandler);
	FaultEventBatteryTestObject.isAFirePanel();
	FaultEventBatteryTestObject.GetmyObjectRef();
	FaultEventBatteryTestObject.GetmyPanelObjectRef();
	FaultEventBatteryTestObject.IsFaultHandledByReset();
	FaultEventBatteryTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventBatteryTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventBatteryTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventBatteryTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ChargerPointStateHandler ChargerPointHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ChargerPointStateHandler> CommonFaultEventChargerHandler{ChargerPointHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ChargerPointStateHandler>> FaultEventChargerTestObject(CommonFaultEventChargerHandler);
	FaultEventChargerTestObject.isAFirePanel();
	FaultEventChargerTestObject.GetmyObjectRef();
	FaultEventChargerTestObject.GetmyPanelObjectRef();
	FaultEventChargerTestObject.IsFaultHandledByReset();
	FaultEventChargerTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventChargerTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventChargerTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventChargerTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ControlInputStateHandler ControlInputHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlInputStateHandler> CommonFaultEventControlInputHandler{ControlInputHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlInputStateHandler>> FaultEventControlInputTestObject(CommonFaultEventControlInputHandler);
	FaultEventControlInputTestObject.isAFirePanel();
	FaultEventControlInputTestObject.GetmyObjectRef();
	FaultEventControlInputTestObject.GetmyPanelObjectRef();
	FaultEventControlInputTestObject.IsFaultHandledByReset();
	FaultEventControlInputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventControlInputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventControlInputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventControlInputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ControlOutputStateHandler ControlOuptutHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlOutputStateHandler> CommonFaultEventControlOutputHandler{ControlOuptutHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlOutputStateHandler>> FaultEventControlOutputTestObject(CommonFaultEventControlOutputHandler);
	FaultEventControlOutputTestObject.isAFirePanel();
	FaultEventControlOutputTestObject.GetmyObjectRef();
	FaultEventControlOutputTestObject.GetmyPanelObjectRef();
	FaultEventControlOutputTestObject.IsFaultHandledByReset();
	FaultEventControlOutputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventControlOutputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventControlOutputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventControlOutputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::DetectionZoneStateHandler DetectionZoneHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::DetectionZoneStateHandler> CommonFaultEventDetectionZoneHandler{DetectionZoneHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::DetectionZoneStateHandler>> FaultEventDetectionZoneTestObject(CommonFaultEventDetectionZoneHandler);
	FaultEventDetectionZoneTestObject.isAFirePanel();
	FaultEventDetectionZoneTestObject.GetmyObjectRef();
	FaultEventDetectionZoneTestObject.GetmyPanelObjectRef();
	FaultEventDetectionZoneTestObject.IsFaultHandledByReset();
	FaultEventDetectionZoneTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventDetectionZoneTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventDetectionZoneTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventDetectionZoneTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::AuxDCOutputPointStateHandler AuxDCHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::AuxDCOutputPointStateHandler> CommonFaultEventAuxDCHandler{AuxDCHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::AuxDCOutputPointStateHandler>> FaultEventAuxDCTestObject(CommonFaultEventAuxDCHandler);
	FaultEventAuxDCTestObject.isAFirePanel();
	FaultEventAuxDCTestObject.GetmyObjectRef();
	FaultEventAuxDCTestObject.GetmyPanelObjectRef();
	FaultEventAuxDCTestObject.IsFaultHandledByReset();
	FaultEventAuxDCTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventAuxDCTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventAuxDCTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventAuxDCTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::ExternalPSUPointStateHandler ExternalPSUHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::ExternalPSUPointStateHandler> CommonFaultEventExternalPSUHandler{ExternalPSUHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::ExternalPSUPointStateHandler>> FaultEventExternalPSUTestObject(CommonFaultEventExternalPSUHandler);
	FaultEventExternalPSUTestObject.isAFirePanel();
	FaultEventExternalPSUTestObject.GetmyObjectRef();
	FaultEventExternalPSUTestObject.GetmyPanelObjectRef();
	FaultEventExternalPSUTestObject.IsFaultHandledByReset();
	FaultEventExternalPSUTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventExternalPSUTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventExternalPSUTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventExternalPSUTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::FireRoutingOutputStateHandler FireRoutingHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::FireRoutingOutputStateHandler> CommonFaultEventFireRoutingHandler{FireRoutingHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::FireRoutingOutputStateHandler>> FaultEventFireRountingTestObject(CommonFaultEventFireRoutingHandler);
	FaultEventFireRountingTestObject.isAFirePanel();
	FaultEventFireRountingTestObject.GetmyObjectRef();
	FaultEventFireRountingTestObject.GetmyPanelObjectRef();
	FaultEventFireRountingTestObject.IsFaultHandledByReset();
	FaultEventFireRountingTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFireRountingTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFireRountingTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFireRountingTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::FaultRoutingOutputStateHandler FaultRoutingHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultRoutingOutputStateHandler> CommonFaultEventFaultRountingHandler{FaultRoutingHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultRoutingOutputStateHandler>> FaultEventFaultRoutingTestObject(CommonFaultEventFaultRountingHandler);
	FaultEventFaultRoutingTestObject.isAFirePanel();
	FaultEventFaultRoutingTestObject.GetmyObjectRef();
	FaultEventFaultRoutingTestObject.GetmyPanelObjectRef();
	FaultEventFaultRoutingTestObject.IsFaultHandledByReset();
	FaultEventFaultRoutingTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFaultRoutingTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFaultRoutingTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFaultRoutingTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::TechnicalAlarmInputStateHandler TechnicalAlarmHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::TechnicalAlarmInputStateHandler> CommonFaultEventTechnicalHandler{TechnicalAlarmHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::TechnicalAlarmInputStateHandler>> FaultEventTechnicalTestObject(CommonFaultEventTechnicalHandler);
	FaultEventTechnicalTestObject.isAFirePanel();
	FaultEventTechnicalTestObject.GetmyObjectRef();
	FaultEventTechnicalTestObject.GetmyPanelObjectRef();
	FaultEventTechnicalTestObject.IsFaultHandledByReset();
	FaultEventTechnicalTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventTechnicalTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventTechnicalTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventTechnicalTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::CommonFireOutputPointStateHandler CommonFireOutputPointHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::CommonFireOutputPointStateHandler> CommonFaultEventCommonFireHandler{CommonFireOutputPointHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::CommonFireOutputPointStateHandler>> FaultEventCommonFireTestObject(CommonFaultEventCommonFireHandler);
	FaultEventCommonFireTestObject.isAFirePanel();
	FaultEventCommonFireTestObject.GetmyObjectRef();
	FaultEventCommonFireTestObject.GetmyPanelObjectRef();
	FaultEventCommonFireTestObject.IsFaultHandledByReset();
	FaultEventCommonFireTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventCommonFireTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventCommonFireTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventCommonFireTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensor, fireSystemState::FireSensorStateHandler> BaseFireDetectionFireSensorHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensor, fireSystemState::FireSensorStateHandler>> CommonFaultEventFireSensorHandler{BaseFireDetectionFireSensorHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensor, fireSystemState::FireSensorStateHandler>>> FaultEventFireSensorTestObject(CommonFaultEventFireSensorHandler);
	FaultEventFireSensorTestObject.isAFirePanel();
	FaultEventFireSensorTestObject.GetmyObjectRef();
	FaultEventFireSensorTestObject.GetmyPanelObjectRef();
	FaultEventFireSensorTestObject.IsFaultHandledByReset();
	FaultEventFireSensorTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFireSensorTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFireSensorTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFireSensorTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensorInput, fireSystemState::FireSensorInputStateHandler> BaseFireDetectionFireSensorInputHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensorInput, fireSystemState::FireSensorInputStateHandler>> CommonFaultEventFireSensorInputHandler{BaseFireDetectionFireSensorInputHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::FireSensorInput, fireSystemState::FireSensorInputStateHandler>>> FaultEventFireSensorInputTestObject(CommonFaultEventFireSensorInputHandler);
	FaultEventFireSensorInputTestObject.isAFirePanel();
	FaultEventFireSensorInputTestObject.GetmyObjectRef();
	FaultEventFireSensorInputTestObject.GetmyPanelObjectRef();
	FaultEventFireSensorInputTestObject.IsFaultHandledByReset();
	FaultEventFireSensorInputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventFireSensorInputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventFireSensorInputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventFireSensorInputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::ManualCallPoint, fireSystemState::ManualCallPointStateHandler> BaseFireDetectionHandler2{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::ManualCallPoint, fireSystemState::ManualCallPointStateHandler>> CommonFaultEventManualHandler{BaseFireDetectionHandler2};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::ManualCallPoint, fireSystemState::ManualCallPointStateHandler>>> FaultEventManualTestObject(CommonFaultEventManualHandler);
	FaultEventManualTestObject.isAFirePanel();
	FaultEventManualTestObject.GetmyObjectRef();
	FaultEventManualTestObject.GetmyPanelObjectRef();
	FaultEventManualTestObject.IsFaultHandledByReset();
	FaultEventManualTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventManualTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventManualTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventManualTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::MCPInput, fireSystemState::ManualCallPointInputStateHandler> BaseFireDetectionManualInputHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::MCPInput, fireSystemState::ManualCallPointInputStateHandler>> CommonFaultEventManualInputHandler{BaseFireDetectionManualInputHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::BaseFireDetectionPointStateHandler<Dol::Entities::MCPInput, fireSystemState::ManualCallPointInputStateHandler>>> FaultEventManaulInputTestObject(CommonFaultEventManualInputHandler);
	FaultEventManaulInputTestObject.isAFirePanel();
	FaultEventManaulInputTestObject.GetmyObjectRef();
	FaultEventManaulInputTestObject.GetmyPanelObjectRef();
	FaultEventManaulInputTestObject.IsFaultHandledByReset();
	FaultEventManaulInputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventManaulInputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventManaulInputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventManaulInputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::CommonFaultOutputPointStateHandler CommonFaultOutputHandler{10, config};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::CommonFaultOutputPointStateHandler> CommonFaultEventCommonOutputHandler{CommonFaultOutputHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::CommonFaultOutputPointStateHandler>> FaultEventCommonOutputTestObject(CommonFaultEventCommonOutputHandler);
	FaultEventCommonOutputTestObject.isAFirePanel();
	FaultEventCommonOutputTestObject.GetmyObjectRef();
	FaultEventCommonOutputTestObject.GetmyPanelObjectRef();
	FaultEventCommonOutputTestObject.IsFaultHandledByReset();
	FaultEventCommonOutputTestObject.ClearAllEntityFaults(eventResetCode);
	FaultEventCommonOutputTestObject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventCommonOutputTestObject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventCommonOutputTestObject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);

	fireSystemState::DummyStateHandler DummyHandler{};
	fireSystemState::CommonFaultEventStateHandler<fireSystemState::DummyStateHandler> CommonFaultDummyStateHandler{DummyHandler};
	fireSystemState::FaultEventStateMachine<fireSystemState::CommonFaultEventStateHandler<fireSystemState::DummyStateHandler>> FaultEventDummyTestobject(CommonFaultDummyStateHandler);
	FaultEventDummyTestobject.isAFirePanel();
	FaultEventDummyTestobject.GetmyObjectRef();
	FaultEventDummyTestobject.GetmyPanelObjectRef();
	FaultEventDummyTestobject.IsFaultHandledByReset();
	FaultEventDummyTestobject.ClearAllEntityFaults(eventResetCode);
	FaultEventDummyTestobject.ClearAllEntityFaults(eventFaultClearedEventCode);
	FaultEventDummyTestobject.SetFaultAndForwardEvent(eventFaultEventCode);
	FaultEventDummyTestobject.m_handler.m_faultEventupdaterStateMachine.process_event(eventFaultEventCode);
}