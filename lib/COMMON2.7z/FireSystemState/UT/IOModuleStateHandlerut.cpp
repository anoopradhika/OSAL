#include "gmock/gmock.h"
#include "IOModuleStateHandlerut.h"
#include "Utility.h"

TEST(IOModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::IOModuleStateHandlerTest testobject{10, config};
}

TEST(ModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ModuleStateHandlerTest testobject{10, config};
    testobject.SetupTest();
    testobject.RevInformationEvent();

    fireSystemState::ModuleStateHandlerloopTest testobject1{10, config};
    testobject1.SetupTest();
    testobject1.RevInformationEvent();

    fireSystemState::ModuleStateHandlercpuTest testobject2{10, config};
    testobject2.SetupTest();
    testobject2.RevInformationEvent();

    fireSystemState::ModuleStateHandlerchargerTest testobject3{10, config};
    testobject3.SetupTest();
    testobject3.RevInformationEvent();

    fireSystemState::ModuleStateHandlerFareTest testobject4{10, config};
    testobject4.SetupTest();
    testobject4.RevInformationEvent();

    fireSystemState::ModuleStateHandlerfatTest testobject5{10, config};
    testobject5.SetupTest();
    testobject5.RevInformationEvent();

    fireSystemState::ModuleStateHandlernetworkTest testobject6{10, config};
    testobject6.SetupTest();
    testobject6.RevInformationEvent();

    fireSystemState::ModuleStateHandlerserialTest testobject7{10, config};
    testobject7.SetupTest();
    testobject7.RevInformationEvent();
}

TEST(NetworkModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::NetworkModuleStateHandlerTest testobject{10, config};
}

TEST(FAREFREModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FAREFREModuleStateHandlerTest testobject{10, config};
}

TEST(FATFBFModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FATFBFModuleStateHandlerTest testobject{10, config};
}

TEST(CPUModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::CPUModuleStateHandlerTest testobject{10, config};
}

TEST(SerialCommsStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::SerialCommsStateHandlerTest testobject{10, config};
}

TEST(ChargerModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ChargerModuleStateHandlerTest testobject{10, config};
}

TEST(LoopModuleStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::LoopModuleStateHandlerTest testobject{10, config};
    testobject.SetupTest();
}

TEST(AuxDCOutputPointStateHandlerTest, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AuxDCOutputPointStateHandlerTest testobject{10, config};
    testobject.SetupTest();
}

//TEST(BuildingStateHandlerTest, SetupTest)
//{
//    char source[PATH_MAX];
//    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
//    std::string active = Utility::GetActiveConfigLocation();
//    std::string distination = active.append("configuration.xml");
//    Utility::RemoveFile(distination);
//    Utility::CopyFile(source,distination);
//
//    fireSystemState::XmlElementConfig config;
//    config.id = 0x100010000000000;//72058693549555712
//    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
//    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
//
//    fireSystemState::BuildingStateHandlerTest testobject{0x100010000000000};
//    testobject.Prepare();
//
//}

TEST(FATFBFModuleStateHandlerTest, StaticGetIdTest)
{
    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Module, fireSystemState::FATFBFModuleStateHandler> StateObjectFactoryFATFBFAdapter;
    StateObjectFactoryFATFBFAdapter.StaticGetId();

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Module, fireSystemState::NetworkModuleStateHandler> StateObjectFactoryNetworkAdapter;
    StateObjectFactoryNetworkAdapter.StaticGetId();

    SateHandlerDowncastAdapter<Dol::Entities::Module, fireSystemState::FATFBFModuleStateHandler> SateDowncastFATFBFAdapter;
    SateDowncastFATFBFAdapter.StaticGetId();

    SateHandlerDowncastAdapter<Dol::Entities::Module, fireSystemState::NetworkModuleStateHandler> SateDowncastNetworkAdapter;
    SateDowncastNetworkAdapter.StaticGetId();
}

TEST(FATFBFModuleStateHandlerTest, CreateTest)
{
    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Module, fireSystemState::SerialCommsStateHandler> StateObjectFactorySerialCommAdapter;
    StateObjectFactorySerialCommAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Module, fireSystemState::FATFBFModuleStateHandler> StateObjectFactoryFATFBFAdapter;
    StateObjectFactoryFATFBFAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Module, fireSystemState::NetworkModuleStateHandler> StateObjectFactoryNetworkAdapter;
    StateObjectFactoryNetworkAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});
}

TEST(FATFBFModuleStateHandlerTest, OperationTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::PrepareOperation prepareOperation{};
    fireSystemState::SetupSignalOperation setupSignalOperarion{};

    std::shared_ptr<fireSystemState::SerialCommsStateHandler> serialCommObj = std::make_shared<fireSystemState::SerialCommsStateHandler>(10, config);
    prepareOperation.operator()(serialCommObj);
    setupSignalOperarion.operator()(serialCommObj);

    std::shared_ptr<fireSystemState::FATFBFModuleStateHandler> fatfbfModulObj = std::make_shared<fireSystemState::FATFBFModuleStateHandler>(10, config);
    prepareOperation.operator()(fatfbfModulObj);
    setupSignalOperarion.operator()(fatfbfModulObj);

    std::shared_ptr<fireSystemState::NetworkModuleStateHandler> networkModuleObj = std::make_shared<fireSystemState::NetworkModuleStateHandler>(10, config);
    prepareOperation.operator()(networkModuleObj);
    setupSignalOperarion.operator()(networkModuleObj);
}

TEST(FATFBFModuleStateHandlerTest, DynamicGetIdTest)
{
    std::shared_ptr<fireSystemState::FATFBFModuleStateHandler> fatfbfModuleObj = std::make_shared<fireSystemState::FATFBFModuleStateHandler>(10, fireSystemState::XmlElementConfig{});
    SateHandlerDowncastAdapter<Dol::Entities::Module, fireSystemState::FATFBFModuleStateHandler> SateDowncastFATFBFAdapter;
    SateDowncastFATFBFAdapter.DynamicGetId(fatfbfModuleObj);

    std::shared_ptr<fireSystemState::NetworkModuleStateHandler> networkModuleObj = std::make_shared<fireSystemState::NetworkModuleStateHandler>(10, fireSystemState::XmlElementConfig{});
    SateHandlerDowncastAdapter<Dol::Entities::Module, fireSystemState::NetworkModuleStateHandler> SateDowncastNetworkAdapter;
    SateDowncastNetworkAdapter.DynamicGetId(networkModuleObj);
}