/******************************************************************************//**
*
* @file   DummyStateHandler.h
* @brief  State handler for Loop
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_DUMMY_H
#define FIRESYSTEM_STATE_HANDLER_DUMMY_H

#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "DOL/Entities/Zone/Zone.h"
#include "DOL/Entities/ManagedArea.h"

namespace fireSystemState
{

/**
* @brief DummyStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class DummyStateHandler: public Dol::Entities::Point, public StateHandler<DummyStateHandler>
{
public:
    /**
    * Prepare the StateMaschine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    DummyStateHandler(bool faultHandledByReset = false):
        Point(myType, ID)
    {
        Dol::Entities::Zone zone;
        Dol::Entities::ManagedArea m1(myManagedAreaID);
        zone.AddManagedArea(std::make_shared<Dol::Entities::ManagedArea>(m1));
        zone.SetManagedAreaId(myManagedAreaID);
        Dol::Entities::Point::AddParentZone(std::make_shared<Dol::Entities::Zone>(zone));
        SetFaultHandledByReset(faultHandledByReset);
        ClearAllSignals();
        myPanelObjectRef = Mol::DataType::ObjectReference{0x100010000000000,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
        myObjectRef = Mol::DataType::ObjectReference{ID,myType};
    }

    ~DummyStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
    }
    static constexpr uint64_t ID = 0x100010100000001;
    static constexpr Dol::DOMAIN_OBJECT_TYPE myType = Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE;
    static constexpr uint64_t myManagedAreaID = 1;
    static constexpr uint64_t myZoneID = 1010;
    static constexpr Dol::DOMAIN_OBJECT_TYPE myZoneType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    Mol::DataType::ObjectReference myPanelObjectRef;
    Mol::DataType::ObjectReference myObjectRef;

protected:

    uint64_t m_managedAreaId = 0;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_DUMMY_H
