#include "gmock/gmock.h"
#include "KeySafeStateUt.h"
#include "Utility.h"

TEST(KeySafeStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::KeySafeStateHandlerTest testobject{10,config};
    testobject.Setup_Test();
}

TEST(KeySafeStateHandlerTestUT, Active_Deactive_Cmd_Test)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::KeySafeStateHandlerTest testobject{10,config};
    testobject.RcvActivationEvent();
    testobject.RcvActivationEventNoFDA();
    testobject.RcvActivationEventDeactivateNoFDA();
    testobject.RcvActivationCmd();
    testobject.RcvActivationCmdNoFDA();
    testobject.RcvDeActivationCmd();
    testobject.RcvDeActivationCmdNoFDA();
}

TEST(KeySafeStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::KeySafeStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
}
