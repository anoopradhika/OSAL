#ifndef TECHNICAL_ALARM_INPUT_STATE_UT_H
#define TECHNICAL_ALARM_INPUT_STATE_UT_H

#include "StateHandler/TechnicalAlarmInputStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DOL/Entities/ManagedArea.h"

namespace fireSystemState
{
    class TechnicalAlarmInputStateHandlerTest : public TechnicalAlarmInputStateHandler
    {
    public:
        TechnicalAlarmInputStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            TechnicalAlarmInputStateHandler(id, element)
        {
            Dol::Entities::Zone zone(Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE, 1);
            Dol::Entities::ManagedArea m1(1);
            zone.AddManagedArea(std::make_shared<Dol::Entities::ManagedArea>(m1));
            zone.SetManagedAreaId(1);
            AddParentZone(std::make_shared<Dol::Entities::Zone>(zone));
        }
        ~TechnicalAlarmInputStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>();
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event,0,PROC_ADDRESS::MODULE_APP);
		}

		void RcvTestEvent()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvTestEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvTestEventZoneRemoved()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void ReceiveResetCommandTestIncorrect()
		{
			auto command = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::GENERAL);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA;
			auto managedarea = 1;
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(managedarea, type);
			command->SetCommandTarget(target);
			ReceiveResetCommand(command, 0,PROC_ADDRESS::MODULE_APP);
		}

		void RcvAlarmEvent()
		{
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058702156398848, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{1101,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent(parent);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvAlarmEventNoFDA()
		{
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058702156398848, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{1101,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent(parent);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::CMCAPP);
		}
		
		void RcvAlarmEventReturnFromAlarm()
		{
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058702156398848, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{1101,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent(parent);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::CMCAPP);
		}

		void RcvAlarmEventTestAlarm()
		{
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::TEST_ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058702156398848, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{1101,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent(parent);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::CMCAPP);
		}
		
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);
            
            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);
            
            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }


    };
}
#endif //TECHNICAL_ALARM_INPUT_STATE_UT_H
