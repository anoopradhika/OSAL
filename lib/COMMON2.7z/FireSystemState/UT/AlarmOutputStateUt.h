#ifndef ALARM_OUTPUT_STATE_UT_H
#define ALARM_OUTPUT_STATE_UT_H

#include "StateHandler/AlarmOutputStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class AlarmOutputStateHandlerTest : public AlarmOutputStateHandler
    {
    public:
        AlarmOutputStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            AlarmOutputStateHandler(id, element)
        {
        }
        ~AlarmOutputStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
			EnableAction();
		}

		void RcvFunctionEnbleEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFunctionEnbleEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDisablementEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void AlarmSignalEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(1);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveAlarmSignalEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void AlarmSignalEvent()
		{
			auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(0);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveAlarmSignalEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void UserOperationEventTest()
		{
			auto event=std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			UserOperationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvSetAlarmSignal()
		{
			auto event=std::make_shared<Mol::Command::SetAlarmSignal>(1);
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
			ReceiveSetAlarameSignalCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvSetAlarmSignalVal()
		{
			auto event=std::make_shared<Mol::Command::SetAlarmSignal>(0);
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
			ReceiveSetAlarameSignalCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvMultiQueryRequest()
		{
			auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
			multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT});
			multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);

			auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
			multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT});
			multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

			auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
			multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT});
			multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);

			auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
			multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
			multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
		}
        bool ReceiveFaultEventTest()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 1, PROC_ADDRESS::MODULE_APP);
			return (GetLastError() == STATE_ERROR::NO_ERROR);
        }

        bool ReceiveFaultClearedEventTestIgnoreFDAEvents()
        {
            auto event = std::make_shared < Mol::Event::FaultClearedEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            ReceiveFaultEvent<Mol::Event::FaultClearedEvent>(event, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);;
            return (GetLastError() == STATE_ERROR::INVALID_PROCCESS_ID);
        }

        bool ReceiveFaultClearedEventTest()
        {
            auto clearEvent = std::make_shared < Mol::Event::FaultClearedEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            clearEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            ReceiveFaultEvent<Mol::Event::FaultClearedEvent>(clearEvent, 0, PROC_ADDRESS::MODULE_APP);
            return (GetLastError() == STATE_ERROR::NO_ERROR);
        }

        bool ReceiveFaultEventTestINullPtr()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event = nullptr;
            ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return (GetLastError() == STATE_ERROR::NULL_EVENT);
        }

        bool ReceiveFaultClearedEventTestINullPtr()
        {
            auto event = std::make_shared < Mol::Event::FaultEvent > (Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
            event = nullptr;
            ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return (GetLastError() == STATE_ERROR::NULL_EVENT);
        }

        bool ReceiveResetCommandIncorrectCommandTest()
        {
            auto command = std::make_shared<Mol::Command::Deactivate>();
            ReceiveResetCommand(command, 0, PROC_ADDRESS::MODULE_APP);
            return (GetLastError() == STATE_ERROR::INVALID_EVENT);
        }

        bool ReceiveResetCommandCorrectCommandTest()
        {
            auto command = std::make_shared < Mol::Command::Reset > (Mol::Command::RESET_TYPE_CODE::GENERAL);
            ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return (GetLastError() == STATE_ERROR::NO_ERROR);
        }

    };
}
#endif //ALARM_OUTPUT_STATE_UT_H
