#ifndef DETECTION_ZONE_STATE_UT_H
#define DETECTION_ZONE_STATE_UT_H

#include "StateHandler/DetectionZoneStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class DetectionZoneStateHandlerTest : public DetectionZoneStateHandler
    {
    public:
        DetectionZoneStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            DetectionZoneStateHandler(id, element)
        {
        }
        ~DetectionZoneStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvDisablementEvent()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDisablementEventEnabledNoFDA()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvTestEvent()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvTestEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvTestEventZoneRemovedNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::CMCAPP);

		}

		void RcvTestReceiveSensitivityCommand()
		{
			auto event=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::ACTIVATE);
			ReceiveSensitivityCommand(event,10,PROC_ADDRESS::CMCAPP);

		}
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestPreAlarm = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_PRE_ALARM);
            multiQueryRequestPreAlarm->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE});
            multiQueryRequestPreAlarm->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestPreAlarm,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInTest = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST);
            multiQueryRequestInTest->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE});
            multiQueryRequestInTest->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInTest,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }
		void ProcessPanelFailoverTestNullptr()
		{
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            event = nullptr;
            ProcessPanelFailover(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
        }

        void ProcessPanelFailoverTestIgnorFDA()
        {
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            ProcessPanelFailover(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
        }

        void ProcessPanelFailoverTestIgnorEvent()
        {
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
        }

        void ProcessPanelFailoverTestIgnorMyPanelFailure()
        {
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source{0x100020010000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->SetSource(source);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
        }
		void ProcessPanelFailoverTestIgnorPanelFailureIfNoAlaramSignal()
		{
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source{0x100030010000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->SetSource(source);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
        }

        void ProcessPanelFailoverTestGoodSenario()
        {
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source{0x100030010000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->SetSource(source);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
        }
    };
}

#endif //DETECTION_ZONE_STATE_UT_H
