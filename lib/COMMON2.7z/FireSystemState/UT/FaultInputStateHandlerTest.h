/******************************************************************************//**
* @file FaultInputStateHandlerTest.h
* @brief Test case verify FaultInputStateHandler Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef UT_FAULT_INPUT_STATE_TEST_H
#define UT_FAULT_INPUT_STATE_TEST_H

#include "StateHandler/FaultInputStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FaultInputStateHandlerTest : public FaultInputStateHandler
    {
    public:
        FaultInputStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FaultInputStateHandler(id,element)
        {
        }
        ~FaultInputStateHandlerTest() override = default;

        bool SetupSignalTest()
        {
            SetupSignal();
            return true;
        }

        bool ReceiveDisablementEventTest()
        {
            auto event=std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
            ReceiveDisablementEvent(event,0, PROC_ADDRESS::BROADCAST);
            return GetLastError() == STATE_ERROR::NO_ERROR;
        }

        bool ReceiveDisablementEventTestInvalidEvent()
        {
            auto event=std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
            ReceiveDisablementEvent(event,0, PROC_ADDRESS::BROADCAST);
            return GetLastError() == STATE_ERROR::INVALID_EVENT;
        }

        bool ReceiveFaultEventTestInvalidProccessID()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return GetLastError() == STATE_ERROR::INVALID_PROCCESS_ID;
        }

        bool ReceiveFaultEventTestInvalidFaultCode()
        {
            uint64_t point_id = 72058693549555712;
            //valid code are only COMMUNICATIONS_STOPPED and NO_REPLY
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template  ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "quiescent";
        }

        bool ReceiveFaultEventTestValidFualtState()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "unreachable";
        }

        bool ReceiveFaultEventTestValidFualClearedtState()
        {
            //send first a fault event then the clear evnt to get the correct expected state
            ReceiveFaultEventTestValidFualtState();
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultClearedEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "was_unreachable";
        }

        bool ReceiveResetCommandTestInvalidProcessID()
        {
            uint64_t point_id = 72058693549555712;
            auto cmd = std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            ReceiveResetCommand(cmd, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return GetLastError() == STATE_ERROR::INVALID_PROCCESS_ID;
        }

        bool ReceiveResetCommandTestCorrectState()
        {
            //we send a fault the fault cleared event, the reset to get the expected sate later.
            ReceiveFaultEventTestValidFualClearedtState();//was_unreachable
            auto cmd = std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            m_mayManagedArea = Mol::DataType::ObjectReference{5, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
            cmd->SetCommandTarget(m_mayManagedArea);
            ReceiveResetCommand(cmd, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "quiescent";
        }
        
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);
            
            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);
            
            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }

    };
}
#endif //UT_FAULT_INPUT_STATE_TEST_H
