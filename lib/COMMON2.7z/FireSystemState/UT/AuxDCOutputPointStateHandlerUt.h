#ifndef AUX_DC_OUTPUT_POINT_STATE_UT_H
#define AUX_DC_OUTPUT_POINT_STATE_UT_H

#include "StateHandler/AuxDCOutputPointStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class AuxDCOutputPointStateHandlerTest : public AuxDCOutputPointStateHandler
    {
    public:
        AuxDCOutputPointStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            AuxDCOutputPointStateHandler(id, element)
        {
        }
        ~AuxDCOutputPointStateHandlerTest() override = default;

		void Setup_Test()
		{
			SetupSignal();
		}

		//--------------------//added_
	void RcvMultiQueryRequest()
	{
	    auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
		multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT});
		multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
		ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);
		
		auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
		multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT});
		multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
		ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

		auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
		multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT});
		multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
		ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);
		
		auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
		multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
		multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
		ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
	}

    };
}
#endif //AUX_DC_OUTPUT_POINT_STATE_UT_H
