#ifndef ZONETEST_COMMANDHANDLER_UT_H
#define ZONETEST_COMMANDHANDLER_UT_H

#include "StateHandler/ZoneTestCommandHandler.h"
#include "StateHandler/DelayOperationHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DummyStateHandler.h"
#include "Mol/DataType/ObjectReference.h"
#include "Mol/Events/EventCategory.h"
#include "Mol/Commands/Disable.h"
#include "Mol/Commands/Enable.h"

namespace fireSystemState
{
template<typename HANDLER>
    class ZoneTestCommandHandlerTest : public ZoneTestCommandHandler<HANDLER>
	{
    public:
	using NAME = ZoneTestCommandHandlerTest<HANDLER>;

    	ZoneTestCommandHandlerTest(HANDLER&  handler):
    		ZoneTestCommandHandler<HANDLER> (handler)
        {
        }
    	~ZoneTestCommandHandlerTest() = default;
        void Rcvzoneteststartcommand()
        {
        	auto event=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::TEST_ZONE_START);
        	NAME::ReceiveZoneTestStartCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

        }

        void RcvReceiveZoneTestStopCommand()
        {
           	auto event=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::TEST_ZONE_START);
           	NAME::ReceiveZoneTestStopCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);

        }

    };
}
#endif //ZONETEST_COMMANDHANDLER_UT_H


#ifndef DELAY_OPERATIONHANDLER_UT_H
#define DELAY_OPERATIONHANDLER_UT_H

namespace fireSystemState
{
template<typename HANDLER>
    class DelayOperationHandlerTest : public DelayOperationHandler<HANDLER>
	{
    public:
	using NAME = DelayOperationHandlerTest<HANDLER>;

	DelayOperationHandlerTest(HANDLER&  handler):
		DelayOperationHandler<HANDLER> (handler)
        {
        }
	~DelayOperationHandlerTest() = default;

	void SetupSignal()
	{
		SetupSignal();
	}
        void RcvReceiveDelayOperation()
        {
        	auto command=std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::DELAY_OFF);
        	NAME::ReceiveDelayOperation(command,10,PROC_ADDRESS::MOL_RECEIVER);

        }

    };
}
#endif //DELAY_OPERATIONHANDLER_UT_H

