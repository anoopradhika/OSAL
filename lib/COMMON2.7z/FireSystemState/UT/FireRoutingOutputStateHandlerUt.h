#ifndef FIRE_ROUTING_OUTPUT_STATE_UT_H
#define FIRE_ROUTING_OUTPUT_STATE_UT_H

#include "StateHandler/FireRoutingOutputStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FireRoutingOutputStateHandlerTest : public FireRoutingOutputStateHandler
    {
    public:
        FireRoutingOutputStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FireRoutingOutputStateHandler(id, element)
        {
        }
        ~FireRoutingOutputStateHandlerTest() override = default;

		void Setup_Test()
    	{
        	Prepare();
        	SetupSignal();
    	}

		void RcvActivationEvent()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationEventNoFDA()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationEventDeactivate()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::CMCAPP);
		}
		
		void RcvActivateCommand()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivateCommandNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDeActivateCommand()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::BROADCAST);
		}

		void RcvFunctionDisablementEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFunctionDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvFunctionEnableEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFunctionEnableEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}
		void DecrementActivationReqCount()
		{
			DecrementActivationRequestCount();
		}

		bool ActivationReqPending()
		{
			bool act = ActivationRequestsPending();
			return act;
		}

		void RcvInformationEvent()
		{
			auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::CHANGE_MODULE_MODE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveInformationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}
		
		void RcvInformationEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::CHANGE_MODULE_MODE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveInformationEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvFARETestEventStart()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFARETestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFARETestEventStartNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFARETestEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvFARETestEventEndNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_REMOVED_FROM_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFARETestEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

        bool ReceiveFaultEventTestInvalidProccessID()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return GetLastError() == STATE_ERROR::INVALID_PROCCESS_ID;
        }

        bool ReceiveFaultEventTestInvalidFaultCode()
        {
            uint64_t point_id = 72058693549555712;
            //valid code are only COMMUNICATIONS_STOPPED and NO_REPLY
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template  ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "quiescent";
        }

        bool ReceiveFaultEventTestValidFualtState()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "unreachable";
        }

        bool ReceiveFaultEventTestValidFualClearedtState()
        {
            //send first a fault event then the clear evnt to get the correct expected state
            ReceiveFaultEventTestValidFualtState();
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultClearedEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "was_unreachable";
        }

        bool ReceiveResetCommandTestInvalidProcessID()
        {
            uint64_t point_id = 72058693549555712;
            auto cmd = std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            ReceiveResetCommand(cmd, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return GetLastError() == STATE_ERROR::INVALID_PROCCESS_ID;
        }

        bool ReceiveResetCommandTestCorrectState()
        {
            //we send a fault the fault cleared event, the reset to get the expected sate later.
            ReceiveFaultEventTestValidFualClearedtState();//was_unreachable
            auto cmd = std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            Mol::DataType::ObjectReference m_UtManagedArea  = Mol::DataType::ObjectReference{1, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
            cmd->SetCommandTarget(m_UtManagedArea);
            ReceiveResetCommand(cmd, 0, PROC_ADDRESS::MODULE_APP);
            return GetCurrentState() == "quiescent";
        }
    };
}

#endif //FIRE_ROUTING_OUTPUT_STATE_UT_H
