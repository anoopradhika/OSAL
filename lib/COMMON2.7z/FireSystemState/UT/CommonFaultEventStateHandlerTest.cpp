#include "gmock/gmock.h"
#include "CommonFaultEventStateHandlerTest.h"
#include "DummyStateHandler.h"
#include "Utility.h"

TEST(CommonFaultEventStateHandlerUT, SetupSignalCommonTestHandledNotByReset)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.SetupSignalCommonTestHandledNotByReset());
}

TEST(CommonFaultEventStateHandlerUT, SetupSignalCommonTestHandledByReset)
{
    fireSystemState::DummyStateHandler handler(true);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.SetupSignalCommonTestHandledByReset());
}

TEST(CommonFaultEventStateHandlerUT, SetGetFaultTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.SetGetFaultTest());
}

TEST(CommonFaultEventStateHandlerUT, SendFaultEventTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.SendFaultEventTest());
}

TEST(CommonFaultEventStateHandlerUT, GetmyPanelObjectRefTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.GetmyPanelObjectRefTest());
}

TEST(CommonFaultEventStateHandlerUT, GetmyObjectRefTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.GetmyObjectRefTest());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveFaultEventTestIgnoreFDAEvents)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultEventTestIgnoreFDAEvents());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveFaultEventTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultEventTest());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveFaultClearedEventTestIgnoreFDAEvents)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTestIgnoreFDAEvents());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveFaultClearedEventTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTest());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveFaultEventTestINullPtr)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultEventTestINullPtr());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveFaultClearedEventTestINullPtr)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveFaultClearedEventTestINullPtr());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveResetCommandIncorrectCommandTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveResetCommandIncorrectCommandTest());
}

TEST(CommonFaultEventStateHandlerUT, ReceiveResetCommandCorrectCommandTest)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::CommonFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  objectEnderTest(handler);
    EXPECT_TRUE(objectEnderTest.ReceiveResetCommandCorrectCommandTest());
}

TEST(CommonFaultEventStateHandlerUT, GetmyPanelObjectRefTestAllHandlers)
{
    auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::NO_REPLY);
    event = nullptr;
    auto command = std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);

    fireSystemState::FPOStateHandler FpoHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FPOStateHandler> FpoObj(FpoHandler);
    FpoObj.GetmyObjectRef();
    FpoObj.GetmyPanelObjectRef();
    FpoObj.SetFault(true);
    FpoObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FpoObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::LoopStateHandler LoopHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::LoopStateHandler> LoopObj(LoopHandler);
    LoopObj.GetmyObjectRef();
    LoopObj.GetmyPanelObjectRef();
    LoopObj.SetFault(true);
    LoopObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    LoopObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::XmlElementConfig config;
    fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule> LoopModHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule>> LoopModObj (LoopModHandler);
    LoopModObj.GetmyObjectRef();
    LoopModObj.GetmyPanelObjectRef();
    LoopModObj.SetFault(true);
    LoopModObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    LoopModObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms> SerialComHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms>> SerialComObj(SerialComHandler);
    SerialComObj.GetmyObjectRef();
    SerialComObj.GetmyPanelObjectRef();
    SerialComObj.SetFault(true);
    SerialComObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    SerialComObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule> FATFBFModHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule>> FATFBFModObj(FATFBFModHandler);
    FATFBFModObj.GetmyObjectRef();
    FATFBFModObj.GetmyPanelObjectRef();
    FATFBFModObj.SetFault(true);
    FATFBFModObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FATFBFModObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule> ChargerModHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule>> ChargerModObj(ChargerModHandler);
    ChargerModObj.GetmyObjectRef();
    ChargerModObj.GetmyPanelObjectRef();
    ChargerModObj.SetFault(true);
    ChargerModObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    ChargerModObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule> FAREFREModuleHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule>> FAREFREModuleObj(FAREFREModuleHandler);
    FAREFREModuleObj.GetmyObjectRef();
    FAREFREModuleObj.GetmyPanelObjectRef();
    FAREFREModuleObj.SetFault(true);
    FAREFREModuleObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FAREFREModuleObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule> NetworkModuleHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule>> NetworkModuleObj(NetworkModuleHandler);
    NetworkModuleObj.GetmyObjectRef();
    NetworkModuleObj.GetmyPanelObjectRef();
    NetworkModuleObj.SetFault(true);
    NetworkModuleObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    NetworkModuleObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::IOModule> IOModuleHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::IOModule>> IOModuleObj(IOModuleHandler);
    IOModuleObj.GetmyObjectRef();
    IOModuleObj.GetmyPanelObjectRef();
    IOModuleObj.SetFault(true);
    IOModuleObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    IOModuleObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule> CPUModuleHandler{10, config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule>> CPUModuleObj(CPUModuleHandler);
    CPUModuleObj.GetmyObjectRef();
    CPUModuleObj.GetmyPanelObjectRef();
    CPUModuleObj.SetFault(true);
    CPUModuleObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    CPUModuleObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
    
    fireSystemState::KeySafeStateHandler KeySafeHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::KeySafeStateHandler> KeySafeObj(KeySafeHandler);
    KeySafeObj.GetmyObjectRef();
    KeySafeObj.GetmyPanelObjectRef();
    KeySafeObj.SetFault(true);
    KeySafeObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    KeySafeObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::FirePanelStateHandler FirePanelHandler{config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FirePanelStateHandler> FirePanelObj(FirePanelHandler);
    FirePanelObj.GetmyObjectRef();
    FirePanelObj.GetmyPanelObjectRef();
    FirePanelObj.SetFault(true);
    FirePanelObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FirePanelObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::FaultInputStateHandler FaultInputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultInputStateHandler> FaultInputObj(FaultInputHandler);
    FaultInputObj.GetmyObjectRef();
    FaultInputObj.GetmyPanelObjectRef();
    FaultInputObj.SetFault(true);
    FaultInputObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FaultInputObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::SerialPortStateHandler SerialPortHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::SerialPortStateHandler> SerialPortObj(SerialPortHandler);
    SerialPortObj.GetmyObjectRef();
    SerialPortObj.GetmyPanelObjectRef();
    SerialPortObj.SetFault(true);
    SerialPortObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    SerialPortObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::AlarmDeviceStateHandler AlarmDeviceHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmDeviceStateHandler> AlarmDeviceObj(AlarmDeviceHandler);
    AlarmDeviceObj.GetmyObjectRef();
    AlarmDeviceObj.GetmyPanelObjectRef();
    AlarmDeviceObj.SetFault(true);
    AlarmDeviceObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    AlarmDeviceObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::AlarmOutputStateHandler AlarmOutputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmOutputStateHandler> AlarmOutputObj(AlarmOutputHandler);
    AlarmOutputObj.GetmyObjectRef();
    AlarmOutputObj.GetmyPanelObjectRef();
    AlarmOutputObj.SetFault(true);
    AlarmOutputObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    AlarmOutputObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::FieldDeviceStateHandler FieldDeviceHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FieldDeviceStateHandler> FieldDeviceObj(FieldDeviceHandler);
    FieldDeviceObj.GetmyObjectRef();
    FieldDeviceObj.GetmyPanelObjectRef();
    FieldDeviceObj.SetFault(true);
    FieldDeviceObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FieldDeviceObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::BatteryPointStateHandler BatteryPointHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::BatteryPointStateHandler> BatteryPointObj(BatteryPointHandler);
    BatteryPointObj.GetmyObjectRef();
    BatteryPointObj.GetmyPanelObjectRef();
    BatteryPointObj.SetFault(true);
    BatteryPointObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    BatteryPointObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::ChargerPointStateHandler ChargerPointHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ChargerPointStateHandler> ChargerPointObj(ChargerPointHandler);
    ChargerPointObj.GetmyObjectRef();
    ChargerPointObj.GetmyPanelObjectRef();
    ChargerPointObj.SetFault(true);
    ChargerPointObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    ChargerPointObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::ControlInputStateHandler ControlInputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlInputStateHandler> ControlInputObj(ControlInputHandler);
    ControlInputObj.GetmyObjectRef();
    ControlInputObj.GetmyPanelObjectRef();
    ControlInputObj.SetFault(true);
    ControlInputObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    ControlInputObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::ControlOutputStateHandler ControlOutputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlOutputStateHandler> ControlOutputObj(ControlOutputHandler);
    ControlOutputObj.GetmyObjectRef();
    ControlOutputObj.GetmyPanelObjectRef();
    ControlOutputObj.SetFault(true);
    ControlOutputObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    ControlOutputObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::DetectionZoneStateHandler DetectionZoneHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::DetectionZoneStateHandler> DetectionZoneObj(DetectionZoneHandler);
    DetectionZoneObj.GetmyObjectRef();
    DetectionZoneObj.GetmyPanelObjectRef();
    DetectionZoneObj.SetFault(true);
    DetectionZoneObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    DetectionZoneObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::AuxDCOutputPointStateHandler AuxDCHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::AuxDCOutputPointStateHandler> AuxDCObj(AuxDCHandler);
    AuxDCObj.GetmyObjectRef();
    AuxDCObj.GetmyPanelObjectRef();
    AuxDCObj.SetFault(true);
    AuxDCObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    AuxDCObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::ExternalPSUPointStateHandler ExPSUHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ExternalPSUPointStateHandler> ExPSUObj(ExPSUHandler);
    ExPSUObj.GetmyObjectRef();
    ExPSUObj.GetmyPanelObjectRef();
    ExPSUObj.SetFault(true);
    ExPSUObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    ExPSUObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::FireRoutingOutputStateHandler FireRoutOpHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FireRoutingOutputStateHandler> FireRoutOpObj(FireRoutOpHandler);
    FireRoutOpObj.GetmyObjectRef();
    FireRoutOpObj.GetmyPanelObjectRef();
    FireRoutOpObj.SetFault(true);
    FireRoutOpObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FireRoutOpObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::FaultRoutingOutputStateHandler FaultRoutOpHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultRoutingOutputStateHandler> FaultRoutOpObj(FaultRoutOpHandler);
    FaultRoutOpObj.GetmyObjectRef();
    FaultRoutOpObj.GetmyPanelObjectRef();
    FaultRoutOpObj.SetFault(true);
    FaultRoutOpObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    FaultRoutOpObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::TechnicalAlarmInputStateHandler TechAlarmIpHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::TechnicalAlarmInputStateHandler> TechAlarmIpObj(TechAlarmIpHandler);
    TechAlarmIpObj.GetmyObjectRef();
    TechAlarmIpObj.GetmyPanelObjectRef();
    TechAlarmIpObj.SetFault(true);
    TechAlarmIpObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    TechAlarmIpObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

    fireSystemState::CommonFireOutputPointStateHandler CommonFireOpPtHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::CommonFireOutputPointStateHandler> CommonFireOpPtObj(CommonFireOpPtHandler);
    CommonFireOpPtObj.GetmyObjectRef();
    CommonFireOpPtObj.GetmyPanelObjectRef();
    CommonFireOpPtObj.SetFault(true);
    CommonFireOpPtObj.ReceiveFaultEventUT(event, 0, PROC_ADDRESS::MODULE_APP);
    CommonFireOpPtObj.ReceiveResetCommand(command, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);

}

TEST(CommonFaultEventStateHandlerUT, SendFaultEventTestAllHandlers)
{
    auto faultEvent = std::make_shared<Mol::Event::FaultEvent>();
    auto faultClearedEvent = std::make_shared<Mol::Event::FaultClearedEvent>();

    fireSystemState::FPOStateHandler FpoHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FPOStateHandler> FpoObj(FpoHandler);
    FpoObj.SendFaultEvent(faultEvent);
    FpoObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::LoopStateHandler LoopHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::LoopStateHandler> LoopObj(LoopHandler);
    LoopObj.SendFaultEvent(faultEvent);
    LoopObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::XmlElementConfig config;
    fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule> LoopModHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::LoopModule>> LoopModObj(LoopModHandler);
    LoopModObj.SendFaultEvent(faultEvent);
    LoopModObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms> SerialComHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::SerialComms>> SerialComObj(SerialComHandler);
    SerialComObj.SendFaultEvent(faultEvent);
    SerialComObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule> FATFBFModHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FATFBFModule>> FATFBFModObj(FATFBFModHandler);
    FATFBFModObj.SendFaultEvent(faultEvent);
    FATFBFModObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule> ChargerModHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::ChargerModule>> ChargerModObj(ChargerModHandler);
    ChargerModObj.SendFaultEvent(faultEvent);
    ChargerModObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule> FAREFREModuleHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::FAREFREModule>> FAREFREModuleObj(FAREFREModuleHandler);
    FAREFREModuleObj.SendFaultEvent(faultEvent);
    FAREFREModuleObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule> NetworkModuleHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::NetworkModule>> NetworkModuleObj(NetworkModuleHandler);
    NetworkModuleObj.SendFaultEvent(faultEvent);
    NetworkModuleObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::IOModule> IOModuleHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::IOModule>> IOModuleObj(IOModuleHandler);
    IOModuleObj.SendFaultEvent(faultEvent);
    IOModuleObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule> CPUModuleHandler{10,config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ModuleStateHandler<Dol::Entities::CPUModule>> CPUModuleObj(CPUModuleHandler);
    CPUModuleObj.SendFaultEvent(faultEvent);
    CPUModuleObj.SendFaultClearedEvent(faultClearedEvent);
    
    fireSystemState::KeySafeStateHandler KeySafeHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::KeySafeStateHandler> KeySafeObj(KeySafeHandler);
    KeySafeObj.SendFaultEvent(faultEvent);
    KeySafeObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::FirePanelStateHandler FirePanelHandler{config};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FirePanelStateHandler> FirePanelObj(FirePanelHandler);
    FirePanelObj.SendFaultEvent(faultEvent);
    FirePanelObj.SendFaultClearedEvent(faultClearedEvent);
    Mol::DataType::ObjectReference pointPanelRef;
    uint64_t pointID = 10;
    FirePanelObj.PointFromThisPanel(pointID, pointPanelRef);

    fireSystemState::FaultInputStateHandler FaultInputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultInputStateHandler> FaultInputObj(FaultInputHandler);
    FaultInputObj.SendFaultEvent(faultEvent);
    FaultInputObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::SerialPortStateHandler SerialPortHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::SerialPortStateHandler> SerialPortObj(SerialPortHandler);
    SerialPortObj.SendFaultEvent(faultEvent);
    SerialPortObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::AlarmDeviceStateHandler AlarmDeviceHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmDeviceStateHandler> AlarmDeviceObj(AlarmDeviceHandler);
    AlarmDeviceObj.SendFaultEvent(faultEvent);
    AlarmDeviceObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::AlarmOutputStateHandler AlarmOutputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::AlarmOutputStateHandler> AlarmOutputObj(AlarmOutputHandler);
    AlarmOutputObj.SendFaultEvent(faultEvent);
    AlarmOutputObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::FieldDeviceStateHandler FieldDeviceHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FieldDeviceStateHandler> FieldDeviceObj(FieldDeviceHandler);
    FieldDeviceObj.SendFaultEvent(faultEvent);
    FieldDeviceObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::BatteryPointStateHandler BatteryPointHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::BatteryPointStateHandler> BatteryPointObj(BatteryPointHandler);
    BatteryPointObj.SendFaultEvent(faultEvent);
    BatteryPointObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::ChargerPointStateHandler ChargerPointHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ChargerPointStateHandler> ChargerPointObj(ChargerPointHandler);
    ChargerPointObj.SendFaultEvent(faultEvent);
    ChargerPointObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::ControlInputStateHandler ControlInputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlInputStateHandler> ControlInputObj(ControlInputHandler);
    ControlInputObj.SendFaultEvent(faultEvent);
    ControlInputObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::ControlOutputStateHandler ControlOutputHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ControlOutputStateHandler> ControlOutputObj(ControlOutputHandler);
    ControlOutputObj.SendFaultEvent(faultEvent);
    ControlOutputObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::DetectionZoneStateHandler DetectionZoneHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::DetectionZoneStateHandler> DetectionZoneObj(DetectionZoneHandler);
    DetectionZoneObj.SendFaultEvent(faultEvent);
    DetectionZoneObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::AuxDCOutputPointStateHandler AuxDCHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::AuxDCOutputPointStateHandler> AuxDCObj(AuxDCHandler);
    AuxDCObj.SendFaultEvent(faultEvent);
    AuxDCObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::ExternalPSUPointStateHandler ExPSUHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::ExternalPSUPointStateHandler> ExPSUObj(ExPSUHandler);
    ExPSUObj.SendFaultEvent(faultEvent);
    ExPSUObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::FireRoutingOutputStateHandler FireRoutOpHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FireRoutingOutputStateHandler> FireRoutOpObj(FireRoutOpHandler);
    FireRoutOpObj.SendFaultEvent(faultEvent);
    FireRoutOpObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::FaultRoutingOutputStateHandler FaultRoutOpHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::FaultRoutingOutputStateHandler> FaultRoutOpObj(FaultRoutOpHandler);
    FaultRoutOpObj.SendFaultEvent(faultEvent);
    FaultRoutOpObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::TechnicalAlarmInputStateHandler TechAlarmIpHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::TechnicalAlarmInputStateHandler> TechAlarmIpObj(TechAlarmIpHandler);
    TechAlarmIpObj.SendFaultEvent(faultEvent);
    TechAlarmIpObj.SendFaultClearedEvent(faultClearedEvent);

    fireSystemState::CommonFireOutputPointStateHandler CommonFireOpPtHandler{10,fireSystemState::XmlElementConfig{}};
    fireSystemState::CommonFaultEventStateHandler<fireSystemState::CommonFireOutputPointStateHandler> CommonFireOpPtObj(CommonFireOpPtHandler);
    CommonFireOpPtObj.SendFaultEvent(faultEvent);
    CommonFireOpPtObj.SendFaultClearedEvent(faultClearedEvent);

}