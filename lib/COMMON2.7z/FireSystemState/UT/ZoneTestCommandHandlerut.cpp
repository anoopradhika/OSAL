#include "gmock/gmock.h"
#include "ZoneTestCommandHandlerut.h"
#include "Utility.h"
#include "StateHandler/FaultInputStateHandler.h"
#include "StateHandler/FPOStateHandler.h"
#include "StateHandler/AlarmZoneStateHandler.h"
#include "StateHandler/AlarmDeviceStateHandler.h"
#include "StateHandler/AlarmOutputStateHandler.h"
#include "StateHandler/ControlOutputStateHandler.h"
#include "StateHandler/ControlZoneStateHandler.h"
#include "StateHandler/FireRoutingOutputStateHandler.h"
#include "StateHandler/DetectionZoneStateHandler.h"

TEST(ZoneTestCommandHandlerTest, SetupTest)
{
	Utility::RunShellCommand( "mkdir /config/config1/");
	Utility::RunShellCommand( "touch /config/config1/active");
	Utility::RunShellCommand( "cp ../LIBRARIES/COMMON/FireSystemState/UT/configuration.xml /config/config1/configuration.xml");
	Utility::RunShellCommand( "sync");


    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FaultInputStateHandler handler{72058719336268547, config};
    fireSystemState::ZoneTestCommandHandlerTest<fireSystemState::FaultInputStateHandler>  testobject(handler);
    testobject.Rcvzoneteststartcommand();
    testobject.RcvReceiveZoneTestStopCommand();

    fireSystemState::DetectionZoneStateHandler handler1{72058719336268548, config};
    fireSystemState::ZoneTestCommandHandlerTest<fireSystemState::DetectionZoneStateHandler>  testobject1(handler1);
    testobject1.Rcvzoneteststartcommand();
    testobject1.RcvReceiveZoneTestStopCommand();
}

TEST(DelayOperationHandler, ReceiveDelayOperation )
{
	Utility::RunShellCommand( "mkdir /config/config1/");
	Utility::RunShellCommand( "touch /config/config1/active");
	Utility::RunShellCommand( "cp ../LIBRARIES/COMMON/FireSystemState/UT/configuration.xml /config/config1/configuration.xml");
	Utility::RunShellCommand( "sync");

	fireSystemState::XmlElementConfig config;
	config.id = 0x100010000000000;//72058693549555712
	config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
	config.key = "/configuration/site/building/managed_area[@id=1]/zone";

	fireSystemState::FaultInputStateHandler handler{72058719336268547, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::FaultInputStateHandler>  testobject(handler);
	testobject.RcvReceiveDelayOperation();

	fireSystemState::FPOStateHandler handler1{72058719336268548, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::FPOStateHandler>  testobject1(handler1);
	testobject1.RcvReceiveDelayOperation();

	fireSystemState::AlarmZoneStateHandler handler2{72058719336268549, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::AlarmZoneStateHandler>  testobject2(handler2);
	testobject2.RcvReceiveDelayOperation();


	fireSystemState::AlarmDeviceStateHandler handler3{72058719336268550, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::AlarmDeviceStateHandler>  testobject3(handler3);
	testobject3.RcvReceiveDelayOperation();

	fireSystemState::AlarmOutputStateHandler handler4{72058719336268551, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::AlarmOutputStateHandler>  testobject4(handler4);
	testobject4.RcvReceiveDelayOperation();

	fireSystemState::ControlZoneStateHandler handler5{72058719336268552, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::ControlZoneStateHandler>  testobject5(handler5);
	testobject5.RcvReceiveDelayOperation();

	fireSystemState::FireRoutingOutputStateHandler handler6{72058719336268553, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::FireRoutingOutputStateHandler>  testobject6(handler6);
	testobject6.RcvReceiveDelayOperation();

	fireSystemState::ControlOutputStateHandler handler7{72058719336268554, config};
	fireSystemState::DelayOperationHandlerTest<fireSystemState::ControlOutputStateHandler>  testobject7(handler7);
	testobject7.RcvReceiveDelayOperation();

}

