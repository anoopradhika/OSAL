/******************************************************************************//**
* @file FirePanelStateHandlerTest.h
* @brief Test case verify EventProviderService Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef ALARM_ZONE_STATE_UT_H
#define ALARM_ZONE_STATE_UT_H

#include "StateHandler/AlarmZoneStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class AlarmZoneStateHandlerTest : public AlarmZoneStateHandler
    {
    public:
        AlarmZoneStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            AlarmZoneStateHandler(id, element)
        {
        }
        ~AlarmZoneStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
			EnableAction();
		}

	   void FunctionDisableEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void FunctionDisableEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void FunctionEnbleEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void FunctionEnbleEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void AlarmSignalEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(1);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveAlarmSignalEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void AlarmSignalEvent()
		{
			auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(0);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveAlarmSignalEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void UserOperationEventTest()
		{
			auto event=std::make_shared<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			UserOperationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvSetAlarmSignal()
		{
			auto event=std::make_shared<Mol::Command::SetAlarmSignal>(1);
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
			ReceiveSetAlarameSignalCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvSetAlarmSignalVal()
		{
			auto event=std::make_shared<Mol::Command::SetAlarmSignal>(0);
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
			ReceiveSetAlarameSignalCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }

        bool AddAlaramSignalFromAnotherPanelTestChildEvent()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(1);
            Mol::DataType::ObjectReference source{1, Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE};
            event->SetSource(source);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            AddAlaramSignalFromAnotherPanel(event);
            return (thisPanelHasAlarmSignal == false && m_alarmSignalPanels.empty());
        }

        bool AddAlaramSignalFromAnotherPanelTestNotFromNetwork()
        {
            uint32_t signalID = 1;
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(signalID);
            Mol::DataType::ObjectReference source{10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE};
            event->SetSource(source);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            AddAlaramSignalFromAnotherPanel(event);
            return (thisPanelHasAlarmSignal == true && m_alarmSignalPanels.empty());
        }

        bool AddAlaramSignalFromAnotherPanelTestFromNetworkNoParent()
        {
            uint32_t signalID = 1;
            thisPanelHasAlarmSignal = false;
            auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(signalID);
            Mol::DataType::ObjectReference source{10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE};
            event->SetSource(source);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            std::string param = "ID2NET_Network";
            event->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, param);
            AddAlaramSignalFromAnotherPanel(event);
            return (thisPanelHasAlarmSignal == false && m_alarmSignalPanels.empty());
        }

        bool AddAlaramSignalFromAnotherPanelTestFromNetworkWithParent()
        {
            uint32_t signalID = 1;
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            auto event=std::make_shared<Mol::Event::AlarmSignalEvent>(signalID);
            Mol::DataType::ObjectReference source{10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE};
            event->SetSource(source);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            std::string param = "ID2NET_Network";
            event->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, param);
            Mol::DataType::ObjectReference parentPanel{2, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->AddParent(parentPanel);
            AddAlaramSignalFromAnotherPanel(event);
            return (thisPanelHasAlarmSignal == false && !m_alarmSignalPanels.empty());
        }

        bool  ProcessPanelFailoverTestNullptr()
        {
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            event = nullptr;
            ProcessPanelFailover(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
            return (currentErrorCode  == ERROR_CODE::NULL_FAULT_EVENT);
        }

        bool ProcessPanelFailoverTestIgnorFDA()
        {
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            ProcessPanelFailover(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
            return (currentErrorCode  == ERROR_CODE::IGNOR_INTERNAL_EVENT);
        }

        bool ProcessPanelFailoverTestIgnorEvent()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
            return (currentErrorCode  == ERROR_CODE::IGNOR_EVENT);
        }

        bool ProcessPanelFailoverTestIgnorMyPanelFailure()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            m_alarmSignalPanels.insert({1, false});
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source{0x100020010000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->SetSource(source);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
            return (currentErrorCode  == ERROR_CODE::IGNOR_EVENT);
        }

        bool ProcessPanelFailoverTestIgnorPanelFailureIfNoAlaramSignal()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            m_alarmSignalPanels.insert({1, false});
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source{0x100030010000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->SetSource(source);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
            return (currentErrorCode  == ERROR_CODE::IGNOR_IF_NOT_SAME_PANEL);
        }

        bool ProcessPanelFailoverTestGoodSenario()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            m_alarmSignalPanels.insert({3, false});
            m_myPanelObjectRef = Mol::DataType::ObjectReference{0x100020000000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            auto event=std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source{0x100030010000000, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL};
            event->SetSource(source);
            ProcessPanelFailover(event,10,PROC_ADDRESS::CMCAPP);
            return (m_alarmSignalPanels[3]  == true);
        }

        bool ReceiveResetCommandTestNullPtr()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            auto cmd=std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            cmd->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            cmd = nullptr;
            ReceiveResetCommand(cmd,10,PROC_ADDRESS::CMCAPP);
            return (currentErrorCode  == ERROR_CODE::NULL_FAULT_EVENT);
        }

        bool ReceiveResetCommandTestNotManagedArea()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            auto cmd=std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            cmd->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            ReceiveResetCommand(cmd,10,PROC_ADDRESS::CMCAPP);
            return (currentErrorCode  == ERROR_CODE::NULL_FAULT_EVENT);
        }

        bool ReceiveResetCommandTestNotAllPnelsLost()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            m_alarmSignalPanels.insert({1, true});
            m_alarmSignalPanels.insert({2, false});
            auto ma = std::make_shared<Dol::Entities::ManagedArea>(1);
            AddManagedArea(ma);
            auto cmd=std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            cmd->SetCommandTarget({1, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
            ReceiveResetCommand(cmd,10,PROC_ADDRESS::CMCAPP);
            return (!m_alarmSignalPanels.empty());
        }

        bool ReceiveResetCommandTestAllPnelsLost()
        {
            thisPanelHasAlarmSignal = false;
            m_alarmSignalPanels.clear();
            m_alarmSignalPanels.insert({1, true});
            m_alarmSignalPanels.insert({2, true});
            auto ma = std::make_shared<Dol::Entities::ManagedArea>(1);
            AddManagedArea(ma);
            auto cmd=std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            cmd->SetCommandTarget({1, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
            ReceiveResetCommand(cmd,10,PROC_ADDRESS::CMCAPP);
            return (m_alarmSignalPanels.empty());
        }

        bool ReceiveResetCommandTestAllPnelsLostAndthisPanelHasAlarmSignal()
        {
            thisPanelHasAlarmSignal = true;
            m_alarmSignalPanels.clear();
            m_alarmSignalPanels.insert({1, true});
            m_alarmSignalPanels.insert({2, true});
            auto ma = std::make_shared<Dol::Entities::ManagedArea>(1);
            AddManagedArea(ma);
            auto cmd=std::make_shared<Mol::Command::Reset>(Mol::Command::RESET_TYPE_CODE::GENERAL);
            cmd->SetCommandTarget({1, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
            ReceiveResetCommand(cmd,10,PROC_ADDRESS::CMCAPP);
            return (m_alarmSignalPanels.empty());
        }
    };
}
#endif //ALARM_ZONE_STATE_UT_H
