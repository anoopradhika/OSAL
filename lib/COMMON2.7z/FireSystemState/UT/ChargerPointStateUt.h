#ifndef CHARGER_POINT_STATE_UT_H
#define CHARGER_POINT_STATE_UT_H

#include "StateHandler/ChargerPointStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class ChargerPointStateHandlerTest : public ChargerPointStateHandler
    {
    public:
        ChargerPointStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            ChargerPointStateHandler(id, element)
        {
        }
        ~ChargerPointStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvActivationEvent()
		{
			auto activationEvent = std::make_shared<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			activationEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(activationEvent, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvActivationEventDeactivate()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvDisablementEvent()
		{
			auto disableEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
			disableEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(disableEvent, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvDisablementEventEnable()
		{
			auto disableEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
			disableEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(disableEvent, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event, 0, PROC_ADDRESS::END_OF_LIST);
		}

		void RcvActivationCmd()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDeActivationCmd()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvDeActivationCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}
		void RcvMultiQueryRequest()
		{
			auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
			multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CHARGER});
			multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);
			
			auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
			multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CHARGER});
			multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

			auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
			multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CHARGER});
			multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);
			
			auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
			multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
			multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
		}

    };
}

#endif //CHARGER_POINT_STATE_UT_H
