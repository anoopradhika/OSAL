#include "gmock/gmock.h"
#include "FirePanelStateHandlerTest.h"
#include "Utility.h"

TEST(FirePanelStateHandlerUT, SetupSignalTestWithReset)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FirePanelStateHandlerTest testobject{config};
    testobject.TestPreper();
    EXPECT_TRUE(testobject.SetupSignalTestWithReset());
}

TEST(FirePanelStateHandlerUT, MainCPUModuleReceivedTestInvalidEvent)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FirePanelStateHandlerTest testobject{config};
    EXPECT_TRUE(testobject.MainCPUModuleReceivedTestInvalidEvent());
}

TEST(FirePanelStateHandlerUT, MainCPUModuleReceivedTestInvalidCatalog)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FirePanelStateHandlerTest testobject{config};
    EXPECT_TRUE(testobject.MainCPUModuleReceivedTestInvalidCatalog());
}

TEST(FirePanelStateHandlerUT, MainCPUModuleReceivedTestNullModule)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FirePanelStateHandlerTest testobject{config};
    EXPECT_TRUE(testobject.MainCPUModuleReceivedTestNullModule());
}

TEST(FirePanelStateHandlerUT, MainCPUModuleReceivedTestIncorrectModuleType)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FirePanelStateHandlerTest testobject{config};
    EXPECT_TRUE(testobject.MainCPUModuleReceivedTestIncorrectModuleType());
}

TEST(FirePanelStateHandlerUT, MainCPUModuleReceivedTestNotCorrectMainCPUAddress)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    fireSystemState::FirePanelStateHandlerTest testobject{config};
    testobject.RcvReceiveUserAccessEvent();
    EXPECT_TRUE(testobject.MainCPUModuleReceivedTestNotCorrectMainCPUAddress());
}

TEST(FirePanelStateHandlerUT, MainCPUModuleReceivedTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    auto testobject =  std::make_shared<fireSystemState::FirePanelStateHandlerTest>(config);
    EXPECT_TRUE(testobject->MainCPUModuleReceivedTest());
}


TEST(FirePanelStateHandlerUT, SerializeDeserializeTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
    config.key = "/configuration/site/fire_panel[@panel_id=72058693549555712]";

    auto testobject =  std::make_shared<fireSystemState::FirePanelStateHandler>(config);
    testobject->SetPanelNumber(5);
    testobject->SetPanelType(Dol::PanelType::MODULAR_PANEL);
    testobject->SetPanelSoftwareVersion("SoftwareVersion");
    testobject->SetPanelHardwareVersion("HardwareVersion");
    testobject->SetPanelIPv6Address("IPv6Address");
    testobject->SetPanelConfigVersion("ConfigVersion");

    std::stringstream outstream;
    cereal::BinaryOutputArchive oarchive { outstream };
    oarchive(testobject);
    auto serializedStr = outstream.str();

    std::shared_ptr<Dol::Entities::FirePanel> deserializedObject;
    std::stringstream dataStream(serializedStr);
    cereal::BinaryInputArchive inputArchive(dataStream);
    inputArchive(deserializedObject);

    EXPECT_TRUE(deserializedObject->GetPanelNumber() == 5);
    EXPECT_TRUE(deserializedObject->GetPanelType() == Dol::PanelType::MODULAR_PANEL);
    EXPECT_TRUE(deserializedObject->GetPanelSoftwareVersion() == "SoftwareVersion");
    EXPECT_TRUE(deserializedObject->GetPanelHardwareVersion() == "HardwareVersion");
    EXPECT_TRUE(deserializedObject->GetPanelIPv6Address() == "IPv6Address");
    EXPECT_TRUE(deserializedObject->GetPanelConfigVersion() == "ConfigVersion");
}
TEST(FirePanelStateHandlerUT, DomainConfigTest)
{
    fireSystemState::DomainConfigurationHandle::GetInstance();
    fireSystemState::DomainConfiguration DoaminConfigObj;
    uint8_t loops=0,repeaters=0;
    DoaminConfigObj.GetNumberOfLoops(loops,repeaters);
    std::string panelLanguage = DoaminConfigObj.GetCurrentLanguage();
}



TEST(FirePanelStateHandlerUT, ObjectDataRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    std::shared_ptr<fireSystemState::FirePanelStateHandler> firePanelObj = std::make_shared<fireSystemState::FirePanelStateHandler>(config);
	std::shared_ptr<Mol::Request::ObjectData> request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS);
	Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;
	auto zoneid = 72058693549555712;
	Mol::DataType::ObjectReference target(zoneid,type);
	request->SetSourceTarget(target);
	firePanelObj->Init();
	firePanelObj->Prepare();
	firePanelObj->Start();

    firePanelObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN);
	request->SetSourceTarget(target);
    firePanelObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::END_OF_LIST);
	request->SetSourceTarget(target);
    firePanelObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	type = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    Mol::DataType::ObjectReference targetAlarm(zoneid,type);
    request->SetSourceTarget(targetAlarm);
    firePanelObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

    firePanelObj->ReceiveObjectData(NULL,zoneid,PROC_ADDRESS::CMCAPP);

    firePanelObj->Stop();
    firePanelObj->Shutdown();
    firePanelObj->Uninit();
}
