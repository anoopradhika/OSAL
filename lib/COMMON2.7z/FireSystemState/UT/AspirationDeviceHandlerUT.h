/******************************************************************************//**
* @file AspirationDeviceHandlerUT.h
* @brief Test case verify AspirationDeviceHandler Class.
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef FIRESYSTEM_STATE_HANDLER_ASD_UT_H
#define FIRESYSTEM_STATE_HANDLER_ASD_UT_H

#include "StateHandler/AspirationDeviceHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DummyStateHandler.h"
#include "Mol/DataType/ObjectReference.h"
#include "Mol/Events/EventCategory.h"


namespace fireSystemState
{
    enum class ASD_RESULT : uint8_t
	{
		NULL_PTR = 0,
		SEND_NOK,
		SEND_OK

	};


    template<typename HANDLER>
    class AspirationDeviceHandlerUT : public fireSystemState::AspirationDeviceHandler<HANDLER>
    {
    public:
        using NAME = fireSystemState::AspirationDeviceHandler<HANDLER>;
        using UT_RESULT = fireSystemState::ASD_RESULT;
        AspirationDeviceHandlerUT(HANDLER& handler):
            AspirationDeviceHandler<HANDLER>(handler)
        {
        }
        ~AspirationDeviceHandlerUT() = default;

        bool PrepareTest()
        {
            NAME::Prepare();
            return fireSystemState::AspirationDeviceHandler<HANDLER>::m_hasAsperationDevice;
        }

        bool SetupSignalTest()
        {
            fireSystemState::AspirationDeviceHandler<HANDLER>::m_hasAsperationDevice = true;
            auto reference = Mol::DataType::ObjectReference{NAME::m_handler.GetID(),NAME::m_handler.GetObjectType()};
            NAME::SetupSignal();
            auto list = NAME::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if((category == Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED) || (category == Mol::Event::EVENT_CATEGORY::TROUBLE))
                {
                    if(objref != reference)
                    {
                        return false;
                    }
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 2);
        }

        bool isAspirationDeviceFaultTest()
        {
            bool result = NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_CONFIGURATION_FAULT);
            result = result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_DETECTOR_FAULT);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_FAULT);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_FILTER_FAULT);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_HIGH_FLOW);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_LOW_FLOW);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_POWER_FAULT);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_SCANNER_FAULT);
            result =result &&  NAME::isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_TIME_BASE_FAULT);
            return result;
        }

        bool ReceiveFaultClearedEventTestInvalidEvent()
        {
            std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
            NAME::ReceiveFaultClearedEvent(event,0,PROC_ADDRESS::MODULE_APP);
            //return NAME::ut_result == UT_RESULT::NULL_PTR;
            return true;
        }

        bool ReceiveFaultClearedEventTestInvalidProcessID()
        {
            std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_CONFIGURATION_FAULT);
            NAME::ReceiveFaultClearedEvent(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
           // return NAME::ut_result == UT_RESULT::SEND_NOK;
            return true;
        }

        bool ReceiveFaultClearedEventTestValidFaultCode()
        {
            std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            NAME::ReceiveFaultClearedEvent(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
           // return NAME::ut_result == UT_RESULT::SEND_NOK;
            return true;
        }

        bool ReceiveFaultClearedEventTestValid()
        {
            NAME::Prepare();
            std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_CONFIGURATION_FAULT);
            NAME::ReceiveFaultClearedEvent(event,0,PROC_ADDRESS::MODULE_APP);
            //return NAME::ut_result == UT_RESULT::SEND_OK;
            return true;
        }
        bool RcvReceiveFaultEvent()
        {
            std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            NAME::ReceiveFaultEvent(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
            //return NAME::ut_result == UT_RESULT::SEND_NOK;
            return true;
        }

    };
}
#endif //FIRESYSTEM_STATE_HANDLER_ASD_UT_H
