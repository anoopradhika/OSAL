#include "gmock/gmock.h"
#include "FaultRoutingOutputStateHandlerUt.h"
#include "Mol/Responses/GeneralIndicatorServiceResponse.h"
#include "Utility.h"

TEST(FaultRoutingOutputStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FaultRoutingOutputStateHandlerTest testobject(10,config);
    testobject.Setup_Test();

    bool FaultStatus = testobject.GetFaultStatus();
    EXPECT_EQ(FaultStatus,false);
}

TEST(FaultRoutingOutputStateHandlerTestUT, EventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FaultRoutingOutputStateHandlerTest testobject(10,config);

    testobject.RcvFunctionDisablementEvent();
    testobject.RcvFunctionDisablementEventNoFDA();
    testobject.RcvFunctionEnableEvent();
    testobject.RcvFunctionEnableEventNoFDA();
    testobject.RcvActivationEvent();
    testobject.RcvActivationEventNoFDA();
    testobject.RcvActivationEventDeactivate();
    testobject.RcvActivationEventNoFDA();
    testobject.RcvFunctionDisablementEventNoFDA();
    testobject.ProcModuleConnectedEvent();
    testobject.RcvFaultResponseNotification();
}

TEST(FaultRoutingOutputStateHandlerTestUT, CommandTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FaultRoutingOutputStateHandlerTest testobject(10,config);

    testobject.SendActivateCommand();
    testobject.SendDeactivateCommand();
    testobject.RcvActivateCommand();
    testobject.RcvDeActivateCommand();
}

TEST(FaultRoutingOutputStateHandlerTestUT, FaultResponseNotificationTest)
{
    fireSystemState::XmlElementConfig config;
    fireSystemState::FaultRoutingOutputStateHandlerTest testobject(10,config);

    testobject.FaultResponseNotification(std::make_shared<Mol::Response::GeneralIndicatorServiceResponse>(0xFFFFFFFF),0);
//    EXPECT_EQ(testobject.m_faultStatus,true); //Private functions used.
    testobject.FaultResponseNotification(std::make_shared<Mol::Response::GeneralIndicatorServiceResponse>(0),0);
//    EXPECT_EQ(testobject.m_faultStatus,false);
}


