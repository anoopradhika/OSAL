#include "gmock/gmock.h"
#include "AlarmDeviceStateUt.h"
#include "Utility.h"

TEST(AlarmDeviceStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.Setup_Test();
    testobject.EnableAction();
}

TEST(AlarmDeviceStateHandlerTestUT, FunctionEnableEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.RcvDisablementEvent();
    testobject.RcvDisablementEventNoFDA();
    testobject.RcvFunctionEnbleEvent();
    testobject.RcvFunctionEnbleEventNoFDA();
}

TEST(AlarmDeviceStateHandlerTestUT, FunctionDisableEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.RcvDisablementEvent();
    testobject.RcvDisablementEventNoFDA();
}

TEST(AlarmDeviceStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
}

TEST(AlarmDeviceStateHandlerTestUT, AlramEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.AlarmSignalEventNoFDA();
    testobject.AlarmSignalEvent();
}

TEST(AlarmDeviceStateHandlerTestUT, UserOperationEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.UserOperationEventTest();
}

TEST(AlarmDeviceStateHandlerTestUT, RcvSetAlarmSignalTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    testobject.RcvSetAlarmSignal();
    testobject.RcvSetAlarmSignalVal();
    testobject.RcvSetAlarmSignalNoFDA();
    testobject.RcvSetAlarmSignalValNoFDA();
}

TEST(AlarmDeviceStateHandlerTestUT, ReceiveFaultEventTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmDeviceStateHandlerTest testobject{10,config};
    EXPECT_TRUE(testobject.ReceiveFaultClearedEventTestIgnoreFDAEvents());
    EXPECT_TRUE(testobject.ReceiveFaultClearedEventTest());
    EXPECT_TRUE(testobject.ReceiveFaultEventTestINullPtr());
    EXPECT_TRUE(testobject.ReceiveFaultClearedEventTestINullPtr());
    EXPECT_TRUE(testobject.ReceiveResetCommandIncorrectCommandTest());
    EXPECT_TRUE(testobject.ReceiveResetCommandCorrectCommandTest());
}


