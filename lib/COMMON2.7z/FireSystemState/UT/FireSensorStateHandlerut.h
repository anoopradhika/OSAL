#include "StateHandler/FireSensorStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

#ifndef FIRESENSOR_STATEHANDLER_UT_H
#define FIRESENSOR_STATEHANDLER_UT_H

namespace fireSystemState
{
    class FireSensorStateHandlerTest : public FireSensorStateHandler
	{
    public:
    	FireSensorStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		FireSensorStateHandler(id, element)
        {
        }

        ~FireSensorStateHandlerTest() override = default;
        void Setupsignal()
        {
        	SetupSignal();
        }
        void RcvReceiveSensitivityCommand()
        {
        	auto command=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE);
           	ReceiveSensitivityCommand(command,10,PROC_ADDRESS::BROADCAST);

        }
        void RcvReceiveDeactivateLedCommand()
        {
        	auto command=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::DEACTIVATE);
        	ReceiveDeactivateLedCommand(command,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
        }

        void RcvReceiveFaultEvent()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            this->GetmyPanelObjectRef();
        }

    };
}
#endif //FIRESENSOR_STATEHANDLER_UT_H
