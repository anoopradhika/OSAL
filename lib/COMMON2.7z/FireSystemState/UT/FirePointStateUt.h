#ifndef FIELD_DEVICE_STATE_UT_H
#define FIELD_DEVICE_STATE_UT_H

#include "StateHandler/FireSensorStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FireSensorStateHandlerTest : public FireSensorStateHandler
    {
    public:
        FireSensorStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FireSensorStateHandler(id, element)
        {
        }
        ~FireSensorStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::DisablementEvent>();
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveDisablementEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvAlarmEvent()
		{
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058702156398848, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{1101,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent(parent);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::CMCAPP);
		}

		void RcvResetCommand()
		{
			auto command = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::GENERAL);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
			auto managedarea = 1;
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(managedarea, type);
			command->SetCommandTarget(target);
			ReceiveResetCommand(command, 0,PROC_ADDRESS::MODULE_APP);
		}

		void RcvTestEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationLedCmd()
		{
			auto event=std::make_shared<Mol::Command::ActivateLed>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateLedCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationLEDCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::ActivateLed>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateLedCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDeActivationLedCmd()
		{
			auto event=std::make_shared<Mol::Command::DeactivateLed>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateLedCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvDeActivationLedCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::DeactivateLed>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateLedCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

    };
}
#endif //FIELD_DEVICE_STATE_UT_H
