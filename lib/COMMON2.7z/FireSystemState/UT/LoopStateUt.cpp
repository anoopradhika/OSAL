#include "gmock/gmock.h"
#include "LoopStateUt.h"
#include "Utility.h"

TEST(LoopStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::LoopStateHandlerTest testobject{10,config};
    testobject.Setup_Test();
    fireSystemState::LoopStateHandlerTest testobject2{config};
    testobject2.Setup_Test();
}
