#include "gmock/gmock.h"
#include "DetectionZoneStateUt.h"
#include "Utility.h"

TEST(DetectionZoneStateHandlerTestUT, SetupTest)
{
    Utility::RunShellCommand( "mkdir /config/config1/");
    Utility::RunShellCommand( "touch /config/config1/active");
    Utility::RunShellCommand( "cp ../../../LIBRARIES/COMMON/FireSystemState/UT/configuration.xml /config/config1/configuration.xml");
    Utility::RunShellCommand( "sync");

    fireSystemState::XmlElementConfig config;
    config.id = 5;
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::DetectionZoneStateHandlerTest testobject(5,config);
    testobject.Setup_Test();
}

TEST(DetectionZoneStateHandlerTestUT, DisablementEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::DetectionZoneStateHandlerTest testobject(10,config);

    testobject.RcvDisablementEvent();
    testobject.RcvDisablementEventNoFDA();
    testobject.RcvDisablementEventEnabledNoFDA();
}

TEST(DetectionZoneStateHandlerTestUT, TestOperationEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::DetectionZoneStateHandlerTest testobject(10,config);
    testobject.RcvTestEvent();
    testobject.RcvTestEventNoFDA();
    testobject.RcvTestEventZoneRemovedNoFDA();
    testobject.RcvTestReceiveSensitivityCommand();
}

TEST(DetectionZoneStateHandlerTestUT, ObjectDataRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    std::shared_ptr<fireSystemState::DetectionZoneStateHandler> detectionObj = std::make_shared<fireSystemState::DetectionZoneStateHandler>(10,config);
	std::shared_ptr<Mol::Request::ObjectData> request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS);
	Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
	auto zoneid = 10;
	Mol::DataType::ObjectReference target(zoneid,type);
	request->SetSourceTarget(target);
	detectionObj->Prepare();
    detectionObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN);
	request->SetSourceTarget(target);
    detectionObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::END_OF_LIST);
	request->SetSourceTarget(target);
    detectionObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	type = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    Mol::DataType::ObjectReference targetAlarm(zoneid,type);
    request->SetSourceTarget(targetAlarm);
    detectionObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	detectionObj->ReceiveObjectData(NULL,zoneid,PROC_ADDRESS::CMCAPP);
}
TEST(DetectionZoneStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::DetectionZoneStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
}

TEST(DetectionZoneStateHandlerTestUT, ProcessPanelFailoverTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::DetectionZoneStateHandlerTest testobject{10, config};

    testobject.ClearRemotePanelLost();
    testobject.ProcessPanelFailoverTestNullptr();
    testobject.ProcessPanelFailoverTestIgnorFDA();
    testobject.ProcessPanelFailoverTestIgnorEvent();
    testobject.ProcessPanelFailoverTestIgnorMyPanelFailure();
    testobject.ProcessPanelFailoverTestIgnorPanelFailureIfNoAlaramSignal();
    testobject.ProcessPanelFailoverTestGoodSenario();
}


