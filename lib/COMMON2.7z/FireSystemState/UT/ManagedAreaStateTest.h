///******************************************************************************//**
//* @file     ManagedAreaStateTest.h
//* @brief
//*
//* @copyright Copyright 2019 by Honeywell International Inc.
//* All rights reserved.  This software and code comprise proprietary
//* information of Honeywell International Inc.  This software and code
//* may not be reproduced, used, altered, reengineered, distributed or
//* disclosed to others without the written consent of Honeywell.
//**********************************************************************************/
//#ifndef UT_MANAGEDAREA_STATE_TEST_H
//#define UT_MANAGEDAREA_STATE_TEST_H
//
//#include <iostream>
//
//#include "DOL/Entities/Site.h"
//#include "ACT/ACT.hpp"
//#include "StateHandler/BuildingStateHandler.h"
//#include "StateHandler/FirePanelStateHandler.h"
//#include "DomainConfiguration/DomainConfiguration.h"
//namespace fireSystemState
//{
//
///**
// * @brief   ManagedAreaState Class test
// */
//class ManagedAreaStateTest:  public platform::ACT, public Dol::Entities::Site, public fireSystemState::DomainConfiguration
//{
//public:
//
//protected:
//
//    /** Get MessagePort */
//    ManagedAreaStateTest()
//    {
//        AddComponent(std::make_shared<fireSystemState::BuildingStateHandler>(id));
//        // FirePanelConfig(firePanelConfig);
//        // for(auto& firePanel : firePanelConfig)
//        // {
//        //     std::cout<<"Herrrrrr "<<std::endl;
//        //     AddComponent(std::make_shared<fireSystemState::FirePanelStateHandler>(firePanel));
//        // }
//    }
//    /** Default destructor */
//    ~ManagedAreaStateTest() override = default;
//
//    /** Add test Setup here */
//    virtual void SetUp()
//    {
//        DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
//        DEBUGPRINT::SetOutStream(OutStream::STDOUT);
//        Init();
//        Prepare();
//    }
//
//    /** Add test cleanup here */
//    virtual void TearDown()
//    {
//        Stop();
//        Shutdown();
//        Uninit();
//    }
//
//    void Prepare() override
//    {
//        m_communicator.m_messageTransporter.Connect(m_address);
//        m_communicator.m_messageTransporter.Connect(m_broadCastGroup);
//        platform::ACT::Prepare();
//    }
//
//    uint64_t id = 1;
//    std::set<PROC_ADDRESS> m_broadCastGroup{PROC_ADDRESS::MOL_RECEIVER};
//    std::vector<fireSystemState::XmlElementConfig> firePanelConfig;
//};
//
//} // end namespace fireSystemState
//#endif // UT_MANAGEDAREA_STATE_TEST_H
