#ifndef CONTROL_ZONE_STATE_UT_H
#define CONTROL_ZONE_STATE_UT_H

#include "StateHandler/ControlZoneStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class ControlZoneStateHandlerTest : public ControlZoneStateHandler
    {
    public:
        ControlZoneStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            ControlZoneStateHandler(id, element)
        {
        }
        ~ControlZoneStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void RcvFunctionEnbleEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::CONTROL_INPUTS);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFunctionEnbleEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::CONTROL_INPUTS);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationEvent()
		{
			auto event=std::make_shared<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationEventDeactivateNoFDA()
		{
			auto event=std::make_shared<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivationCmd()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivationCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDeActivationCmd()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvDeActivationCmdNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}
		
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);
            
            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestOutputActive = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED);
            multiQueryRequestOutputActive->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            multiQueryRequestOutputActive->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestOutputActive,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);
            
            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
        }
    };
}
#endif //CONTROL_ZONE_STATE_UT_H
