#ifndef BASEFIREDETECTION_POINTSTATEHANDLER_UT_H
#define BASEFIREDETECTION_POINTSTATEHANDLER_UT_H

#include "DummyStateHandler.h"
#include "StateHandler/BaseFireDetectionPointStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
template<typename PointType ,typename HANDLER>
    class BaseFireDetectionPointStateHandlerTest : public BaseFireDetectionPointStateHandler<PointType,HANDLER>
	{
    public:
    	using BASE_HANDLER = fireSystemState::BaseFireDetectionPointStateHandler<PointType,HANDLER>;
    	BaseFireDetectionPointStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
    		BaseFireDetectionPointStateHandler<PointType,HANDLER>(id)
        {
        }

        ~BaseFireDetectionPointStateHandlerTest() override = default;
        void SetupTest()
        {
        	BASE_HANDLER::SetupSignal();
         }
        void RcvDeActivationLedCmd()
        {
        	auto event=std::make_shared<Mol::Event::EVENT_CATEGORY>(Mol::Event::EVENT_CATEGORY::END_OF_LIST);
        	BASE_HANDLER::ReceiveFaultEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
        }
    };
}
#endif //BASEFIREDETECTION_POINTSTATEHANDLER_UT_H
