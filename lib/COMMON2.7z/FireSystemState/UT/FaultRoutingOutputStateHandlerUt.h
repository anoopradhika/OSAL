#ifndef FAULT_ROUTING_OUTPUT_STATE_UT_H
#define FAULT_ROUTING_OUTPUT_STATE_UT_H

#include "StateHandler/FaultRoutingOutputStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FaultRoutingOutputStateHandlerTest : public FaultRoutingOutputStateHandler
    {
    public:
        FaultRoutingOutputStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FaultRoutingOutputStateHandler(id, element)
        {
        }
        ~FaultRoutingOutputStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}

		void ProcModuleConnectedEvent()
		{
			auto ie = std::make_shared< Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED);
			ProcessModuleConnectedEvent(ie,0);
		}

		void RcvActivationEvent()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}
	
		void RcvActivationEventNoFDA()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::CMCAPP);
		}
	
		void RcvActivationEventDeactivate()
		{
			auto event = std::make_shared< Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveActivationEvent(event,0,PROC_ADDRESS::CMCAPP);
		}

		void RcvActivateCommand()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvActivateCommandNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Activate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveActivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvDeActivateCommand()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}
	
		void RcvDeActivateCommandNoFDA()
		{
			auto event=std::make_shared<Mol::Command::Deactivate>();
			event->SetCommandTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
			ReceiveDeactivateCommand(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvFunctionDisablementEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::FAULT_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFunctionDisablementEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::FAULT_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionDisableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvFunctionEnableEvent()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::FAULT_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
		}

		void RcvFunctionEnableEventNoFDA()
		{
			auto event=std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::FAULT_ROUTING);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveFunctionEnableEvent(event,10,PROC_ADDRESS::CMCAPP);
		}

		void RcvFaultResponseNotification()
		{
			uint64_t senderID=1;
			auto event=std::make_shared<Mol::Message<Mol::Response::RESPONSE_CATEGORY>>(Mol::Response::RESPONSE_CATEGORY::GENERAL_INDICATOR_SERVICE_RESPONSE);
			FaultResponseNotification(event,senderID);
		}

    };
}

#endif //FAULT_ROUTING_OUTPUT_STATE_UT_H
