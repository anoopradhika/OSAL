///******************************************************************************//**
// * @file     ManagedAreaStateTest.cpp
// * @brief
// *
// * @copyright Copyright 2019 by Honeywell International Inc.
// * All rights reserved.  This software and code comprise proprietary
// * information of Honeywell International Inc.  This software and code
// * may not be reproduced, used, altered, reengineered, distributed or
// * disclosed to others without the written consent of Honeywell.
// **********************************************************************************/
//
//#include "ManagedAreaStateTest.h"
//
//namespace fireSystemState
//{
//    /**
//    * @brief   ManagedAreaState Class test
//    */
//    TEST_F(ManagedAreaStateTest, ReadValue)
//    {
//        WaitForResult(10000000000);
//        // UdevDeviceManager iio("iio");
//        // EXPECT_EQ(iio.MatchEntry("adc128s052"),TRUE);
//        // EXPECT_EQ(iio.MatchEntry("opt3001"),TRUE);
//        //
//        // UdevDeviceManager hwmon("hwmon");
//        // EXPECT_EQ(hwmon.MatchEntry("lm75"),TRUE);
//        // EXPECT_EQ(hwmon.MatchEntry("amc6821"),TRUE);
//        // EXPECT_EQ(hwmon.MatchEntry("imx_thermal_zone"),TRUE);
//    }
//} // end namespace DeviceManager
