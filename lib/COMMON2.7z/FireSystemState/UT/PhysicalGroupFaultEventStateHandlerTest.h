/******************************************************************************//**
* @file PhysicalGroupFaultEventStateHandlerTest.h
* @brief Test case verify PhysicalGroupFaultEventStateHandler Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef FIRESYSTEM_STATE_HANDLER_PHYSICAL_GROUP_FAULT_EVENT_TEST_H
#define FIRESYSTEM_STATE_HANDLER_PHYSICAL_GROUP_FAULT_EVENT_TEST_H

#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DummyStateHandler.h"

namespace fireSystemState
{
    template<typename HANDLER>
    class PhysicalGroupFaultEventStateHandlerTest : public fireSystemState::PhysicalGroupFaultEventStateHandler<HANDLER>
    {
    public:
        using NAME = fireSystemState::PhysicalGroupFaultEventStateHandlerTest<HANDLER>;
        PhysicalGroupFaultEventStateHandlerTest(DummyStateHandler handler):
            PhysicalGroupFaultEventStateHandler<HANDLER>(handler)
        {
        }
        ~PhysicalGroupFaultEventStateHandlerTest() = default;

        bool SetupSignalTestNotByReset()
        {
            fireSystemState::PhysicalGroupFaultEventStateHandler<HANDLER>::SetupSignal();
            return (TestResetCommand() && TestEventNotByReset());
        }

        bool SetupSignalTestByReset()
        {
            fireSystemState::PhysicalGroupFaultEventStateHandler<HANDLER>::SetupSignal();
            return (TestResetCommand() && TestEventByReset());
        }

        bool TestResetCommand()
        {
            auto mangedAreaRef = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::myManagedAreaID,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
            auto list = CommonFaultEventStateHandler<HANDLER>::m_handler.GetListOfCommandSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Command::COMMAND_CATEGORY category = keyVal.first.m_category;
                if(category == Mol::Command::COMMAND_CATEGORY::RESET)
                {
                    ;//we can not verify the manged area id here, it has to be done in DomainConfiguration Class UT
                    return true;
                }
                else
                {
                    ;//Don't care about others they are tested in other UTs
                }
            }
            return false;
        }

        bool TestEventNotByReset()
        {
            auto reference = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::ID,fireSystemState::DummyStateHandler::myType};
            auto list = CommonFaultEventStateHandler<HANDLER>::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if((category == Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED) || (category == Mol::Event::EVENT_CATEGORY::TROUBLE))
                {
                    if( ( (objref != reference) && (objref != CommonFaultEventStateHandler<HANDLER>::GetmyPanelObjectRef()) ))
                    {
                        return false;
                    }
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 2);
        }

        bool TestEventByReset()
        {
            auto reference = Mol::DataType::ObjectReference{fireSystemState::DummyStateHandler::ID,fireSystemState::DummyStateHandler::myType};
            auto list = CommonFaultEventStateHandler<HANDLER>::m_handler.GetListOfEventSignals();
            for (const auto& keyVal : list) {
                Mol::DataType::ObjectReference objref = keyVal.first.m_reference;
                Mol::Event::EVENT_CATEGORY category = keyVal.first.m_category;
                if( category == Mol::Event::EVENT_CATEGORY::TROUBLE)
                {
                        return (objref == reference);
                }
                else
                {
                    ;// do nothing for the moment, may new subscription comes in the future, so we need to add the test here also;
                }
            }
            return (list.size() >= 1);
        }
    };
}
#endif //FIRESYSTEM_STATE_HANDLER_PHYSICAL_GROUP_FAULT_EVENT_TEST_H
