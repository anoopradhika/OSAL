#include "gmock/gmock.h"
#include "FireRoutingOutputStateHandlerUt.h"
#include "Utility.h"

TEST(FireRoutingOutputStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FireRoutingOutputStateHandlerTest testobject(10,config);
    testobject.Setup_Test();

    testobject.SendActivate();
    testobject.SendDeactivate();
    testobject.SetConfirmation(true);
    
    bool conf = testobject.IsConfirmed();
    EXPECT_EQ(conf,true);

    testobject.DecrementActivationReqCount();
    bool req = testobject.ActivationReqPending();
    EXPECT_EQ(req,0);
}

TEST(FireRoutingOutputStateHandlerTestUT, EventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FireRoutingOutputStateHandlerTest testobject(10,config);

    testobject.RcvFunctionDisablementEvent();
    testobject.RcvFunctionDisablementEventNoFDA();
    testobject.RcvFunctionEnableEvent();	
    testobject.RcvFunctionEnableEventNoFDA();	
    testobject.RcvActivationEvent();
    testobject.RcvActivationEventNoFDA();
    testobject.RcvActivationEventDeactivate();
    testobject.RcvFARETestEventStart();
    testobject.RcvFARETestEventStartNoFDA();
    testobject.RcvFARETestEventEndNoFDA();
    testobject.RcvActivationEventNoFDA();
    testobject.RcvFunctionDisablementEventNoFDA();

    testobject.RcvInformationEvent();
    testobject.RcvInformationEventNoFDA();
    uint64_t pointID = 0x100010200000001;
    fireSystemState::FireRoutingOutputStateHandlerTest testobject1{pointID,config};
    EXPECT_TRUE(testobject1.ReceiveFaultEventTestInvalidProccessID());
    fireSystemState::FireRoutingOutputStateHandlerTest testobject2{pointID,config};
    EXPECT_TRUE(testobject2.ReceiveFaultEventTestInvalidFaultCode());
    fireSystemState::FireRoutingOutputStateHandlerTest testobject3{pointID,config};
    EXPECT_TRUE(testobject3.ReceiveFaultEventTestValidFualtState());
    fireSystemState::FireRoutingOutputStateHandlerTest testobject4{pointID,config};
    EXPECT_TRUE(testobject4.ReceiveFaultEventTestValidFualClearedtState());


}

TEST(FireRoutingOutputStateHandlerTestUT, CommandTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);
    
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FireRoutingOutputStateHandlerTest testobject(10,config);

    testobject.RcvActivateCommand();
    testobject.RcvActivateCommandNoFDA();
    testobject.RcvDeActivateCommand();
    uint64_t pointID = 0x100010200000001;
    fireSystemState::FireRoutingOutputStateHandlerTest testobject5{pointID,config};
    EXPECT_TRUE(testobject5.ReceiveResetCommandTestInvalidProcessID());
    fireSystemState::FireRoutingOutputStateHandlerTest testobject6{pointID,config};
    EXPECT_TRUE(testobject6.ReceiveResetCommandTestCorrectState());
}

