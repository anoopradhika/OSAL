#ifndef COMMON_FIRE_OUTPUT_POINT_STATE_UT_H
#define COMMON_FIRE_OUTPUT_POINT_STATE_UT_H

#include "StateHandler/CommonFireOutputPointStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class CommonFireOutputPointStateHandlerTest : public CommonFireOutputPointStateHandler
    {
    public:
        CommonFireOutputPointStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            CommonFireOutputPointStateHandler(id, element)
        {
        }
        ~CommonFireOutputPointStateHandlerTest() override = default;

		void Setup_Test()
		{
			Prepare();
			SetupSignal();
		}
    };
}
#endif //COMMON_FIRE_OUTPUT_POINT_STATE_UT_H
