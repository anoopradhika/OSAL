#ifndef FIRE_SENSOR_INPUT_STATE_HANDLER_UT_H
#define FIRE_SENSOR_INPUT_STATE_HANDLER_UT_H

#include "StateHandler/FireSensorInputStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DOL/Entities/Zone/Zone.h"
#include "DOL/Entities/ManagedArea.h"

namespace fireSystemState
{
    class FireSensorInputStateHandlerTest : public FireSensorInputStateHandler
    {
    public:
        FireSensorInputStateHandlerTest(const Dol::DomainObjectID id, XmlElementConfig element):
            FireSensorInputStateHandler(id, element)
        {
            Dol::Entities::Zone zone(Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE, 1);
            Dol::Entities::ManagedArea m1(1);
            zone.AddManagedArea(std::make_shared<Dol::Entities::ManagedArea>(m1));
            zone.SetManagedAreaId(1);
            AddParentZone(std::make_shared<Dol::Entities::Zone>(zone));
        }
        ~FireSensorInputStateHandlerTest() override = default;

	    void Setup_Test()
	    {
			SetupSignal();
	    }

	    void RcvDisablementEvent()
	    {
			uint64_t point_id = 72060901162745857;
			uint64_t parentID = 1101;
			auto disableEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;
			disableEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(point_id, type);
			disableEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{parentID,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			disableEvent->AddParent( parent);

			ReceiveDisablementEvent(disableEvent,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
	    }

	    void RcvAlarmEvent()
	    {
			uint64_t parentID = 1101;
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058706451301376, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{parentID,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent( parent);

			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::MODULE_APP);
	    }

	    void RcvReceiveFaultEvent()
	    {
			uint64_t parentID = 1101;
			auto faultEvent = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::ASPIRATION_FAULT);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR;
			faultEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058706451301376, type);
			faultEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{parentID,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			faultEvent->AddParent( parent);

			ReceiveAlarmEvent(faultEvent,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
			ReceiveAlarmEvent(faultEvent,0,PROC_ADDRESS::MODULE_APP);
	    }

	    void RcvAlarmEventReturnFromAlarm()
	    {
			uint64_t parentID = 1101;
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058706451301376, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{parentID,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent( parent);

			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::MODULE_APP);
	    }

	    void RcvAlarmEventTestAlarm()
	    {
			uint64_t parentID = 1101;
			auto alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::TEST_ALARM);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR;
			alarmEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(72058706451301376, type);
			alarmEvent->SetSource(target);
			auto parent = Mol::DataType::ObjectReference{parentID,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
			alarmEvent->AddParent( parent);

			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::FIRE_DOMAIN_APP);
			ReceiveAlarmEvent(alarmEvent,0,PROC_ADDRESS::MODULE_APP);
	    }

	    void RcvResetCommand()
	    {
			auto command = std::make_shared<Mol::Command::Reset>(Mol::RESET_TYPE_CODE::GENERAL);
			Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA;
			auto managedarea = 1;
			Mol::DataType::ObjectReference target = Mol::DataType::ObjectReference(managedarea, type);
			command->SetCommandTarget(target);
			ReceiveResetCommand(command, 0,PROC_ADDRESS::MODULE_APP);
	    }

	    void RcvTestEvent()
	    {
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
	    }

	    void RcvTestEventNoFDA()
	    {
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::CMCAPP);
	    }

	    void RcvTestEventZoneRemoveNoFDA()
	    {
			auto event=std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST);
			event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
			ReceiveTestEvent(event,10,PROC_ADDRESS::CMCAPP);
	    }
        void RcvMultiQueryRequest()
        {
            auto multiQueryRequestFault = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT);
            multiQueryRequestFault->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT});
            multiQueryRequestFault->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestFault,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDisabled = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDisabled->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT});
            multiQueryRequestDisabled->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDisabled,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestInvalidQuery = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM);
            multiQueryRequestInvalidQuery->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT});
            multiQueryRequestInvalidQuery->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestInvalidQuery,10,PROC_ADDRESS::CMCAPP);

            auto multiQueryRequestDiffPoint = std::make_shared<Mol::Request::MultiObjectQuery>(Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED);
            multiQueryRequestDiffPoint->SetTarget({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT});
            multiQueryRequestDiffPoint->SetSource({10, Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE});
            ReceiveMultiObjectQuery(multiQueryRequestDiffPoint,10,PROC_ADDRESS::CMCAPP);
		}

	    bool IsEventFromParentTest(Mol::DataType::ObjectReference ref)
	    {
	        return IsEventFromParent(ref);
	    }

        bool ReceiveFaultEventTestInvalidProccessID()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::GENERAL_FAULT);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::FIRE_DOMAIN_APP);
            return GetLastError() == STATE_ERROR::INVALID_PROCCESS_ID;
        }

        bool ReceiveFaultEventTestValidFualtState()
        {
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetLastError() == STATE_ERROR::NO_ERROR;
        }

        bool ReceiveFaultEventTestValidFualClearedtState()
        {
            //send first a fault event then the clear evnt to get the correct expected state
            ReceiveFaultEventTestValidFualtState();
            uint64_t point_id = 72058693549555712;
            auto event = std::make_shared<Mol::Event::FaultClearedEvent>(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED);
            event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            Mol::DataType::ObjectReference source = Mol::DataType::ObjectReference(point_id, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            event->SetSource(source);
            this->template ReceiveFaultEvent<Mol::Event::FaultClearedEvent>(event, 0, PROC_ADDRESS::MODULE_APP);
            return GetLastError() == STATE_ERROR::NO_ERROR;
        }
    };
}

#endif //FIRE_SENSOR_INPUT_STATE_HANDLER_UT_H
