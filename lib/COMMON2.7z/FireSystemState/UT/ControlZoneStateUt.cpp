#include "gmock/gmock.h"
#include "ControlZoneStateUt.h"
#include "Utility.h"

TEST(ControlZoneStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ControlZoneStateHandlerTest testobject{10,config};
    testobject.Setup_Test();
}

TEST(ControlZoneStateHandlerTestUT, FunctionEnableEventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ControlZoneStateHandlerTest testobject{10,config};
    testobject.RcvActivationEvent();
    testobject.RcvActivationEventNoFDA();
    testobject.RcvActivationEventDeactivateNoFDA();

    testobject.RcvFunctionEnbleEvent();
    testobject.RcvFunctionEnbleEventNoFDA();
}

TEST(ControlZoneStateHandlerTestUT, DeactivationCommandTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ControlZoneStateHandlerTest testobject{10,config};
    testobject.RcvDeActivationCmd();
    testobject.RcvDeActivationCmdNoFDA();
}

TEST(ControlZoneStateHandlerTestUT, ActivationCommandTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ControlZoneStateHandlerTest testobject{10,config};
    testobject.RcvActivationCmdNoFDA();
    testobject.RcvActivationCmd();
}

TEST(ControlZoneStateHandlerTestUT, ReceiveObjectDataRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

	std::shared_ptr<fireSystemState::ControlZoneStateHandler> controlObj = std::make_shared<fireSystemState::ControlZoneStateHandler>(10,config);
    std::shared_ptr<Mol::Request::ObjectData> request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS);
    Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    auto zoneid = 10;
    Mol::DataType::ObjectReference target(zoneid,type);
    request->SetSourceTarget(target);
    controlObj->Prepare();
    controlObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

    request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN);
    request->SetSourceTarget(target);
    controlObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::END_OF_LIST);
    request->SetSourceTarget(target);
    controlObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

	type = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    Mol::DataType::ObjectReference targetDetection(zoneid,type);
    request->SetSourceTarget(targetDetection);
    controlObj->ReceiveObjectData(request,zoneid,PROC_ADDRESS::CMCAPP);

    controlObj->ReceiveObjectData(NULL,zoneid,PROC_ADDRESS::CMCAPP);
}

TEST(ControlZoneStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::ControlZoneStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
}