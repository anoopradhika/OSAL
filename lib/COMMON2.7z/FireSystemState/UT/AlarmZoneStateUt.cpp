#include "gmock/gmock.h"
#include "AlarmZoneStateUt.h"
#include "Utility.h"

TEST(AlarmZoneStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};
    testobject.Setup_Test();
}

TEST(AlarmZoneStateHandlerTestUT, FunctionDisable)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};
    testobject.FunctionDisableEventNoFDA();
    testobject.FunctionDisableEvent();
}

TEST(AlarmZoneStateHandlerTestUT, FunctionEnable)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    testobject.FunctionEnbleEvent();
    testobject.FunctionEnbleEventNoFDA();
}

TEST(AlarmZoneStateHandlerTestUT, AlarmSignalEvent)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    testobject.AlarmSignalEventNoFDA();
    testobject.AlarmSignalEvent();
}
TEST(AlarmZoneStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::AlarmZoneStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
}

TEST(AlarmZoneStateHandlerTestUT, UserOperationEvent)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    testobject.UserOperationEventTest();
}

TEST(AlarmZoneStateHandlerTestUT, ReceiveAlarmSignalEvent)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    testobject.RcvSetAlarmSignal();
    testobject.RcvSetAlarmSignalVal();
}

TEST(AlarmZoneStateHandlerTestUT, ReceiveObjectDataRequest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml", source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source, distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    std::shared_ptr<fireSystemState::AlarmZoneStateHandler> alarmObj = std::make_shared<fireSystemState::AlarmZoneStateHandler>(10, config);
    std::shared_ptr<Mol::Request::ObjectData> request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS);
    Dol::DOMAIN_OBJECT_TYPE type = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    auto zoneid = 10;
    Mol::DataType::ObjectReference target(zoneid, type);
    request->SetSourceTarget(target);
    alarmObj->Prepare();
    alarmObj->ReceiveObjectData(request, zoneid, PROC_ADDRESS::CMCAPP);

    request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN);
    request->SetSourceTarget(target);
    alarmObj->ReceiveObjectData(request, zoneid, PROC_ADDRESS::CMCAPP);

    request = std::make_shared<Mol::Request::ObjectData>(Mol::Request::OBJECT_DATA_REQUEST_CODE::END_OF_LIST);
    request->SetSourceTarget(target);
    alarmObj->ReceiveObjectData(request, zoneid, PROC_ADDRESS::CMCAPP);

    type = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    Mol::DataType::ObjectReference targetDetection(zoneid, type);
    request->SetSourceTarget(targetDetection);
    alarmObj->ReceiveObjectData(request, zoneid, PROC_ADDRESS::CMCAPP);

    alarmObj->ReceiveObjectData(NULL, zoneid, PROC_ADDRESS::CMCAPP);
}

TEST(AlarmZoneStateHandlerTestUT, AddAlaramSignalFromAnotherPanelTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    EXPECT_TRUE(testobject.AddAlaramSignalFromAnotherPanelTestChildEvent());
    EXPECT_TRUE(testobject.AddAlaramSignalFromAnotherPanelTestNotFromNetwork());
    EXPECT_TRUE(testobject.AddAlaramSignalFromAnotherPanelTestFromNetworkNoParent());
    EXPECT_TRUE(testobject.AddAlaramSignalFromAnotherPanelTestFromNetworkWithParent());
}

TEST(AlarmZoneStateHandlerTestUT, ProcessPanelFailoverTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    EXPECT_TRUE(testobject.ProcessPanelFailoverTestNullptr());
    EXPECT_TRUE(testobject.ProcessPanelFailoverTestIgnorFDA());
    EXPECT_TRUE(testobject.ProcessPanelFailoverTestIgnorEvent());
    EXPECT_TRUE(testobject.ProcessPanelFailoverTestIgnorMyPanelFailure());
    EXPECT_TRUE(testobject.ProcessPanelFailoverTestIgnorPanelFailureIfNoAlaramSignal());
    EXPECT_TRUE(testobject.ProcessPanelFailoverTestGoodSenario());
}

TEST(AlarmZoneStateHandlerTestUT, ReceiveResetCommandTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    EXPECT_TRUE(testobject.ReceiveResetCommandTestNullPtr());
    EXPECT_TRUE(testobject.ReceiveResetCommandTestNotAllPnelsLost());
    EXPECT_TRUE(testobject.ReceiveResetCommandTestAllPnelsLost());
    EXPECT_TRUE(testobject.ReceiveResetCommandTestAllPnelsLostAndthisPanelHasAlarmSignal());
}

TEST(AlarmZoneStateHandlerTestUT, CreateInvalidTest)
{
    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, Dol::Entities::Point> StateObjectFactoryPointAdapter;
    StateObjectFactoryPointAdapter.CreateInvalid();

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Loop, Dol::Entities::Loop> StateObjectFactoryLoopAdapter;
    StateObjectFactoryLoopAdapter.CreateInvalid();

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Module, Dol::Entities::Module> StateObjectFactoryModuleAdapter;
    StateObjectFactoryModuleAdapter.CreateInvalid();
}

TEST(AlarmZoneStateHandlerTestUT, StaticGetIdTest)
{
    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::FaultInputStateHandler> StateObjectFactoryFaultInputAdapter;
    StateObjectFactoryFaultInputAdapter.StaticGetId();

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::TechnicalAlarmInputStateHandler> StateObjectFactoryTechnicalAlarmAdapter;
    StateObjectFactoryTechnicalAlarmAdapter.StaticGetId();

    SateHandlerDowncastAdapter<Dol::Entities::Point, fireSystemState::FaultInputStateHandler> SateDowncastFaultInputAdapter;
    SateDowncastFaultInputAdapter.StaticGetId();

    SateHandlerDowncastAdapter<Dol::Entities::Point, fireSystemState::TechnicalAlarmInputStateHandler> SateDowncastTechnicalAlarmAdapter;
    SateDowncastTechnicalAlarmAdapter.StaticGetId();
}

TEST(AlarmZoneStateHandlerTestUT, ErrorTest)
{
    SateHandlerDowncastAdapter<Dol::Entities::Loop, Dol::DomainObject> SateDowncastLoopAdapter;
    SateDowncastLoopAdapter.Error(0);

    SateHandlerDowncastAdapter<Dol::Entities::Module, Dol::DomainObject> SateDowncastModuleAdapter;
    SateDowncastModuleAdapter.Error(0);

    SateHandlerDowncastAdapter<Dol::Entities::Point, Dol::DomainObject> SateDowncastPointAdapter;
    SateDowncastPointAdapter.Error(0);
}

TEST(AlarmZoneStateHandlerTestUT, CreateTest)
{
    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::FPOStateHandler> StateObjectFactoryFPOStateAdapter;
    StateObjectFactoryFPOStateAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::FaultInputStateHandler> StateObjectFactoryFaultInputAdapter;
    StateObjectFactoryFaultInputAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::SerialPortStateHandler> StateObjectFactorySeriaPortAdapter;
    StateObjectFactorySeriaPortAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::AlarmDeviceStateHandler> StateObjectFactoryAlarmDeviceAdapter;
    StateObjectFactoryAlarmDeviceAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::FieldDeviceStateHandler> StateObjectFactoryFieldDeviceAdapter;
    StateObjectFactoryFieldDeviceAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::ExternalPSUPointStateHandler> StateObjectFactoryExternalPSUAdapter;
    StateObjectFactoryExternalPSUAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::TechnicalAlarmInputStateHandler> StateObjectFactoryTechnicalAAdapter;
    StateObjectFactoryTechnicalAAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::ManualCallPointInputStateHandler> StateObjectFactoryManualAdapter;
    StateObjectFactoryManualAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::CommonFireOutputPointStateHandler> StateObjectFactoryCommonFireAdapter;
    StateObjectFactoryCommonFireAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});

    fireSystemState::StateObjectFactoryAdapter<Dol::Entities::Point, fireSystemState::CommonFaultOutputPointStateHandler> StateObjectFactoryCommonFaultAdapter;
    StateObjectFactoryCommonFaultAdapter.Create<unsigned long const &, fireSystemState::XmlElementConfig const &>(10, fireSystemState::XmlElementConfig{});
}

TEST(AlarmZoneStateHandlerTestUT, SendCommandTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    auto commandDisable = std::make_shared<Mol::Command::Disable>();
    commandDisable->SetCommandTarget(Mol::DataType::ObjectReference{testobject.GetID(), testobject.GetObjectType()});
    testobject.SendCommand(commandDisable, PROC_ADDRESS::BROADCAST);

    auto commandEnable = std::make_shared<Mol::Command::Enable>();
    commandEnable->SetCommandTarget(Mol::DataType::ObjectReference{testobject.GetID(), testobject.GetObjectType()});
    testobject.SendCommand(commandEnable, PROC_ADDRESS::BROADCAST);

    auto commandTestZoneStart = std::make_shared<Mol::Command::TestZoneStart>();
    commandTestZoneStart->SetCommandTarget(Mol::DataType::ObjectReference{testobject.GetID(), testobject.GetObjectType()});
    testobject.SendCommand(commandTestZoneStart, PROC_ADDRESS::BROADCAST);

    auto commandTestZoneStop = std::make_shared<Mol::Command::TestZoneStop>();
    commandTestZoneStop->SetCommandTarget(Mol::DataType::ObjectReference{testobject.GetID(), testobject.GetObjectType()});
    testobject.SendCommand(commandTestZoneStop, PROC_ADDRESS::BROADCAST);

    auto commandSetSensitivityProfile = std::make_shared<Mol::Command::SetSensitivityProfile>();
    commandSetSensitivityProfile->SetCommandTarget(Mol::DataType::ObjectReference{testobject.GetID(), testobject.GetObjectType()});
    testobject.SendCommand(commandSetSensitivityProfile, PROC_ADDRESS::BROADCAST);
}

TEST(AlarmZoneStateHandlerTestUT, EventTest)
{
    auto eventTestOperationEventCode = std::make_shared<Mol::Event::TestOperationEvent>(Mol::Event::TEST_OPERATION_EVENT_CODE::END_OF_LIST);
    fireSystemState::CreateEventFromEvent<Mol::Event::TestOperationEvent, Mol::Event::TestOperationEvent, Mol::Event::TEST_OPERATION_EVENT_CODE>(eventTestOperationEventCode, Mol::Event::TEST_OPERATION_EVENT_CODE::END_OF_LIST);

    auto eventAlarmEventCode = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
    fireSystemState::CreateEventFromEvent<Mol::Event::AlarmEvent, Mol::Event::AlarmEvent, Mol::Event::ALARM_EVENT_CODE>(eventAlarmEventCode, Mol::Event::ALARM_EVENT_CODE::BACKUP_ALARM);

    auto eventFaultEventCode = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::FAULT_DETECTED_BETWEEN_POINTS);
    fireSystemState::CreateEventFromEvent<Mol::Event::FaultEvent, Mol::Event::FaultEvent, Mol::Event::FAULT_EVENT_CODE>(eventFaultEventCode, Mol::Event::FAULT_EVENT_CODE::FAULT_DETECTED_BETWEEN_POINTS);

    auto eventInputChangeEventCode = std::make_shared<Mol::Event::InputChangeEvent>(Mol::Event::INPUT_CHANGE_EVENT_CODE::ACTIVATED);
    fireSystemState::CreateEventFromEvent<Mol::Event::InputChangeEvent, Mol::Event::InputChangeEvent, Mol::Event::INPUT_CHANGE_EVENT_CODE>(eventInputChangeEventCode, Mol::Event::INPUT_CHANGE_EVENT_CODE::ACTIVATED);

    auto eventFunctionCode = std::make_shared<Mol::Event::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
    fireSystemState::CreateEventFromEvent<Mol::Event::FunctionDisable, Mol::Event::FunctionEnable>(eventFunctionCode, Mol::FUNCTION_CODE::ALARM_DEVICES);
}

TEST(AlarmZoneStateHandlerTestUT, DynamicGetIdTest)
{
    std::shared_ptr<fireSystemState::FaultInputStateHandler> faultInputObj = std::make_shared<fireSystemState::FaultInputStateHandler>(10, fireSystemState::XmlElementConfig{});
    SateHandlerDowncastAdapter<Dol::Entities::Point, fireSystemState::FaultInputStateHandler> DowncastAdapterFaultInputHandler;
    DowncastAdapterFaultInputHandler.DynamicGetId(faultInputObj);

    std::shared_ptr<fireSystemState::TechnicalAlarmInputStateHandler> technicalAlarmObj = std::make_shared<fireSystemState::TechnicalAlarmInputStateHandler>(10, fireSystemState::XmlElementConfig{});
    SateHandlerDowncastAdapter<Dol::Entities::Point, fireSystemState::TechnicalAlarmInputStateHandler> DownlcastAdapterTechnicalAlarmHandler;
    DownlcastAdapterTechnicalAlarmHandler.DynamicGetId(technicalAlarmObj);
}

TEST(AlarmZoneStateHandlerTestUT, OperatorTest)
{
    fireSystemState::PrepareOperation prepareOperation{};
    fireSystemState::SetupSignalOperation setupSignalOperarion{};

    std::shared_ptr<fireSystemState::FPOStateHandler> fpoObj = std::make_shared<fireSystemState::FPOStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(fpoObj);
    setupSignalOperarion.operator()(fpoObj);

    std::shared_ptr<fireSystemState::FaultInputStateHandler> faultInputObj = std::make_shared<fireSystemState::FaultInputStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(faultInputObj);
    setupSignalOperarion.operator()(faultInputObj);

    std::shared_ptr<fireSystemState::SerialPortStateHandler> serialPortObj = std::make_shared<fireSystemState::SerialPortStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(serialPortObj);
    setupSignalOperarion.operator()(serialPortObj);

    std::shared_ptr<fireSystemState::AlarmDeviceStateHandler> alarmDeviceObj = std::make_shared<fireSystemState::AlarmDeviceStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(alarmDeviceObj);
    setupSignalOperarion.operator()(alarmDeviceObj);

    std::shared_ptr<fireSystemState::FieldDeviceStateHandler> fieldDeviceObj = std::make_shared<fireSystemState::FieldDeviceStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(fieldDeviceObj);
    setupSignalOperarion.operator()(fieldDeviceObj);

    std::shared_ptr<fireSystemState::CommonFireOutputPointStateHandler> commonFireObj = std::make_shared<fireSystemState::CommonFireOutputPointStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(commonFireObj);
    setupSignalOperarion.operator()(commonFireObj);

    std::shared_ptr<fireSystemState::CommonFaultOutputPointStateHandler> commonFaultObj = std::make_shared<fireSystemState::CommonFaultOutputPointStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(commonFaultObj);
    setupSignalOperarion.operator()(commonFaultObj);

    std::shared_ptr<fireSystemState::ManualCallPointInputStateHandler> manualCallObj = std::make_shared<fireSystemState::ManualCallPointInputStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(manualCallObj);
    setupSignalOperarion.operator()(manualCallObj);

    std::shared_ptr<fireSystemState::TechnicalAlarmInputStateHandler> technicalAlarmObj = std::make_shared<fireSystemState::TechnicalAlarmInputStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(technicalAlarmObj);
    setupSignalOperarion.operator()(technicalAlarmObj);

    std::shared_ptr<fireSystemState::ExternalPSUPointStateHandler> externalPSUObj = std::make_shared<fireSystemState::ExternalPSUPointStateHandler>(10, fireSystemState::XmlElementConfig{});
    prepareOperation.operator()(externalPSUObj);
    setupSignalOperarion.operator()(externalPSUObj);
}

TEST(AlarmZoneStateHandlerTestUT, SendEventTest)
{
    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000; //72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";
    fireSystemState::AlarmZoneStateHandlerTest testobject{10, config};

    auto eventAccessEventCode = std::make_shared<Mol::Event::AccessEvent>(Mol::Event::ACCESS_EVENT_CODE::TOKEN_DECODE_ERROR);
    testobject.SendEvent(eventAccessEventCode, PROC_ADDRESS::BROADCAST);

    auto eventFunctionEventCode = std::make_shared<Mol::Event::FunctionEnable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
    testobject.SendEvent(eventFunctionEventCode, PROC_ADDRESS::BROADCAST);
}