#include "gmock/gmock.h"
#include "FPOStateUt.h"
#include "Utility.h"

TEST(FPOStateHandlerTestUT, SetupTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FPOStateHandlerTest testobject{10,config};
    testobject.Setup_Test();
}

TEST(FPOStateHandlerTestUT, Active_Deactive_Cmd_Test)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FPOStateHandlerTest testobject{10,config};
    testobject.RcvDisablementEventNoFDA();
    testobject.RcvFunctionEnbleEventNoFDA();
    testobject.RcvActivationEvent();
    testobject.RcvActivationEventDeactivate();
    testobject.RcvActivationEvent();
    testobject.RcvDisablementEventNoFDA();
    testobject.RcvFunctionEnbleEventNoFDA();
  
    testobject.RcvInformationEvent();
    testobject.RcvInformationEventReset();
   
    testobject.RcvActivationCmd();
    testobject.RcvActivationCmdNoFDA();
    testobject.RcvDeActivationCmd();
    testobject.RcvDeActivationCmdNoFDA();
}

TEST(FPOStateHandlerTestUT, InformationEvent_Test)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FPOStateHandlerTest testobject{10,config};
    testobject.RcvInformationEvent();
    testobject.RcvInformationEventNoConfirmation();

}
