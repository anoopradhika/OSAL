#include "gmock/gmock.h"
#include "FaultEventStateHandlerTest.h"
#include "DummyStateHandler.h"
#include "Utility.h"

TEST(FaultEventStateHandlerUT, SetupSignalTestNotByReset)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::FaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  m_faultEventHandler(handler);
    EXPECT_TRUE(m_faultEventHandler.SetupSignalTestNotByReset());
}

TEST(FaultEventStateHandlerUT, SetupSignalTestByReset)
{
    fireSystemState::DummyStateHandler handler(true);
    fireSystemState::FaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  m_faultEventHandler(handler);
    EXPECT_TRUE(m_faultEventHandler.SetupSignalTestByReset());
}
