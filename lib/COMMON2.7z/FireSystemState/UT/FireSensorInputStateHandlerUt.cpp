#include "gmock/gmock.h"
#include "FireSensorInputStateHandlerUt.h"
#include "Utility.h"

TEST(FireSensorInputStateHandlerTestUT, SetupTest)
{

    Utility::RunShellCommand( "mkdir /config/config1/");
    Utility::RunShellCommand( "touch /config/config1/active");
    Utility::RunShellCommand( "cp ../../../LIBRARIES/COMMON/FireSystemState/UT/configuration.xml /config/config1/configuration.xml");
    Utility::RunShellCommand( "sync");

    DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
    DEBUGPRINT::SetOutStream(OutStream::STDOUT);

    fireSystemState::XmlElementConfig config;
    fireSystemState::FireSensorInputStateHandlerTest testobject(72058702156342784,config);
    testobject.Setup_Test();
    auto ref1 = Mol::DataType::ObjectReference { 1, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE };
    auto ref2 = Mol::DataType::ObjectReference { 5, Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE };
    auto parent = Mol::DataType::ObjectReference { 1, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL };
    EXPECT_TRUE(testobject.IsEventFromParentTest(ref1));
    EXPECT_FALSE(testobject.IsEventFromParentTest(ref2));
    EXPECT_EQ(parent,testobject.GetmyPanelObjectRef());
}

TEST(FireSensorInputStateHandlerTestUT, EventTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FireSensorInputStateHandlerTest testobject(10,config);

    testobject.RcvDisablementEvent();
    testobject.RcvAlarmEvent();
    testobject.RcvAlarmEventReturnFromAlarm();
    testobject.RcvTestEvent();
    testobject.RcvTestEventNoFDA();
    testobject.RcvAlarmEventTestAlarm();
    testobject.RcvTestEventZoneRemoveNoFDA();
    testobject.RcvReceiveFaultEvent();

    uint64_t pointID = 0x100010200000001;
    fireSystemState::FireSensorInputStateHandlerTest testobject1{pointID,config};
    EXPECT_TRUE(testobject1.ReceiveFaultEventTestInvalidProccessID());
    fireSystemState::FireSensorInputStateHandlerTest testobject3{pointID,config};
    EXPECT_TRUE(testobject3.ReceiveFaultEventTestValidFualtState());
    fireSystemState::FireSensorInputStateHandlerTest testobject4{pointID,config};
    EXPECT_TRUE(testobject4.ReceiveFaultEventTestValidFualClearedtState());
}

TEST(FireSensorInputStateHandlerTestUT, CommandTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::cout<<"file = "<<source<<std::endl;
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FireSensorInputStateHandlerTest testobject(10,config);

    testobject.RcvResetCommand();
}

TEST(FireSensorInputStateHandlerTestUT, MultiQueryRequestTest)
{
    char source[PATH_MAX];
    realpath("../../../UTSUPPORTFILES/FireSystemState/configuration.xml",source);
    std::string active = Utility::GetActiveConfigLocation();
    std::string distination = active.append("configuration.xml");
    Utility::RemoveFile(distination);
    Utility::CopyFile(source,distination);

    fireSystemState::XmlElementConfig config;
    config.id = 0x100010000000000;//72058693549555712
    config.pointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
    config.key = "/configuration/site/building/managed_area[@id=1]/zone";

    fireSystemState::FireSensorInputStateHandlerTest testobject{10,config};
    testobject.RcvMultiQueryRequest();
}
