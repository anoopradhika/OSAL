
#include "StateHandler/DisableCommandHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"
#include "DummyStateHandler.h"
#include "Mol/DataType/ObjectReference.h"
#include "Mol/Events/EventCategory.h"

#ifndef DISABLE_COMMANDHANDLER_UT_H
#define DISABLE_COMMANDHANDLER_UT_H
namespace fireSystemState
{
template<typename HANDLER>
    class DisableCommandHandlerTest : public DisableCommandHandler<HANDLER>
	{
    public:
	using NAME = DisableCommandHandlerTest<HANDLER>;

	DisableCommandHandlerTest(HANDLER&  handler):
		DisableCommandHandler<HANDLER> (handler)
        {
        }
	void RcvReceiveDisableCommand()
	{
		auto command=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::DISABLE);
		NAME::ReceiveDisableCommand(command,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
	}
	void RcvReceiveEnableCommand()
	{
		auto command=std::make_shared<Mol::Message<Mol::Command::COMMAND_CATEGORY>>(Mol::Command::COMMAND_CATEGORY::ENABLE);
		NAME::ReceiveEnableCommand(command,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
	}

    };
}
#endif //DISABLE_COMMANDHANDLER_UT_H
