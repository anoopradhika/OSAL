#include "gmock/gmock.h"
#include "PhysicalGroupFaultEventStateHandlerTest.h"
#include "DummyStateHandler.h"
#include "Utility.h"

TEST(PhysicalGroupFaultEventStateHandlerUT, SetupSignalTestNotByReset)
{
    fireSystemState::DummyStateHandler handler(false);
    fireSystemState::PhysicalGroupFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  m_faultEventHandler(handler);
    EXPECT_TRUE(m_faultEventHandler.SetupSignalTestNotByReset());

}

TEST(PhysicalGroupFaultEventStateHandlerUT, SetupSignalTestByReset)
{
    fireSystemState::DummyStateHandler handler(true);
    fireSystemState::PhysicalGroupFaultEventStateHandlerTest<fireSystemState::DummyStateHandler>  m_faultEventHandler(handler);
    EXPECT_TRUE(m_faultEventHandler.SetupSignalTestByReset());

}
