/******************************************************************************//**
* @file FirePanelStateHandlerTest.h
* @brief Test case verify EventProviderService Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef UT_FIRE_PANEL_STATE_TEST_H
#define UT_FIRE_PANEL_STATE_TEST_H

#include "StateHandler/FirePanelStateHandler.h"
#include "XmlConfigReader/XmlConfigReader.h"

namespace fireSystemState
{
    class FirePanelStateHandlerTest : public FirePanelStateHandler
    {
    public:
        FirePanelStateHandlerTest(XmlElementConfig& element):
            FirePanelStateHandler(element)
        {
        }
        ~FirePanelStateHandlerTest() override = default;

        int TestPreper()
        {
            Init();
            Prepare();
            Start();
            Stop();
            Shutdown();
            Uninit();
            auto modules = GetModules();
            return modules.size();
        }

        bool SetupSignalTestWithReset()
        {
            SetFaultHandledByReset(true);
            SetupSignal();
            return true;
        }

        bool MainCPUModuleReceivedTestInvalidEvent()
        {
            MainCPUModuleReceived(GetInformationEvent(GetTestModule(Dol::Entities::Module::MODULE_TYPE::MAINCPU,0x100010600000000),
                                                        Mol::Event::INFORMATION_EVENT_CODE::CONFIRMATION_NOT_RECEIVED,
                                                        Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT), 0);
            return  (GetPanelSoftwareVersion().empty());
        }

        bool MainCPUModuleReceivedTestInvalidCatalog()
        {
            MainCPUModuleReceived(GetInformationEvent(GetTestModule(Dol::Entities::Module::MODULE_TYPE::MAINCPU,0x100010600000000),
                                                        Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED,
                                                        Mol::DataType::Parameter::CATALOG::ANALOG_VALUE), 0);
            return  (GetPanelSoftwareVersion().empty());
        }

        bool MainCPUModuleReceivedTestNullModule()
        {
            MainCPUModuleReceived(GetInformationEvent(nullptr, Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED,
                                                    Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT), 0);
            return  (GetPanelSoftwareVersion().empty());
        }

        bool MainCPUModuleReceivedTestIncorrectModuleType()
        {
            MainCPUModuleReceived(GetInformationEvent(GetTestModule(Dol::Entities::Module::MODULE_TYPE::CHARGER,0x100010600000000),
                                                      Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED,
                                                      Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT), 0);
            return  (GetPanelSoftwareVersion().empty());
        }

        bool MainCPUModuleReceivedTestNotCorrectMainCPUAddress()
        {
            MainCPUModuleReceived(GetInformationEvent(GetTestModule(Dol::Entities::Module::MODULE_TYPE::MAINCPU,0x100020600000000),
                                                      Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED,
                                                      Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT), 0);
            return  (GetPanelSoftwareVersion().empty());
        }

        bool MainCPUModuleReceivedTest()
        {
            MainCPUModuleReceived(GetInformationEvent(GetTestModule(Dol::Entities::Module::MODULE_TYPE::MAINCPU,0x100010600000000),
                                                      Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED,
                                                      Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT), 0);
            return  (GetPanelSoftwareVersion() == "1.2.3-D.100");
        }

        std::shared_ptr<Mol::Event::InformationEvent> GetInformationEvent(std::shared_ptr<Dol::Entities::Module> module, Mol::Event::INFORMATION_EVENT_CODE state, Mol::DataType::Parameter::CATALOG catalog)
        {
            auto information = std::make_shared<Mol::Event::InformationEvent>(state);
            information->AddParameter(catalog, module);
            if(nullptr != module)
            {
                 Mol::DataType::ObjectReference source{module->GetID(),  Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
                 information->SetSource(source);
            }
            return information;
        }

        std::shared_ptr<Dol::Entities::Module> GetTestModule(Dol::Entities::Module::MODULE_TYPE type, uint64_t id)
        {
            auto module =  std::make_shared<Dol::Entities::Module>("IPaddress",id);
            module->SetType(type);
            module->SetLabel("MAINCPU");
            module->SetSerialNumber("0x12345678");
            module->SetHardwareVersion("0x12345678");
            module->SetModuleStatus(Dol::Entities::Module::Status::NORMAL_OPERATION);
            module->SetConfigurationVersion(std::make_shared<Dol::Entities::SemanticVersion>(Utility::GetSemanticVersionUsingRegex("1.2.3-D.100")));
            module->SetSoftwareVersion(std::make_shared<Dol::Entities::SemanticVersion>(Utility::GetSemanticVersionUsingRegex("1.2.3-D.100")));
            return module;
        }

        void RcvReceiveUserAccessEvent()
        {
        	auto event= std::make_shared<Mol::Event::AccessEvent>(Mol::Event::ACCESS_EVENT_CODE::ACCESS_LEVEL_1);
        	ReceiveUserAccessEvent(event,10,PROC_ADDRESS::FIRE_DOMAIN_APP);
        }
    };
}
#endif //UT_FIRE_PANEL_STATE_TEST_H
