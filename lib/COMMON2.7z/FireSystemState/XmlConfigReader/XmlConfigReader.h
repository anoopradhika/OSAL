/*****************************************************************//**
 *
 * @file    XmlConfigReader.h
 * @brief   Read XML configuration for Domain objects
 *
 * Current implementation is limited to ONLY read config for coincedence
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>

#include "tinyxml2.h"
#include "tixml2ex.h"

#include "DOL/DomainObject/DomainObject.h"

#ifndef XML_CONFIG_READER
#define XML_CONFIG_READER

namespace fireSystemState
{

/**
  @brief: Data structure representing the zone in a XML file
  */
struct XmlElementConfig
{
    XmlElementConfig( const XmlElementConfig& ) = default;
    XmlElementConfig( ) = default;

    XmlElementConfig  operator=(const XmlElementConfig& others)
    {
        id = others.id;
        pointType = others.pointType;
        key = others.key;
        return *this;
    }
    uint64_t id = 0;                           //!< DOL uid type
    Dol::DOMAIN_OBJECT_TYPE pointType = Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;      //!< DOL point type
    std::string key;
};

/**
  @brief: Assign object type from a given char* text representation

  DOL did not define a general serialisation method for enums so we need
  a full handcrafted one here.

  @param[out] out found text representation will be stored as enum here
  @param[in]  in  text which should be converted to enum value
  */
inline void Assign( Dol::DOMAIN_OBJECT_TYPE& out, const char* in )
{
    if      ( 0 == std::strcmp( in, "ORGANIZATION" )) { out = Dol::DOMAIN_OBJECT_TYPE::ORGANIZATION;  }
    else if ( 0 == std::strcmp( in, "CONTACT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONTACT;  }
    else if ( 0 == std::strcmp( in, "SITE" )) { out = Dol::DOMAIN_OBJECT_TYPE::SITE;  }
    else if ( 0 == std::strcmp( in, "BUILDING" )) { out = Dol::DOMAIN_OBJECT_TYPE::BUILDING;  }
    else if ( 0 == std::strcmp( in, "MANAGED_AREA" )) { out = Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA;  }
    else if ( 0 == std::strcmp( in, "MULTI_DEPENDENCY_GROUP" )) { out = Dol::DOMAIN_OBJECT_TYPE::MULTI_DEPENDENCY_GROUP;  }
    else if ( 0 == std::strcmp( in, "DETECTION" )) { out = Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE;  }
    else if ( 0 == std::strcmp( in, "CONTROL" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE;  }
    else if ( 0 == std::strcmp( in, "ALARM" )) { out = Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE;  }
    else if ( 0 == std::strcmp( in, "GENERAL_ZONE" )) { out = Dol::DOMAIN_OBJECT_TYPE::GENERAL_ZONE;  }
    else if ( 0 == std::strcmp( in, "RELEASING_ZONE" )) { out = Dol::DOMAIN_OBJECT_TYPE::RELEASING_ZONE;  }
    else if ( 0 == std::strcmp( in, "LIFE_SAFETY_SYSTEM" )) { out = Dol::DOMAIN_OBJECT_TYPE::LIFE_SAFETY_SYSTEM;  }
    else if (( 0 == std::strcmp( in, "FIRE_PANEL" )) || (0 == std::strcmp( in, "fire_panel" ))) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL;  }
    else if ( 0 == std::strcmp( in, "LOOP" )) { out = Dol::DOMAIN_OBJECT_TYPE::LOOP;  }
    else if ( 0 == std::strcmp( in, "loop" )) { out = Dol::DOMAIN_OBJECT_TYPE::LOOP;  }
    else if ( 0 == std::strcmp( in, "FIELD_DEVICE" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIELD_DEVICE;  }
    else if ( 0 == std::strcmp( in, "IO_CHANNEL" )) { out = Dol::DOMAIN_OBJECT_TYPE::IO_CHANNEL;  }
    else if ( 0 == std::strcmp( in, "FIRE_BRIGADE_CONTROL_PANEL" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_BRIGADE_CONTROL_PANEL;  }
    else if ( 0 == std::strcmp( in, "FIRE_ALARM_ROUTING_EQUIPMENT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "fare_output" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "fare_input" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "FAULT_ROUTING_EQUIPMENT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "fre_input" )) { out = Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "fre_output" )) { out = Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "TECHNICAL_ALARM_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT;  }
    else if ( 0 == std::strcmp( in, "CONTROL_INPUT_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT;  }
    else if ( 0 == std::strcmp( in, "CONTROL_OUTPUT_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;  }
    else if ( 0 == std::strcmp( in, "RELEASING_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::RELEASING_POINT;  }
    else if ( 0 == std::strcmp( in, "FIRE_ALARM_DEVICE_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_DEVICE_POINT;  }
    else if ( 0 == std::strcmp( in, "MANUAL_CALL_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;  }
    else if ( 0 == std::strcmp( in, "FIRE_SENSOR" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR;  }
    else if ( 0 == std::strcmp( in, "FIRE_SENSOR_INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT;  }
    else if ( 0 == std::strcmp( in, "MCP INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::MCP_INPUT;  }
    else if ( 0 == std::strcmp( in, "mcp_input" )) { out = Dol::DOMAIN_OBJECT_TYPE::MCP_INPUT;  }
    else if ( 0 == std::strcmp( in, "FAULT_INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT;  }
    else if ( 0 == std::strcmp( in, "ALARM_DEVICE" )) { out = Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE;  }
    else if ( 0 == std::strcmp( in, "ALARM_OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "SOUNDER" )) { out = Dol::DOMAIN_OBJECT_TYPE::SOUNDER;  }
    else if ( 0 == std::strcmp( in, "VISUAL_ELEMENT" )) { out = Dol::DOMAIN_OBJECT_TYPE::VISUAL_ELEMENT;  }
    else if ( 0 == std::strcmp( in, "VOICE_ELEMENT" )) { out = Dol::DOMAIN_OBJECT_TYPE::VOICE_ELEMENT;  }
    else if ( 0 == std::strcmp( in, "ANALOG_INPUT_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::ANALOG_INPUT_POINT;  }
    else if ( 0 == std::strcmp( in, "ANNUNCIATOR_PANEL_SWITCH_INPUT_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::ANNUNCIATOR_PANEL_SWITCH_INPUT_POINT;  }
    else if ( 0 == std::strcmp( in, "ANNUNCIATIOR_PANEL_INDICATION_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::ANNUNCIATIOR_PANEL_INDICATION_POINT;  }
    else if ( 0 == std::strcmp( in, "PAM_POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::PAM_POINT;  }
    else if ( 0 == std::strcmp( in, "keysafe" )) { out = Dol::DOMAIN_OBJECT_TYPE::KEY_SAFE;  }
    else if ( 0 == std::strcmp( in, "CONFIRMATION_INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONFIRMATION_INPUT;  }
    else if ( 0 == std::strcmp( in, "aux_dc_output" )) { out = Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "AUX_DC_OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "SERIAL_PORT" )) { out = Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT;  }
    else if ( 0 == std::strcmp( in, "serial_port" )) { out = Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT;  }
    else if ( 0 == std::strcmp( in, "backup_power_source" )) { out = Dol::DOMAIN_OBJECT_TYPE::CHARGER;  }
    else if ( 0 == std::strcmp( in, "CHARGER" )) { out = Dol::DOMAIN_OBJECT_TYPE::CHARGER;  }
    else if ( 0 == std::strcmp( in, "charger" )) { out = Dol::DOMAIN_OBJECT_TYPE::CHARGER;  }
    else if ( 0 == std::strcmp( in, "BATTERY" )) { out = Dol::DOMAIN_OBJECT_TYPE::BATTERY;  }
    else if ( 0 == std::strcmp( in, "battery_set" )) { out = Dol::DOMAIN_OBJECT_TYPE::BATTERY;  }
    else if ( 0 == std::strcmp( in, "EXTERNAL_PSU" )) { out = Dol::DOMAIN_OBJECT_TYPE::EXTERNAL_PSU;  }
    else if ( 0 == std::strcmp( in, "external_PSU" )) { out = Dol::DOMAIN_OBJECT_TYPE::EXTERNAL_PSU;  }
    else if ( 0 == std::strcmp( in, "FIRE_PROTECTION_OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "MODULE" )) { out = Dol::DOMAIN_OBJECT_TYPE::MODULE;  }
    else if ( 0 == std::strcmp( in, "input_output_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::IO_MODULE;  }
    else if ( 0 == std::strcmp( in, "fire_loop_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE;  }
    //else if ( 0 == std::strcmp( in, "main_cpu_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::MODULE;  }
    else if ( 0 == std::strcmp( in, "main_cpu_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE;  }
    else if ( 0 == std::strcmp( in, "serial_interface_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::SERIAL_COMM_MODULE;  }
    else if ( 0 == std::strcmp( in, "charger_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::CHARGER_MODULE;  }
    else if ( 0 == std::strcmp( in, "id2net_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE;  }
    else if ( 0 == std::strcmp( in, "fare_fre_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::FARE_FRE_MODULE;  }
    //else if ( 0 == std::strcmp( in, "fat_fbf_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::MODULE;  }
    else if ( 0 == std::strcmp( in, "fat_fbf_module" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_BRIGADE_CONTROL_PANEL;  }
    else if ( 0 == std::strcmp( in, "VOICE_PANEL" )) { out = Dol::DOMAIN_OBJECT_TYPE::VOICE_PANEL;  }
    else if ( 0 == std::strcmp( in, "CMSI_PANEL" )) { out = Dol::DOMAIN_OBJECT_TYPE::CMSI_PANEL;  }
    else if ( 0 == std::strcmp( in, "common_fire_output" )) { out = Dol::DOMAIN_OBJECT_TYPE::COMMON_FIRE_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "common_fault_output" )) { out = Dol::DOMAIN_OBJECT_TYPE::COMMON_FAULT_OUTPUT;  }

    else if ( 0 == std::strcmp( in, "AUX DC OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "ALARM DEVICE" )) { out = Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE;  }
    else if ( 0 == std::strcmp( in, "ALARM OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "BATTERY_SET" )) { out = Dol::DOMAIN_OBJECT_TYPE::BATTERY;  }
    else if ( 0 == std::strcmp( in, "COMMON FAULT OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::COMMON_FAULT_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "COMMON FIRE OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::COMMON_FIRE_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "CONFIRMATION INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONFIRMATION_INPUT;  }
    else if ( 0 == std::strcmp( in, "CONTROL INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT;  }
    else if ( 0 == std::strcmp( in, "CONTROL OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;  }
    else if ( 0 == std::strcmp( in, "FAULT INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT;  }
    else if ( 0 == std::strcmp( in, "FAULT ROUTING OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT;  }
    else if ( 0 == std::strcmp( in, "FIELD DEVICE" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIELD_DEVICE;  }
    else if ( 0 == std::strcmp( in, "FIRE PROTECTION OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT;  }
    else if ( 0 == std::strcmp( in, "FIRE SENSOR" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR;  }
    else if ( 0 == std::strcmp( in, "FIRE SENSOR INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT;  }
    else if ( 0 == std::strcmp( in, "MANUAL CALL POINT" )) { out = Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT;  }
	else if ( 0 == std::strcmp( in, "MCP_INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::MCP_INPUT;  }
    else if ( 0 == std::strcmp( in, "TECHNICAL ALARM INPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT;  }
    else if ( 0 == std::strcmp( in, "FIRE ROUTING OUTPUT" )) { out = Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_ROUTING_EQUIPMENT;  }

    else                                        { out = Dol::DOMAIN_OBJECT_TYPE::INVALID; }
}


/**
  @brief Assign any kind of type from a char* text
  if not specialized later on...

  @param[out]  out instance to fill with native value from given text
  @param[in]   in  text to convert to native value
  */
    template < typename OutType >
inline void Assign( OutType& out, const std::string& in )
{
    std::istringstream is( in );
    is >> out;
}

/**
  @brief Read content from XML attribute and assign it to the given "native c++" data object.

  @param[out]  out      instance to fill with native value from given XML attribute
  @param[in]   attr     XML attribute to convert to native value

  */
    template < typename OutType >
inline void Assign( OutType& out, const tinyxml2::XMLAttribute* attr )
{
    // if there is nothing found, we intentionally fail silently! Out value stay untouched!
    if ( attr )
    {
        Assign( out, attr->Value() );
    }
}

/**
  @brief: Read content from XML element and assign it to the given "native c++" data object.

  @param[out]  out instance to fill with native value from given text
  @param[in]   el  xml element to convert to native value

  */
    template < typename OutType >
inline void Assign( OutType& out, const tinyxml2::XMLElement* el )
{
    // if there is nothing found, we intentionally fail silently! Out value stay untouched!
    if ( el )
    {
        Assign( out, el->GetText() );
    }
}

/**
  @brief: Read content from an attribute in a given XML element and assign it to the given "native c++" data object.

  @param[out]  name     instance to fill with native value from given XML attribute
  @param[in]   element  XML element where we search for an attribute to convert to native value
  */
inline const tinyxml2::XMLAttribute* GetAttribute( tinyxml2::XMLElement* element, const std::string& name )
{
    const tinyxml2::XMLAttribute* attr = element->FirstAttribute();

    for( ;attr; attr = attr->Next())
    {
        if ( name == attr->Name() )
        {
            return attr;
        }
    }

    return nullptr;
}

} // end namespace

#endif
