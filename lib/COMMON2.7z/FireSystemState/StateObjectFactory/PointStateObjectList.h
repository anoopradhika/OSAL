/*********************************************************************
 *
 * @file    PointStateObjectList.h
 * @brief   PointState object list for factory
 *
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

 #ifndef FIRESYSTEM_STATE_POINT_OBJECT_TYPES_H
 #define FIRESYSTEM_STATE_POINT_OBJECT_TYPES_H

#include "StateHandler/AlarmOutputStateHandler.h"
#include "StateHandler/AlarmDeviceStateHandler.h"
#include "StateHandler/FireSensorInputStateHandler.h"
#include "StateHandler/FireSensorStateHandler.h"
#include "StateHandler/ControlOutputStateHandler.h"
#include "StateHandler/ControlInputStateHandler.h"
#include "StateHandler/FPOStateHandler.h"
#include "StateHandler/ManualCallPointStateHandler.h"
#include "StateHandler/FireRoutingOutputStateHandler.h"
#include "StateHandler/FaultRoutingOutputStateHandler.h"
#include "StateHandler/ChargerPointStateHandler.h"
#include "StateHandler/BatteryPointStateHandler.h"
#include "StateHandler/SerialPortStateHandler.h"
#include "StateHandler/ManualCallPointInputStateHandler.h"
#include "StateHandler/ExternalPSUPointStateHandler.h"
#include "StateHandler/AuxDCOutputPointStateHandler.h"
#include "StateHandler/CommonFireOutputPointStateHandler.h"
#include "StateHandler/CommonFaultOutputPointStateHandler.h"
#include "StateHandler/FieldDeviceStateHandler.h"
#include "StateHandler/KeySafeStateHandler.h"
#include "StateHandler/TechnicalAlarmInputStateHandler.h"
#include "StateHandler/FaultInputStateHandler.h"
#include "StateHandler/ConfirmationInputStateHandler.h"
#include "StateHandler/VoiceAlarmDeviceStateHandler.h"

namespace fireSystemState
{

/**
  Description of point State handler entity hierarchy for factory and other design pattern implementations
  */
using PointStateObjectTypes = std::tuple<
    AlarmOutputStateHandler,
    AlarmDeviceStateHandler,
    ControlOutputStateHandler,
    ControlInputStateHandler,
    FPOStateHandler,
    FireSensorInputStateHandler,
    ManualCallPointStateHandler,
    ManualCallPointInputStateHandler,
    FireRoutingOutputStateHandler,
    FireSensorStateHandler,
    FaultRoutingOutputStateHandler,
    ChargerPointStateHandler,
    BatteryPointStateHandler,
    ExternalPSUPointStateHandler,
    AuxDCOutputPointStateHandler,
    CommonFireOutputPointStateHandler,
    CommonFaultOutputPointStateHandler,
    SerialPortStateHandler,
    FieldDeviceStateHandler,
    KeySafeStateHandler,
	TechnicalAlarmInputStateHandler,
    FaultInputStateHandler,
    ConfirmationInputStateHandler,
	VoiceAlarmDeviceStateHandler
    >;
}

#endif //FIRESYSTEM_STATE_POINT_OBJECT_TYPES_H
