/*********************************************************************
 *
 * @file    ZoneStateObjectList.h
 * @brief   ZoneState object list for factory
 *
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

 #ifndef FIRESYSTEM_STATE_ZONE_OBJECT_TYPES_H
 #define FIRESYSTEM_STATE_ZONE_OBJECT_TYPES_H

// #include "StateHandler/BuildingStateHandler.h"
// #include "StateHandler/ManagedAreaStateHandler.h"
#include "StateHandler/AlarmZoneStateHandler.h"
#include "StateHandler/DetectionZoneStateHandler.h"
#include "StateHandler/ControlZoneStateHandler.h"

namespace fireSystemState
{

/**
  Description of zone State handler entity hierarchy for factory and other design pattern implementations
  */
using ZoneStateObjectTypes = std::tuple<
    AlarmZoneStateHandler,
    ControlZoneStateHandler,
    DetectionZoneStateHandler
    >;
}

#endif //FIRESYSTEM_STATE_ZONE_OBJECT_TYPES_H
