/*********************************************************************
 *
 * @file    LoopStateObjectList.h
 * @brief   LoopState object list for factory
 *
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

 #ifndef FIRESYSTEM_STATE_LOOP_OBJECT_TYPES_H
 #define FIRESYSTEM_STATE_LOOP_OBJECT_TYPES_H

#include "StateHandler/LoopStateHandler.h"

namespace fireSystemState
{

/**
  Description of loop State handler entity hierarchy for factory and other design pattern implementations
  */
using LoopStateObjectTypes = std::tuple<
    LoopStateHandler
    >;
}

#endif //FIRESYSTEM_STATE_LOOP_OBJECT_TYPES_H
