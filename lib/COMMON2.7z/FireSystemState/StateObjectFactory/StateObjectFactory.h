
/*****************************************************************//**
 *
 * @file    StateObjectFactory.h
 * @brief   factory for dol state objects
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

 #ifndef FIRESYSTEM_STATE_OBJECT_FACTORY_H
 #define FIRESYSTEM_STATE_OBJECT_FACTORY_H

// framework
#include "DesignPatterns/factory/factory.h"


namespace fireSystemState {


/**
  Adapter for DOL factoy
  @tparam BASE base type of a class hirarchy
  @tparam OBJ_TYPE obj type to create
  */

template <typename BASE, typename OBJ_TYPE>
class StateObjectFactoryAdapter
{
    public:
        /**
          Get the static type id of the type OBJ_TYPE
          @retval returns the static ID of the referenced OBJ_TYPE
          */
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }

        /**
          Create new instance of OBJ_TYPE
          @param[in] args forward all input parameters to factory which forward to constructor
          @retval shared_ptr for new instance
          */
          template <typename ... ARGS>
            static std::shared_ptr<BASE> Create( ARGS&& ... args ) {
                auto object =  std::make_shared<OBJ_TYPE>( std::forward<ARGS>( args )...);
                // object->Prepare();
                // object->SetupSignal();
                return object;
             }

          /**
            Create a default instance of pointer to BASE type which is intentional an invalid std::shared_ptr
            @retval invalid instance of a shared_ptr to BASE type
            */
        static auto CreateInvalid( ) { return std::shared_ptr<BASE>{}; }
};



/**
  Factory to create DOL objects

  @todo customer data read and object configuration not implemented!
  */
template<typename objectType, typename objectTypeList>
class StateObjectFactory
{
    public:
        /**
          Create a new DOL instance.
          @param[in] element        id and type of object to create
          @retval                   new instance of requested type given by @p uid
          */

        static auto Create( const XmlElementConfig& element )
        {
            return Factory::Create( element.pointType, element.id, element);
        }

    private:
        using Factory = Platform::Factory< StateObjectFactoryAdapter, objectType, objectTypeList >;
};

} // end namespace
#endif //FIRESYSTEM_STATE_OBJECT_FACTORY_H
