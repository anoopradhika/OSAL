/*********************************************************************
 *
 * @file    ModuleStateObjectList.h
 * @brief   ModuleState object list for factory
 *
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

 #ifndef FIRESYSTEM_STATE_MODULE_OBJECT_TYPES_H
 #define FIRESYSTEM_STATE_MODULE_OBJECT_TYPES_H

#include "StateHandler/ModuleStateHandler.h"
#include "StateHandler/SerialCommsStateHandler.h"
#include "StateHandler/ChargerModuleStateHandler.h"
#include "StateHandler/IOModuleStateHandler.h"
#include "StateHandler/LoopModuleStateHandler.h"
#include "StateHandler/CPUModuleStateHandler.h"
#include "StateHandler/FAREFREModuleStateHandler.h"
#include "StateHandler/FATFBFModuleStateHandler.h"
#include "StateHandler/NetworkModuleStateHandler.h"

namespace fireSystemState
{

/**
  Description of module State handler entity hierarchy for factory and other design pattern implementations
  */

using ModuleStateObjectTypes = std::tuple<
    ChargerModuleStateHandler,
    SerialCommsStateHandler,
    IOModuleStateHandler,
    LoopModuleStateHandler,
    CPUModuleStateHandler,
    FAREFREModuleStateHandler,
    FATFBFModuleStateHandler,
    NetworkModuleStateHandler
    >;
}

#endif //FIRESYSTEM_STATE_MODULE_OBJECT_TYPES_H
