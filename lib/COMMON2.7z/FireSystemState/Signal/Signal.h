/******************************************************************************//**
*
* @file   Signal.h
* @brief  singleton class to access all type signalkey maps
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_SIGNAL_H
#define FIRESYSTEM_SIGNAL_H

#include "Signals/Delegate.h"
#include "Signals/Signal.h"

#include "Mol/Events/Event.h"
#include "Mol/Events/EventCategory.h"

#include "Mol/Commands/Command.h"
#include "Mol/Commands/CommandTypeList.h"

#include "Mol/DataType/ObjectReference.h"
#include <iostream>
#include "CommonDef.h"

namespace fireSystemState
{

/**
* @brief Template to specify the signalkey to access mol signal
*
* @tparam[in]   MessageCategoryType     The message Category
*/
template<typename MessageCategoryType>
struct SignalKey
{

    Mol::DataType::ObjectReference m_reference;
    MessageCategoryType m_category;

    SignalKey(Mol::DataType::ObjectReference reference
            , MessageCategoryType category)
            : m_reference{reference}
            , m_category{category}
    {}

    /**
     * Equality operator.
     *
     * @param otherKey  The SignalKey to compare with.
     * @return @c true if the reference is equal.
     */
    bool operator == (const SignalKey &otherKey) const
    {
        return ( (otherKey.m_reference==m_reference) &&
                (otherKey.m_category==m_category) );
    }

    /**
     * Assignment operator.
     *
     * @param otherKey  The SignalKey to get assigend
     * @return @c reference object.
     */
    SignalKey& operator = (const SignalKey &otherKey)
    {
        if(this != &otherKey)
        {
            this->m_reference = otherKey.m_reference;
            this->m_category = otherKey.m_category;
        }
        return *this;
    }

    /**
     * Inequality operator.
     *
     * @param otherKey  The SignalKey to compare with.
     * @return @c true if the reference is not equal.
     */
    bool operator != (const SignalKey &otherKey) const
    {
        return ( !(otherKey == *this) );
    }

    /**
     * less than operator.
     *
     * @param otherKey  The SignalKey to compare with.
     * @return @c true if the reference is not equal.
     */
    bool operator<(const SignalKey &otherKey) const
    {
        if (m_reference < otherKey.m_reference)
        {
            return true;
        }
        else if (m_reference == otherKey.m_reference)
        {
            return (m_category < otherKey.m_category);
        }
        else
        {
            return false;
        }
    }
};

/**
* @brief Signal is a singleton class to access all type signalkey maps
*/
class Signal
{
public:
    using EventSignalKey = SignalKey<Mol::Event::EVENT_CATEGORY>;
    using EventSignalExtendedType = Gallant::Signal3<std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>>,uint64_t,PROC_ADDRESS>;
    std::map< EventSignalKey,EventSignalExtendedType,std::less<> > EventSignalExtended;

    using CommandSignalKey = SignalKey<Mol::Command::COMMAND_CATEGORY>;
    using CommandSignalExtendedType = Gallant::Signal3<std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>>,uint64_t,PROC_ADDRESS>;
    std::map< CommandSignalKey,CommandSignalExtendedType,std::less<> > CommandSignalExtended;
    //@todo need to add support for Command
    static Signal& GetSignal()
    {
        static Signal m_signal;
        return m_signal;
    }
};
}
#endif //FIRESYSTEM_SIGNAL_H
