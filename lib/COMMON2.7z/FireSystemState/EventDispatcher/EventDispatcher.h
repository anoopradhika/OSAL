/*****************************************************************//**
 *
 * @file    Dispatcher.h
 * @brief   Disaptch mol events
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_EVENT_DISAPTCHER_H
#define FIRESYSTEM_STATE_EVENT_DISAPTCHER_H

// framework
#include "Mol/Events/Event.h"
#include "Mol/Events/EventTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"

#include "Signal/Signal.h"
#include "Helper/MolDowncastAdapter.h"
#include "DomainConfiguration/DomainConfiguration.h"

#include <chrono>
#include <ctime>

namespace fireSystemState {

/**
* @brief it find the registered Entities for the event and forward
* the event to it
*/
template<typename CommunicatorType>
struct EventExtendedForwader {
    EventExtendedForwader(CommunicatorType& communicator
                            , uint64_t id
                            , PROC_ADDRESS address):
               m_communicator{communicator}
               , m_id{id}
               , m_address{address}
    {}
    template < typename TYPE >
    bool operator()( std::shared_ptr<TYPE> message)
    {
        bool found = false;
        DEBUGPRINT(DEBUG_INFO,"EventExtendedDispatcher : receive event");
        auto EntitiesEventSignalKey =Signal::EventSignalKey{message->GetSource(),message->GetObjectType()};
        auto entitysignalext = m_communicator.EventSignalExtended.find(EntitiesEventSignalKey);
        found = ( entitysignalext != m_communicator.EventSignalExtended.end());
        if(found)
        {
            DEBUGPRINT(DEBUG_INFO,"find a point requester !!!!");
            entitysignalext->second(message, m_id, m_address);
        }
        auto parents = fireSystemState::DomainConfiguration{}.GetAllParents(Mol::DataType::ObjectReference(message->GetSource()));
        for(auto parent : parents)
        {
            auto parentsEventSignalKey =Signal::EventSignalKey{parent,message->GetObjectType()};
            if(m_communicator.EventSignalExtended.find(parentsEventSignalKey) != m_communicator.EventSignalExtended.end())
            {
                DEBUGPRINT(DEBUG_INFO,"find a parent requester !!!!");
                auto parentsignalext = m_communicator.EventSignalExtended.find(parentsEventSignalKey);
                parentsignalext->second(message, m_id, m_address);
            }
        }
        return found;
    }
    CommunicatorType& m_communicator;
    uint64_t m_id;
    PROC_ADDRESS m_address;
};

using EventType = Mol::Event::EVENT_CATEGORY;
using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;
using EventCaster = Platform::CastAndCall< MolDowncastAdapter,  Mol::Message<EventType>, EventObjectTypes >;


/**
* @brief Disaptch only a event with sendr ID and Application address
*/
auto EventExtendedDispatcher = [](auto command,uint64_t id, PROC_ADDRESS address, Signal& communicator)
{
    return EventCaster::Do<Mol::Event::EventDefault>(command, EventExtendedForwader<Signal>{communicator, id, address});
};
} // end namespace fireSystemState

#endif //FIRESYSTEM_STATE_EVENT_DISAPTCHER_H
