/******************************************************************************//**
*
* @file   LabelConfiguration.h
* @brief  LabelConfiguration file operation handles here
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_LABEL_CONFIGURATION_HANDLE_H
#define FIRESYSTEM_LABEL_CONFIGURATION_HANDLE_H
#include <map>
#include "tinyxml2.h"
#include "tixml2ex.h"

#include "XmlConfigReader/XmlConfigReader.h"
#include "DEBUGPRINT/DEBUGPRINT.h"
#include "Utility.h"
#include "../../Platform/Tools/Helper/Helper.h"

namespace fireSystemState
{
    /**
    * @brief Create xml handle for Label configuration file
    */
    class LabelConfigurationHandle
    {
        public:
        static LabelConfigurationHandle& GetInstance()
        {
            static LabelConfigurationHandle handle;
            return handle;
        }

        std::string& FindZoneLabel(uint64_t id , Dol::DOMAIN_OBJECT_TYPE type)
        {
            m_label = "";
            std::string key = std::to_string(id) + "~" + Platform::Dol_toString(type);
            if(m_labelMap.find(key) != m_labelMap.end())
            {
                m_label = m_labelMap[key];
            }
            return m_label;
        }

         std::string& FindDeviceLabel(uint64_t id)
        {
            m_label = "";
            if(m_deviceLabelMap.find(id) != m_deviceLabelMap.end())
            {
                m_label = m_deviceLabelMap[id];
            }
            return m_label;
        }

        private:
        
        LabelConfigurationHandle()
        {
            tinyxml2::XMLDocument m_doc;
            try
            {
                std::string configFile = Utility::GetActiveConfigLocation();
                configFile.append("labels.xml");
                m_doc.LoadFile(configFile.c_str() );
            }
//LCOV_EXCL_START
            catch( tinyxml2::XmlException &e )
            {
				DEBUGPRINT(DEBUG_ERROR, "LabelConfiguration: Tinyxml Exception thrown - {}", e.what());
				return;
            }
            catch(...)
            {
				DEBUGPRINT(DEBUG_ERROR, "LabelConfiguration: Unknown exception while reading the file ");
				return;
            }
//LCOV_EXCL_STOP
            auto elements = selection( m_doc, "/labels/label" );

            for(auto element : elements  )
            {
                std::string attributeId = attribute_value(element, "id");
                if(attributeId.length() > 0)
                {
                    uint64_t id = std::stoll(attributeId);
                    std::string attributeType = attribute_value(element, "type");
                    std::string key = attributeId + "~" + attributeType ;
                    const char* labelText = element->GetText();
                    if(nullptr != labelText)
                    {
                        DEBUGPRINT(DEBUG_INFO, "*********Label ID & Type:: {0} , Label Text:: {1}******* ",key,labelText);
                        m_labelMap.emplace(key,std::string(labelText));
                        m_deviceLabelMap.emplace(id,std::string(labelText));
                    }
                }
            }
        }

    std::string m_label = "";
    std::map<std::string, std::string> m_labelMap;
    std::map<uint64_t, std::string> m_deviceLabelMap;

    };
}
#endif //FIRESYSTEM_LABEL_CONFIGURATION_HANDLE_H
