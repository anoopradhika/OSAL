/*****************************************************************//**
 *
 * @file    SateHandlerDowncastAdapter.h
 * @brief   Downcast SateHandler
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_HANDLER_DOWNCAST_H
#define FIRESYSTEM_STATE_HANDLER_DOWNCAST_H

/**
* @brief Adapter to interface to a given user type
*/
template <typename BASE, typename OBJ_TYPE>
class SateHandlerDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i ) 
        {
            // Intentionally unimplemented...
        }
};

#endif //FIRESYSTEM_STATE_HANDLER_DOWNCAST_H
