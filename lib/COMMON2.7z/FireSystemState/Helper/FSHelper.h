/******************************************************************************//**
*
* @file   FSHelper.h
* @brief  General helper for fireSystemState
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HELPER_H
#define FIRESYSTEM_STATE_HELPER_H


#include "Mol/Events/EventTypeList.h"
#include "Mol/Commands/Command.h"
#include "Mol/DataType/ObjectReference.h"
#include "Mol/Requests/Request.h"
#include "Mol/Responses/Response.h"
#include "Utility.h"

namespace fireSystemState
{

/**
 * @brief different errors in state handlers
 */
enum class STATE_ERROR : uint8_t
{
    NO_ERROR = 0,                   //no error
    NULL_EVENT,                      ///< null pointer event
    INVALID_EVENT,                       ///< incorrect event deserialized
    INVALID_PROCCESS_ID                     ///< invalid process id
};

/**
* @brief check the integrity of response
* @param[in]    response           Response to validate
* @param[in]    responseCategory   Category of response
* @tparam       RESPONSE           type of response
* @return                       concrete response if response is valid, else return nullptr
*/
template<typename RESPONSE>
inline std::shared_ptr<RESPONSE> ValidateResponse(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> response
                                        , Mol::Response::RESPONSE_CATEGORY responseCategory)
{
    if(!response)
    {
        return nullptr;;
    }

    if(response->GetObjectType() != responseCategory)
    {
        return nullptr;
    }
    return std::static_pointer_cast<RESPONSE>(response);
}

/**
* @brief check the integrity of request
* @param[in]    request           Request to validate
* @param[in]    requestCategory   Category of request
* @tparam       REQUEST           type of request
* @return                       concrete event if event is valid, else return nullptr
*/
template<typename REQUEST>
inline std::shared_ptr<REQUEST> ValidateRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request
                                        , Mol::Request::REQUEST_CATEGORY requestCategory)
{
    if(!request)
    {
        return nullptr;;
    }

    if(request->GetObjectType() != requestCategory)
    {
        return nullptr;
    }
    return std::static_pointer_cast<REQUEST>(request);
}

/**
* @brief check the integrity of event
* @param[in]    event           Event to validate
* @param[in]    eventCategory   Category of event
* @tparam       EVENT           type of event
* @return                       concrete event if event is valid, else return nullptr
*/
template<typename EVENT>
inline std::shared_ptr<EVENT> ValidateEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event
                                        , Mol::Event::EVENT_CATEGORY eventCategory)
{
    if(!event)
    {
        return nullptr;;
    }

    if(event->GetObjectType() != eventCategory)
    {
        return nullptr;
    }
    return std::static_pointer_cast<EVENT>(event);
}

/**
* @brief check the integrity of event
* @param[in]    event           Event to validate
* @param[in]    eventCategory   Category of event
* @param[in]    code            Eventcode to validate
* @tparam       EVENT           type of event
* @return                       concrete event if event is valid, else return nullptr
*/
template<typename EVENT, typename CODE>
inline std::shared_ptr<EVENT>  ValidateEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event
                                            , Mol::Event::EVENT_CATEGORY eventCategory
                                            , CODE code)
{
    if(!event)
    {
        return nullptr;;
    }

    if(event->GetObjectType() != eventCategory)
    {
        return nullptr;
    }

    auto concreteEvent = std::static_pointer_cast<EVENT>(event);
    if(concreteEvent->GetEventCode() != code)
    {
        return nullptr;
    }
    return concreteEvent;
}

template<typename EVENT, typename CODE>
inline std::shared_ptr<EVENT>  ValidateEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event
                                            , Mol::Event::EVENT_CATEGORY eventCategory
                                            , CODE code
                                            , Dol::DOMAIN_OBJECT_TYPE type)
{
    if(!event)
    {
        return nullptr;;
    }

    if(event->GetObjectType() != eventCategory)
    {
        return nullptr;
    }

    auto concreteEvent = std::static_pointer_cast<EVENT>(event);
    if(concreteEvent->GetEventCode() != code)
    {
        return nullptr;
    }
    if(concreteEvent->GetSource().GetObjectType() != type)
    {
        return nullptr;
    }
    return concreteEvent;
}
/**
* @brief check the integrity of Command
* @param[in]    command         Command to validate
* @param[in]    commandCategory Category of command
* @tparam       COMMAND         type of command
* @return                       concrete command if command is valid, else return nullptr
*/
template<typename COMMAND>
inline std::shared_ptr<COMMAND> ValidateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command
                                        , Mol::Command::COMMAND_CATEGORY commandCategory)
{
    if(!command)
    {
        return nullptr;;
    }

    if(command->GetObjectType() != commandCategory)
    {
        return nullptr;
    }

    return std::static_pointer_cast<COMMAND>(command);
}

/**
* @brief check the integrity of Command
* @param[in] command: Command to validate
* @param[in] commandCategory: Category of command
* @param[in] reference: Id and type of Entities
* @tparam    COMMAND type of command
* @return  concrete command if command is valid, else return nullptr
*/
template<typename COMMAND>
inline std::shared_ptr<COMMAND> ValidateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command
                                        , Mol::Command::COMMAND_CATEGORY commandCategory
                                        , Mol::DataType::ObjectReference& reference)
{
    if(!command)
    {
        return nullptr;;
    }

    if(command->GetObjectType() != commandCategory)
    {
        return nullptr;
    }

    auto concreteCommand = std::static_pointer_cast<COMMAND>(command);
    if(reference != concreteCommand->GetCommandTarget())
    {
        return nullptr;
    }
    return concreteCommand;
}


template<typename Message>
bool IsItFromNetwork(Message message)
{
    auto parameters = message->GetParameters();
    std::string discription;

    for(auto& parameter : parameters)
    {
        if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
        {
            if(parameter.template GetValue<std::string>() == "ID2NET_Network")
            {
                return true;
            }
        }
    }
    return false;
}

template <typename EventType, typename CodeType, typename Handler>
void UpdatePointZoneReference(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, CodeType code, Handler* handler)
{
    auto validevent = ValidateEvent<EventType>(event, code);
    if (!validevent)
    {
        return;
    }
    if(validevent->GetSource() == Mol::DataType::ObjectReference{handler->GetID(), handler->GetObjectType()}){
        if(!validevent->GetZonePointReference().empty() && handler->GetZonePointReference().empty()){
            handler->SetZonePointReference(validevent->GetZonePointReference());
            }
        }
}

//@todo we should port all ValidateEvent call in all the sate handlers to use this version to insure ignore event with wrong code number
/**
* @brief check the integrity of event, and that code is in the rang of the enum
* @param[in]    event           Event to validate
* @param[in]    eventCategory   Category of event
* @tparam       EVENT           type of event
* @return                       concrete event if event is valid, else return nullptr
*/
template<typename EVENT, typename CodeType>
inline std::shared_ptr<EVENT> ValidateEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event
                                        , Mol::Event::EVENT_CATEGORY eventCategory)
{
    if(!event)
    {
        return nullptr;;
    }

    if(event->GetObjectType() != eventCategory)
    {
        return nullptr;
    }
    auto concreteEvent = std::static_pointer_cast<EVENT>(event);
    if(concreteEvent->GetEventCode() >= CodeType::END_OF_LIST)
    {
        return nullptr;
    }
    return std::static_pointer_cast<EVENT>(event);
}

template<typename EventType>
bool IsItMyPanelFailure(EventType event, Mol::DataType::ObjectReference objRef)
{
    auto source = event->GetSource();
    source.PrepareDeviceUniqueID();
    //convert to a fire panel ObjectReference (it might be CPU_MODULE in case of NO_REPLAY)
    auto thisPanelObjRef =  Mol::DataType::PointReferenceHelper::Create(source.GetDomainID(), source.GetNodeID(),0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
    if(nullptr != event && (thisPanelObjRef  == objRef) &&
            (event->GetEventCode() == Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED || event->GetEventCode() == Mol::Event::FAULT_EVENT_CODE::NO_REPLY))
    {
        return true;
    }
    return false;
}

template<typename EventType>
bool IsItMine(EventType event, Mol::DataType::ObjectReference objRef)
{
    return (event->GetSource() == objRef);
}

template<typename EventTypeInput, typename EventTypeOutput, typename CodeType>
std::shared_ptr<EventTypeOutput> CreateEventFromEvent(std::shared_ptr<EventTypeInput> src_event, CodeType code)
{
    auto event = std::make_shared<EventTypeOutput>(code);
    event->SetSource(src_event->GetSource());
    event->SetEventApplication(src_event->GetEventApplication());

    for(auto& parent: src_event->GetParents())
    {
        event->AddParent(parent);
    }
    for(auto& label: src_event->GetLabels())
    {
        event->AddLabel(label);
    }
    auto parameters = src_event->GetParameters();
    event->SetParameters(parameters);
    return event;
}

template<typename EventType>
uint64_t GetPanelRefFromEvent(EventType event)
{
    auto parents = event->GetParents();
    for(Mol::DataType::ObjectReference& parent: parents)
    {
        if(Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL == parent.GetObjectType())
        {
            return parent.GetObjectId();
        }
    }
    return 0;
}


struct NoResound{};

}
#endif //FIRESYSTEM_STATE_HELPER_H
