/*****************************************************************//**
 *
 * @file    CommandDispatcher.h
 * @brief   Disaptch mol commands
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef FIRESYSTEM_STATE_COMMAND_DISAPTCHER_H
#define FIRESYSTEM_STATE_COMMAND_DISAPTCHER_H

// framework
#include "Mol/Commands/Command.h"
#include "Mol/Commands/CommandTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"

#include "Signal/Signal.h"
#include "Helper/MolDowncastAdapter.h"

#include <chrono>
#include <ctime>

namespace fireSystemState {

/**
* @brief it find the registered Entities for the command and forward
* the command to it
*/

template<typename CommunicatorType>
struct CommandExtendedForwader {
    CommandExtendedForwader(CommunicatorType& communicator
                            , uint64_t id
                            , PROC_ADDRESS address):
               m_communicator{communicator}
               , m_id{id}
               , m_address{address}
    {}
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message)
    {
        auto EntitiesCommandSignalKey =Signal::CommandSignalKey{message->GetCommandTarget(),message->GetObjectType()};
        auto cmdsignalext = m_communicator.CommandSignalExtended.find(EntitiesCommandSignalKey);
        if( cmdsignalext != m_communicator.CommandSignalExtended.end())
        {
            DEBUGPRINT(DEBUG_INFO,"find a point requester !!!!");
            cmdsignalext->second(message, m_id, m_address);
        }
    }
    CommunicatorType& m_communicator;
    uint64_t m_id;
    PROC_ADDRESS m_address;
};

using CommandType = Mol::Command::COMMAND_CATEGORY;
using CommandCaster = Platform::CastAndCall< MolDowncastAdapter,  Mol::Message<CommandType>, CommandObjectTypes >;

/**
* @brief Disaptch only a command with sendr ID and Application address
*/
auto CommandExtendedDispatcher = [](auto command,uint64_t id, PROC_ADDRESS address, Signal& communicator)
{
    CommandCaster::Do<Mol::Command::CommandDefault>(command, CommandExtendedForwader<Signal>{communicator, id, address});
};
} // end namespace fireSystemState

#endif //FIRESYSTEM_STATE_COMMAND_DISAPTCHER_H
