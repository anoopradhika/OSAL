/******************************************************************************//**
*
* @file   CommonFaultOutputPointStateHandler.h
* @brief  State handler for CommonFaultOutput Point
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_COMMON_FAULT_OUTPUT_H
#define FIRESYSTEM_STATE_HANDLER_COMMON_FAULT_OUTPUT_H

#include <queue>

#include "DOL/Entities/Point/CommonFaultOutput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

#ifdef UT_TARGET
#define private protected
#endif

namespace fireSystemState
{

/**
* @brief CommonFaultOutputPointStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class CommonFaultOutputPointStateHandler: public Dol::Entities::CommonFaultOutput, public StateHandler<CommonFaultOutputPointStateHandler>
{
public:
    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    CommonFaultOutputPointStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
    CommonFaultOutput(id)
    ,m_faultEventHandler(*this)
    {
    }

    ~CommonFaultOutputPointStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &CommonFaultOutputPointStateHandler::ReceiveMultiObjectQuery);
  
        m_faultEventHandler.SetupSignal();
    }
protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"CommonFaultOutputPointStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::COMMON_FAULT_OUTPUT || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"CommonFaultOutputPointStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }

#ifndef UT_TARGET
        auto CommonFaultOutputObj = std::static_pointer_cast<Dol::Entities::CommonFaultOutput>(shared_from_this());
        bool statusFlag = false;
#else
        auto CommonFaultOutputObj = std::make_shared<Dol::Entities::CommonFaultOutput>();
        bool statusFlag = true;
#endif
        if(nullptr == CommonFaultOutputObj)
        {
            DEBUGPRINT(DEBUG_INFO,"CommonFaultOutputPointStateHandler:ReceiveMultiObjectQuery:CommonFaultOutput object is null");
            return;
        }

		if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(CommonFaultOutputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!CommonFaultOutputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(CommonFaultOutputObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED)
        {
            if(CommonFaultOutputObj->IsActivated())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
                statusFlag = true;
            }
        }
        else
        {
            /* nothing to do*/
        }

        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::COMMON_FAULT_OUTPUT,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"CommonFaultOutputPointStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *CommonFaultOutputObj);
		
		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"CommonFaultOutputPointStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

private:
    PhysicalGroupFaultEventStateHandler<CommonFaultOutputPointStateHandler> m_faultEventHandler;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_COMMON_FAULT_OUTPUT_H
