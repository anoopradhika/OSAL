/******************************************************************************//**
*
* @file   ControlZoneStateHandler.h
* @brief   State handler for Control zone.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_CONTROL_ZONE_H
#define FIRESYSTEM_STATE_HANDLER_CONTROL_ZONE_H

#include "DOL/Entities/Zone/ControlZone.h"


#include "EventDispatcher/EventDispatcher.h"
#include "StateHandler/ControlOutputStateHandler.h"
#include "Signal/Signal.h"
#include "MessageCommunicator/MessageCommunicator.h"

#include "Mol/Events/EventCategory.h"

#include "DomainConfiguration/DomainConfiguration.h"
#include "StateObjectFactory/StateObjectFactory.h"
#include "StateObjectFactory/PointStateObjectList.h"
#include "StateSetup/PointStateSetup.h"
#include "StateHandler/StateHandler.h"
#include "StateMachine/ControlZoneStateMachine.h"
#include "StateHandler/DisableCommandHandler.h"
#include "boost/sml.hpp"
#include <queue>
#include "StateHandler/DelayOperationHandler.h"
#include "Mol/Requests/ObjectData.h"
#include "Mol/Responses/ObjectDataResponse.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"
#include <systemd/sd-daemon.h>

namespace fireSystemState
{

/**
* @brief ControlZoneStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class ControlZoneStateHandler: public Dol::Entities::ControlZone, public StateHandler<ControlZoneStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    ControlZoneStateHandler(Dol::DomainObjectID id,XmlElementConfig element):
    ControlZone(id)
    ,m_element{element}
    ,m_zoneStateMachine(*this)
    ,m_updaterStateMachine{m_zoneStateMachine}
    ,m_disableCommandHandler(*this)
    ,m_delayOperationHandler(*this)
	,m_faultEventHandler(*this)
    {
    }

    ~ControlZoneStateHandler() override = default;

    void ResendCommand()
    {
        if((m_retry > 1) || (AreAnyFunctionDisablementForControlZone()))
        {
            m_waitingForCommandAck = 0;
            return;
        }
        if((time(0) - m_commandSendTime) <= 5)
        {
            return;
        }
        if(m_waitingForCommandAck > 0)
        {
            if((m_waitingForCommandAck & 0xF0) > 0)
            {
                DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler:Resend Activate Command");
                ReSendCommand(std::make_shared<Mol::Command::Activate>());
            }
            if((m_waitingForCommandAck & 0x0F) > 0)
            {
                DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler:Resend Deactivate Command");
                ReSendCommand(std::make_shared<Mol::Command::Deactivate>());
            }
            m_retry++;
        }
    }
    void ReSendCommand(auto command)
    {
        command->SetCommandTarget(Mol::DataType::ObjectReference{ GetID(), GetObjectType() });
        DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler: ResendCommand ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));

        for(auto dnm: m_associatedDNM)
        {
            SendCommand(command, PROC_ADDRESS::CMCAPP,false, dnm);
        }
        SendCommand(command, PROC_ADDRESS::MOL_RECEIVER, true);
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void Prepare() override
    {
        PointConfig(m_element,m_pointsConfig,&m_disableablePointType);
        DEBUGPRINT(DEBUG_INFO,"Loaded Control Zone Point Config:[{0}]",time(nullptr));
        for(auto pointConfig: m_pointsConfig)
        {
            std::cout<<" Control zone point id "<<std::hex<<pointConfig.id<<" type "<< (uint32_t)pointConfig.pointType<<std::endl;
            auto pointState = StateObjectFactory<Dol::Entities::Point,PointStateObjectTypes>::Create(pointConfig);
            if(pointState)
            {
                PointStatePrepare(pointState);
#ifndef UT_TARGET
                pointState->AddParentZone(shared_from_this());
#endif
                AddPoint(pointState);
				Mol::DeviceUniqueID uniqueid(pointConfig.id);
				m_associatedModules.emplace(uniqueid.GetModuleID()); //it is std::set, duplicates are not allowed
                m_associatedDNM.emplace(uniqueid.GetDNM64Bit());
            }
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Control Zone Point Objects:[{0}]",time(nullptr));
		//To set count of input and output modules
		std::set<std::shared_ptr<Dol::Entities::Point>> objReference = GetPointsOfZone();
		uint32_t numberOfInputModules{0};
		uint32_t numberOfOutputModules{0};
		for(auto const&obj:objReference)
		{
			if(obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT)
			{
				numberOfInputModules++;
			}
			else if(obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT || obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT)
			{
				numberOfOutputModules++;
			}
            else
            {
                //Do nothing
            }
		}
        DEBUGPRINT(DEBUG_INFO,"Set count of input and output modules:[{0}]",time(nullptr));
		SetInformationCount(Dol::Entities::Zone::INFORMATION_TYPE::INPUT_MODULE,numberOfInputModules);
		SetInformationCount(Dol::Entities::Zone::INFORMATION_TYPE::OUTPUT_MODULE,numberOfOutputModules);
		uint16_t panelNumber = Mol::DeviceUniqueID{Utility::ReadPanelID()}.GetNodeID();
        SetPanelNumber(panelNumber);

		PrepareLastOperation(Dol::CONTROL_OPERATION::END_OF_LIST);
    }

    void SetupSignal() override
    {
        for(auto& point : m_points)
        {
            PointSignalSetup(point);
        }
#ifndef UT_TARGET
        auto managedAreaReference = Mol::DataType::ObjectReference{GetManagedAreaId(),Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
		//Contro zone function disablement is not supported as of now
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,managedAreaReference,this, &ControlZoneStateHandler::ReceiveFunctionEnableEvent);
		PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,managedAreaReference,this, &ControlZoneStateHandler::ReceiveFunctionDisableEvent);


        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION,reference,this,&ControlZoneStateHandler::ReceiveActivationEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE,reference,this,&ControlZoneStateHandler::ReceiveActivateCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE,reference,this,&ControlZoneStateHandler::ReceiveDeactivateCommand);
		PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&ControlZoneStateHandler::ReceiveDisablementEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference, this, &ControlZoneStateHandler::ReceiveResetCommand);
#endif

		m_communicator.m_request.Subscribe<Mol::Request::ObjectData>(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA)->Connect(this, &ControlZoneStateHandler::ReceiveObjectData);

		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &ControlZoneStateHandler::ReceiveMultiObjectQuery);

		m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &ControlZoneStateHandler::TroubleClearedEventReceived);

        m_disableCommandHandler.SetupSignal();
        m_delayOperationHandler.SetupSignal();
		m_faultEventHandler.SetupSignal(true);
    }

    void EnableAction()
    {
//LCOV_EXCL_START
        if(CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
            auto activate = std::make_shared<Mol::Command::Activate>();
            activate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
            for(auto dnm:m_associatedDNM)
            {
                SendCommand(activate,PROC_ADDRESS::BROADCAST,false,dnm);
            }
            return;
        }
        /*else if(CheckLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE))
        {
            auto deactivate = std::make_shared<Mol::Command::Deactivate>();
            deactivate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
            SendCommand(deactivate,PROC_ADDRESS::BROADCAST);
            return;
        }*/

//LCOV_EXCL_STOP
    }
    std::shared_ptr<Mol::Event::ActivationEvent> lastActivationEvent = nullptr;
protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::OFF_NORMAL && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::NORMAL && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ALL_ENTITIES)
        {
            return;
        }

#ifndef UT_TARGET
        auto ControlZoneObj = std::static_pointer_cast<Dol::Entities::ControlZone>(shared_from_this());
        bool statusFlag = false;
#else
        auto ControlZoneObj = std::make_shared<Dol::Entities::ControlZone>();
		bool statusFlag = true;
#endif
        if(nullptr == ControlZoneObj)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveMultiObjectQuery:ControlZone object is null");
            return;
        }

        //SetDisablement status of a zone
        ControlZoneObj->SetDisabledStatus(ControlZoneObj->IsDisabled());
        ControlZoneObj->SetPartialDisabledStatus(ControlZoneObj->IsPartialDisabled());
        ControlZoneObj->SetFaultStatus(ControlZoneObj->IsFault());
        
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(ControlZoneObj->GetDisabledStatus() || ControlZoneObj->GetPartialDisabledStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!ControlZoneObj->GetDisabledStatus())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(ControlZoneObj->GetFaultStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED)
        {
            if(ControlZoneObj->IsActivated())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::OFF_NORMAL)
        {
            if(ControlZoneObj->GetDisabledStatus() || ControlZoneObj->GetPartialDisabledStatus() || ControlZoneObj->GetFaultStatus() || ControlZoneObj->IsActivated())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::NORMAL)
        {
            if(!ControlZoneObj->GetDisabledStatus() && !ControlZoneObj->GetPartialDisabledStatus() && !ControlZoneObj->GetFaultStatus() && !ControlZoneObj->IsActivated()) 
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ALL_ENTITIES)
        {
            statusFlag = true;
        }
        else
        {
            /* nothing to do*/
        }
        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *ControlZoneObj);
		
		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

	/**
    * Receive a ObjectData Request and invoke state machine
    * @param event      ObjectData Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveObjectData(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto ObjectDataRequest = ValidateRequest<Mol::Request::ObjectData>(request, Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        if(nullptr == ObjectDataRequest)
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveObjectData:ObjectData request is null");
            return;
        }
	
		auto sourceRef = ObjectDataRequest->GetSource();
		auto targetRef = ObjectDataRequest->GetTarget();
		auto source = ObjectDataRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE || targetRef.GetObjectId() != this->GetID())
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveObjectData:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());                        
			return;
        }
 	
		auto statusRequest = std::static_pointer_cast<Mol::Request::ObjectData>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS)
		{
			auto ControlZoneObj = std::static_pointer_cast<Dol::Entities::ControlZone>(shared_from_this());
			if(nullptr == ControlZoneObj)
			{
				DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveObjectData:ControlZone object is null");
				return;
			}

            //SetDisablement status of a zone
            ControlZoneObj->SetDisabledStatus(ControlZoneObj->IsDisabled());
            ControlZoneObj->SetPartialDisabledStatus(ControlZoneObj->IsPartialDisabled());
            ControlZoneObj->SetFaultStatus(ControlZoneObj->IsFault());

			auto ObjectDataResponse = std::make_shared<Mol::Response::ObjectDataResponse>();
			if(nullptr == ObjectDataResponse)
			{
				DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveObjectData:ObjectdataResponse object is null");
				return;
			}

			ObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *ControlZoneObj);	
			ObjectDataResponse->SetObjectStatusType(Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE);

			//Setting source and target for the response	
            ObjectDataResponse->SetTarget(sourceRef);
            ObjectDataResponse->SetSource(targetRef);
            ObjectDataResponse->SetResponseTarget(source);

            SendResponse(ObjectDataResponse, PROC_ADDRESS::MAINLOOP);
            DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveObjectData:Object Data response sent");
		}

		else if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN)
		{
            DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveObjectData:REQUEST FOR NUMBER OF CHILDREN");
		}
		
		else
        {
            DEBUGPRINT(DEBUG_INFO, "ControlZoneStateHandler:ReceiveObjectData: Invalid request type[{}]", static_cast<int>(queryType));
        }
    }

    /**
    * Receive Function functionEnablement event and process the event
    * @param event      functionEnablement
    * @param id         Object ID
    * @param address    Originator of event
    */
	//Contro zone function disablement is not supported as of now
    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionEnable = ValidateEvent<Mol::Event::FunctionEnable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE);
        if(! functionEnable)
        {
            return;
        }

        DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveFunctionEnableEvent Code [{}]", static_cast<int>(functionEnable->GetEventCode()));
        if(((functionEnable->GetEventCode() == Mol::FUNCTION_CODE::CONTROL_OUTPUTS) &&
            (Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT == m_disableablePointType)) ||
           ((functionEnable->GetEventCode() == Mol::FUNCTION_CODE::FIRE_PROTECTION) &&
            (Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT == m_disableablePointType)))
        {
			m_updaterStateMachine.process_event(functionEnable);
            SetDisablement(Zone::DISABLEMENT_STATE::ENABLED);
            EnableAction();
        }
    }
	
	void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionDisable = ValidateEvent<Mol::Event::FunctionDisable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE);
        if(! functionDisable)
        {
            return;
        }

        DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveFunctionDisableEvent Code [{}]", static_cast<int>(functionDisable->GetEventCode()));
        if(((functionDisable->GetEventCode() == Mol::FUNCTION_CODE::CONTROL_OUTPUTS) &&
            (Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT == m_disableablePointType)) ||
           ((functionDisable->GetEventCode() == Mol::FUNCTION_CODE::FIRE_PROTECTION) &&
            (Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT == m_disableablePointType)))
        {
            SetDisablement(Zone::DISABLEMENT_STATE::DISABLED);

            if(nullptr != lastActivationEvent && CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
            {
				m_updaterStateMachine.process_event(functionDisable);
                auto event = CreateEventFromEvent<Mol::Event::ActivationEvent, Mol::Event::ActivationEvent, Mol::Event::ACTIVATION_EVENT_CODE>(lastActivationEvent, Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
                SendEvent(event, PROC_ADDRESS::NETWORK, true);
				SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true); //send to eventprovider as these events are not cleared
                SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            }
        }
    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        if (nullptr == command)
        {
            return;
        }

        m_waitingForCommandAck = 0;
        m_commandSendTime = 0;
    }

	/**
    * Receive a disablementzoneEvent and invoke state machine
    * @param event      zoneDisable
    * @param id         an ID
    * @param address    Originator of event
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event,Mol::Event::EVENT_CATEGORY::DISABLEMENT);
        DEBUGPRINT(DEBUG_INFO, "ControlZoneStateHandler: ReceiveDisablementEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));

        if(nullptr == disablementEvent)
        {
            return;
        }
        if (PROC_ADDRESS::FIRE_DOMAIN_APP == address)
        {
            return;
        }

        // @TODO: This below implementation should be moved to State machine in future. For reference check Alarm Zone and Detection Zone.
        if (disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
        {
            if(GetDisablement()== Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED)
            {
                /* Here we need to Send Enable Event first to HMI & EVENT PROVIDER to clear the Partial Disablement.
                Then send a Zone Disablement Event. This will prevent duplicate entries in those applications */
                SendZoneEnablementEvent(disablementEvent);
            }
            SetDisablement(Zone::DISABLEMENT_STATE::DISABLED);
        }
        else if (disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
        {
            SetDisablement(Zone::DISABLEMENT_STATE::ENABLED);
        }
        else if (disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED)
        {
            // If the Zone is already Partially Disabled, don't forward it again.
            if(GetDisablement() == Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED)
            {
                return;
            }

            if(GetDisablement() == Zone::DISABLEMENT_STATE::DISABLED)
            {
                /* Here we need to Send Enable Event first to HMI & EVENT PROVIDER to clear the Disablement.
                Then send partial Disablement Event. This will prevent duplicate entries in those applications */
                SendZoneEnablementEvent(disablementEvent);
            }
            SetDisablement(Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED);
        }
        else
		{
			/*do nothing*/
		}

        SendEvent(disablementEvent,PROC_ADDRESS::BROADCAST,true);
		EnableAction();
     }

    //@TODO: This function should be moved to Statemachine, along with the caller
    void SendZoneEnablementEvent(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler: SendZoneEnablementEvent()");

        auto srcId = disablementEvent->GetSource().GetObjectId();
        auto srcType = disablementEvent->GetSource().GetObjectType();
        auto zoneEnablementEvent = std::make_shared < Mol::Event::DisablementEvent > (Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
        zoneEnablementEvent->SetSource(Mol::DataType::ObjectReference { srcId, srcType });
        zoneEnablementEvent->SetEventApplication(disablementEvent->GetEventApplication());

        auto parents = disablementEvent->GetParents();
        for(auto &parent : parents)
        {
            zoneEnablementEvent->AddParent(parent);
        }

        auto labels = disablementEvent->GetLabels();
        for(auto &label : labels)
        {
            zoneEnablementEvent->AddLabel(label);
        }

        // Send the Events to HMI, Event Provider and Dragon
        SendEvent(zoneEnablementEvent, PROC_ADDRESS::NETWORK, true);
        SendEvent(zoneEnablementEvent, PROC_ADDRESS::EVENT_PROVIDERAPP, true);
        SendEvent(zoneEnablementEvent, PROC_ADDRESS::MOL_RECEIVER, true);
    }

    /**
    * Receive a activation event and invoke state machine
    * @param event      Activation Event
    * @param id         Object ID
    * @param address    Originator of event
    */
    void ReceiveActivationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
		m_retry = 0;
        DEBUGPRINT(DEBUG_INFO,"In ControlZoneStateHandler:ReceiveActivationEvent");
        auto activationEvent = ValidateEvent<Mol::Event::ActivationEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::ACTIVATION
                                                                            );
        if((nullptr == activationEvent ) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
           DEBUGPRINT(DEBUG_ERROR,"ControlZoneStateHandler:ReceiveActivationEvent activationEvent is nullptr");
            return;
        }

         if(activationEvent->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)  //Deactivation Event
         {
            m_waitingForCommandAck = m_waitingForCommandAck & 0xF0; //Clear Deactivation Command on receiving Deactivation event
         }
         else if(activationEvent->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
         {
            m_waitingForCommandAck = m_waitingForCommandAck & 0x0F; //Clear Activation Command on receiving Activation event
         }
         else
         {
            //Do Nothing
         }

        DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveActivationEvent before state machine");
        m_updaterStateMachine.process_event(activationEvent);
        DEBUGPRINT(DEBUG_INFO,"ControlZoneStateHandler:ReceiveActivationEvent After state machine");
    }

    void ReceiveActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
		m_retry = 0;
        auto activate = ValidateCommand<Mol::Command::Activate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::ACTIVATE
                                                        );
        if((nullptr == activate) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
             return;
        }
		
		m_activationCounter++;	
        PrepareLastOperation(Dol::CONTROL_OPERATION::ACTIVATE);
		
		if(IsActivated())
		{
			return;
		}

        else if(!(AreAnyFunctionDisablementForControlZone()))
        {
            m_commandSendTime = time(0);
            m_waitingForCommandAck = m_waitingForCommandAck | 0xF0; //Received Activation Command
            for(auto dnm:m_associatedDNM)
            {
                SendCommand(activate,PROC_ADDRESS::BROADCAST,false, dnm);
            }
        }
//LCOV_EXCL_START
        else
        {
            //do nothing
        }

//LCOV_EXCL_STOP
    }

    void ReceiveDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
		m_retry = 0;
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::DEACTIVATE
                                                        );
        if(! deactivate)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
             return;
        }
		
		if(m_activationCounter) //this is defensive code, not to decrement if m_activationCounter is already zero
		{
		    m_activationCounter--;
		   	if(0 == m_activationCounter)
			{
				PrepareLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
			}
		}
		
        if(!AreAnyFunctionDisablementForControlZone())
        {
			if(0 == m_activationCounter)
			{
                m_commandSendTime = time(0);
                m_waitingForCommandAck = m_waitingForCommandAck | 0x0F;  //Received Deactivation Command
                for(auto dnm:m_associatedDNM)
                {
                    SendCommand(deactivate,PROC_ADDRESS::BROADCAST,false,dnm);
                }
				DEBUGPRINT(DEBUG_INFO,"Deactivate command is sent");
			}
        }
    }


//LCOV_EXCL_START
    void PrepareLastOperation(Dol::CONTROL_OPERATION current)
    {
        if(! CheckLastOperation(current))
        {
            SetLastOperation(current);
        }
    }
    bool AreAnyFunctionDisablementForControlZone()
    {
		//As of now control zone function disablement is not supported, return false always
		//Once we start control zone function disablement we can uncomment this code.
        /*if( IsFunctionDisablementActive(Dol::FUNCTION::CONTROL_OUTPUTS))
        {
            return true;
        }*/
        if(Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT == m_disableablePointType)
        {
            return IsFunctionDisablementActive(Dol::FUNCTION::CONTROL_OUTPUTS);
        }
        else if(Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT == m_disableablePointType)
        {
            return IsFunctionDisablementActive(Dol::FUNCTION::FIRE_PROTECTION);
        }

        return false;
    }

    /*
     * This function is only to get if there is a point that can disabled using function disable feature.
     * Of the supported point types for a control zone, only control output and fire protection output can be function disabled
     * as of now. 
     * Its assumed that a control zone can have points of either CONTROL OUTPUT type or FPO type. Not both
     */
    void GetDisableablePointType( const std::string& fileName)
    {
        try
        {
            tinyxml2::XMLDocument doc;

            if (Utility::IsSymlinkOrHardlink(fileName)) {
                DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler:GetDisableablePointType: [{0}] is a Symlink or Hardlink", fileName);
                return;
            }

            doc.LoadFile( fileName.c_str() );

            auto s = selection( doc, "/configuration/site/building/managed_area/zone" );
            for ( auto el: s )
            {
                auto zone_type_child = el->FirstChildElement("zone_type");
                std::string zone_type = zone_type_child->GetText();
#ifndef UT_TARGET
                // Kick WatchDog here
                if(Utility::TimeElapsed(40))
                {
                     Utility::IamAlive();
                }
#endif
                if(zone_type == "CONTROL")
                {
                    uint32_t zone_id = el->IntAttribute("zone_id");
                    if(zone_id != GetID())
                    {
                        continue;
                    }

                    auto pref= el->FirstChildElement("point_ref");
                    while ( pref )
                    {
                        auto point_id_child = pref->FirstChildElement("point_type");
                        std::string point_id = point_id_child->GetText();
                        DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler:GetDisableablePointType: [{}]", point_id.c_str());
                        if(point_id == "CONTROL OUTPUT")
                        {
                            m_disableablePointType = Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT;
                            return;
                        }
                        else if(point_id ==  "FIRE PROTECTION OUTPUT")
                        {
                            m_disableablePointType = Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT;
                            return;
                        }

                        pref = pref->NextSiblingElement("point_ref");
                    }
                }
            }

        } catch( tinyxml2::XmlException &e )
        {
            DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler:GetDisableablePointType: Tinyxml Exception thrown - {}", e.what());
            return;
        }
        catch(...)
        {
            DEBUGPRINT(DEBUG_ERROR, "ControlZoneStateHandler:GetDisableablePointType: Tinyxml Exception while reading the file ");
            return;
        }

        m_disableablePointType = Dol::DOMAIN_OBJECT_TYPE::INVALID;
        return;
    }

	void TroubleClearedEventReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		if((nullptr == event) || (PROC_ADDRESS::MODULE_APP != address))
		{
			return;
		}

		auto troublecleared = std::static_pointer_cast <Mol::Event::FaultClearedEvent> (event);

		if(troublecleared->GetEventCode()!= Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
		{
			return;
		}

        Mol::DeviceUniqueID uniqueid(troublecleared->GetSource().GetObjectId());
		auto pos = m_associatedModules.find(uniqueid.GetModuleID());

		if(m_associatedModules.end() != pos)
		{
			if( 0 != m_activationCounter )
			{
		        auto activate = std::make_shared<Mol::Command::Activate>();
                activate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                for(auto dnm:m_associatedDNM)
                {
                    SendCommand(activate,PROC_ADDRESS::BROADCAST,false,dnm);
                }    
			    DEBUGPRINT(DEBUG_INFO,"FDA::ControlZoneStateHandler::TroubleClearedEventReceived: activate command sent");
			}

			if(m_disableCommandHandler.m_disablementCount > 0)
			{
				auto disable = std::make_shared<Mol::Command::Disable>();
                disable->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                for(auto dnm:m_associatedDNM)
                {
                    SendCommand(disable,PROC_ADDRESS::BROADCAST,false,dnm);
                }
			    DEBUGPRINT(DEBUG_INFO,"FDA::ControlZoneStateHandler::TroubleClearedEventReceived: disable command sent");
			}
		}
	}

private:
//LCOV_EXCL_STOP
    std::vector<XmlElementConfig> m_pointsConfig;

    XmlElementConfig m_element;

    ControlZoneStateMachine<ControlZoneStateHandler> m_zoneStateMachine;

    boost::sml::sm<ControlZoneStateMachine<ControlZoneStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    DisableCommandHandler<ControlZoneStateHandler> m_disableCommandHandler;
    DelayOperationHandler<ControlZoneStateHandler> m_delayOperationHandler;
	PhysicalGroupFaultEventStateHandler<ControlZoneStateHandler> m_faultEventHandler;
	std::set<uint8_t>m_associatedModules;
    std::set<uint64_t> m_associatedDNM;
    
	uint16_t m_activationCounter = 0;

    Dol::DOMAIN_OBJECT_TYPE m_disableablePointType = Dol::DOMAIN_OBJECT_TYPE::INVALID;
	uint16_t m_retry = 0;

    //|------------|------------|
    //| Activation |Deactivation|
    //|------------|------------|
    uint8_t m_waitingForCommandAck = 0;
    time_t  m_commandSendTime = 0;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_CONTROL_ZONE_H
