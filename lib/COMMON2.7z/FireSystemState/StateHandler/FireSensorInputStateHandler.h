/******************************************************************************//**
*
* @file   FireSensorInputStateHandler.h
* @brief  State handler for FireSensorInput
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FIRESENSOR_INPUT_H
#define FIRESYSTEM_STATE_HANDLER_FIRESENSOR_INPUT_H

#include <queue>

#include "DOL/Entities/Point/FireSensorInput.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"
#include "Mol/Events/EventCategory.h"
#include "StateHandler/StateHandler.h"
#include "boost/sml.hpp"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "StateHandler/BaseFireDetectionPointStateHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

namespace fireSystemState
{

/**
* @brief FireSensorInputStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class FireSensorInputStateHandler: public BaseFireDetectionPointStateHandler<Dol::Entities::FireSensorInput, FireSensorInputStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    FireSensorInputStateHandler(const Dol::DomainObjectID id, XmlElementConfig element):
        BaseFireDetectionPointStateHandler(id, element)
    {
    }

    ~FireSensorInputStateHandler() = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal()
    {
		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &FireSensorInputStateHandler::ReceiveMultiObjectQuery);

        BaseFireDetectionPointStateHandler::SetupSignal();
    }

protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorInputStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorInputStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }
#ifndef UT_TARGET
        auto FireSensorInputObj = std::static_pointer_cast<Dol::Entities::FireSensorInput>(shared_from_this());
        bool statusFlag = false;
#else
        auto FireSensorInputObj = std::make_shared<Dol::Entities::FireSensorInput>();
		bool statusFlag = true;
#endif
        if(nullptr == FireSensorInputObj)
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorInputStateHandler:ReceiveMultiObjectQuery:FireSensorInput object is null");
            return;
        }
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(FireSensorInputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
			if(!FireSensorInputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM)
        {
            if(FireSensorInputObj->IsFireDetected())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST)
        {
            if(FireSensorInputObj->IsTestFire())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(FireSensorInputObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
                statusFlag = true;
            }
        }
        else
        {
            /*nothing to do*/
        }

        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorInputStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *FireSensorInputObj);

		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"FireSensorInputStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }
};

}

#endif //FIRESYSTEM_STATE_HANDLER_FIRESENSOR_INPUT_H
