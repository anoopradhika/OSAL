/******************************************************************************//**
*
* @file   AlarmZoneStateHandler.h
* @brief  State handler for Alarm zone.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_ALARM_ZONE_H
#define FIRESYSTEM_STATE_HANDLER_ALARM_ZONE_H

#include "DOL/Entities/Zone/AlarmZone.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "Mol/Events/EventCategory.h"
#include "DomainConfiguration/DomainConfiguration.h"
#include "StateObjectFactory/StateObjectFactory.h"
#include "StateObjectFactory/PointStateObjectList.h"
#include "StateMachine/AlarmZoneStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateSetup/PointStateSetup.h"
#include "boost/sml.hpp"
#include "StateHandler/DisableCommandHandler.h"
#include "Mol/Events/FunctionDisable.h"
#include "StateHandler/DelayOperationHandler.h"
#include <queue>
#include "Mol/Requests/ObjectData.h"
#include "Mol/Responses/ObjectDataResponse.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

#ifdef UT_TARGET
#ifdef private
#undef private
#endif
#define private protected
#endif
#define noop (void)0

namespace fireSystemState
{
/**
* @brief AlarmZoneStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class AlarmZoneStateHandler: public Dol::Entities::AlarmZone, public StateHandler<AlarmZoneStateHandler>
{
public:

    enum class ERROR_CODE : uint8_t
    {
        NULL_RESET_CMD,
        NULL_FAULT_EVENT,
        IGNOR_INTERNAL_EVENT,
        IGNOR_EVENT,
        IGNOR_IF_NOT_SAME_PANEL,
        NO_ERROR,
        END_OF_LIST
    };

    AlarmZoneStateHandler(AlarmZoneStateHandler&& other) = delete;

    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    AlarmZoneStateHandler(Dol::DomainObjectID id,XmlElementConfig element):
    AlarmZone(id)
    ,m_element{element}
    ,m_alarmZoneStateMachine(*this)
    ,m_updaterStateMachine{m_alarmZoneStateMachine}
    ,m_disableCommandHandler(*this)
    ,m_delayOperationHandler(*this)
	,m_faultEventHandler(*this)
    {
        SetLastAlarmSignalId(INVALID_SIGNAL_ID);
        auto m_thisPanelID = Utility::ReadPanelID();
        auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
        auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
        m_myPanelObjectRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        m_myPanelObjectRef.PrepareDeviceUniqueID();
    }

    ~AlarmZoneStateHandler() override = default;

    void ResendCommand()
    {
        if((m_retry > 1) || (IsDisabled()))
        {
            m_waitingForCommandAck = 0;
            return;
        }
        if((time(0) - m_commandSendTime) <= 5) 
        {
            return;
        }    
        if(m_waitingForCommandAck > 0)
        {
            if((m_waitingForCommandAck & 0xF0) > 0)
            {
                DEBUGPRINT(DEBUG_ERROR, "AlarmZoneStateHandler:Resend Set Alarm Signal({0})",GetLastAlarmSignalId());
                SendSetAlarmSignal(GetLastAlarmSignalId());
            }
            if((m_waitingForCommandAck & 0x0F) > 0)
            {
                DEBUGPRINT(DEBUG_ERROR, "AlarmZoneStateHandler:Resend Set Alarm Signal(0)");    
                SendSetAlarmSignal(0);
            }
            m_retry++;
        }        
    }
    void SendSetAlarmSignal(uint32_t code)
    {
        auto setAlarmSignalCommand = std::make_shared < Mol::Command::SetAlarmSignal > (code);
        setAlarmSignalCommand->SetCommandTarget(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
        DEBUGPRINT(DEBUG_ERROR, "AlarmZoneStateHandler: ResendCommand ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));

        for(auto dnm: m_associatedDNM)
        {
            SendCommand(setAlarmSignalCommand, PROC_ADDRESS::CMCAPP,false, dnm);
        }
        SendCommand(setAlarmSignalCommand, PROC_ADDRESS::MOL_RECEIVER, true);
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void Prepare() override
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ID[{0}], Type[{1}]", GetID(), static_cast<int>(GetObjectType()));
        try
        {
            PointConfig(m_element,m_pointsConfig);
        }
//LCOV_EXCL_START
        catch( tinyxml2::XmlException &e )
        {
            DEBUGPRINT(DEBUG_ERROR, "AlarmZoneStateHandler: exception[{}] while reading XML file", e .what());
			noop;						//To fix sonarqube vulnerability
        }
        catch(...)
        {
            DEBUGPRINT(DEBUG_ERROR, "AlarmZoneStateHandler: Unknown exception while reading XML file");
			noop;						//To fix sonarqube vulnerability
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Alarm Zone Point Config:[{0}]",time(nullptr));
//LCOV_EXCL_STOP
        for(auto pointConfig: m_pointsConfig)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: Alarm zone point ID[{0}], Type[{1}]", pointConfig.id, (uint32_t)pointConfig.pointType);
            auto pointState = StateObjectFactory<Dol::Entities::Point,PointStateObjectTypes>::Create(pointConfig);

            if(pointState)
            {
                PointStatePrepare(pointState);
#ifndef UT_TARGET //this pointer will not work in UT
                pointState->AddParentZone(shared_from_this());
                pointState->AddZone(Dol::ObjectReference{GetID(),GetObjectType()});
#endif
                AddPoint(pointState);
				Mol::DeviceUniqueID uniqueid(pointConfig.id);
				m_associatedModules.emplace(uniqueid.GetModuleID()); //it is std::set, duplicates are not allowed
                m_associatedDNM.emplace(uniqueid.GetDNM64Bit());
            }
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Alarm Zone Point Objects:[{0}]",time(nullptr));
		//To Set output module count
		std::set<std::shared_ptr<Dol::Entities::Point>> objReference = GetPointsOfZone();
		uint32_t numberOfOutputModules{0};
		for(auto const&obj:objReference)
		{
			if(obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE || obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT)
			{
				numberOfOutputModules++;
			}
		}
        DEBUGPRINT(DEBUG_INFO,"Set output module count:[{0}]",time(nullptr));
		SetInformationCount(Dol::Entities::Zone::INFORMATION_TYPE::OUTPUT_MODULE,numberOfOutputModules);
		uint16_t panelNumber = Mol::DeviceUniqueID{Utility::ReadPanelID()}.GetNodeID();
        SetPanelNumber(panelNumber);
    }

    void SetupSignal() override
    {
        for(auto& point : m_points)
        {
            PointSignalSetup(point);
        }
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL,reference,this,&AlarmZoneStateHandler::ReceiveAlarmSignalEvent);
		PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&AlarmZoneStateHandler::ReceiveDisablementEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL,reference,this,&AlarmZoneStateHandler::ReceiveSetAlarameSignalCommand);
#ifndef UT_TARGET
        auto managedAreaReference = Mol::DataType::ObjectReference{GetManagedAreaId(),Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::USER_OPERATION,managedAreaReference,this,&AlarmZoneStateHandler::UserOperationEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,managedAreaReference,this,&AlarmZoneStateHandler::ReceiveFunctionEnableEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,managedAreaReference,this,&AlarmZoneStateHandler::ReceiveFunctionDisableEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference, this, &AlarmZoneStateHandler::ReceiveResetCommand);
#endif

		m_communicator.m_request.Subscribe<Mol::Request::ObjectData>(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA)->Connect(this, &AlarmZoneStateHandler::ReceiveObjectData);

		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &AlarmZoneStateHandler::ReceiveMultiObjectQuery);

        //subscribe for fault event here to handle panels in the network communication stopped or no replay
        m_communicator.m_event.Subscribe<Mol::Event::FaultEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE)->Connect(this, &AlarmZoneStateHandler::ProcessPanelFailover);
		
		m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &AlarmZoneStateHandler::TroubleClearedEventReceived);

		m_disableCommandHandler.SetupSignal();
        m_delayOperationHandler.SetupSignal();
		m_faultEventHandler.SetupSignal(true);
    }
    void TestMe()
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: you can test the hell out of me");
    }
	
	void SendActiveEventtoHMI()
	{
		if (!IsThisLastAlarmSignalId(INVALID_SIGNAL_ID) && (GetLastAlarmSignalId() != 0))
        {
            auto AlarmSignalEvent = std::make_shared < Mol::Event::AlarmSignalEvent > (GetLastAlarmSignalId());
            AlarmSignalEvent->SetSource(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
            SendEvent(AlarmSignalEvent, PROC_ADDRESS::NETWORK);
        }
	}
	
	void SendDeactiveEventtoHMI()
	{
		if (!IsThisLastAlarmSignalId(INVALID_SIGNAL_ID) && (GetLastAlarmSignalId() != 0))
        {
            auto AlarmSignalEvent = std::make_shared < Mol::Event::AlarmSignalEvent > (0);
            AlarmSignalEvent->SetSource(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
            SendEvent(AlarmSignalEvent, PROC_ADDRESS::NETWORK);
        }
	}
	
	void SendEvacuationDeactiveEventtoHMI()
	{
        auto AlarmSignalEvent = std::make_shared < Mol::Event::AlarmSignalEvent > (0);
        AlarmSignalEvent->SetSource(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
        SendEvent(AlarmSignalEvent, PROC_ADDRESS::NETWORK);
	}

    void EnableAction()
    {
        if (!IsThisLastAlarmSignalId(INVALID_SIGNAL_ID) && (GetLastAlarmSignalId() != 0))
        {
            auto setAlarmSignalCommand = std::make_shared < Mol::Command::SetAlarmSignal > (GetLastAlarmSignalId());
            setAlarmSignalCommand->SetCommandTarget(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
            DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: EnableAction IsItActivatedBefore true for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
            for(auto dnm: m_associatedDNM)
            {
                SendCommand(setAlarmSignalCommand, PROC_ADDRESS::BROADCAST,false, dnm);
            }
        }
    }

    void AddAlaramSignalFromAnotherPanel(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        //ignore child events
        if(alarmSignal->GetSource() != Mol::DataType::ObjectReference {GetID(), GetObjectType() })
        {   
            return ;
        }
        //add it only if it is from another panel in the network
        if(IsItFromNetwork(alarmSignal))
        {
            auto id = GetPanelRefFromEvent(alarmSignal);
            if (id)
            {
                if(alarmSignal->GetEventCode() == 0)
                {
                    m_alarmSignalPanels.erase(id);
                }
                else
                {
                    m_alarmSignalPanels.insert({id, false});
                }
            }
        }
        else//mark as this is a local activation of alarm signal
        {
            thisPanelHasAlarmSignal = (alarmSignal->GetEventCode() > 0);
        }
    }

    bool  NoRemoteAlarmSignalPending()
    {
        return m_alarmSignalPanels.empty();
    }
    std::shared_ptr<Mol::Event::AlarmSignalEvent> lastAlarmSignalEvent = nullptr;
protected:

	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::OFF_NORMAL && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::NORMAL && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ALL_ENTITIES)
        {
            return;
        }
#ifndef UT_TARGET
        auto AlarmZoneObj = std::static_pointer_cast<Dol::Entities::AlarmZone>(shared_from_this());
        bool statusFlag = false;
#else
        auto AlarmZoneObj = std::make_shared<Dol::Entities::AlarmZone>();
		bool statusFlag = true;
#endif
        if(nullptr == AlarmZoneObj)
        {
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveMultiObjectQuery:AlarmZone object is null");
            return;
        }

        //SetDisablement status of a zone
        AlarmZoneObj->SetDisabledStatus(AlarmZoneObj->IsDisabled());
        AlarmZoneObj->SetPartialDisabledStatus(AlarmZoneObj->IsPartialDisabled());
        AlarmZoneObj->SetFaultStatus(AlarmZoneObj->IsFault());

        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(AlarmZoneObj->GetDisabledStatus() || AlarmZoneObj->GetPartialDisabledStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!AlarmZoneObj->GetDisabledStatus())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(AlarmZoneObj->GetFaultStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::OFF_NORMAL)
        {
            if(AlarmZoneObj->GetDisabledStatus() || AlarmZoneObj->GetPartialDisabledStatus() || AlarmZoneObj->GetFaultStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::NORMAL)
        {
            if(!AlarmZoneObj->GetDisabledStatus() && !AlarmZoneObj->GetPartialDisabledStatus() && !AlarmZoneObj->GetFaultStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ALL_ENTITIES)
        {
            statusFlag = true;
        }
        else
        {
            /* nothing to do*/
        }
        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *AlarmZoneObj);	

		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

	/**
    * Receive a ObjectData Request and invoke state machine
    * @param event      ObjectData Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveObjectData(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto ObjectDataRequest = ValidateRequest<Mol::Request::ObjectData>(request, Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        if(nullptr == ObjectDataRequest)
        {
			DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveObjectData:ObjectData Request is null");
            return;
        }

		auto sourceRef = ObjectDataRequest->GetSource();
		auto targetRef = ObjectDataRequest->GetTarget();
		auto source = ObjectDataRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE || targetRef.GetObjectId() != this->GetID())
        {
			DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveObjectData:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
			return;
        }
 	
		auto statusRequest = std::static_pointer_cast<Mol::Request::ObjectData>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS)
		{
			auto AlarmZoneObj = std::static_pointer_cast<Dol::Entities::AlarmZone>(shared_from_this());
			if(nullptr == AlarmZoneObj)
			{
				DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveObjectData:AlarmZone object is null");
				return;
			}
            //Set current disablement status of a zone
            AlarmZoneObj->SetDisabledStatus(AlarmZoneObj->IsDisabled());
            AlarmZoneObj->SetPartialDisabledStatus(AlarmZoneObj->IsPartialDisabled());
            AlarmZoneObj->SetFaultStatus(AlarmZoneObj->IsFault());

			auto ObjectDataResponse = std::make_shared<Mol::Response::ObjectDataResponse>();
			if(nullptr == ObjectDataResponse)
			{
				DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveObjectData:ObjectdataResponse object is null");
				return;
			}
			
			ObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *AlarmZoneObj);	
			ObjectDataResponse->SetObjectStatusType(Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE);

			//Setting source and target for the response
            ObjectDataResponse->SetTarget(sourceRef);
            ObjectDataResponse->SetSource(targetRef);
            ObjectDataResponse->SetResponseTarget(source);

            SendResponse(ObjectDataResponse, PROC_ADDRESS::MAINLOOP);
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveObjectData:Object Data response sent");
		}

		else if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN)
		{
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateHandler:ReceiveObjectData:Request For Number Of Children");
		}

		else
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler:ReceiveObjectData: Invalid request type[{}]", static_cast<int>(queryType));
        }
    }

    /**
    * Receive a disablementEvent and invoke state machine
    * @param event      FunctionDisable
    * @param id         an ID
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         auto disablementEvent = ValidateEvent<Mol::Event::FunctionDisable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,Mol::FUNCTION_CODE::ALARM_DEVICES);
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveFunctionDisableEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
         if(nullptr == disablementEvent)
         {
             return;
         }
         if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
         {
             DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveAlarmSignalEvent ignore from FIRE_DOMAIN_APP");
             return;
         }

         m_updaterStateMachine.process_event(disablementEvent);

         m_updaterStateMachine.visit_current_states([](auto state){
         DEBUGPRINT(DEBUG_INFO, "****************** AlarmZoneStateMachine is now in state[{}]", state.c_str());
         });

     }

    /**
    * Receive a disablementzoneEvent and invoke state machine
    * @param event      zoneDisable
    * @param id         an ID
    * @param address    Originator of event
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event,Mol::Event::EVENT_CATEGORY::DISABLEMENT);
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveDisablementEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));

        if(nullptr == disablementEvent)
        {
            return;
        }
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveAlarmSignalEvent ignore from FIRE_DOMAIN_APP");
            return;
        }

        m_updaterStateMachine.process_event(disablementEvent);

        m_updaterStateMachine.visit_current_states([](auto state){
        DEBUGPRINT(DEBUG_INFO, "****************** AlarmZoneStateMachine is now in state[{}]", state.c_str());
        });
     }

     void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         auto enablementEvent = ValidateEvent<Mol::Event::FunctionEnable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,Mol::FUNCTION_CODE::ALARM_DEVICES);
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveFunctionEnableEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
         if(! enablementEvent)
         {
             return;
         }
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveFunctionEnableEvent for ID {0}", GetID());
         m_updaterStateMachine.process_event(enablementEvent);
         m_updaterStateMachine.visit_current_states([](auto state){
             DEBUGPRINT(DEBUG_INFO, "******************* AlarmZoneStateMachine is now in state[{}]", state.c_str());
         });
     }

     void ReceiveAlarmSignalEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         m_updaterStateMachine.visit_current_states([](auto state){
             DEBUGPRINT(DEBUG_INFO, "******************* Before entering ALMSIG state machine AlarmZoneStateMachine is now in state[{}]", state.c_str());
         });
		 
		 m_retry = 0;
         auto alarmSignalEvent = ValidateEvent<Mol::Event::AlarmSignalEvent>(event, Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL);
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ******************* ReceiveAlarmSignalEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
		 DEBUGPRINT(DEBUG_INFO,"ReceiveAlarmSignalEvent is called event code [{}]",alarmSignalEvent->GetEventCode());
         if(! alarmSignalEvent)
         {
             return;
         }
         if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
         {
             DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveAlarmSignalEvent ignore from FIRE_DOMAIN_APP");
             return;
         }
         AddAlaramSignalFromAnotherPanel(alarmSignalEvent);
        
         if(alarmSignalEvent->GetEventCode() == 0)  //Deactivation Event
         {
            m_waitingForCommandAck = m_waitingForCommandAck & 0xF0; //Clear Deactivation Command on receiving Deactivation event
         }
         else
         {
            m_waitingForCommandAck = m_waitingForCommandAck & 0x0F; //Clear Activation Command on receiving Activation event
         } 
        
         m_updaterStateMachine.process_event(alarmSignalEvent);
		 
         m_updaterStateMachine.visit_current_states([](auto state){
             DEBUGPRINT(DEBUG_INFO, "******************* After leaving state machine ALMSIG AlarmZoneStateMachine is now in state[{}]", state.c_str());
         });
         PrintState();
     }

     void UserOperationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         m_updaterStateMachine.visit_current_states([](auto state){
             DEBUGPRINT(DEBUG_INFO, "USROP START AlarmZoneStateMachine is now in state[{}]", state.c_str());
         });
		 
         auto userOperationEvent = ValidateEvent<Mol::Event::UserOperationEvent>(event, Mol::Event::EVENT_CATEGORY::USER_OPERATION);
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: UserOperationEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
         if (!userOperationEvent)
         {
             return;
         }
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: receive USER_OPERATION[{0}] Event for ID {1}", (uint32_t)userOperationEvent->GetEventCode(), GetID());
         if((userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE)
                 || (userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND)
			     || (userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_ON)
				 || (userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_OFF))
         {
             m_updaterStateMachine.process_event(userOperationEvent);
         }
		 
         m_updaterStateMachine.visit_current_states([](auto state){
             DEBUGPRINT(DEBUG_INFO, "USROP END AlarmZoneStateMachine is now in state[{}]", state.c_str());
         });
     }

     void ReceiveSetAlarameSignalCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
     {
         auto setAlarmSignalCommand = ValidateCommand<Mol::Command::SetAlarmSignal>(command, Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL);
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveSetAlarameSignalCommand ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
         if (!setAlarmSignalCommand)
         {
             return;
         }
		 m_retry = 0;
         if(setAlarmSignalCommand->GetCommandTarget() != Mol::DataType::ObjectReference {GetID(), GetObjectType() })
         {
             //ignore event if it not sent to us
             DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveSetAlarameSignalCommand ignore this zone");
             return ;
         }

         if((setAlarmSignalCommand->GetCommandCode() == 0) && (m_activationRequestCount != 0))
         {
            --m_activationRequestCount;
            if(m_activationRequestCount > 0)
            {
                return;
            }
         }
         else if(setAlarmSignalCommand->GetCommandCode() != 0)
         {
            ++m_activationRequestCount;
         }
         else{
        	 /* Do Nothing */
         }
         if ((GetAlarmSignalId() == setAlarmSignalCommand->GetCommandCode() )
                 && IsThisLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode()))
         {
             return;
         }
         if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
         {
             DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveSetAlarameSignalCommand ignore from FIRE_DOMAIN_APP");
             return;
         }
         DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ReceiveSetAlarameSignalCommand(command=[], id =[{0}], address=[{1}])", id, (uint32_t) address);
         if(!IsDisabled())
         {
            if(setAlarmSignalCommand->GetCommandCode() == 0)
            {
                m_waitingForCommandAck = m_waitingForCommandAck | 0x0F;  //Received Deactivation Command
            }
            else
            {
                m_waitingForCommandAck = m_waitingForCommandAck | 0xF0; //Received Activation Command
            }
            m_commandSendTime = time(0);
            for(auto dnm: m_associatedDNM)
            {       
                SendCommand(setAlarmSignalCommand, PROC_ADDRESS::BROADCAST,false,dnm);
            }
         }
         if (! IsThisLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode()))
         {
             SetLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode());
         }
     }

         /**
    * Receive a FaultEvent and process panel failover
    * @param event      FaultEvent
    * @param id         an ID
    * @param address    Originator of event
    */
    void ProcessPanelFailover(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        if (nullptr == event)
        {
            currentErrorCode  = ERROR_CODE::NULL_FAULT_EVENT;
            return;
        }
        auto faultEvent = ValidateEvent<Mol::Event::FaultEvent>(event, Mol::Event::EVENT_CATEGORY::TROUBLE);
		
		auto sourceid = faultEvent->GetSource().GetObjectId();
		
		if((faultEvent->GetEventCode() != Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED) || ((sourceid & 0x00FFFF0000000000) == 0))
		{
			return;
		}
		
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ProcessPanelFailover for panel ID {0:#x} ", id);
        if (nullptr == faultEvent)
        {
            currentErrorCode  = ERROR_CODE::NULL_FAULT_EVENT;
            return;
        }
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler: ProcessPanelFailover ignore from FIRE_DOMAIN_APP");
            currentErrorCode  = ERROR_CODE::IGNOR_INTERNAL_EVENT;
            return;
        }
        //we ignore fault event from this panel, interested only on other panels in the network getting lost
        if(m_alarmSignalPanels.empty() || IsItMyPanelFailure(faultEvent,m_myPanelObjectRef))
        {
            currentErrorCode  = ERROR_CODE::IGNOR_EVENT;
            return;
        }
        Mol::DataType::ObjectReference source = faultEvent->GetSource();
        source.PrepareDeviceUniqueID();
        if(m_alarmSignalPanels.find(source.GetNodeID()) != m_alarmSignalPanels.end())
        {
            //mark panel as lost
            m_alarmSignalPanels[source.GetNodeID()] = true;
        }
        else
        {
            currentErrorCode  = ERROR_CODE::IGNOR_IF_NOT_SAME_PANEL;
        }
    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        if (nullptr == command)
        {
            currentErrorCode  = ERROR_CODE::NULL_FAULT_EVENT;
            return;
        }
       
        m_waitingForCommandAck = 0; 
        m_commandSendTime = 0;

        auto managedAreaReference = Mol::DataType::ObjectReference{GetManagedAreaId(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
        auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference);
        bool allPnelsLost =  !m_alarmSignalPanels.empty();
        if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP) || (m_alarmSignalPanels.empty()))
        {
            currentErrorCode  = ERROR_CODE::NULL_FAULT_EVENT;
            return;
        }
        //loop into all the alarm signals we received from remote panels and check if they are all lost
        for(auto& alarmPanel: m_alarmSignalPanels)
        {
            //if still one remote panel is not lost w'll not clear this entity
            if(!alarmPanel.second)
            {
                allPnelsLost =false;
                break;
            }
        }
        if(allPnelsLost)
        {
            m_alarmSignalPanels.clear();
        }
        //if no more alarm signal from remote panel is there, and no local alarm signal
        if(!thisPanelHasAlarmSignal && allPnelsLost)
        {
            auto alarmSignalEvent =  std::make_shared<Mol::Event::AlarmSignalEvent>(0);
            auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
            alarmSignalEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
            alarmSignalEvent->SetSource(reference);
            alarmSignalEvent->AddParent(managedAreaReference);
            m_updaterStateMachine.process_event(alarmSignalEvent);
            PrintState();
        }
    }
	
	void TroubleClearedEventReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		if((nullptr == event) || (PROC_ADDRESS::MODULE_APP != address))
		{
			return;
		}

		auto troublecleared = std::static_pointer_cast <Mol::Event::FaultClearedEvent> (event);

		if(troublecleared->GetEventCode()!= Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
		{
			return;
		}

        Mol::DeviceUniqueID uniqueid(troublecleared->GetSource().GetObjectId());
		auto pos = m_associatedModules.find(uniqueid.GetModuleID());
	
		if(m_associatedModules.end() != pos)
		{
			if( 0 != m_activationRequestCount )
			{
                auto setAlarmSignalCommand = std::make_shared < Mol::Command::SetAlarmSignal > (GetLastAlarmSignalId());
                setAlarmSignalCommand->SetCommandTarget(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
                for(auto dnm: m_associatedDNM)
                {
                    SendCommand(setAlarmSignalCommand, PROC_ADDRESS::BROADCAST,false, dnm);
                }
			    DEBUGPRINT(DEBUG_INFO,"FDA::AlarmZoneStateHandler::TroubleClearedEventReceived: set alarm signal command sent last alarm signal id [{0}]",GetLastAlarmSignalId());
			}

			if(m_disableCommandHandler.m_disablementCount > 0)
			{
				auto disable = std::make_shared<Mol::Command::Disable>();
                disable->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                for(auto dnm: m_associatedDNM)
                {
                    SendCommand(disable,PROC_ADDRESS::BROADCAST,false, dnm);
                }
			    DEBUGPRINT(DEBUG_INFO,"FDA::AlarmZoneStateHandler::TroubleClearedEventReceived: disable command sent");
			}
		}
	}
	
private:
     //LCOV_EXCL_START
     void PrintState()//print state
     {
         if (DEBUGPRINT::GetDebugLevel() >= DebugLevel::DEBUG_INFO)
         {
             m_updaterStateMachine.visit_current_states([this](auto state){
                 DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateHandler with ID: [{0}] is now in state[{1}]", GetID(), state.c_str());
                     });
         }
     }
     //LCOV_EXCL_STOP

    std::vector<XmlElementConfig> m_pointsConfig;
    XmlElementConfig m_element;
    uint32_t m_activationRequestCount = 0;
    AlarmZoneStateMachine<AlarmZoneStateHandler> m_alarmZoneStateMachine;
    boost::sml::sm<AlarmZoneStateMachine<AlarmZoneStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;
    DisableCommandHandler<AlarmZoneStateHandler> m_disableCommandHandler;
    DelayOperationHandler<AlarmZoneStateHandler> m_delayOperationHandler;
	PhysicalGroupFaultEventStateHandler<AlarmZoneStateHandler> m_faultEventHandler;
    Mol::DataType::ObjectReference m_myPanelObjectRef;
    bool thisPanelHasAlarmSignal = false;
    std::map<uint64_t, bool> m_alarmSignalPanels {};
	std::set<uint8_t>m_associatedModules;
    std::set<uint64_t> m_associatedDNM;
    ERROR_CODE currentErrorCode = ERROR_CODE::END_OF_LIST;
	uint16_t m_retry = 0;

    //|------------|------------|
    //| Activation |Deactivation|
    //|------------|------------|
    uint8_t m_waitingForCommandAck = 0;
    time_t  m_commandSendTime = 0;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_ALARM_ZONE_H
