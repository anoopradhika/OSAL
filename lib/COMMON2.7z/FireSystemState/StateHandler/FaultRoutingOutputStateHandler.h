/******************************************************************************//**
*
* @file   FaultRoutingOutputStateHandler.h
* @brief  State handler for FaultRoutingOutput
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FAULT_ROUTING_OUTPUT_H
#define FIRESYSTEM_STATE_HANDLER_FAULT_ROUTING_OUTPUT_H

#include <queue>
#include <bitset>
#include "DOL/Entities/Module.h"
#include "DOL/Entities/Point/FaultRoutingOutput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/FaultRoutingOutputPointStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "Mol/Requests/GeneralIndicatorServiceRequest.h"
#include "Mol/Responses/GeneralIndicatorServiceResponse.h"

#ifdef UT_TARGET

#ifndef protected
#define protected public
#endif

#ifndef private
#define prvate public
#endif

#endif

namespace fireSystemState
{

/**
* @brief FaultRoutingOutputStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class FaultRoutingOutputStateHandler: public Dol::Entities::FaultRoutingOutput, public StateHandler<FaultRoutingOutputStateHandler>
{
public:
    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    FaultRoutingOutputStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        FaultRoutingOutput(id)
        ,m_pointId{id}
        ,m_pointStateMachine(*this)
        ,m_updaterStateMachine{m_pointStateMachine}
        ,m_faultEventHandler(*this)
        ,m_disableCommandHandler(*this)
    {
    }

    ~FaultRoutingOutputStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto managedAreaReference = Mol::DataType::ObjectReference{0x1, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
        auto reference = Mol::DataType::ObjectReference{GetID(), GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION, reference, this, &FaultRoutingOutputStateHandler::ReceiveActivationEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE, managedAreaReference, this, &FaultRoutingOutputStateHandler::ReceiveFunctionDisableEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE, managedAreaReference, this, &FaultRoutingOutputStateHandler::ReceiveFunctionEnableEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE, reference, this, &FaultRoutingOutputStateHandler::ReceiveActivateCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE, reference, this, &FaultRoutingOutputStateHandler::ReceiveDeactivateCommand);

        m_communicator.m_response.Subscribe<Mol::Response::GeneralIndicatorServiceResponse>(Mol::Response::RESPONSE_CATEGORY::GENERAL_INDICATOR_SERVICE_RESPONSE);
        m_communicator.m_response.getService(Mol::Response::RESPONSE_CATEGORY::GENERAL_INDICATOR_SERVICE_RESPONSE)->Connect(this, &FaultRoutingOutputStateHandler::FaultResponseNotification);

        m_communicator.m_event.Subscribe<Mol::Event::InformationEvent>(Mol::Event::EVENT_CATEGORY::INFORMATION);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::INFORMATION)->Connect(this, &FaultRoutingOutputStateHandler::ProcessModuleConnectedEvent);


        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
        RequestGeneralIndicatorStatus();
    }

    bool GetFaultStatus() const
    {
        return m_faultStatus;
    }

    void SendActivateCommand()
    {
        auto command = std::make_shared<Mol::Command::Activate>();
        command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
        m_communicator.m_command.Send(command, PROC_ADDRESS::BROADCAST, GetID());
    }

    void SendDeactivateCommand()
    {
        auto command = std::make_shared<Mol::Command::Deactivate>();
        command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
        m_communicator.m_command.Send(command, PROC_ADDRESS::BROADCAST, GetID());
    }


protected:

    /**
     * @brief  Fault response notification handler
     *
     * @param messageBase - received message
     * @param senderID - Unique id of the sender
     */
    void FaultResponseNotification(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> messageBase, uint64_t senderID)
    {
        if(nullptr == messageBase)
        {
            return;
        }
        auto indicatorResponse = std::static_pointer_cast<Mol::Response::GeneralIndicatorServiceResponse>(messageBase);
        std::bitset<32> indicatorBits(static_cast<uint16_t>(indicatorResponse->GetResponseCode()));
        if(indicatorBits.test(Mol::Response::GeneralIndicatorSnapshot::Fault))
        {
            m_faultStatus = true;
            m_updaterStateMachine.process_event(FROSMEvents::Fault{});
        }
        else
        {
            m_faultStatus = false;
            m_updaterStateMachine.process_event(FROSMEvents::FaultCleared{});
			SendDeactivateCommand();
        }
    }

    /**
     * @brief  InformationEvent notification for new module connected
     * @param event - new module connected event received
     * @param senderID - Unique id of the sender
     */
void ProcessModuleConnectedEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
    {
        if(event == nullptr)
        {
            DEBUGPRINT(DEBUG_ERROR,"ProcessModuleConnectedEvent:Received invalid event");
            return;
        }
	DEBUGPRINT(DEBUG_INFO, "FaultRoutingOutputStateHandler:ProcessModuleConnectedEvent");
        auto infoEvent = std::static_pointer_cast<Mol::Event::InformationEvent>(event);
        if (infoEvent->GetEventCode() == Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED)
        {
	    DEBUGPRINT(DEBUG_ERROR, "FaultRoutingOutputStateHandler:NEW_MODULE_CONNECTED event received");
            try
            {
                using dolModType = Dol::Entities::Module::MODULE_TYPE;
                std::vector<Mol::DataType::Parameter> parameter = infoEvent->GetParameters();
                if (parameter.size() == 0)
                {
                    DEBUGPRINT(DEBUG_ERROR, "FaultRoutingOutputStateHandler:No module object in NEW_MODULE_CONNECTED event");
                    return;
                }
                std::shared_ptr<Dol::Entities::Module> moduleObject = parameter.at(0).GetValue<std::shared_ptr<Dol::Entities::Module> >();
                if (moduleObject == nullptr)
                {
                    DEBUGPRINT(DEBUG_ERROR, "FaultRoutingOutputStateHandler:nullptr when deserializing module object");
                    return;
                }
                dolModType dolType = moduleObject->GetType();
                if (Dol::Entities::Module::MODULE_TYPE::FARE_FRE == dolType && GetFaultStatus())
                {
	            DEBUGPRINT(DEBUG_ERROR, "FaultRoutingOutputStateHandler:Send FRE Activate command");
                    SendActivateCommand();
                }
            }
            catch (...)
            {
                DEBUGPRINT(DEBUG_ERROR, "FaultRoutingOutputStateHandler:New Module Connected failed ");
				return;
            }
        }
  
    }

    /**
    * Receive a activation event and invaoke state mechine
    * @param event      Activation Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveActivationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto activationEvent = ValidateEvent<Mol::Event::ActivationEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::ACTIVATION
                                                                            );
        if((nullptr == activationEvent ) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(activationEvent);
    }


    void ReceiveActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto activate = ValidateCommand<Mol::Command::Activate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::ACTIVATE
                                                        );

        if((nullptr == activate) || IsActivated() || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        SendCommand(activate, PROC_ADDRESS::BROADCAST);
    }

    void ReceiveDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::DEACTIVATE
                                                        );
        if(! deactivate)
        {
            return;
        }

        if(!IsActivated() || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        SendCommand(deactivate, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive a Function disablement Event and invaoke state mechine
    * @param event      Function disablement Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionDisable = ValidateEvent<Mol::Event::FunctionDisable>(event
                                                                            , Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE
                                                                            , Mol::FUNCTION_CODE::FAULT_ROUTING);
        if((nullptr == functionDisable) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(functionDisable);
    }

    /**
    * Receive a Function enablement Event and invaoke state mechine
    * @param event      Function enablement Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionEnable = ValidateEvent<Mol::Event::FunctionEnable>(event
                                                                            , Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE
                                                                            , Mol::FUNCTION_CODE::FAULT_ROUTING);
        if(nullptr == functionEnable)
        {
            return;
        }
        m_updaterStateMachine.process_event(functionEnable);
    }

    /**
    * @brief Request for General Indicator status
    */
    void RequestGeneralIndicatorStatus()
    {
        auto generalRequest = std::make_shared<Mol::Request::GeneralIndicatorServiceRequest>(Mol::IndicatorServiceCode::ADD, Mol::SubscriberList::FDA);
        m_communicator.m_request.Send(generalRequest, PROC_ADDRESS::EVENT_PROVIDERAPP,0,0,true);
    }
private:
    uint64_t m_pointId;

    FaultRoutingOutputPointStateMachine<FaultRoutingOutputStateHandler> m_pointStateMachine;

    boost::sml::sm<FaultRoutingOutputPointStateMachine<FaultRoutingOutputStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    PhysicalGroupFaultEventStateHandler<FaultRoutingOutputStateHandler> m_faultEventHandler;

    DisableCommandHandler<FaultRoutingOutputStateHandler> m_disableCommandHandler;

    bool m_faultStatus{false};
};

}

#endif //FIRESYSTEM_STATE_HANDLER_FAULT_ROUTING_OUTPUT_H

