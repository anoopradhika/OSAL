/******************************************************************************//**
*
* @file   ChargerModuleStateHandler.h
* @brief  State handler for Module
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_CHARGER_MODULE_H
#define FIRESYSTEM_STATE_HANDLER_CHARGER_MODULE_H

#include "ModuleStateHandler.h"

namespace fireSystemState
{

/**
* @brief ChargerModuleStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class ChargerModuleStateHandler: public ModuleStateHandler<Dol::Entities::ChargerModule>
{

public:

    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    ChargerModuleStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        ModuleStateHandler<Dol::Entities::ChargerModule>(id, element)
    {
    }
//  LCOV_EXCL_START
    ~ChargerModuleStateHandler() override = default;
//  LCOV_EXCL_STOP
};

}

#endif //FIRESYSTEM_STATE_HANDLER_CHARGER_MODULE_H
