/******************************************************************************//**
*
* @file   FirePanelStateHandler.h
* @brief  State handler for FirePanel
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FIRE_PANEL_H
#define FIRESYSTEM_STATE_HANDLER_FIRE_PANEL_H

#include "DOL/LifeSafetyNetworkDevice/FirePanel.h"
#include "Utility.h"
#include "Component/Component.h"

#include "Mol/Events/Event.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/AccessEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/AlarmSignalEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/InputChangeEvent.h"
#include "Mol/Events/MaintenanceEvent.h"
#include "Mol/Events/Reset.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/WarningEvent.h"

#include "Mol/Commands/Command.h"
#include "Mol/Commands/Activate.h"
#include "Mol/Commands/Deactivate.h"
#include "Mol/Commands/ApplyConfiguration.h"
#include "Mol/Commands/CancelBuzzer.h"
#include "Mol/Commands/DelayOff.h"
#include "Mol/Commands/DelayOn.h"
#include "Mol/Commands/Disable.h"
#include "Mol/Commands/Enable.h"
#include "Mol/Commands/ExtendDelays.h"
#include "Mol/Commands/MeasureReferenceResistance.h"
#include "Mol/Commands/ModuleReboot.h"
#include "Mol/Commands/ModuleShutdown.h"
#include "Mol/Commands/OverrideDelays.h"
#include "Mol/Commands/Reset.h"
#include "Mol/Commands/ClearCounter.h"
#include "Mol/Commands/Resound.h"
#include "Mol/Commands/ServiceMode.h"
#include "Mol/Commands/Silence.h"
#include "Mol/Commands/EarthFaultMonitoring.h"
#include "Mol/Commands/SoftwareCenterCommands.h"
#include "Mol/Commands/SetAlarmSignal.h"
#include "Mol/Commands/SetDayNightMode.h"
#include "Mol/Commands/BatteryOperation.h"
#include "Mol/Commands/TestZoneStart.h"
#include "Mol/Commands/TestZoneStop.h"
#include "Mol/Commands/StartIndicatorTest.h"
#include "Mol/Commands/StopIndicatorTest.h"
#include "Mol/Commands/SetDebugLevel.h"
#include "Mol/Commands/FunctionDisable.h"
#include "Mol/Commands/FunctionEnable.h"
#include "Mol/Commands/EvacuationOn.h"
#include "Mol/Commands/EvacuationOff.h"
#include "Mol/Commands/FareTest.h"

#include "EventDispatcher/EventDispatcher.h"
#include "CommandDispatcher/CommandDispatcher.h"
#include "Signal/Signal.h"

#include "StateHandler/ManagedAreaStateHandler.h"
#include "StateHandler/ModuleStateHandler.h"
#include "StateObjectFactory/ModuleStateObjectList.h"
#include "StateSetup/ModuleStateSetup.h"
#include "DomainConfiguration/DomainConfiguration.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"

#include "Utility.h"
#include "SystemConfigFileParser.h"
#include <cereal/types/polymorphic.hpp>
#include "EnumHelper.h"

#define noop (void)0

namespace fireSystemState
{

/**
* FirePanelStateHandler is a Component. It handles Dol FirePanel status and children status
* It receive all Mol API and forwatd to children
*/
class FirePanelStateHandler: public Dol::Entities::FirePanel,  public Platform::Component, public StateHandler<FirePanelStateHandler>
{
public:
    /**
    * Setup Dol FirePanel
    */
    explicit FirePanelStateHandler(XmlElementConfig& element):
        FirePanel{element.id}
        ,m_element{element}
        ,m_faultEventHandler(*this)
        ,m_currentUserAccessLevel(1)
    {
    }

    ~FirePanelStateHandler() override = default;

    /**
    * Collect ManagedArea configuration
    * Add managedArea StateHandler to building
    */
    void Prepare() override
    {
        Platform::Component::Prepare();

        ModuleConfig(m_element,m_modulesConfig);
        for(auto& moduleConfig: m_modulesConfig)
        {
            auto moduleState = StateObjectFactory<Dol::Entities::Module,ModuleStateObjectTypes>::Create(moduleConfig);
            if(moduleState)
            {
                ModuleStatePrepare(moduleState);
                ModuleSignalSetup(moduleState);
                AddModule(moduleState);
            }
        }

        std::string panelLanguage = GetCurrentLanguage();
        uint8_t     numberOfLoops = 0u;
        uint8_t     numberOfRepeaters = 0u;

        GetNumberOfLoops(numberOfLoops, numberOfRepeaters);

        FirePanel::SetPanelLanguage(panelLanguage);
        FirePanel::SetPanelLoopCount(numberOfLoops);
        FirePanel::SetPanelRepeaterCount(numberOfRepeaters);

        SetupSignal();
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal()
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        m_faultEventHandler.SetupSignal();
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::USER_ACCESS,reference,this,&FirePanelStateHandler::ReceiveUserAccessEvent);

        Platform::Component::m_communicator.m_event.Subscribe<Mol::Event::InformationEvent>(Mol::Event::EVENT_CATEGORY::INFORMATION);
        Platform::Component::m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::INFORMATION)->Connect(this, &FirePanelStateHandler::MainCPUModuleReceived);
        Platform::Component::m_communicator.m_request.Subscribe<Mol::Request::ObjectData>(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        Platform::Component::m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA)->Connect(this, &FirePanelStateHandler::ReceiveObjectData);
    }
    /**
    * Receive a User Access event
    * @param event : UserAccessEvent
    */
    void ReceiveUserAccessEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto userAccessEvent = ValidateEvent<Mol::Event::AccessEvent>(event , Mol::Event::EVENT_CATEGORY::USER_ACCESS);

        if(! userAccessEvent)
        {
            return;
        }

		Mol::DataType::ObjectReference source = userAccessEvent->GetSource();
        if(source.GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL && userAccessEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::FIRE)
        {
            m_currentUserAccessLevel = static_cast<uint16_t>(userAccessEvent->GetEventCode());
            DEBUGPRINT(DEBUG_INFO, "FirePanelStateHandler::ReceiveUserAccessEvent: Access Level code[{}]", m_currentUserAccessLevel);
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        SendEvent(userAccessEvent,PROC_ADDRESS::BROADCAST,true);
        DEBUGPRINT(DEBUG_INFO, "FirePanelStateHandler is now in state - User access received");
    }

    /**
      * @brief MainCPUModuleReceived call back is called when a new MainCPU is connected, it is used to fill some of the FirePanel common information like software version
      * @param event : the NEW_MODULE_CONNECTED information event containing the MainCPU domain object as a parameter
      * @param senderID : not used
      */
     void MainCPUModuleReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
     {
         std::shared_ptr<Dol::Entities::CPUModule> moduleObject{};
         auto newModuleInfoEvent = fireSystemState::ValidateEvent<Mol::Event::InformationEvent>(event, Mol::Event::EVENT_CATEGORY::INFORMATION,  Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED);
         if(newModuleInfoEvent == nullptr)
         {
             return;
         }
         auto parameters = newModuleInfoEvent->GetParameters();
         for(auto& parameter : parameters)
         {
            if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT)
            {
                DEBUGPRINT(DEBUG_INFO, "FirePanelStateHandler:MainCPUModuleReceived DOMAIN_OBJECT in catalog found");
                moduleObject = parameter.GetValue<std::shared_ptr<Dol::Entities::CPUModule> >();
                if(nullptr != moduleObject)
                {
                    if(Dol::Entities::Module::MODULE_TYPE::MAINCPU !=  moduleObject->GetType())
                    {
                        return;
                    }
                    auto id = GetID();
                    if ((Mol::DeviceUniqueID { moduleObject->GetID() }.GetDomainID() != Mol::DeviceUniqueID { id }.GetDomainID()) ||
                            (Mol::DeviceUniqueID { moduleObject->GetID() }.GetNodeID() != Mol::DeviceUniqueID {id}.GetNodeID()))
                    {
                        //not interested on others Main CPU in the network
                        return;
                    }
                    SendDol(GetFirePanel(moduleObject), PROC_ADDRESS::BROADCAST);
                }
                else
                {
                    DEBUGPRINT(DEBUG_ERROR, "FirePanelStateHandler::MainCPUModuleReceived() nullptr moduleObject");
                    return;
                }
            }
         }
         return;
     }
protected:
   /**
    * Receive a ObjectData Request and invoke state machine
    * @param event      ObjectData Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveObjectData(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto ObjectDataRequest = ValidateRequest<Mol::Request::ObjectData>(request, Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        if(nullptr == ObjectDataRequest)
        {
			DEBUGPRINT(DEBUG_INFO,"FirePanelStateHandler:ReceiveObjectData:ObjectData request is null");
            return;
        }
	
		auto sourceRef = ObjectDataRequest->GetSource();
		auto targetRef = ObjectDataRequest->GetTarget();
		auto source = ObjectDataRequest->GetSourceTarget();

        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL || targetRef.GetObjectId() != this->GetID())
        {
			DEBUGPRINT(DEBUG_INFO,"FirePanelStateHandler:ReceiveObjectData:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }
 	
		auto statusRequest = std::static_pointer_cast<Mol::Request::ObjectData>(request);
        auto queryType = statusRequest->GetRequestCode();

		if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS)
		{
            auto FirePaneleObj = std::static_pointer_cast<Dol::Entities::FirePanel>(shared_from_this());
			if(nullptr == FirePaneleObj)
			{
				DEBUGPRINT(DEBUG_INFO,"FirePanelStateHandler:ReceiveObjectData:FirePanel object is null");
				return;
			}
            // Add the current access level
            FirePaneleObj->SetUserAccessLevel(m_currentUserAccessLevel);
			auto ObjectDataResponse = std::make_shared<Mol::Response::ObjectDataResponse>();
			if(nullptr == ObjectDataResponse)
			{
				DEBUGPRINT(DEBUG_INFO,"FirePanelStateHandler:ReceiveObjectData:ObjectdataResponse object is null");
				return;
			}
		
			ObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *FirePaneleObj);	
			ObjectDataResponse->SetObjectStatusType(Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
			
			ObjectDataResponse->SetTarget(sourceRef);
			ObjectDataResponse->SetSource(targetRef);
			ObjectDataResponse->SetResponseTarget(source);

			SendResponse(ObjectDataResponse, PROC_ADDRESS::CMCAPP);
            SendResponse(ObjectDataResponse, PROC_ADDRESS::MOL_RECEIVER);
            DEBUGPRINT(DEBUG_INFO,"FirePanelStateHandler:ReceiveObjectData:Object Data response sent");
		}

		else if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN)
		{
            DEBUGPRINT(DEBUG_INFO,"FirePanelStateHandler:ReceiveObjectData:Request For Number Of Children");
		}

		else
        {
            DEBUGPRINT(DEBUG_INFO, "FirePanelStateHandler::ReceiveObjectData: Invalid request type[{}]", static_cast<int>(queryType));
        }
    }

 /**
   * @brief GetFirePanel update local FirePanel DOL with default information from MainCPU DOL
   * @param cpuModule : to be used to fill comone info like software version and config version
   */
    std::shared_ptr<FirePanelStateHandler> GetFirePanel(std::shared_ptr<Dol::Entities::CPUModule> cpuModule)
    {
        Dol::PanelType validType;
        if(EnumHelper::StringToEnumerator(SystemConfigParser{}.GetThisPanelType().c_str(), validType))
        {
            SetPanelType(validType);
        }

        if(nullptr != cpuModule)
        {

            if(nullptr != cpuModule->GetSoftwareVersion())
            {
                SetPanelSoftwareVersion(cpuModule->GetSoftwareVersion()->GetString());
            }
            SetPanelSerialNumber(cpuModule->GetSerialNumber());
            try
            {
                SetPanelNumber(std::stoi(SystemConfigParser{}.GetThisPanelNumber()));
            }
	    	catch(...)		//not interested by the result of the exception, just don't crash
			{
				DEBUGPRINT(DEBUG_ERROR, "GetFirePanel: Exception ");
				noop;						//To fix sonarqube vulnerability
			}
            SetPanelHardwareVersion(cpuModule->GetHardwareVersion());
            SetPanelIPv6Address(cpuModule->GetIpv6Address());
            if(nullptr != cpuModule->GetConfigurationVersion())
            {
                SetPanelConfigVersion(cpuModule->GetConfigurationVersion()->GetString());
            }
        }
        return shared_from_this();
    }
    friend class cereal::access;
    //! Member shall be added here for serialization
    template<class Archive>
    void serialize(Archive& archive)
    {
        archive(cereal::base_class<Dol::Entities::FirePanel>(this));
    }

    XmlElementConfig& m_element;
private:
    PhysicalGroupFaultEventStateHandler<FirePanelStateHandler> m_faultEventHandler;
    std::vector<XmlElementConfig> m_modulesConfig;
    uint16_t m_currentUserAccessLevel;
};

}

#endif // FIRESYSTEM_STATE_HANDLER_FIRE_PANEL_H
