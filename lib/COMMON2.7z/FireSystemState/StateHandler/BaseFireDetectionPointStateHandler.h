/******************************************************************************//**
*
* @file   BaseFireDetectionPointStateHandler.h
* @brief  State handler for FireSensor
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_BASE_FIRE_DETECTION_POINT_SENSOR_H
#define FIRESYSTEM_STATE_HANDLER_BASE_FIRE_DETECTION_POINT_SENSOR_H

#include <queue>

#include "DOL/Entities/Point/FireSensor.h"
#include "DOL/Entities/Zone/Zone.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"
#include "Mol/Events/EventCategory.h"
#include "StateMachine/FirePointStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "boost/sml.hpp"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include <cereal/types/set.hpp>

namespace fireSystemState
{

/**
* @brief BaseFireDetectionPointStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
template<typename PointType, typename HANDLER>
class BaseFireDetectionPointStateHandler: public PointType, public StateHandler<HANDLER>
{
    using BASE_HANDLER = BaseFireDetectionPointStateHandler<PointType,HANDLER>;
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    BaseFireDetectionPointStateHandler(const Dol::DomainObjectID id, XmlElementConfig element):
        PointType(id)
        ,m_pointStateMachine(*this)
        ,m_updaterStateMachine{m_pointStateMachine}
        ,m_faultEventHandler(*this)
        ,m_disableCommandHandler(*this)
    {
        std::cout<<"FS:BaseFireDetectionPointStateHandler id "<<std::hex<<id<<std::endl;
        //if this entity belonging to the current panel, then we should not subscribe to panel failure fault event later.
        m_isFromThisPanel = PointFromThisPanel(BASE_HANDLER::GetID(), m_myPanelObjectRef);
        m_myObjectRef = Mol::DataType::ObjectReference{BASE_HANDLER::GetID(), BASE_HANDLER::GetObjectType()};
        if(! m_isFromThisPanel)
        {
            m_myCPUModuleObjectRef = Mol::DataType::ObjectReference{BASE_HANDLER::GetCPUModuleIDFromPanelID(m_myPanelObjectRef.GetObjectId()), Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
        }
    }

    ~BaseFireDetectionPointStateHandler() override = default;

    bool PointFromThisPanel(uint64_t pointID, Mol::DataType::ObjectReference& pointPanelRef)
    {
        auto nodeID = Mol::DeviceUniqueID(pointID).GetNodeID();
        auto domainID = Mol::DeviceUniqueID(pointID).GetDomainID();
        pointPanelRef =  Mol::DataType::PointReferenceHelper::Create(domainID, nodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        auto m_thisPanelID = Utility::ReadPanelID();
        auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
        auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
        auto m_thisPanelObjRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        return  (pointPanelRef == m_thisPanelObjRef);
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto parentZones = BASE_HANDLER::GetParentZones();
        uint64_t managedAreaId = 0;
        for(auto& parent: parentZones)
        {
            //std::cout<<"FS: ID: "<<std::hex<<BASE_HANDLER::GetID()<<" Zone: "<<std::hex<<parent->BASE_HANDLER::GetID()<<" MA:"<<std::hex<<parent->BASE_HANDLER::GetManagedAreaId()<<std::endl;
            if(managedAreaId != parent->GetManagedAreaId())
            {
                managedAreaId = parent->GetManagedAreaId();
                auto managedAreaReference = Mol::DataType::ObjectReference{managedAreaId,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
                //need managed area info to add it to alarm events later
                // @TODO we may need also to add parent zone informations
                m_parentReferences.emplace(managedAreaReference);
                BASE_HANDLER::PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET,managedAreaReference,this,&BASE_HANDLER::ReceiveResetCommand);
            }

            if(parent->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE)
            {
                //std::cout<<"FS: Subscribe for zone Disablement: ID: "<<std::hex<<GetID()<<" Zone: "<<std::hex<<parent->GetID()<<" MA:"<<
                        //std::hex<<parent->GetManagedAreaId()<<std::endl;
                auto zoneReference = Mol::DataType::ObjectReference{parent->GetID(),parent->GetObjectType()};
                BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT, zoneReference, this, &BASE_HANDLER::ReceiveDisablementEvent);
                BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TEST, zoneReference, this, &BASE_HANDLER::ReceiveTestEvent);
            }
        }

        auto reference = Mol::DataType::ObjectReference{BASE_HANDLER::GetID(),BASE_HANDLER::GetObjectType()};
        BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&BASE_HANDLER::ReceiveDisablementEvent);
        BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ALARM, reference, this, &BASE_HANDLER::ReceiveAlarmEvent);

        if(! m_isFromThisPanel)//register only for entities connected to other panels in the network (ignore for this one)
        {
            BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myPanelObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultEvent>);
            //@TODO remove later when we ensure they don't change their mind agin
            //BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myPanelObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            if(m_myCPUModuleObjectRef.GetObjectId())
            {
                BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myCPUModuleObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultEvent>);
                //@TODO remove later when we ensure they don't change their mind agin
                //BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myCPUModuleObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            }
        }
		Platform::Communicator  communicator;

		communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &BASE_HANDLER::ReceiveSubsystemFaultClearEvent);

        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
    }

    /**
    * @brief check if the provided ObjectReference is a one of the current state handler parents
    * @param reference      Mol::DataType::ObjectReference
    * @return bool         true/false
    */
    bool IsEventFromParent(const Mol::DataType::ObjectReference& reference)
    {
        auto parentZones = BASE_HANDLER::GetParentZones();
        for(auto& parent: parentZones)
        {
            if((reference.GetObjectType() == parent->GetObjectType()) && (reference.GetObjectId() == parent->GetID()))
            {
                return true;
            }
        }
        return false;
    }

    /**
    * @brief return the panel ID of the current entity state handler
    * Example: 0x100020000000000 for panel 2 if the entity ID is 0x100020300000001
    * DOMAIN_OBJECT_TYPE::FIRE_PANEL type and ID 0x100020000000000
    * @return Mol::DataType::ObjectReference  of the panel
    */
    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_myPanelObjectRef;
    }

    /**
    * @brief return the ObjectReference of the current entity state handler
    * @return Mol::DataType::ObjectReference  of the panel
    */
    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return Mol::DataType::ObjectReference{BASE_HANDLER::GetID(),BASE_HANDLER::GetObjectType()};
    }

    /**
    * @brief last Alarem event received form Loop module, to create another return from alarm event out of it
    */
    std::shared_ptr<Mol::Event::AlarmEvent> lastAlarmEvent = nullptr;
    /**
    * @brief last TestOperationEvent event received form Loop module, to create another End Of Test event out of it
    */
    std::shared_ptr<Mol::Event::TestOperationEvent> lastTestEvent = nullptr;
    /**
    * @brief last Point Disablement event received form Loop module, to create another Enablment event out of it
    */
    std::shared_ptr<Mol::Event::DisablementEvent> lastPointDisablementEvent = nullptr;
    /**
    * @brief last Zone Disablement event received form Loop module, to create another Enablment event out of it
    */
    std::shared_ptr<Mol::Event::DisablementEvent> lastZoneDisablementEvent = nullptr;

protected:

    /**
    * Receive a disablementEvent and invoke state machine
    * @param event      DisablementEvent
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event, Mol::Event::EVENT_CATEGORY::DISABLEMENT);
        DEBUGPRINT(DEBUG_INFO,"BaseFireDetectionPointStateHandler: ReceiveDisablementEvent() address[{0}], disablementEvent[{1}]",
                (uint8_t)address, disablementEvent);
        if(nullptr == disablementEvent)
        {
            return;
        }
        UpdatePointZoneReference<Mol::Event::DisablementEvent,
                                    Mol::Event::EVENT_CATEGORY,
                                    BASE_HANDLER>(disablementEvent,Mol::Event::EVENT_CATEGORY::DISABLEMENT, this);
        m_updaterStateMachine.process_event(disablementEvent);
        auto pointID = BASE_HANDLER::GetID();
        m_updaterStateMachine.visit_current_states([pointID](auto state){
            DEBUGPRINT(DEBUG_INFO, "BaseFireDetectionPointStateHandler:ReceiveFaultClearedEvent for [{0:#x}] is now in state[{1}]", pointID, state.c_str());
                });
    }

    /**
    * Receive a Alarm Event and invoke state machine
    * @param event      Alarm Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveAlarmEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto alarmEvent = ValidateEvent<Mol::Event::AlarmEvent>(event, Mol::Event::EVENT_CATEGORY::ALARM);
        if(nullptr == alarmEvent)
        {
            return;
        }
        for (auto& parentReferences : m_parentReferences)
        {
            alarmEvent->AddParent(parentReferences);
        }
        UpdatePointZoneReference<Mol::Event::AlarmEvent,
                                Mol::Event::EVENT_CATEGORY,
                                BASE_HANDLER>(alarmEvent,Mol::Event::EVENT_CATEGORY::ALARM, this);
        m_updaterStateMachine.process_event(alarmEvent);
        auto pointID = BASE_HANDLER::GetID();
        m_updaterStateMachine.visit_current_states([pointID](auto state){
            DEBUGPRINT(DEBUG_INFO, "BaseFireDetectionPointStateHandler:ReceiveFaultClearedEvent for [{0:#x}] is now in state[{1}]", pointID, state.c_str());
                });
    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto zone = BASE_HANDLER::GetParentZones();
        for (auto elem : zone)
        {
            auto managedAreaID = elem->GetManagedAreaId();
            auto managedAreaReference = Mol::DataType::ObjectReference{managedAreaID, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
            auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference);
            if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
            {
                return;
            }
            m_updaterStateMachine.process_event(reset);
            auto pointID = BASE_HANDLER::GetID();
            m_updaterStateMachine.visit_current_states([pointID](auto state){
                DEBUGPRINT(DEBUG_INFO, "BaseFireDetectionPointStateHandler:ReceiveResetCommand for [{0:#x}]is now in state[{1}]", pointID, state.c_str());
                    });
        }
    }

     /**
     * Receive a Test Event and invoke state machine
     * @param event      test Event
     * @param id         senderID - Unique id of the sender
     * @param address    Originator of event
     */
     void ReceiveTestEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         auto testEvent = ValidateEvent<Mol::Event::TestOperationEvent>(event, Mol::Event::EVENT_CATEGORY::TEST);
         if(nullptr == testEvent)
         {
             return;
         }
         m_updaterStateMachine.process_event(testEvent);
         auto pointID = BASE_HANDLER::GetID();
         m_updaterStateMachine.visit_current_states([pointID](auto state){
             DEBUGPRINT(DEBUG_INFO, "BaseFireDetectionPointStateHandler:ReceiveTestEvent for [{0:#x}]is now in state[{1}]", pointID, state.c_str());
                 });
     }

     /** Receive a Fault/FaultCleared event and invoke state machine
     * @param event      Fault/FaultClearedEvent Event
     * @param id         senderID - Unique id of the sender
     * @param address    Originator of event
     */
     template<typename FaultEventType>
     void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID, PROC_ADDRESS address)
     {
         Mol::Event::EVENT_CATEGORY category = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
         if(std::is_same<FaultEventType, Mol::Event::FaultClearedEvent>::value)
         {
             DEBUGPRINT(DEBUG_INFO,"BaseFireDetectionPointStateHandler: FaultClearedEvent");
             category = Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED;
         }
         else if(std::is_same<FaultEventType, Mol::Event::FaultEvent>::value)
         {
             DEBUGPRINT(DEBUG_INFO,"BaseFireDetectionPointStateHandler: FaultEvent");
             category = Mol::Event::EVENT_CATEGORY::TROUBLE;
         }
         else
         {
            //Do nothing
         }

         auto faultEvent = ValidateEvent<FaultEventType>(event, category);
         if(! faultEvent)
         {
             return;
         }
         //we handle both FIRE_PANEL && CPU_MODULE
         if( !IsItMyPanelFailure(faultEvent,m_myPanelObjectRef))
         {
             return;
         }
         if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
         {
             return;
         }
         if(IsItMine(faultEvent, m_myObjectRef)) //Ignore faults event from my panel
         {
             for (auto &parentReferences : m_parentReferences)
             {
                 faultEvent->AddParent(parentReferences);
             }
         }
         m_updaterStateMachine.process_event(faultEvent);
         auto pointID = BASE_HANDLER::GetID();
         m_updaterStateMachine.visit_current_states([pointID](auto state){
             DEBUGPRINT(DEBUG_INFO, "BaseFireDetectionPointStateHandler:ReceiveFaultEvent for [{0:#x}]is now in state[{1}]", pointID, state.c_str());
                 });
     }

	void ReceiveSubsystemFaultClearEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		DEBUGPRINT(DEBUG_INFO, "In BASE_HANDLER::ReceiveSubsystemFaultClearEvent");

		auto FaultClearedEvent = std::static_pointer_cast<Mol::Event::FaultClearedEvent>(event);

		if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS == FaultClearedEvent->GetEventCode())
		{
           auto objectReference = FaultClearedEvent->GetSource();
           Mol::DeviceUniqueID msgsrcid(objectReference.GetObjectId());
		   Mol::DeviceUniqueID thispanelid(BASE_HANDLER::GetID());

		   if(msgsrcid.GetNodeID() == thispanelid.GetNodeID())
		   {
			   m_updaterStateMachine.process_event(FaultClearedEvent);
		   }
		}
	}
private:
     Mol::DataType::ObjectReference m_myPanelObjectRef;
     Mol::DataType::ObjectReference m_myCPUModuleObjectRef;
     bool m_isFromThisPanel = false;
    FirePointStateMachine<BaseFireDetectionPointStateHandler> m_pointStateMachine;
    boost::sml::sm<FirePointStateMachine<BaseFireDetectionPointStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    FaultEventStateHandler<BaseFireDetectionPointStateHandler> m_faultEventHandler;
    DisableCommandHandler<BaseFireDetectionPointStateHandler> m_disableCommandHandler;
    std::set<Mol::DataType::ObjectReference> m_parentReferences;
    Mol::DataType::ObjectReference m_myObjectRef;
};
}

#endif //FIRESYSTEM_STATE_HANDLER_BASE_FIRE_DETECTION_POINT_SENSOR_H
