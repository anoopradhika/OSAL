/****************************************************************************************//**
*
* @file  TechnicalAlarmInputStateHandler.h
* @brief  State handler for TechnicalAlarmInput DOL type TechnicalAlarmPoint
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
********************************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_TECHNICAL_ALARM_INPUT_H
#define FIRESYSTEM_STATE_HANDLER_TECHNICAL_ALARM_INPUT_H

#include <queue>

#include "DOL/Entities/Point/TechnicalAlarmInput.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"
#include "Mol/Events/EventCategory.h"
#include "StateMachine/TechAlarmPointStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "boost/sml.hpp"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

namespace fireSystemState
{

/**
* @brief TechnicalAlarmInputStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class TechnicalAlarmInputStateHandler: public Dol::Entities::TechnicalAlarmInput, public StateHandler<TechnicalAlarmInputStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    TechnicalAlarmInputStateHandler(const Dol::DomainObjectID id, XmlElementConfig element):
        TechnicalAlarmInput(id)
        ,m_pointStateMachine(*this)
        ,m_updaterStateMachine{m_pointStateMachine}
        ,m_faultEventHandler(*this)
        ,m_disableCommandHandler(*this)
    {
    }

    ~TechnicalAlarmInputStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto parentZones = GetParentZones();
        uint64_t managedAreaId = 0;
        for(auto& parent: parentZones )
        {
//LCOV_EXCL_START
            std::cout<<"Technical alarm point : ID: "<<std::hex<<GetID()<<" Zone: "<<std::hex<<parent->GetID()<<" MA:"<<std::hex<<parent->GetManagedAreaId()<<std::endl;
            if(managedAreaId != parent->GetManagedAreaId())
            {
                managedAreaId = parent->GetManagedAreaId();
                auto managedAreaReference = Mol::DataType::ObjectReference{managedAreaId,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
                //need managed area info to add it to alarm events later
                // @TODO we may need also to add parent zone informations
                m_parentReferences.emplace(managedAreaReference);
                PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET,managedAreaReference,this,&TechnicalAlarmInputStateHandler::ReceiveResetCommand);
            }
            if(parent->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE)
            {
                std::cout<<"Tech alarm: Subscribe for zone Disablement: ID: "<<std::hex<<GetID()<<" Zone: "<<std::hex<<parent->GetID()<<" MA:"<<
                        std::hex<<parent->GetManagedAreaId()<<std::endl;
                auto zoneReference = Mol::DataType::ObjectReference{parent->GetID(),parent->GetObjectType()};
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT, zoneReference, this, &TechnicalAlarmInputStateHandler::ReceiveDisablementEvent);
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TEST, zoneReference, this, &TechnicalAlarmInputStateHandler::ReceiveTestEvent);
            }
//LCOV_EXCL_STOP
        }

        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&TechnicalAlarmInputStateHandler::ReceiveDisablementEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ALARM, reference, this, &TechnicalAlarmInputStateHandler::ReceiveAlarmEvent);

		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &TechnicalAlarmInputStateHandler::ReceiveMultiObjectQuery);

        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
    }

    bool IsEventFromParent(const Mol::DataType::ObjectReference& reference)
    {
        auto parentZones = GetParentZones();
        for(auto& parent: parentZones)
        {
//LCOV_EXCL_START
            if((reference.GetObjectType() == parent->GetObjectType()) && (reference.GetObjectId() == parent->GetID()))
            {
                std::cout<<"Tech alarm: IsEventFromParent true for ID: "<<std::hex<<GetID()<<" Zone: "<<std::hex<<parent->GetID()<<std::endl;
                return true;
            }
//LCOV_EXCL_STOP
        }
        return false;
    }

    std::shared_ptr<Mol::Event::DisablementEvent> lastPointDisablementEvent = nullptr;
    /**
    * @brief last Zone Disablement event received form Loop module, to create another Enablment event out of it
    */
    std::shared_ptr<Mol::Event::DisablementEvent> lastZoneDisablementEvent = nullptr;

protected:

	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"TechnicalAlarmInputStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"TechnicalAlarmInputStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType != Mol::Request::MULTI_OBJECT_QUERY_CODE::TECHNICAL_ALARM && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
		{
			return;
		}
#ifndef UT_TARGET		
        auto TechnicalAlarmInputObj = std::static_pointer_cast<Dol::Entities::TechnicalAlarmInput>(shared_from_this());
        bool statusFlag = false;
#else
        auto TechnicalAlarmInputObj = std::make_shared<Dol::Entities::TechnicalAlarmInput>();
		bool statusFlag = true;
#endif
        if(nullptr == TechnicalAlarmInputObj)
        {
            DEBUGPRINT(DEBUG_INFO,"TechnicalAlarmInputStateHandler:ReceiveMultiObjectQuery:TechnicalAlarmInput object is null");
            return;
        }
		if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::TECHNICAL_ALARM)
		{
			if(TechnicalAlarmInputObj->IsAlarmDetected())
			{
				statusFlag = true;
			}
		}
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
		{
			if(TechnicalAlarmInputObj->IsFault())
            {
                statusFlag = true;
            }
		}
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
		{
			if(TechnicalAlarmInputObj->IsDisabled())
            {
                statusFlag = true;
            }
		}
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
		{
			if(!TechnicalAlarmInputObj->IsDisabled())
            {
                statusFlag = true;
            }
		}
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
                statusFlag = true;
            }
        }
		else
		{
			/*nothing to do*/
		}

		if(!statusFlag)
		{
			return;
		}

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"TechnicalAlarmInputStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *TechnicalAlarmInputObj);
		
		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"TechnicalAlarmInputStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

    /**
    * Receive a disablementEvent and invoke state machine
    * @param event      DisablementEvent
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event, Mol::Event::EVENT_CATEGORY::DISABLEMENT);
        DEBUGPRINT(DEBUG_INFO,"TechnicalAlarmInputStateHandler: ReceiveDisablementEvent() address[{0}], disablementEvent[{1}]",
                (uint8_t)address, disablementEvent);
        if(nullptr == disablementEvent)
        {
            return;
        }
        UpdatePointZoneReference<Mol::Event::DisablementEvent,
                                    Mol::Event::EVENT_CATEGORY,
                                   fireSystemState::TechnicalAlarmInputStateHandler>(disablementEvent,Mol::Event::EVENT_CATEGORY::DISABLEMENT, this);
        m_updaterStateMachine.process_event(disablementEvent);
        
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "TechnicalAlarmInputStateHandler:ReceiveDisablementEvent updated status");
                });

    }

    /**
    * Receive a Alarm Event and invoke state machine
    * @param event      Alarm Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveAlarmEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto alarmEvent = ValidateEvent<Mol::Event::AlarmEvent>(event, Mol::Event::EVENT_CATEGORY::ALARM);
        if((nullptr == alarmEvent)  || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        for (auto& parentReferences : m_parentReferences)
        {
            alarmEvent->AddParent(parentReferences);
        }
       /* UpdatePointZoneReference<Mol::Event::AlarmEvent,
                                Mol::Event::EVENT_CATEGORY,
                                fireSystemState::TechnicalAlarmInputStateHandler>(alarmEvent,Mol::Event::EVENT_CATEGORY::ALARM, this);*/
        m_updaterStateMachine.process_event(alarmEvent);
    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto zone = GetParentZones();
        for (auto elem : zone)
        {
//LCOV_EXCL_START
            auto managedAreaID = elem->GetManagedAreaId();
            auto managedAreaReference = Mol::DataType::ObjectReference{managedAreaID, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
            auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference);
            if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
            {
                return;
            }
            m_updaterStateMachine.process_event(reset);
//LCOV_EXCL_STOP
        }
    }
    /**
     * Receive a Test Event and invoke state machine
     * @param event      test Event
     * @param id         senderID - Unique id of the sender
     * @param address    Originator of event
     */
     void ReceiveTestEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         auto testEvent = ValidateEvent<Mol::Event::TestOperationEvent>(event, Mol::Event::EVENT_CATEGORY::TEST);
         if((nullptr == testEvent) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
         {
             return;
         }
         m_updaterStateMachine.process_event(testEvent);
     }

private:

    TechAlarmPointStateMachine<TechnicalAlarmInputStateHandler> m_pointStateMachine;

    boost::sml::sm<TechAlarmPointStateMachine<TechnicalAlarmInputStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    FaultEventStateHandler<TechnicalAlarmInputStateHandler> m_faultEventHandler;

    DisableCommandHandler<TechnicalAlarmInputStateHandler> m_disableCommandHandler;
    std::set<Mol::DataType::ObjectReference> m_parentReferences;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_TECHNICAL_ALARM_INPUT_H
