/******************************************************************************//**
*
* @file   AlarmDeviceStateHandler.h
* @brief  State handler for Alarm Device.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_ALARM_DEVICE_H
#define FIRESYSTEM_STATE_HANDLER_ALARM_DEVICE_H

#include "DOL/Entities/Point/AlarmDevice.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "StateMachine/AlarmPointStateMachine.h"
#include "Helper/FSHelper.h"
#include "Signal/Signal.h"
#include "StateHandler/FaultEventStateHandler.h"
#include "Mol/Events/EventCategory.h"
#include "Mol/Events/FunctionDisable.h"
#include "StateHandler/DisableCommandHandler.h"
#include "StateHandler/DelayOperationHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

#include "boost/sml.hpp"
#include "StateHandler/StateHandler.h"
#include <queue>

#ifdef UT_TARGET

#ifndef private
#define private public
#endif

#endif

/**
@startuml
//
class AlarmPointStateMachine {
 +AlarmPointStateMachine()
 +~AlarmPointStateMachine()
 #CheckForAactivation() : alarmSignal is present
 #CheckForDeactivation() : alarmSignal is not present
 #ValidateParentDisablement() : is parent zone disabled?
 #Enable() : update handler to enabled sate and call handler EnableAction
 #Disable() : update handler to disable sate
 #NoResoundEnable() : update handler to disable sate
 #AlarmSignalEvent()
 #SendAlarmSignal(): Send Alarm Signal
 #SwitchToOperation() : Switch to operation SILENCE or RESOUND
}

class AlarmDeviceStateHandler {
m_pointId
m_activationRequestCount
m_updaterStateMachine
m_faultEventHandler
m_disableCommandHandler
m_delayOperationHandler

 +AlarmDeviceStateHandler()
 +~AlarmDeviceStateHandler()
 #SetupSignal() : subscribe to the needed Events and Commands
 #EnableAction(): if needed brodcast Mol::Command::SetAlarmSignal
 #ReceiveFunctionDisableEvent() : process the sate machine
 #ReceiveFunctionEnableEvent(): process the sate machine
 #ReceiveAlarmSignalEvent(): process the sate machine
 #UserOperationEvent(): process the sate machine
 #ReceiveSetAlarameSignalCommand(): process the sate machine
}


Dol::Entities::AlarmDevice<|--  AlarmDeviceStateHandler
StateHandler<|--  AlarmDeviceStateHandler



AlarmDeviceStateHandler "1" *-- "1" AlarmPointStateMachine: handling Alarm Point state machine
AlarmDeviceStateHandler "1" *-- "1" FaultEventStateHandler : handling fault state machine
AlarmDeviceStateHandler "1" *-- "1" DisableCommandHandler : handling disablment state machine
AlarmDeviceStateHandler "1" *-- "1" DelayOperationHandler : handling Delay Operation state machine
//
//@enduml
 *
 */
namespace fireSystemState
{

/**
* @brief AlarmDeviceStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class AlarmDeviceStateHandler: public Dol::Entities::AlarmDevice, public StateHandler<AlarmDeviceStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id: DomainObjectId
    * @param[in] element: configuration about a child or children
    */
    AlarmDeviceStateHandler(const Dol::DomainObjectID id, XmlElementConfig element):
    AlarmDevice(id)
    ,m_pointId{id}
    ,m_alarmPointStateMachine(*this)
    ,m_updaterStateMachine{m_alarmPointStateMachine}
    ,m_faultEventHandler(*this)
    ,m_disableCommandHandler(*this)
    ,m_delayOperationHandler(*this)
    {
        m_isFromThisPanel = PointFromThisPanel(GetID(), m_myPanelObjectRef);
        m_myObjectRef = Mol::DataType::ObjectReference{GetID(), GetObjectType()};
        if(! m_isFromThisPanel)
        {
            m_myCPUModuleObjectRef = Mol::DataType::ObjectReference{GetCPUModuleIDFromPanelID(m_myPanelObjectRef.GetObjectId()), Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
        }
    }

    ~AlarmDeviceStateHandler() override = default;

    bool PointFromThisPanel(uint64_t pointID, Mol::DataType::ObjectReference& pointPanelRef)
    {
        auto nodeID = Mol::DeviceUniqueID(pointID).GetNodeID();
        auto domainID = Mol::DeviceUniqueID(pointID).GetDomainID();
        pointPanelRef =  Mol::DataType::PointReferenceHelper::Create(domainID, nodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        auto m_thisPanelID = Utility::ReadPanelID();
        auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
        auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
        auto m_thisPanelObjRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        return  (pointPanelRef == m_thisPanelObjRef);
    }

    /**
    * @brief return the panel ID of the current entity state handler
    * Example: 0x100020000000000 for panel 2 if the entity ID is 0x100020300000001
    * DOMAIN_OBJECT_TYPE::FIRE_PANEL type and ID 0x100020000000000
    * @return Mol::DataType::ObjectReference  of the panel
    */
    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_myPanelObjectRef;
    }

    /**
    * @brief return the ObjectReference of the current entity state handler
    * @return Mol::DataType::ObjectReference  of the panel
    */
    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return Mol::DataType::ObjectReference{GetID(),GetObjectType()};
    }

    void SetupSignal() override
    {
          DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ID[{0}], Type[{1}]", GetID(), static_cast<int>(GetObjectType()));
          /*point based registration*/
          auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
          PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL,reference,this,&AlarmDeviceStateHandler::ReceiveAlarmSignalEvent);
          PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL,reference,this,&AlarmDeviceStateHandler::ReceiveSetAlarameSignalCommand);
          m_faultEventHandler.SetupSignal();

          /* We register for parent alarm signal event as well, as we need to move the devices to deactivated state on getting zone deactivation */
          auto parentZoneRefs = GetZones();
          for(auto& parent: parentZoneRefs)
          {
              auto parentReference = Mol::DataType::ObjectReference{parent.GetObjectId(),parent.GetObjectType()};
              PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL, parentReference, this, &AlarmDeviceStateHandler::ReceiveAlarmSignalEventForParent);
              PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL,parentReference,this,&AlarmDeviceStateHandler::ReceiveSetAlarameSignalZoneCommand);

          }

          auto parentZones = GetParentZones();
          uint64_t managedAreaId = 0;
          for(auto& parent: parentZones )
          {
//LCOV_EXCL_START
              if(managedAreaId != parent->GetManagedAreaId())
              {
                  /*managed Area based registration*/
                  managedAreaId = parent->GetManagedAreaId();
                  m_managedAreaReference = Mol::DataType::ObjectReference{managedAreaId,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
                  PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::USER_OPERATION,m_managedAreaReference,this,&AlarmDeviceStateHandler::UserOperationEvent);
                  PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,m_managedAreaReference,this,&AlarmDeviceStateHandler::ReceiveFunctionEnableEvent);
                  PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,m_managedAreaReference,this,&AlarmDeviceStateHandler::ReceiveFunctionDisableEvent);
              }
          }

          if(! m_isFromThisPanel)//register only for entities connected to other panels in the network (ignore for this one)
          {
              PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET,m_managedAreaReference,this,&AlarmDeviceStateHandler::ReceiveResetCommand);
              PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myPanelObjectRef,this,&AlarmDeviceStateHandler::ReceiveFaultEvent< Mol::Event::FaultEvent>);
              //@TODO remove later when we ensure they don't change their mind agin
              //PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myPanelObjectRef,this,&ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
              if(m_myCPUModuleObjectRef.GetObjectId())
              {
                  PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myCPUModuleObjectRef,this,&AlarmDeviceStateHandler::ReceiveFaultEvent< Mol::Event::FaultEvent>);
                  //@TODO remove later when we ensure they don't change their mind agin
                  //PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myCPUModuleObjectRef,this,&ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
              }
//LCOV_EXCL_STOP
          }
		  m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		  m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &AlarmDeviceStateHandler::ReceiveMultiObjectQuery);

		  m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
          m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &AlarmDeviceStateHandler::TroubleClearedEventReceived);		  

          m_disableCommandHandler.SetupSignal();
          m_delayOperationHandler.SetupSignal();
      }


    void EnableAction()
    {
        if (!IsThisLastAlarmSignalId(INVALID_SIGNAL_ID) && (GetLastAlarmSignalId() != 0))
        {
            auto setAlarmSignalCommand = std::make_shared < Mol::Command::SetAlarmSignal > (GetLastAlarmSignalId());
            setAlarmSignalCommand->SetCommandTarget(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: EnableAction IsItActivatedBefore true for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
            SendCommand(setAlarmSignalCommand, PROC_ADDRESS::BROADCAST);
        }
    }
	
	void SendActiveEventtoHMI()
	{
		if (!IsThisLastAlarmSignalId(INVALID_SIGNAL_ID) && (GetLastAlarmSignalId() != 0))
        {
			if(m_isModuleEventFromSource == true)
			{
                auto AlarmSignalEvent = std::make_shared < Mol::Event::AlarmSignalEvent > (GetLastAlarmSignalId());
                AlarmSignalEvent->SetSource(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
                SendEvent(AlarmSignalEvent, PROC_ADDRESS::NETWORK);
			}
        }
	}
	
	void SendDeactiveEventtoHMI()
	{
		if (!IsThisLastAlarmSignalId(INVALID_SIGNAL_ID) && (GetLastAlarmSignalId() != 0))
        {
			if(m_isModuleEventFromSource == true)
			{
                auto AlarmSignalEvent = std::make_shared < Mol::Event::AlarmSignalEvent > (0);
                AlarmSignalEvent->SetSource(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
                SendEvent(AlarmSignalEvent, PROC_ADDRESS::NETWORK);
			}
        }
	}
    /**
    * @brief last Alarem event received form Loop module, to create another return from alarm event out of it
    */
    std::shared_ptr<Mol::Event::AlarmSignalEvent> lastAlarmSignalEvent = nullptr;
	bool m_isModuleEventFromSource = false;
protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
			DEBUGPRINT(DEBUG_INFO,"AlarmDeviceStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

		auto sourceRef = MultiObjectQueryRequest->GetSource();
		auto targetRef = MultiObjectQueryRequest->GetTarget();
		auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE || targetRef.GetObjectId() != this->GetID())
        {
			DEBUGPRINT(DEBUG_INFO,"AlarmDeviceStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
			return;
        }

		auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }

#ifndef UT_TARGET
		auto AlarmDeviceObj = std::static_pointer_cast<Dol::Entities::AlarmDevice>(shared_from_this());
        bool statusFlag = false;
#else
        auto AlarmDeviceObj = std::make_shared<Dol::Entities::AlarmDevice>();
        bool statusFlag = true;
#endif
		if(nullptr == AlarmDeviceObj)
		{
			DEBUGPRINT(DEBUG_INFO,"AlarmDeviceStateHandler:ReceiveMultiObjectQuery:AlarmDevice object is null");
			return;
		}
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(AlarmDeviceObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!AlarmDeviceObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(AlarmDeviceObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
			auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
			if(channelNum != 0)
			{
				deviceUniqueId.SetChannelNumber(0);
				Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
				targetRef = ObjectReference;
				statusFlag = true;
			}
        }
        else
        {
            /* nothing to do*/
        }

        if(!statusFlag )
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
		if(nullptr == MultiObjectDataResponse)
		{
			DEBUGPRINT(DEBUG_INFO,"AlarmDeviceStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
			return;
		}
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *AlarmDeviceObj);

		//Setting source and target for the response
		MultiObjectDataResponse->SetTarget(sourceRef);
		MultiObjectDataResponse->SetSource(targetRef);
		MultiObjectDataResponse->SetResponseTarget(source);

		SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
		DEBUGPRINT(DEBUG_INFO,"AlarmDeviceStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
	}
    /**
    * Receive a disablementEvent and invoke state machine
    * @param event      event Function Disable
    * @param id         an ID
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::FunctionDisable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,Mol::FUNCTION_CODE::ALARM_DEVICES);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveFunctionDisableEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if(nullptr == disablementEvent)
        {
            return;
        }
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEvent ignore from FIRE_DOMAIN_APP");
            return;
        }
        m_updaterStateMachine.process_event(disablementEvent);
        //print only if debug level is equal to DebugLevel::DEBUG_ALL
        PrintState(GetID());
    }

    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto enablementEvent = ValidateEvent<Mol::Event::FunctionEnable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,Mol::FUNCTION_CODE::ALARM_DEVICES);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveFunctionEnableEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if(! enablementEvent)
        {
            return;
        }
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEvent ignore from FIRE_DOMAIN_APP");
            return;
        }
        m_updaterStateMachine.process_event(enablementEvent);
        //print only if debug level is equal to DebugLevel::DEBUG_ALL
        PrintState(GetID());
    }

    void ReceiveAlarmSignalEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto alarmSignalEvent = ValidateEvent<Mol::Event::AlarmSignalEvent>(event, Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if(! alarmSignalEvent)
        {
            return;
        }
#ifndef UT_TARGET
        if(alarmSignalEvent->GetSource() != Mol::DataType::ObjectReference {GetID(), GetObjectType() })
        {
            //ignore event if it not sent to us
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEvent ignore this point");
            return ;
        }
#endif
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEvent ignore from FIRE_DOMAIN_APP");
            return;
        }

		if(alarmSignalEvent->GetEventCode() > 0 )
		{
		    m_isModuleEventFromSource = true; //silence resound and activated outut screen issue https://acsjira.honeywell.com/browse/FSNPNL-29245
		}
		else
		{
			m_isModuleEventFromSource = false;
		}

        m_updaterStateMachine.process_event(alarmSignalEvent);
        //print only if debug level is equal to DebugLevel::DEBUG_ALL
        PrintState(GetID());
    }

    void ReceiveAlarmSignalEventForParent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto alarmSignalEvent = ValidateEvent<Mol::Event::AlarmSignalEvent>(event, Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEventForParent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if(! alarmSignalEvent)
        {
            return;
        }
		
		if(alarmSignalEvent->GetEventCode() == 0 )
		{
		    m_isModuleEventFromSource = false; //silence resound and activated outut screen issue https://acsjira.honeywell.com/browse/FSNPNL-29245
		}
		
#ifndef UT_TARGET
        auto parentZoneRefs = GetZones();
        bool isAMatchFound = false;
        for(auto& parent: parentZoneRefs)
        {
            if(alarmSignalEvent->GetSource() == Mol::DataType::ObjectReference {parent.GetObjectId(), parent.GetObjectType() })
            {
                isAMatchFound = true;
                break;
            }
        }

        if(!isAMatchFound)
        {
            //ignore event if it not sent to us
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEventForParent ignore this parent");
            return ;
        }
#endif
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveAlarmSignalEventForParent ignore from FIRE_DOMAIN_APP");
            return;
        }
		
        m_updaterStateMachine.process_event(alarmSignalEvent);
        //print only if debug level is equal to DebugLevel::DEBUG_ALL
        PrintState(GetID());
    }


    void UserOperationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto userOperationEvent = ValidateEvent<Mol::Event::UserOperationEvent>(event, Mol::Event::EVENT_CATEGORY::USER_OPERATION);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: UserOperationEvent for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if (!userOperationEvent)
        {
            return;
        }
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: receive USER_OPERATION[{0}] Event for ID {1}", (uint32_t)userOperationEvent->GetEventCode(), GetID());
        if((userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE)
                || (userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND))
        {
            m_updaterStateMachine.process_event(userOperationEvent);
        }
		
		 if(userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_OFF)
		 {
			if(0 < m_activationRequestCount)
			{
				EnableAction();
			}
		 }
        //print only if debug level is equal to DebugLevel::DEBUG_ALL
        PrintState(GetID());
    }

    void ReceiveSetAlarameSignalZoneCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto setAlarmSignalCommand = ValidateCommand<Mol::Command::SetAlarmSignal>(command, Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalZoneCommand for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if (!setAlarmSignalCommand)
        {
            return;
        }
#ifndef UT_TARGET
#endif
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalZoneCommand ignore from FIRE_DOMAIN_APP");
            return;
        }

        if(setAlarmSignalCommand->GetCommandCode() != 0)
        {
            m_zoneactivationCounter++;
			DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalZoneCommand activation count incremented [{}]",m_zoneactivationCounter);
        }
        else if((setAlarmSignalCommand->GetCommandCode() == 0) && (m_zoneactivationCounter != 0))
        {
            if(m_zoneactivationCounter > 0)
            {
                --m_zoneactivationCounter;
				DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalZoneCommand activation count decremented [{}]",m_zoneactivationCounter);
            }
            if(0 == m_zoneactivationCounter)
            {
                m_activationRequestCount = 0;
                SetLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode());
            }
        }

    }

    void ReceiveSetAlarameSignalCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto setAlarmSignalCommand = ValidateCommand<Mol::Command::SetAlarmSignal>(command, Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL);
        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalCommand for ID {0} and GetObjectType[{1}]", GetID(), static_cast<int>(GetObjectType()));
        if (!setAlarmSignalCommand)
        {
            return;
        }
#ifndef UT_TARGET
        if(setAlarmSignalCommand->GetCommandTarget() != Mol::DataType::ObjectReference {GetID(), GetObjectType() })
        {
            //ignore event if it not sent to us
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalCommand ignore this zone");
            return ;
        }
#endif
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalCommand ignore from FIRE_DOMAIN_APP");
            return;
        }

        if((setAlarmSignalCommand->GetCommandCode() == 0) && (m_activationRequestCount != 0))
        {
            --m_activationRequestCount;
            if(m_activationRequestCount > 0)
            {
                return;
            }
        }
        else if(setAlarmSignalCommand->GetCommandCode() != 0)
        {
            ++m_activationRequestCount;
        }
        else{
        	/* Do Nothing */
        }

        if ((GetAlarmSignalId() == setAlarmSignalCommand->GetCommandCode() )
                && IsThisLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode()))
        {
            return;
        }

        DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ReceiveSetAlarameSignalCommand(command=[], id =[{0}], address=[{1}])", id, (uint32_t) address);
        if(!IsDisabled())
        {
            SendCommand(setAlarmSignalCommand, PROC_ADDRESS::BROADCAST);
        }
        if(! IsThisLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode()))
        {
            SetLastAlarmSignalId(setAlarmSignalCommand->GetCommandCode());
        }
    }

private:

    /** Receive a Fault/FaultCleared event and invoke state machine
    * @param event      Fault/FaultClearedEvent Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    template<typename FaultEventType>
    void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID, PROC_ADDRESS address)
    {
        Mol::Event::EVENT_CATEGORY category = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
        if(std::is_same<FaultEventType, Mol::Event::FaultClearedEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"BaseFireDetectionPointStateHandler: FaultClearedEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED;
        }
        else if(std::is_same<FaultEventType, Mol::Event::FaultEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"BaseFireDetectionPointStateHandler: FaultEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE;
        }
        else
        {
            //Do nothing
        }

        auto faultEvent = ValidateEvent<FaultEventType>(event, category);
        if(! faultEvent)
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        //we handle both FIRE_PANEL && CPU_MODULE
        if( !IsItMyPanelFailure(faultEvent,m_myPanelObjectRef))
        {
            return;
        }
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            SetLastError(STATE_ERROR::INVALID_PROCCESS_ID);
            return;
        }
        m_updaterStateMachine.process_event(faultEvent);
        auto pointID = GetID();
        PrintState(pointID);
        SetLastError(STATE_ERROR::NO_ERROR);
    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, m_managedAreaReference);
        if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(reset);
        auto pointID = GetID();
        PrintState(pointID);
    }

	void TroubleClearedEventReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		if((nullptr == event) || (PROC_ADDRESS::MODULE_APP != address))
		{
			return;
		}

		auto troublecleared = std::static_pointer_cast <Mol::Event::FaultClearedEvent> (event);

		if(troublecleared->GetEventCode()!= Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
		{
			return;
		}

        Mol::DeviceUniqueID faultuniqueid(troublecleared->GetSource().GetObjectId());
		Mol::DeviceUniqueID thisuniqueid(GetID());

		if(thisuniqueid.GetModuleID() == faultuniqueid.GetModuleID())
		{
			if( 0 != m_activationRequestCount )
			{
                auto setAlarmSignalCommand = std::make_shared < Mol::Command::SetAlarmSignal > (GetLastAlarmSignalId());
                setAlarmSignalCommand->SetCommandTarget(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
                SendCommand(setAlarmSignalCommand, PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::AlarmDeviceStateHandler::TroubleClearedEventReceived: set alarm signal command sent last alarm signal id [{0}]",GetLastAlarmSignalId());
			}

			if(m_disableCommandHandler.m_disablementCount > 0)
			{
				auto disable = std::make_shared<Mol::Command::Disable>();
                disable->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                SendCommand(disable,PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::AlarmDeviceStateHandler::TroubleClearedEventReceived: disable command sent");
			}
		}
	}

private:

    //LCOV_EXCL_START
    void PrintState(uint64_t id)//print state
    {
        if (DEBUGPRINT::GetDebugLevel() >= DebugLevel::DEBUG_INFO)
        {
            m_updaterStateMachine.visit_current_states([id](auto state){
                DEBUGPRINT(DEBUG_INFO, "AlarmDeviceStateHandler: ID [{0:#x}]is now in state[{1}]", id, state.c_str());
                    });
        }
    }
    //LCOV_EXCL_STOP

    uint64_t m_pointId;
    uint32_t m_activationRequestCount = 0;
    uint32_t m_zoneactivationCounter = 0;

    AlarmPointStateMachine<AlarmDeviceStateHandler> m_alarmPointStateMachine;
    boost::sml::sm<AlarmPointStateMachine<AlarmDeviceStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;
    FaultEventStateHandler<AlarmDeviceStateHandler> m_faultEventHandler;
    DisableCommandHandler<AlarmDeviceStateHandler> m_disableCommandHandler;
    DelayOperationHandler<AlarmDeviceStateHandler> m_delayOperationHandler;
    Mol::DataType::ObjectReference m_myPanelObjectRef;
    Mol::DataType::ObjectReference m_myCPUModuleObjectRef;
    Mol::DataType::ObjectReference m_managedAreaReference;
    bool m_isFromThisPanel = false;
    Mol::DataType::ObjectReference m_myObjectRef;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_ALARM_DEVICE_H
