/******************************************************************************//**
*
* @file   DelayOperationHandler.h
* @brief
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_DELAY_OPERATION_H
#define FIRESYSTEM_STATE_HANDLER_DELAY_OPERATION_H


#include "Mol/Commands/Disable.h"
#include "Mol/Commands/Enable.h"

namespace fireSystemState
{

/**
* @brief DelayOperationHandler is receives disable command.
* if entity is not disabled it forward the disable command, else it reject the command
*/
template<typename HANDLER>
class DelayOperationHandler
{
public:
    explicit DelayOperationHandler(HANDLER& handler ):
     m_handler(handler)
    {
    }

    ~DelayOperationHandler() = default;

    /**
    * Prepare the signal for receive userOperationEvent for dely on and off
    */
    void SetupSignal()
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::USER_OPERATION,reference,this,&DelayOperationHandler<HANDLER>::ReceiveDelayOperation);
    }

protected:
    /**
     * @brief  User operationEvent notification for site
     * @param event     Delay Operation event received
     * @param id        senderID - Unique id of the sender
     * @param address   Originator of event
     */
    void ReceiveDelayOperation(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto userOperationEvent = ValidateEvent<Mol::Event::UserOperationEvent>(event
                                                        , Mol::Event::EVENT_CATEGORY::USER_OPERATION
                                                        );
        if((! userOperationEvent)  || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        if( (userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::DELAY_ON)
            ||
        (userOperationEvent->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::DELAY_OFF) )
        {
            m_handler.SendEvent(userOperationEvent,PROC_ADDRESS::EVENT_PROVIDERAPP,true);
            m_handler.SendEvent(userOperationEvent,PROC_ADDRESS::EVENTLOGAPP,true);
            m_handler.SendEvent(userOperationEvent,PROC_ADDRESS::MOL_RECEIVER,true);
        }
    }
private:
    HANDLER& m_handler;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_DELAY_OPERATION_H
