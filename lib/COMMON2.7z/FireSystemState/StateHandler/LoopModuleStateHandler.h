/******************************************************************************//**
*
* @file   LoopModuleStateHandler.h
* @brief  State handler for Module
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_LOOP_MODULE_H
#define FIRESYSTEM_STATE_HANDLER_LOOP_MODULE_H

#include "ModuleStateHandler.h"
#include "StateHandler/LoopStateHandler.h"
#include "StateSetup/LoopStateSetup.h"
#define noop (void)0

namespace fireSystemState
{

/**
* @brief LoopModuleStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class LoopModuleStateHandler: public ModuleStateHandler<Dol::Entities::LoopModule>
{

public:

    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    LoopModuleStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        ModuleStateHandler<Dol::Entities::LoopModule>(id, element)
    {
    }
//  LCOV_EXCL_START
    ~LoopModuleStateHandler() override = default;
//  LCOV_EXCL_STOP
    void SetupSignal()
    {
        ModuleStateHandler<Dol::Entities::LoopModule>::SetupSignal();
        for(auto& loop : m_loops)
        {
            LoopSignalSetup(loop);
        }
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void Prepare()
    {
        try
        {
            DomainConfiguration::LoopConfig(m_element,m_loopConfig);
        }
//LCOV_EXCL_START
        catch( tinyxml2::XmlException &e )
        {
            DEBUGPRINT(DEBUG_INFO, "LoopModuleStateHandler: Prepare() exception xm:{}", e .what());
	    	noop;						//To fix sonarqube vulnerability
        }
        catch(...)
        {
            DEBUGPRINT(DEBUG_INFO, "LoopModuleStateHandler: Prepare() Unknown exception while reading XML file");
			noop;						//To fix sonarqube vulnerability
        }

//LCOV_EXCL_STOP
        for(auto loopConfig: m_loopConfig)
        {
            DEBUGPRINT(DEBUG_INFO, "LoopModuleStateHandler: Prepare() loop id[{0}] type[{1}]", loopConfig.id, (uint32_t)loopConfig.pointType);
            auto loopStateHandler = StateObjectFactory<Dol::Entities::Loop,LoopStateObjectTypes>::Create(loopConfig);
            if(nullptr != loopStateHandler)
            {
                LoopStatePrepare(loopStateHandler);
                AddLoop(loopStateHandler);
            }
        }
        ModuleStateHandler<Dol::Entities::LoopModule>::Prepare();
    }

private:
    std::vector<XmlElementConfig> m_loopConfig;

};

}

#endif //FIRESYSTEM_STATE_HANDLER_LOOP_MODULE_H
