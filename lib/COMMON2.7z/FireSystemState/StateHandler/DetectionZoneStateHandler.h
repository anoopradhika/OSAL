/******************************************************************************//**
*
* @file   DetectionZoneStateHandler.h
* @brief   State handler for Detection zone.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_DTECTION_ZONE_H
#define FIRESYSTEM_STATE_HANDLER_DTECTION_ZONE_H

#include <set>
#include <queue>

#include "DOL/Entities/Zone/DetectionZone.h"
#include "EventDispatcher/EventDispatcher.h"
#include "StateHandler/FireSensorInputStateHandler.h"
#include "Signal/Signal.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "Mol/Events/EventCategory.h"
#include "DomainConfiguration/DomainConfiguration.h"
#include "StateObjectFactory/StateObjectFactory.h"
#include "StateObjectFactory/PointStateObjectList.h"
#include "StateHandler/StateHandler.h"
#include "StateMachine/DetectionZoneStateMachine.h"
#include "boost/sml.hpp"
#include "StateSetup/PointStateSetup.h"
#include "StateHandler/DisableCommandHandler.h"
#include "StateHandler/ZoneTestCommandHandler.h"
#include "Mol/Requests/ObjectData.h"
#include "Mol/Responses/ObjectDataResponse.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

namespace fireSystemState
{

/**
* @brief DetectionZoneStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class DetectionZoneStateHandler: public Dol::Entities::DetectionZone, public StateHandler<DetectionZoneStateHandler>
{
public:

    /**
    * Prepare the StateMachine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    DetectionZoneStateHandler(const Dol::DomainObjectID id, XmlElementConfig element):
        DetectionZone(id)
        ,m_element{element}
        ,m_detectionZoneStateMachine(*this)
        ,m_updaterStateMachine{m_detectionZoneStateMachine}
        ,m_disableCommandHandler(*this)
        ,m_testZoneCommandHandler(*this)
        ,m_faultEventHandler(*this)
    {
            auto m_thisPanelID = Utility::ReadPanelID();
            auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
            auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
            m_myPanelObjectRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            m_myPanelObjectRef.PrepareDeviceUniqueID();
    }

    ~DetectionZoneStateHandler() override = default;

    /**
    * Prepare points
    */
    void Prepare() override
    {
        PointConfig(m_element,m_pointsConfig);
        DEBUGPRINT(DEBUG_INFO,"Loaded Detection Zone point config:[{0}]",time(nullptr));
        for(auto pointConfig: m_pointsConfig)
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler: Prepare() add point id[{0}], type[{1}]",
                    (uint32_t)pointConfig.id, (uint8_t)pointConfig.pointType);
            auto pointState = StateObjectFactory<Dol::Entities::Point,PointStateObjectTypes>::Create(pointConfig);
            if(pointState)
            {
                PointStatePrepare(pointState);
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler: zone Add a point()");
#ifndef UT_TARGET
                pointState->AddParentZone(shared_from_this());
#endif
                AddPoint(pointState);
            }
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Detection Zone point objects:[{0}]",time(nullptr));

		//To set count of analog sensor and input modules.
		std::set<std::shared_ptr<Dol::Entities::Point>> objReference = GetPointsOfZone();
		uint32_t numberOfAnalogSensors{0};
		uint32_t numberOfInputModules{0};
		for(auto const&obj:objReference)
		{
			if(obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR)
			{
				numberOfAnalogSensors++;
			}
			else if(obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT || obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::MCP_INPUT || obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT || obj->GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT)
			{
				numberOfInputModules++;
			}
            else
            {
                //Do nothing
            }
		}
        DEBUGPRINT(DEBUG_INFO,"Set count of analog sensor and input modules:[{0}]",time(nullptr));
		SetInformationCount(Dol::Entities::Zone::INFORMATION_TYPE::ANALOG_SENSOR,numberOfAnalogSensors);
		SetInformationCount(Dol::Entities::Zone::INFORMATION_TYPE::INPUT_MODULE,numberOfInputModules);
		uint16_t panelNumber = Mol::DeviceUniqueID{Utility::ReadPanelID()}.GetNodeID();
		SetPanelNumber(panelNumber);		
	}

    /**
    * Set up signal the signal for receive commands and event
    */
    void SetupSignal() override
    {
        for(auto& point : m_points)
        {
            PointSignalSetup(point);
        }
#ifndef UT_TARGET
        auto managedAreaReference = Mol::DataType::ObjectReference{GetManagedAreaId(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT, reference,this,&DetectionZoneStateHandler::ReceiveDisablementEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ALARM, reference, this, &DetectionZoneStateHandler::ReceiveAlarmEvent);

        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference, this, &DetectionZoneStateHandler::ReceiveResetCommand);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TEST, reference, this, &DetectionZoneStateHandler::ReceiveTestEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE,reference,this,&DetectionZoneStateHandler::ReceiveSensitivityCommand);
#endif

		m_communicator.m_request.Subscribe<Mol::Request::ObjectData>(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::OBJECT_DATA)->Connect(this, &DetectionZoneStateHandler::ReceiveObjectData);

        //subscribe for fault event here to handle panels in the network communication stopped or no replay
        m_communicator.m_event.Subscribe<Mol::Event::FaultEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE)->Connect(this, &DetectionZoneStateHandler::ProcessPanelFailover);

		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &DetectionZoneStateHandler::ReceiveMultiObjectQuery);

		m_disableCommandHandler.SetupSignal();
        m_testZoneCommandHandler.SetupSignal();
        m_faultEventHandler.SetupSignal(true);
    }

    bool  OriginatedRemotePanelLost()
    {
		DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:OriginatedRemotePanelLost m_remotPanelLost=[{}]",m_remotPanelLost);
        return m_remotPanelLost;
    }

    void  ClearRemotePanelLost()
    {
        m_remotPanelLost = false;
        m_remotePanelDisablment = 0;
    }
    /**
    * @brief last Zone Disablement event received form Loop module, to create another Enablment event out of it
    */
    std::shared_ptr<Mol::Event::DisablementEvent> lastZoneDisablementEvent = nullptr;
    /**
    * @brief last Alarem event received form Loop module, to create another return from alarm event out of it
    */
    std::shared_ptr<Mol::Event::AlarmEvent> lastAlarmEvent = nullptr;
    /**
    * @brief last TestOperationEvent event received form Loop module, to create another End Of Test event out of it
    */
    std::shared_ptr<Mol::Event::TestOperationEvent> lastTestEvent = nullptr;
protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_PRE_ALARM && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::OFF_NORMAL && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::NORMAL && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ALL_ENTITIES)
        {
            return;
        }
#ifndef UT_TARGET
        auto DetectionZoneObj = std::static_pointer_cast<Dol::Entities::DetectionZone>(shared_from_this());
        bool statusFlag = false;
#else
        auto DetectionZoneObj = std::make_shared<Dol::Entities::DetectionZone>();
		bool statusFlag = true;
#endif
        if(nullptr == DetectionZoneObj)
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveMultiObjectQuery:DetectionZone object is null");
            return;
        }
        //SetDisablement status of a zone
        DetectionZoneObj->SetDisabledStatus(DetectionZoneObj->IsDisabled());
        DetectionZoneObj->SetPartialDisabledStatus(DetectionZoneObj->IsPartialDisabled());
        DetectionZoneObj->SetFaultStatus(DetectionZoneObj->IsFault());
        
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(DetectionZoneObj->GetDisabledStatus() || DetectionZoneObj->GetPartialDisabledStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!DetectionZoneObj->GetDisabledStatus())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(DetectionZoneObj->GetFaultStatus())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_PRE_ALARM)
        {
            if(DetectionZoneObj->IsPreAlarmDetected())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST)
        {
            if(DetectionZoneObj->IsUnderTest())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM)
        {
            if(DetectionZoneObj->IsFireDetected())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::OFF_NORMAL)
        {
            if(DetectionZoneObj->GetDisabledStatus() || DetectionZoneObj->GetPartialDisabledStatus() ||  DetectionZoneObj->GetFaultStatus() || DetectionZoneObj->IsPreAlarmDetected() || DetectionZoneObj->IsUnderTest() || DetectionZoneObj->IsFireDetected())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::NORMAL)
        {
            if(!DetectionZoneObj->GetDisabledStatus() && !DetectionZoneObj->GetPartialDisabledStatus() && !DetectionZoneObj->GetFaultStatus() && !DetectionZoneObj->IsPreAlarmDetected() &&  !DetectionZoneObj->IsUnderTest() && !DetectionZoneObj->IsFireDetected())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ALL_ENTITIES)
        {
            statusFlag = true;
        }
        else
        {
            /* nothing to do */
        }
        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *DetectionZoneObj);

		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MOL_RECEIVER);
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

 	/**
    * Receive a ObjectData Request and invoke state machine
    * @param event      ObjectData Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveObjectData(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto ObjectDataRequest = ValidateRequest<Mol::Request::ObjectData>(request, Mol::Request::REQUEST_CATEGORY::OBJECT_DATA);
        if(nullptr == ObjectDataRequest)
        {
			DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveObjectData:ObjectData request is null");
            return;
        }
	
		auto sourceRef = ObjectDataRequest->GetSource();
		auto targetRef = ObjectDataRequest->GetTarget();
		auto source = ObjectDataRequest->GetSourceTarget();
		if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE || targetRef.GetObjectId() != this->GetID())
        {
			DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveObjectData:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }
 	
		auto statusRequest = std::static_pointer_cast<Mol::Request::ObjectData>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::STATUS)
		{
			auto DetectionZoneObj = std::static_pointer_cast<Dol::Entities::DetectionZone>(shared_from_this());
			if(nullptr == DetectionZoneObj)
			{
				DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveObjectData:DetectionZone object is null");
				return;
			}
            //Set current disablement status of a zone
            DetectionZoneObj->SetDisabledStatus(DetectionZoneObj->IsDisabled());
            DetectionZoneObj->SetPartialDisabledStatus(DetectionZoneObj->IsPartialDisabled());
            DetectionZoneObj->SetFaultStatus(DetectionZoneObj->IsFault());

			auto ObjectDataResponse = std::make_shared<Mol::Response::ObjectDataResponse>();
			if(nullptr == ObjectDataResponse)
			{
				DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveObjectData:ObjectdataResponse object is null");
				return;
			}
	
			ObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *DetectionZoneObj);	
			ObjectDataResponse->SetObjectStatusType(Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE);

			//Setting source and target for the response	
            ObjectDataResponse->SetTarget(sourceRef);
            ObjectDataResponse->SetSource(targetRef);
            ObjectDataResponse->SetResponseTarget(source);

            SendResponse(ObjectDataResponse, PROC_ADDRESS::MAINLOOP);
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveObjectData:Object Data response sent");
		}

		else if(queryType == Mol::Request::OBJECT_DATA_REQUEST_CODE::NUMBER_OF_CHILDREN)
		{
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveObjectData:Request For Number Of Children");
		}

		else
        {
            DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateHandler:ReceiveObjectData: Invalid request type[{}]", static_cast<int>(queryType));
        }
    }
	
    /**
    * Receive a disablementEvent and invoke state machine
    * @param event      DisablementEvent
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
		DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler::ReceiveDisablementEvent called");
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::DISABLEMENT
                                                                            );
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler: ReceiveDisablementEvent() address[{0}], disablementEvent[{1}]",
                (uint8_t)address, disablementEvent);


        if(nullptr == disablementEvent)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            auto parameters = disablementEvent->GetParameters();
            bool isLastPointDisablement = false;
            for(auto& parameter: parameters)
            {
                if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
                {
                    if(parameter.GetValue<std::string>() == std::string("LPD")) //LPD: Last Point Disabled
                    {
                        //Zone Disablement is created by FDA, since last point in the zone is disabled.
                        isLastPointDisablement = true;
                    }
                }
            }
            // If Zone Disablement Event is created due to Last point Disablement, then it should be processed by FDA
            if(!isLastPointDisablement)
                return;
        }

        m_updaterStateMachine.process_event(disablementEvent);
        if(IsItFromNetwork(disablementEvent) && IsItMine(disablementEvent,Mol::DataType::ObjectReference{GetID(),GetObjectType()}))
        {
			DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler::ReceiveDisablementEvent...network condition");
            m_remotePanelDisablment = GetPanelRefFromEvent(disablementEvent);
			DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler::ReceiveDisablementEvent...m_remotePanelDisablment = [{}]",m_remotePanelDisablment);
        }
    }

    /**
    * Receive a Alarm Event and invoke state machine
    * @param event      Alarm Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveAlarmEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto alarmEvent = ValidateEvent<Mol::Event::AlarmEvent>(event, Mol::Event::EVENT_CATEGORY::ALARM);
        if(nullptr == alarmEvent)
        {
            return;
        }
        alarmEvent->AddParent(Mol::DataType::ObjectReference { GetID(), GetObjectType() });
        alarmEvent->AddParent(Mol::DataType::ObjectReference {GetManagedAreaId(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
        m_updaterStateMachine.process_event(alarmEvent);
    }

    /**
    * Receive Sensitivity Profile command and process
    * @param command    SetSensitivityProfile command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveSensitivityCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto setProfile = ValidateCommand<Mol::Command::SetSensitivityProfile>(command
                                                        , Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE
                                                        );

        if((nullptr == setProfile) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        if(setProfile->GetCommandCode() == Mol::Command::SET_SENSITIVITY_PROFILE_CODE::ALTERNATE && !IsSensitivityProfileOverridden())
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:Receive Sensitivity Profile Alternate Command");
            SetSensitivityProfile(true);
            SendCommand(setProfile,PROC_ADDRESS::BROADCAST);
        }
        else if(setProfile->GetCommandCode() == Mol::Command::SET_SENSITIVITY_PROFILE_CODE::DEFAULT && IsSensitivityProfileOverridden())
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:Receive Sensitivity Profile Default Command");
            SetSensitivityProfile(false);
            SendCommand(setProfile,PROC_ADDRESS::BROADCAST);
        }
        else
        {
            return;
        }
    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
		DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateHandler:ReceiveResetCommand called");
        auto managedAreaReference = Mol::DataType::ObjectReference{GetManagedAreaId(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
        auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference);
        if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(reset);
    }

    /**
    * Receive a Test Event and invoke state machine
    * @param event      test Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
     void ReceiveTestEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
     {
         auto testEvent = ValidateEvent<Mol::Event::TestOperationEvent>(event, Mol::Event::EVENT_CATEGORY::TEST);
         if(nullptr == testEvent)
         {
             return;
         }
         m_updaterStateMachine.process_event(testEvent);
     }

     /**
    * Receive a FaultEvent and process panel failover
    * @param event      FaultEvent
    * @param id         an ID
    * @param address    Originator of event
    */
    void ProcessPanelFailover(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        if (nullptr == event)
        {
            SetLastError(STATE_ERROR::NULL_EVENT);
            return;
        }
        auto faultEvent = ValidateEvent<Mol::Event::FaultEvent>(event, Mol::Event::EVENT_CATEGORY::TROUBLE);
		
		auto sourceid = faultEvent->GetSource().GetObjectId();
		
		if((faultEvent->GetEventCode() != Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED) || ((sourceid & 0x00FFFF0000000000) == 0))
		{
			return;
		}
		
        DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateHandler: ProcessPanelFailover for panel ID {0:#x} ", id);
        if (nullptr == faultEvent)
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        if (address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateHandler: ProcessPanelFailover ignore from FIRE_DOMAIN_APP");
            SetLastError(STATE_ERROR::INVALID_PROCCESS_ID);
            return;
        }
        //we ignore fault event from this panel, interested only on other panels in the network getting lost
        if(0 == m_remotePanelDisablment || IsItMyPanelFailure(faultEvent,m_myPanelObjectRef))
        {
			DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateHandler: ProcessPanelFailover return");
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        auto source = faultEvent->GetSource();
        source.PrepareDeviceUniqueID();
        //now panelID is provided as 1, 2, 3 .. Node ID, but for future compatibility both case are tested here
        m_remotPanelLost = (m_remotePanelDisablment == source.GetObjectId() || source.GetNodeID() == m_remotePanelDisablment);
		
		DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateHandler: ProcessPanelFailover m_remotPanelLost = [{0}]  m_remotePanelDisablment = [{1}]",m_remotPanelLost,m_remotePanelDisablment);
		DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateHandler: ProcessPanelFailover source.GetObjectId = [{0}]  source.GetNodeID = [{1}]",source.GetObjectId(),source.GetNodeID());
		
        m_updaterStateMachine.process_event(faultEvent);
        SetLastError(STATE_ERROR::NO_ERROR);
    }

private:
    std::vector<XmlElementConfig> m_pointsConfig;

    XmlElementConfig m_element;

    DetectionZoneStateMachine<DetectionZoneStateHandler> m_detectionZoneStateMachine;

    boost::sml::sm<DetectionZoneStateMachine<DetectionZoneStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    DisableCommandHandler<DetectionZoneStateHandler> m_disableCommandHandler;

    ZoneTestCommandHandler<DetectionZoneStateHandler> m_testZoneCommandHandler;
    PhysicalGroupFaultEventStateHandler<DetectionZoneStateHandler> m_faultEventHandler;
    Mol::DataType::ObjectReference m_myPanelObjectRef;
    uint64_t m_remotePanelDisablment = 0;
    bool m_remotPanelLost = false;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_DTECTION_ZONE_H
