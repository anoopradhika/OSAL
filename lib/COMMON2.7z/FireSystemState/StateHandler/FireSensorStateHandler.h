/******************************************************************************//**
*
* @file   FireSensorStateHandler.h
* @brief  State handler for FireSensor
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FIRESENSOR_H
#define FIRESYSTEM_STATE_HANDLER_FIRESENSOR_H

#include <queue>

#include "DOL/Entities/Point/FireSensor.h"
#include "DOL/Entities/Zone/Zone.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"
#include "Mol/Events/EventCategory.h"
#include "StateHandler/StateHandler.h"
#include "boost/sml.hpp"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "StateHandler/BaseFireDetectionPointStateHandler.h"
#include <cereal/types/set.hpp>
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

namespace fireSystemState
{

/**
* @brief FireSensorStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class FireSensorStateHandler: public BaseFireDetectionPointStateHandler<Dol::Entities::FireSensor, FireSensorStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */


    FireSensorStateHandler(const Dol::DomainObjectID id, XmlElementConfig element):
        BaseFireDetectionPointStateHandler(id, element)
    {
        std::cout<<"FS:FireSensorStateHandler id "<<std::hex<<id<<std::endl;
    }

    ~FireSensorStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        BaseFireDetectionPointStateHandler::SetupSignal();
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE,reference,this,&FireSensorStateHandler::ReceiveActivateLedCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE,reference,this,&FireSensorStateHandler::ReceiveDeactivateLedCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE,reference,this,&FireSensorStateHandler::ReceiveSensitivityCommand);

		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &FireSensorStateHandler::ReceiveMultiObjectQuery);

		m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &FireSensorStateHandler::TroubleClearedEventReceived);
 
    }

private:

        uint16_t m_ActivateCount = 0;

protected:

		/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }
#ifndef UT_TARGET
        auto FireSensorObj = std::static_pointer_cast<Dol::Entities::FireSensor>(shared_from_this());
        bool statusFlag = false;
#else
        auto FireSensorObj = std::make_shared<Dol::Entities::FireSensor>();
		bool statusFlag = true;
#endif
        if(nullptr == FireSensorObj)
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:ReceiveMultiObjectQuery:FireSensor object is null");
            return;
        }
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(FireSensorObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!FireSensorObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_ALARM)
        {
            if(FireSensorObj->IsFireDetected())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_TEST)
        {
            if(FireSensorObj->IsTestFire())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(FireSensorObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
                statusFlag = true;
            }
        }
        else
        {
            /*nothing to do*/
        }

        if(!statusFlag)
        {
            return;
        }


        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *FireSensorObj);

		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

    /**
    * Receive Sensitivity Profile command and process
    * @param command    SetSensitivityProfile command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveSensitivityCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto setProfile = ValidateCommand<Mol::Command::SetSensitivityProfile>(command
                                                        , Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE
                                                        );

        if((nullptr == setProfile) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        if(setProfile->GetCommandCode() == Mol::Command::SET_SENSITIVITY_PROFILE_CODE::ALTERNATE && !IsSensitivityProfileOverridden())
        {
			m_last_sens_prof = Mol::Command::SET_SENSITIVITY_PROFILE_CODE::ALTERNATE;
            DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:Receive Sensitivity Profile Alternate Command");
            SetSensitivityProfile(true);
            SendCommand(setProfile,PROC_ADDRESS::BROADCAST);
        }
        else if(setProfile->GetCommandCode() == Mol::Command::SET_SENSITIVITY_PROFILE_CODE::DEFAULT && IsSensitivityProfileOverridden())
        {
			m_last_sens_prof = Mol::Command::SET_SENSITIVITY_PROFILE_CODE::DEFAULT;
            DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:Receive Sensitivity Profile Default Command");
            SetSensitivityProfile(false);
            SendCommand(setProfile,PROC_ADDRESS::BROADCAST);
        }
        else
        {
			m_last_sens_prof = Mol::Command::SET_SENSITIVITY_PROFILE_CODE::END_OF_LIST;
            return;
        }


    }

    /**
    * Receive Activate Led command and process
    * @param command    ActivateLed command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveActivateLedCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:Receive ActivateLed Command");
        auto activateLed = ValidateCommand<Mol::Command::Activate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::ACTIVATE
                                                        );

        if((nullptr == activateLed) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

		m_ActivateCount++;
		if(IsRemoteLedActiavted())
		{
			return;
		}

        SetRemoteLedState(true);
        SendCommand(activateLed,PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive Deactivate Led command and process
    * @param command    DeactivateLed command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveDeactivateLedCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        DEBUGPRINT(DEBUG_INFO,"FireSensorStateHandler:Receive DectivateLed Command");
        auto deactivateLed = ValidateCommand<Mol::Command::Deactivate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::DEACTIVATE
                                                        );

        if((nullptr == deactivateLed)  || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

		m_ActivateCount--;
		if(!IsRemoteLedActiavted())
		{
			return;
		}

		if(0 == m_ActivateCount)
		{
            SetRemoteLedState(false);
            SendCommand(deactivateLed,PROC_ADDRESS::BROADCAST);
		}
    }
	
	void TroubleClearedEventReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		if((nullptr == event) || (PROC_ADDRESS::MODULE_APP != address))
		{
			return;
		}

		auto troublecleared = std::static_pointer_cast <Mol::Event::FaultClearedEvent> (event);

		if(troublecleared->GetEventCode()!= Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
		{
			return;
		}

        Mol::DeviceUniqueID faultuniqueid(troublecleared->GetSource().GetObjectId());
		Mol::DeviceUniqueID thisuniqueid(GetID());

		if(thisuniqueid.GetModuleID() == faultuniqueid.GetModuleID())
		{
			if( 0 != m_ActivateCount )
			{
                auto command = std::make_shared<Mol::Command::Activate>();
                command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
                SendCommand(command, PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::FPOStateHandler::TroubleClearedEventReceived: activate command sent");
			}

			if(Mol::Command::SET_SENSITIVITY_PROFILE_CODE::END_OF_LIST != m_last_sens_prof)
			{
				auto command = std::make_shared<Mol::Command::SetSensitivityProfile>(m_last_sens_prof);
                command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
                SendCommand(command, PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::FPOStateHandler::TroubleClearedEventReceived: set aensitivity command sent");
			}
		}
	}

	private:
	Mol::Command::SET_SENSITIVITY_PROFILE_CODE m_last_sens_prof = Mol::Command::SET_SENSITIVITY_PROFILE_CODE::END_OF_LIST;
};
}

#endif //FIRESYSTEM_STATE_HANDLER_FIRESENSOR_H
