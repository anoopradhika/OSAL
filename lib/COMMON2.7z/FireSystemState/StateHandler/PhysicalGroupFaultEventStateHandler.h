/******************************************************************************//**
*
* @file   PhysicalGroupFaultEventStateHandler.h
* @brief  State handler for FPO
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_PHYSICAL_GROUP_FAULT_EVENT_H
#define FIRESYSTEM_STATE_HANDLER_PHYSICAL_GROUP_FAULT_EVENT_H

#include "StateHandler/CommonFaultEventStateHandler.h"

namespace fireSystemState
{

/**
* @brief PhysicalGroupFaultEventStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
template<typename HANDLER>
class PhysicalGroupFaultEventStateHandler : public CommonFaultEventStateHandler<HANDLER>
{
public:
    explicit PhysicalGroupFaultEventStateHandler(HANDLER& handler ):
        CommonFaultEventStateHandler<HANDLER>(handler)
    {
    }

    ~PhysicalGroupFaultEventStateHandler() = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal(bool isthiszone = false)
    {
        auto uid = Mol::DeviceUniqueID(CommonFaultEventStateHandler<HANDLER>::m_handler.GetID());
		uint16_t m_managedAreaId = 0;
		
		if(true == isthiszone)
		{
			auto zoneid = CommonFaultEventStateHandler<HANDLER>::m_handler.GetID();
			m_managedAreaId = CommonFaultEventStateHandler<HANDLER>::m_handler.DomainConfiguration::FindManagedAreaIdForPointOrZone(zoneid);
		}
		else
		{
			m_managedAreaId = CommonFaultEventStateHandler<HANDLER>::m_handler.DomainConfiguration::FindManagedAreaId(uid.GetPanelId64Bit());
		}
	
        auto managedAreaReference = Mol::DataType::ObjectReference { m_managedAreaId, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA };
        //@notes ByCommand is the one we had to match the ID3K behavior.
        //or in case of panel failure to clear all faults for that panel
        CommonFaultEventStateHandler<HANDLER>::m_handler.PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference, this, &CommonFaultEventStateHandler<HANDLER>::ReceiveResetCommand);
        CommonFaultEventStateHandler<HANDLER>::SetupSignalCommon();
    }

};

}

#endif //FIRESYSTEM_STATE_HANDLER_PHYSICAL_GROUP_FAULT_EVENT_H
