/******************************************************************************//**
*
* @file   ControlInputStateHandler.h
* @brief  State handler for ControlInput
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_CONTROL_INPUT_H
#define FIRESYSTEM_STATE_HANDLER_CONTROL_INPUT_H

#include <queue>

#include "DOL/Entities/Point/ControlInput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/ControlInputPointStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

#ifdef UT_TARGET

#ifdef private
#undef private
#endif

#define private public

#endif

namespace fireSystemState
{

/**
* @brief ControlInputStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class ControlInputStateHandler: public Dol::Entities::ControlInput, public StateHandler<ControlInputStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    ControlInputStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
    ControlInput(id)
    ,m_pointId{id}
    ,m_pointStateMachine(*this)
    ,m_updaterStateMachine{m_pointStateMachine}
    ,m_faultEventHandler(*this)
    ,m_disableCommandHandler(*this)
    {
        //if this entity belonging to the current panel, then we should not subscribe to panel failure fault event later.
        m_isFromThisPanel = PointFromThisPanel(GetID(), m_myPanelObjectRef);
        if(! m_isFromThisPanel)
        {
            m_myCPUModuleObjectRef = Mol::DataType::ObjectReference{GetCPUModuleIDFromPanelID(m_myPanelObjectRef.GetObjectId()), Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
        }
    }

    ~ControlInputStateHandler() override = default;

    bool PointFromThisPanel(uint64_t pointID, Mol::DataType::ObjectReference& pointPanelRef)
    {
        auto nodeID = Mol::DeviceUniqueID(pointID).GetNodeID();
        auto domainID = Mol::DeviceUniqueID(pointID).GetDomainID();
        pointPanelRef =  Mol::DataType::PointReferenceHelper::Create(domainID, nodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        auto m_thisPanelID = Utility::ReadPanelID();
        auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
        auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
        auto m_thisPanelObjRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        return  (pointPanelRef == m_thisPanelObjRef);
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        DEBUGPRINT(DEBUG_INFO, "SetupSignal:ControlInputStateHandler: ID[{0}], Type[{1}]", GetID(), static_cast<int>(GetObjectType()));
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&ControlInputStateHandler::ReceiveDisablementEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::INPUT_CHANGE_IN_STATUS,reference,this,&ControlInputStateHandler::ReceiveInputChangeEvent);
        auto mid = FindManagedAreaId(GetID());//point is directly under a managed area
        m_mayManagedArea = Mol::DataType::ObjectReference { mid, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA };

        DEBUGPRINT(DEBUG_INFO, "ControlInputStateHandler:managed area ID[{0:#x}]", mid);
        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
        if(mid > 0)//only if a valid managed area is found in configuration file
        {
            PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET,m_mayManagedArea,this,&ControlInputStateHandler::ReceiveResetCommand);
        }
        if(! m_isFromThisPanel)//register only for entities connected to other panels in the network (ignore for this one)
        {
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myPanelObjectRef,this,&ControlInputStateHandler::ReceiveFaultEvent< Mol::Event::FaultEvent>);
            //@TODO remove later when we ensure they don't change their mind agin
            //PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myPanelObjectRef,this,&ControlInputStateHandler::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            if(m_myCPUModuleObjectRef.GetObjectId())
            {
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myCPUModuleObjectRef,this,&ControlInputStateHandler::ReceiveFaultEvent< Mol::Event::FaultEvent>);
                //@TODO remove later when we ensure they don't change their mind agin
                //BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myCPUModuleObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            }
        }
    }

    /**
     * @brief return the panel ID of the current entity state handler
     * Example: 0x100020000000000 for panel 2 if the entity ID is 0x100020300000001
     * DOMAIN_OBJECT_TYPE::FIRE_PANEL type and ID 0x100020000000000
     * @return Mol::DataType::ObjectReference  of the panel
     */
     Mol::DataType::ObjectReference GetmyPanelObjectRef()
     {
		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &ControlInputStateHandler::ReceiveMultiObjectQuery);
         return m_myPanelObjectRef;
     }

     /**
     * @brief return the ObjectReference of the current entity state handler
     * @return Mol::DataType::ObjectReference  of the panel
     */
     Mol::DataType::ObjectReference GetmyObjectRef()
     {
         return Mol::DataType::ObjectReference{GetID(),GetObjectType()};
     }

     /**
     * @brief last Point Disablement event received form Loop module, to create another Enablment event out of it
     */
     std::shared_ptr<Mol::Event::DisablementEvent> lastPointDisablementEvent = nullptr;

     /**
     * @brief last Point InputChange event received form Loop module, to create another RELEASED event out of it
     */
     std::shared_ptr<Mol::Event::InputChangeEvent> lastInputChangeEvent = nullptr;

protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::NON_FIRE_INPUT_ACTIVE && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }
#ifndef UT_TARGET
        auto ControlInputObj = std::static_pointer_cast<Dol::Entities::ControlInput>(shared_from_this());
        bool statusFlag = false;
#else
        auto ControlInputObj = std::make_shared<Dol::Entities::ControlInput>();
		bool statusFlag = true;
#endif
        if(nullptr == ControlInputObj)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler:ReceiveMultiObjectQuery:ControlInput object is null");
            return;
        }
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(ControlInputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!ControlInputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(ControlInputObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::NON_FIRE_INPUT_ACTIVE)
        {
            if(ControlInputObj->IsActive())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
                statusFlag = true;
            }
        }
        else
        {
            /*nothing to do*/
        }

        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
	 	MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *ControlInputObj);

		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

    /**
    * Receive a disablementEvent and invoke state machine
    * @param event : DisablementEvent
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::DISABLEMENT
                                                                            );
        if(nullptr == disablementEvent)
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        m_updaterStateMachine.process_event(disablementEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            //it helps to do UTs and functional test.
            SetCurrentState(std::string(state.c_str()));
            DEBUGPRINT(DEBUG_INFO, "ControlInputStateHandler:ReceiveDisablementEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
        SetLastError(STATE_ERROR::NO_ERROR);
    }

    /** Receive a Fault/FaultCleared event and invoke state machine
    * @param event      Fault/FaultClearedEvent Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    template<typename FaultEventType>
    void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        Mol::Event::EVENT_CATEGORY category = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
        if(std::is_same<FaultEventType, Mol::Event::FaultClearedEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler: FaultClearedEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED;
        }
        else if(std::is_same<FaultEventType, Mol::Event::FaultEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlInputStateHandler: FaultEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE;
        }
        else
        {
            //Do nothing
        }

        auto faultEvent = ValidateEvent<FaultEventType>(event, category);
        if(! faultEvent)
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        //we handle both FIRE_PANEL && CPU_MODULE
        if( !IsItMyPanelFailure(faultEvent,m_myPanelObjectRef))
        {
            return;
        }
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            SetLastError(STATE_ERROR::INVALID_PROCCESS_ID);
            return;
        }

        m_updaterStateMachine.process_event(faultEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            //it helps to do UTs and functional test.
            SetCurrentState(std::string(state.c_str()));
            DEBUGPRINT(DEBUG_INFO, "ControlInputStateHandler:ReceiveFaultEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
        SetLastError(STATE_ERROR::NO_ERROR);

    }

    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, m_mayManagedArea);
        if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        m_updaterStateMachine.process_event(reset);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "ControlInputStateHandler:ReceiveResetCommand for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
        SetLastError(STATE_ERROR::NO_ERROR);
    }
    /**
    * Receive a inputChangeEvent set the activation status
    * It also forward this event to other application
    * @param event : inputChangeEvent
    */
    void ReceiveInputChangeEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto inputChangeEvent = ValidateEvent<Mol::Event::InputChangeEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::INPUT_CHANGE_IN_STATUS
                                                                            );
        if(! inputChangeEvent)
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        SetActive(true);
        m_updaterStateMachine.process_event(inputChangeEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "ControlInputStateHandler for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
        SetLastError(STATE_ERROR::NO_ERROR);
    }

private:
    uint64_t m_pointId;

    ControlInputPointStateMachine<ControlInputStateHandler> m_pointStateMachine;

    boost::sml::sm<ControlInputPointStateMachine<ControlInputStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    FaultEventStateHandler<ControlInputStateHandler> m_faultEventHandler;

    DisableCommandHandler<ControlInputStateHandler> m_disableCommandHandler;
    Mol::DataType::ObjectReference m_mayManagedArea = Mol::DataType::ObjectReference{0, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
    Mol::DataType::ObjectReference m_myPanelObjectRef;
    Mol::DataType::ObjectReference m_myCPUModuleObjectRef;
    bool m_isFromThisPanel = false;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_CONTROL_INPUT_H
