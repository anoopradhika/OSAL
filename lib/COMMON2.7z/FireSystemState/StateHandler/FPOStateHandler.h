/******************************************************************************//**
*
* @file   FPOStateHandler.h
* @brief  State handler for FPO
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FPO_H
#define FIRESYSTEM_STATE_HANDLER_FPO_H

#include <queue>

#include "DOL/Entities/Point/FireProtectionOutput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/FPOStateMachine.h"
#include "StateMachine/ConfirmationStateMachine.h"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "StateHandler/DelayOperationHandler.h"
#include "Mol/Events/EventCategory.h"

namespace fireSystemState
{

/**
* @brief FPOStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class FPOStateHandler: public Dol::Entities::FireProtectionOutput, public StateHandler<FPOStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    FPOStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        FireProtectionOutput(id)
        ,m_pointId{id}
        ,m_pointStateMachine(*this)
        ,m_updaterStateMachine{m_pointStateMachine}
        ,m_faultEventHandler(*this)
        ,m_disableCommandHandler(*this)
        ,m_delayOperationHandler(*this)
        ,m_confirmationStateMachine(*this)
        ,m_confirmationUpdaterStateMachine{m_confirmationStateMachine}
    {
    }

    ~FPOStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION,reference,this,&FPOStateHandler::ReceiveActivationEvent);
        auto parentZones = GetParentZones();
        for(auto& parent: parentZones )
        {
//LCOV_EXCL_START
            auto parentReference = Mol::DataType::ObjectReference{parent->GetID(),parent->GetObjectType()};
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION,parentReference,this,&FPOStateHandler::ReceiveActivationEvent);
            PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE, parentReference, this, &FPOStateHandler::ReceiveZoneActivateCommand);
            PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE, parentReference, this, &FPOStateHandler::ReceiveZoneDeactivateCommand);
//LCOV_EXCL_STOP
        }

        uint64_t managedAreaId = 0;
        for(auto& parent: parentZones )
        {
//LCOV_EXCL_START
            if(managedAreaId != parent->GetManagedAreaId())
            {
                managedAreaId = parent->GetManagedAreaId();
                auto managedAreaReference = Mol::DataType::ObjectReference{managedAreaId,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,managedAreaReference,this, &FPOStateHandler::ReceiveFunctionDisableEvent);
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,managedAreaReference,this, &FPOStateHandler::ReceiveFunctionEnableEvent);
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::INFORMATION, reference, this, &FPOStateHandler::ReceiveInformationEvent);
            }
//LCOV_EXCL_STOP
        }
        
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE,reference,this,&FPOStateHandler::ReceiveActivateCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE,reference,this,&FPOStateHandler::ReceiveDeactivateCommand);
		
	    m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &FPOStateHandler::TroubleClearedEventReceived);
        SetLastOperation(Dol::CONTROL_OPERATION::END_OF_LIST);
        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
        m_delayOperationHandler.SetupSignal();
    }

    void SendActivate()
    {
        auto command = std::make_shared<Mol::Command::Activate>();
        command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
        SendCommand(command, PROC_ADDRESS::BROADCAST);
    }

    void SendDeactivate()
    {
        auto command = std::make_shared<Mol::Command::Deactivate>();
        command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
        SendCommand(command, PROC_ADDRESS::BROADCAST);
    }

protected:

    /**
    * Receive Function functionDisablement event and process the event
    * @param event      functionDisablement event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::FunctionDisable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,Mol::FUNCTION_CODE::FIRE_PROTECTION);
        if(nullptr == disablementEvent)
        {
            return;
        }
        DEBUGPRINT(DEBUG_INFO,"FPO FunctionDisable");
        m_updaterStateMachine.process_event(disablementEvent);
    }

    /**
    * Receive Function functionEnablement event and process the event
    * @param event      functionEnablement event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto enablementEvent = ValidateEvent<Mol::Event::FunctionEnable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,Mol::FUNCTION_CODE::FIRE_PROTECTION);
        if(! enablementEvent)
        {
            return;
        }
        DEBUGPRINT(DEBUG_INFO,"FPO FunctionEnable");
        m_updaterStateMachine.process_event(enablementEvent);
    }

    /**
    * Receive a activation event and invoke state machine
    * @param event      Activation Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveActivationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        DEBUGPRINT(DEBUG_INFO,"In method FPOStateHandler::ReceiveActivationEvent");
        auto activationEvent = ValidateEvent<Mol::Event::ActivationEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::ACTIVATION
                                                                            );
        if(nullptr == activationEvent )
        {
            DEBUGPRINT(DEBUG_ERROR,"FPOStateHandler::ReceiveActivationEvent Received nullptr");
            return;
        }
        DEBUGPRINT(DEBUG_INFO,"FPOStateHandler::ReceiveActivationEvent Before statemachine");
        m_updaterStateMachine.process_event(activationEvent);
        DEBUGPRINT(DEBUG_INFO,"FPOStateHandler::ReceiveActivationEvent After statemachine");
    }

    void ReceiveActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto activate = ValidateCommand<Mol::Command::Activate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::ACTIVATE
                                                        );

        if(nullptr == activate)
        {
             return;
        }

        m_activationRequestCount++;
        SetLastOperation(Dol::CONTROL_OPERATION::ACTIVATE);
        if(IsActivated() || IsDisabled() || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
             return;
        }
        SendCommand(activate,PROC_ADDRESS::BROADCAST);
    }

    void ReceiveDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::DEACTIVATE
                                                        );
        if(! deactivate)
        {
            return;
        }
		
		DecrementActivationRequestCount();

        if(!IsActivated() || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
			if((address != PROC_ADDRESS::FIRE_DOMAIN_APP) && !ActivationRequestsPending())
			{
				SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
				SendCommand(deactivate,PROC_ADDRESS::BROADCAST);
			}
             return;
        }
		
		if(ActivationRequestsPending())
        {
            DEBUGPRINT(DEBUG_INFO,"FPOStateHandler: ReceiveDeactivateCommand() still [{0}] activations request is pending before deactivation",m_activationRequestCount);
            return;
        }
		
		SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
		
        SendCommand(deactivate,PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive a information event for confirmation and invaoke state mechine
    * @param event      InformationEvent
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveInformationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto informationEvent = ValidateEvent<Mol::Event::InformationEvent>(event
                                                    , Mol::Event::EVENT_CATEGORY::INFORMATION);
        if(nullptr == informationEvent)
        {
            return;
        }
        m_confirmationUpdaterStateMachine.process_event(informationEvent);
    }
	
    void DecrementActivationRequestCount()
    {
        if(m_activationRequestCount > 0)
        {
            m_activationRequestCount--;
        }
    }
	
	bool ActivationRequestsPending()
    {
        return(m_activationRequestCount > 0);
    }

    void ReceiveZoneActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto activate = ValidateCommand<Mol::Command::Activate>(command, Mol::Command::COMMAND_CATEGORY::ACTIVATE);
        if ((nullptr == activate) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        m_zoneactivationCounter++;
    }

    void ReceiveZoneDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command, Mol::Command::COMMAND_CATEGORY::DEACTIVATE);
        if ((!deactivate) || address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        if (m_zoneactivationCounter > 0) // this is defensive code, not to decrement if m_zoneactivationCounter is already zero
        {
            m_zoneactivationCounter--;
        }

        if (0 == m_zoneactivationCounter)
        {
            m_activationRequestCount = 0;
            SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
        }
    }

	void TroubleClearedEventReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		if((nullptr == event) || (PROC_ADDRESS::MODULE_APP != address))
		{
			return;
		}

		auto troublecleared = std::static_pointer_cast <Mol::Event::FaultClearedEvent> (event);

		if(troublecleared->GetEventCode()!= Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
		{
			return;
		}

        Mol::DeviceUniqueID faultuniqueid(troublecleared->GetSource().GetObjectId());
		Mol::DeviceUniqueID thisuniqueid(GetID());

		if(thisuniqueid.GetModuleID() == faultuniqueid.GetModuleID())
		{
			if( 0 != m_activationRequestCount )
			{
                auto activate = std::make_shared<Mol::Command::Activate>();
                activate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                SendCommand(activate,PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::FPOStateHandler::TroubleClearedEventReceived: activate command sent");
			}

			if(m_disableCommandHandler.m_disablementCount > 0)
			{
				auto disable = std::make_shared<Mol::Command::Disable>();
                disable->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                SendCommand(disable,PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::FPOStateHandler::TroubleClearedEventReceived: disable command sent");
			}
		}
	}

private:
    uint64_t m_pointId;

    FPOStateMachine<FPOStateHandler> m_pointStateMachine;

    boost::sml::sm<FPOStateMachine<FPOStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    FaultEventStateHandler<FPOStateHandler> m_faultEventHandler;

    DisableCommandHandler<FPOStateHandler> m_disableCommandHandler;

    DelayOperationHandler<FPOStateHandler> m_delayOperationHandler;

    ConfirmationStateMachine<FPOStateHandler> m_confirmationStateMachine;

    boost::sml::sm<ConfirmationStateMachine<FPOStateHandler>, boost::sml::process_queue<std::queue>> m_confirmationUpdaterStateMachine;

    bool m_needActivation = false;

    bool m_needDeactivation = false;
	
	uint16_t m_activationRequestCount = 0;
    uint16_t m_zoneactivationCounter=0;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_FPO_H
