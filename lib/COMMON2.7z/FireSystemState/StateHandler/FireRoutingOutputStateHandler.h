/******************************************************************************//**
*
* @file   FireRoutingOutputStateHandler.h
* @brief  State handler for FireRoutingOutput
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FIRE_ROUTING_OUTPUT_H
#define FIRESYSTEM_STATE_HANDLER_FIRE_ROUTING_OUTPUT_H

#include "DOL/Entities/Point/FireRoutingOutput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/FireRoutingOutputPointStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include <queue>
#include "StateHandler/DelayOperationHandler.h"
#include "StateMachine/ConfirmationStateMachine.h"
#include <bitset>
#include "Helper/FSHelper.h"

namespace fireSystemState
{

/**
* @brief FireRoutingOutputStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class FireRoutingOutputStateHandler: public Dol::Entities::FireRoutingOutput, public StateHandler<FireRoutingOutputStateHandler>
{
public:
    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    FireRoutingOutputStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
    FireRoutingOutput(id)
    ,m_pointId{id}
    ,m_pointStateMachine(*this)
    ,m_updaterStateMachine{m_pointStateMachine}
    ,m_faultEventHandler(*this)
    ,m_disableCommandHandler(*this)
    ,m_delayOperationHandler(*this)
    ,m_confirmationStateMachine(*this)
    ,m_confirmationUpdaterStateMachine{m_confirmationStateMachine}
    {
        //if this entity belonging to the current panel, then we should not subscribe to panel failure fault event later.
        m_isFromThisPanel = PointFromThisPanel(GetID(), m_myPanelObjectRef);
        if(! m_isFromThisPanel)
        {
            m_myCPUModuleObjectRef = Mol::DataType::ObjectReference{GetCPUModuleIDFromPanelID(m_myPanelObjectRef.GetObjectId()), Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
        }
    }

    ~FireRoutingOutputStateHandler() override = default;

    bool PointFromThisPanel(uint64_t pointID, Mol::DataType::ObjectReference& pointPanelRef)
    {
        auto nodeID = Mol::DeviceUniqueID(pointID).GetNodeID();
        auto domainID = Mol::DeviceUniqueID(pointID).GetDomainID();
        pointPanelRef =  Mol::DataType::PointReferenceHelper::Create(domainID, nodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        auto m_thisPanelID = Utility::ReadPanelID();
        auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
        auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
        auto m_thisPanelObjRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        return  (pointPanelRef == m_thisPanelObjRef);
    }

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto mid = FindManagedAreaId(GetID());
        m_mayManagedArea = Mol::DataType::ObjectReference{mid, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputStateHandler:managed area ID[{0:#x}]",mid);
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION, reference, this, &FireRoutingOutputStateHandler::ReceiveActivationEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::INFORMATION, reference, this, &FireRoutingOutputStateHandler::ReceiveInformationEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE, reference, this, &FireRoutingOutputStateHandler::ReceiveActivateCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE, reference, this, &FireRoutingOutputStateHandler::ReceiveDeactivateCommand);
        if(mid > 0)//only if a valid managed area is found in configuration file
        {
            PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET,m_mayManagedArea,this,&FireRoutingOutputStateHandler::ReceiveResetCommand);
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TEST, m_mayManagedArea, this, &FireRoutingOutputStateHandler::ReceiveFARETestEvent);
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE, m_mayManagedArea, this, &FireRoutingOutputStateHandler::ReceiveFunctionEnableEvent);
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE, m_mayManagedArea, this, &FireRoutingOutputStateHandler::ReceiveFunctionDisableEvent);
        }
        SetLastOperation(Dol::CONTROL_OPERATION::END_OF_LIST);
        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
        m_delayOperationHandler.SetupSignal();
        if(! m_isFromThisPanel)
        {
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myPanelObjectRef,this,&FireRoutingOutputStateHandler::ReceiveFaultEvent< Mol::Event::FaultEvent>);
            //PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myPanelObjectRef,this,&FireRoutingOutputStateHandler::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            if(m_myCPUModuleObjectRef.GetObjectId())
            {
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myCPUModuleObjectRef,this,&FireRoutingOutputStateHandler::ReceiveFaultEvent< Mol::Event::FaultEvent>);
                //@TODO remove later when we ensure they don't change their mind agin
                //BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myCPUModuleObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            }
        }
    }

    void SendActivate()
    {
        auto command = std::make_shared<Mol::Command::Activate>();
        command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
        SendCommand(command, PROC_ADDRESS::BROADCAST);
    }

    void SendDeactivate()
    {
        auto command = std::make_shared<Mol::Command::Deactivate>();
        command->SetCommandTarget(Mol::DataType::ObjectReference{GetID(), GetConcreteObjectType()});
        SendCommand(command, PROC_ADDRESS::BROADCAST);
    }

    bool IsConfirmed() const
    {
        return m_confirmed;
    }

    void SetConfirmation(bool confirmed)
    {
        m_confirmed = confirmed;
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_myPanelObjectRef;
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return Mol::DataType::ObjectReference{GetID(),GetObjectType()};
    }

    std::shared_ptr<Mol::Event::TestOperationEvent> lastTestEvent = nullptr;
    std::shared_ptr<Mol::Event::FunctionDisable> lastFunctionDisableEvent = nullptr;

protected:

    /**
    * Receive a activation event and invaoke state mechine
    * @param event      Activation Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveActivationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto activationEvent = ValidateEvent<Mol::Event::ActivationEvent>(event, Mol::Event::EVENT_CATEGORY::ACTIVATION);
        if((nullptr == activationEvent ) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(activationEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveActivationEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });

	    if(activationEvent->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
		{
			SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
		}
		else if(activationEvent->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
		{
			SetLastOperation(Dol::CONTROL_OPERATION::ACTIVATE);
		}
		else
		{
			//do nothing
		}
    }

    /**
    * Receive a activation event and invaoke state mechine
    * @param event      Information Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveInformationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto informationEvent = ValidateEvent<Mol::Event::InformationEvent>(event
                                                    , Mol::Event::EVENT_CATEGORY::INFORMATION);
        if((nullptr == informationEvent) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        //Parallel sate machine for confirmation information
        m_confirmationUpdaterStateMachine.process_event(informationEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveInformationEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
    }

    /**
    * Receive a activation event and invaoke state mechine
    * @param event      Test Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFARETestEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        //check if is ether a FARE_TEST or a FARE_REMOVED_FROM_TEST, if not return
        auto testEvent = ValidateEvent<Mol::Event::TestOperationEvent>(event
                                                    , Mol::Event::EVENT_CATEGORY::TEST
                                                    , Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST);
        if(nullptr == testEvent)
        {
            testEvent = ValidateEvent<Mol::Event::TestOperationEvent>(event
                                                                , Mol::Event::EVENT_CATEGORY::TEST
                                                                , Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_REMOVED_FROM_TEST);
        }
        if(nullptr == testEvent)
        {
            return;
        }
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
        m_updaterStateMachine.process_event(testEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveFARETestEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
    }

    void ReceiveActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto activate = ValidateCommand<Mol::Command::Activate>(command, Mol::Command::COMMAND_CATEGORY::ACTIVATE);
        if(nullptr == activate)
        {
            return;
        }
        SetLastOperation(Dol::CONTROL_OPERATION::ACTIVATE);
        m_activationRequestCount++;
        if(IsActivated() || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        SendCommand(activate, PROC_ADDRESS::BROADCAST);
    }

    void ReceiveDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command, Mol::Command::COMMAND_CATEGORY::DEACTIVATE);
        if(!deactivate)
        {
            return;
        }

        std::cout << "FARE: receive deactivate command IsActivated :"<<IsActivated() << std::endl;

        DecrementActivationRequestCount();
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputStateHandler: ReceiveDeactivateCommand() internally from FDA");
            return;
        }
        if(!IsActivated())
        {
            DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputStateHandler: ReceiveDeactivateCommand() already deactivated");
            return;
        }
        if(ActivationRequestsPending())
        {
            DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputStateHandler: ReceiveDeactivateCommand() still [{0}] activations request is pending before deactivation",m_activationRequestCount);
            return;
        }
        SendCommand(deactivate, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive a Function disablement Event and invaoke state mechine
    * @param event      Function disablement Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionDisable = ValidateEvent<Mol::Event::FunctionDisable>(event, Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,
        Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
        if((nullptr == functionDisable) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(functionDisable);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveFunctionDisableEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
    }

    /**
    * Receive a Function enablement Event and invaoke state mechine
    * @param event      Function enablement Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionEnable = ValidateEvent<Mol::Event::FunctionEnable>(event, Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,
        Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
        if(nullptr == functionEnable)
        {
            return;
        }
        m_updaterStateMachine.process_event(functionEnable);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveFunctionEnableEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
    }

    void DecrementActivationRequestCount()
    {
        if(m_activationRequestCount > 0)
        {
            m_activationRequestCount--;
        }

		if(m_activationRequestCount == 0)
		{
		    SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
		}
    }

    bool ActivationRequestsPending()
    {
        return(m_activationRequestCount > 0);
    }

    /** Receive a Fault/FaultCleared event and invoke state machine
    * @param event      Fault/FaultClearedEvent Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    template<typename FaultEventType>
    void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        Mol::Event::EVENT_CATEGORY category = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
        if(std::is_same<FaultEventType, Mol::Event::FaultClearedEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputStateHandler: FaultClearedEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED;
        }
        else if(std::is_same<FaultEventType, Mol::Event::FaultEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputStateHandler: FaultEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE;
        }
        else
        {
            //Do Nothing
        }

        auto faultEvent = ValidateEvent<FaultEventType>(event, category);
        if(! event)
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        //we handle both FIRE_PANEL && CPU_MODULE
        if( !IsItMyPanelFailure(faultEvent,m_myPanelObjectRef))
        {
            return;
        }
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            SetLastError(STATE_ERROR::INVALID_PROCCESS_ID);
            return;
        }
        // SetFault(true);
        // SendEvent(faulEvent,PROC_ADDRESS::BROADCAST,true);
        m_updaterStateMachine.process_event(faultEvent);
        m_updaterStateMachine.visit_current_states([this](auto state){
            //it helps to do UTs and functional test.
            SetCurrentState(std::string(state.c_str()));
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveFaultEvent for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
        SetLastError(STATE_ERROR::NO_ERROR);
    }


    /**
    * Receive Reset command and process
    * @param command    Reset command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reset = ValidateCommand<Mol::Command::Reset>(command, Mol::Command::COMMAND_CATEGORY::RESET, m_mayManagedArea);
        if((reset ==  nullptr) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            SetLastError(STATE_ERROR::INVALID_EVENT);
            return;
        }
        m_updaterStateMachine.process_event(reset);
        m_updaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "FireRoutingOutputStateHandler:ReceiveResetCommand for [{0:#x}]is now in state[{1}]", GetID(), state.c_str());
                });
        SetLastError(STATE_ERROR::NO_ERROR);
    }
    
private:
    uint64_t m_pointId;
    uint32_t m_activationRequestCount = 0;
    bool m_confirmed = false;
    FireRoutingOutputPointStateMachine<FireRoutingOutputStateHandler> m_pointStateMachine;

    boost::sml::sm<FireRoutingOutputPointStateMachine<FireRoutingOutputStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    PhysicalGroupFaultEventStateHandler<FireRoutingOutputStateHandler> m_faultEventHandler;

    DisableCommandHandler<FireRoutingOutputStateHandler> m_disableCommandHandler;

    DelayOperationHandler<FireRoutingOutputStateHandler> m_delayOperationHandler;
    ConfirmationStateMachine<FireRoutingOutputStateHandler> m_confirmationStateMachine;
    boost::sml::sm<ConfirmationStateMachine<FireRoutingOutputStateHandler>, boost::sml::process_queue<std::queue>> m_confirmationUpdaterStateMachine;
    Mol::DataType::ObjectReference m_myPanelObjectRef;
    Mol::DataType::ObjectReference m_myCPUModuleObjectRef;
    bool m_isFromThisPanel = false;
    Mol::DataType::ObjectReference m_mayManagedArea = Mol::DataType::ObjectReference{0, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_FIRE_ROUTING_OUTPUT_H
