/******************************************************************************//**
*
* @file   CommonFireOutputPointStateHandler.h
* @brief  State handler for CommonFireOutput Point
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_COMMON_FIRE_OUTPUT_H
#define FIRESYSTEM_STATE_HANDLER_COMMON_FIRE_OUTPUT_H

#include <queue>

#include "DOL/Entities/Point/CommonFireOutput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"

#ifdef UT_TARGET
#define private protected
#endif

namespace fireSystemState
{

/**
* @brief CommonFireOutputPointStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class CommonFireOutputPointStateHandler: public Dol::Entities::CommonFireOutput, public StateHandler<CommonFireOutputPointStateHandler>
{
public:
    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    CommonFireOutputPointStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
    CommonFireOutput(id)
    ,m_faultEventHandler(*this)
    {
        DEBUGPRINT(DEBUG_INFO, "CommonFireOutput id[{}]", id);
    }

    ~CommonFireOutputPointStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        m_faultEventHandler.SetupSignal();
    }

private:
    PhysicalGroupFaultEventStateHandler<CommonFireOutputPointStateHandler> m_faultEventHandler;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_COMMON_FIRE_OUTPUT_H
