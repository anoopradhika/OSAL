/******************************************************************************//**
*
* @file   LoopStateHandler.h
* @brief  State handler for Loop
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_LOOP_H
#define FIRESYSTEM_STATE_HANDLER_LOOP_H

#include <queue>

#include "DOL/Entities/Loop.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"
#include "Mol/Events/FaultEvent.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"

namespace fireSystemState
{

/**
* @brief LoopStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class LoopStateHandler: public Dol::Entities::Loop, public StateHandler<LoopStateHandler>
{
public:
    /**
    * Prepare the StateMaschine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    LoopStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        Loop(id)
        ,m_element{element}
        ,m_faultEventHandler(*this)
    {
    }

    explicit LoopStateHandler(XmlElementConfig element):
        Loop(element.id)
        ,m_element{element}
        ,m_faultEventHandler(*this)
    {
    }
//  LCOV_EXCL_START
    ~LoopStateHandler() override = default;
//  LCOV_EXCL_STOP
    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        m_faultEventHandler.SetupSignal();
    }

private:

    XmlElementConfig m_element;
    PhysicalGroupFaultEventStateHandler<LoopStateHandler> m_faultEventHandler;

    uint64_t m_managedAreaId = 0;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_LOOP_H
