/******************************************************************************//**
*
* @file   ModuleStateHandler.h
* @brief  State handler for Module
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_MODULE_H
#define FIRESYSTEM_STATE_HANDLER_MODULE_H

#include <queue>

#include "DOL/Entities/Module.h"
#include "DOL/Entities/Module/ChargerModule.h"
#include "DOL/Entities/Module/IOModule.h"
#include "DOL/Entities/Module/SerialComms.h"
#include "DOL/Entities/Module/SerialComms.h"
#include "DOL/Entities/Module/NetworkModule.h"
#include "DOL/Entities/Module/CPUModule.h"
#include "DOL/Entities/Module/FAREFREModule.h"
#include "DOL/Entities/Module/FATFBFModule.h"
#include "DOL/Entities/Module/LoopModule.h"
#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"
#include "Mol/Events/FaultEvent.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "StateObjectFactory/StateObjectFactory.h"
#include "StateObjectFactory/PointStateObjectList.h"
#include "StateSetup/PointStateSetup.h"

#define noop (void)0

namespace fireSystemState
{

/**
* @brief ModuleStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
template<typename EntitiesType>
class ModuleStateHandler: public EntitiesType, public StateHandler<ModuleStateHandler<EntitiesType>>
{

public:

    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    ModuleStateHandler(const Dol::DomainObjectID id,XmlElementConfig& element):
        EntitiesType(element.id)
        ,m_element{element}
        ,m_faultEventHandler(*this)
        ,m_Id(id)
    {
    }

    ~ModuleStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void Prepare() override
    {
        try
        {
            DomainConfiguration::ModuleChildrenConfig(m_element,m_pointsConfig);
        }
//LCOV_EXCL_START
        catch( tinyxml2::XmlException &e )
        {
            std::cerr << e .what() << std::endl;
			DEBUGPRINT(DEBUG_ERROR, "ModuleStateHandler: Tinyxml Exception while reading the file - {}", e.what());
			noop;						//To fix sonarqube vulnerability
        }
        catch(...)
        {
            std::cerr << "Unknown exception while reading XML file" << std::endl;
			DEBUGPRINT(DEBUG_ERROR, "ModuleStateHandler: Unknown Exception while reading the file ");
			noop;						//To fix sonarqube vulnerability
        }
//LCOV_EXCL_STOP
        for(auto pointConfig: m_pointsConfig)
        {
            std::cout<<"Module point id "<<std::hex<<pointConfig.id<<" type "<< (uint32_t)pointConfig.pointType<<std::endl;
            auto pointState = StateObjectFactory<Dol::Entities::Point,PointStateObjectTypes>::Create(pointConfig);
            // std::cout <<"AZ %%%%%%%%%%%%%%%%%%%%%%%%%%% "<< typeid(shared_from_this()).name() << std::endl;;

            if(pointState)
            {
                PointStatePrepare(pointState);
                EntitiesType::AddPoint(pointState);
            }
        }

    }

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto reference = Mol::DataType::ObjectReference{EntitiesType::GetID(),EntitiesType::GetObjectType()};
        //@notes ByCommand is the one we had to match the ID3K behavior.
        m_faultEventHandler.SetupSignal();
        ModuleStateHandler<EntitiesType>::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::INFORMATION,reference,this,&ModuleStateHandler::ReceiveInformationEvent);
        for(auto& point : EntitiesType::m_points)
        {
            PointSignalSetup(point);
        }
    }

protected:

    void ReceiveInformationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto informationEvent = ValidateEvent<Mol::Event::InformationEvent>(event
                                                                , Mol::Event::EVENT_CATEGORY::INFORMATION
                                                                );
        if((nullptr == informationEvent) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        // SetFault(true);
        // SendEvent(faulEvent,PROC_ADDRESS::BROADCAST,true);
        ModuleStateHandler<EntitiesType>::SendEvent(informationEvent,PROC_ADDRESS::BROADCAST,true);
    }
    XmlElementConfig m_element;
    
private:

    
    std::vector<XmlElementConfig> m_pointsConfig;
    PhysicalGroupFaultEventStateHandler<ModuleStateHandler> m_faultEventHandler;

    uint64_t m_Id = 0;

};

}

#endif //FIRESYSTEM_STATE_HANDLER_FARE_FAE_MODULE_H
