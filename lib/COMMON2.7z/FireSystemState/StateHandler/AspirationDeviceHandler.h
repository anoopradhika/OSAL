/*****************************************************************//**
 *
 * @file    AspirationDeviceHandler.h
 * @brief   Contains the representation of a AspirationDeviceHandler
 *
 *
 * @copyright Copyright 2020 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_ASD_H
#define FIRESYSTEM_STATE_HANDLER_ASD_H

#include "DomainConfiguration/DomainConfiguration.h"
#include "Mol/Events/Event.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/DataType/ObjectReference.h"
#include "Helper/FSHelper.h"

#ifdef UT_TARGET
#ifdef private
#undef private
#endif
#define private public
#endif


namespace fireSystemState
{

//! This class is representing the ASD as per the schema
template<typename HANDLER>
class AspirationDeviceHandler
{
public:
    enum class ASD_TYPE : uint8_t
    {
        NFXI_ASD11,
        NFXI_ASD12,
        NFXI_ASD22,
        END_OF_LIST
    };

    /**
     * Constructor
     * @param objType Type of AspirationDeviceHandler object
     * @param id Object ID
     */
    explicit AspirationDeviceHandler(HANDLER& faultInput):
        m_handler{faultInput}
    {
    }


    ~AspirationDeviceHandler()
    {
        m_sensorsRef.clear();
        m_zonesRef.clear();
    }

    /**
     * Prepare the signal for receive commands and event
     */
    void Prepare()
    {
        auto sensorRefs = m_handler.ParseAspirationDevices(m_handler.GetID(),"NFXI-ASD11");
        for (auto point_id : sensorRefs)
        {
            m_sensorsRef.insert(Mol::DataType::ObjectReference{point_id,Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR});
            auto parent = m_handler.FindParent(point_id);
            if (Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST != parent.GetObjectType())
            {
                m_zonesRef.insert(parent);
            }
        }
        m_hasAsperationDevice = (!m_sensorsRef.empty() && !m_zonesRef.empty());
        if(!m_hasAsperationDevice)
        {
            m_sensorsRef.clear();
            m_zonesRef.clear();
            auto sensorRefs = m_handler.ParseAspirationDevices(m_handler.GetID(),"NFXI-ASD12");
            for (auto point_id : sensorRefs)
            {
                m_sensorsRef.insert(Mol::DataType::ObjectReference{point_id,Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR});
                auto parent = m_handler.FindParent(point_id);
                if (Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST != parent.GetObjectType())
                {
                    m_zonesRef.insert(parent);
                }
            }
        }
        m_hasAsperationDevice = (!m_sensorsRef.empty() && !m_zonesRef.empty());
        if(!m_hasAsperationDevice)
        {
            m_sensorsRef.clear();
            m_zonesRef.clear();
            auto sensorRefs = m_handler.ParseAspirationDevices(m_handler.GetID(),"NFXI-ASD22");
            for (auto point_id : sensorRefs)
            {
                m_sensorsRef.insert(Mol::DataType::ObjectReference{point_id,Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR});
                auto parent = m_handler.FindParent(point_id);
                if (Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST != parent.GetObjectType())
                {
                    m_zonesRef.insert(parent);
                }
            }
        }
        m_hasAsperationDevice = (!m_sensorsRef.empty() && !m_zonesRef.empty());
    }

    void SetupSignal()
    {
        if(m_hasAsperationDevice)
        {
            auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
            m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,reference,this,&AspirationDeviceHandler<HANDLER>::ReceiveFaultClearedEvent);
            m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,reference,this,&AspirationDeviceHandler<HANDLER>::ReceiveFaultEvent);
        }
    }

private:

    bool isAspirationDeviceFault(Mol::Event::FAULT_EVENT_CODE code)
    {
        return (code >= Mol::Event::FAULT_EVENT_CODE::ASPIRATION_FAULT && code <= Mol::Event::FAULT_EVENT_CODE::ASPIRATION_TIME_BASE_FAULT);
    }

    template<typename EventType>
    void SendFaultEvent(Mol::Event::FAULT_EVENT_CODE code)
    {
        auto fault = std::make_shared<EventType>(code);
        for (auto source : m_sensorsRef)
        {
            fault->SetSource(source);
            fault->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, "ASD_FAULT");
            //send to FDA only so that the particular state handler will be proceed and event broadcast after
            m_handler.SendEvent(fault,PROC_ADDRESS::FIRE_DOMAIN_APP,true);
        }
        for (auto source : m_zonesRef)
        {
            fault->SetSource(source);
            fault->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, "ASD_FAULT");
            //send to FDA only so that the particular state handler will be proceed and event broadcast after
            m_handler.SendEvent(fault,PROC_ADDRESS::FIRE_DOMAIN_APP,true);
        }
    }

    /** Receive a Trouble cleared event and invoke state machine
     * @param event      receive fault cleared event
     * @param id         senderID - Unique id of the sender
     * @param address    Originator of event
     */
    void ReceiveFaultClearedEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto faulClearedEvent = ValidateEvent<Mol::Event::FaultClearedEvent>(event
                                                            , Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED
                                                            );
        if(! faulClearedEvent)
        {
            return;
        }

        if(address != PROC_ADDRESS::FIRE_DOMAIN_APP && isAspirationDeviceFault(faulClearedEvent->GetEventCode()))
        {
            //need to send even if m_handler.IsFault() to process fault state for Detection zone & fire sensor handler.
            SendFaultEvent<Mol::Event::FaultClearedEvent>(faulClearedEvent->GetEventCode());
        }
    }

    /** Receive a Trouble cleared event and invoke state machine
     * @param event      receive fault cleared event
     * @param id         senderID - Unique id of the sender
     * @param address    Originator of event
     */
    void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto fault = ValidateEvent<Mol::Event::FaultEvent>(event
                                                            , Mol::Event::EVENT_CATEGORY::TROUBLE
                                                            );
        if(! fault)
        {
            return;
        }

        if(address != PROC_ADDRESS::FIRE_DOMAIN_APP && isAspirationDeviceFault(fault->GetEventCode()) && m_handler.IsFault())
        {
            SendFaultEvent<Mol::Event::FaultEvent>(fault->GetEventCode());
        }
    }

    std::set<Mol::DataType::ObjectReference> m_sensorsRef;
    std::set<Mol::DataType::ObjectReference> m_zonesRef;
    HANDLER& m_handler;
    bool m_hasAsperationDevice = false;
    bool m_isFault = false;
    ASD_TYPE m_type;

};
}

#endif /* FIRESYSTEM_STATE_HANDLER_ASD_H */
