/******************************************************************************//**
*
* @file   SerialPortStateHandler.h
* @brief  State handler for SerialPortPoint
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_SERIAL_PORT_H
#define FIRESYSTEM_STATE_HANDLER_SERIAL_PORT_H

#include <queue>

#include "DOL/Entities/Point/SerialPort.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/SerialPortStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/PhysicalGroupFaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

namespace fireSystemState
{

/**
* @brief SerialPortStateHandler is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class SerialPortStateHandler: public Dol::Entities::SerialPort, public StateHandler<SerialPortStateHandler>
{

public:

    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    SerialPortStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        SerialPort(id)
        ,m_pointId{id}
        ,m_pointStateMachine(*this)
        ,m_updaterStateMachine{m_pointStateMachine}
        ,m_faultEventHandler(*this)
        ,m_disableCommandHandler(*this)
    {
    }

    ~SerialPortStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&SerialPortStateHandler::ReceiveDisablementEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION,reference,this,&SerialPortStateHandler::ReceiveActivationEvent);
		m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &SerialPortStateHandler::ReceiveMultiObjectQuery);
        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
    }

protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"SerialPortStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"SerialPortStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }
#ifndef UT_TARGET
        auto SerialPortObj = std::static_pointer_cast<Dol::Entities::SerialPort>(shared_from_this());
        bool statusFlag = false;
#else
        auto SerialPortObj = std::make_shared<Dol::Entities::SerialPort>();
		bool statusFlag = true;
#endif
        if(nullptr == SerialPortObj)
        {
            DEBUGPRINT(DEBUG_INFO,"SerialPortStateHandler:ReceiveMultiObjectQuery:SerialPort object is null");
            return;
        }
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(SerialPortObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!SerialPortObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(SerialPortObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
                statusFlag = true;
            }
        }
        else
        {
            /*nothing to do*/
        }

        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"SerialPortStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
		MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *SerialPortObj);
		
		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"SerialPortStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }

    /**
    * Receive a disablementEvent and invaoke state mechine
    * @param event : DisablementEvent
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::DISABLEMENT
                                                                            );
        if(nullptr == disablementEvent)
        {
            return;
        }
        m_updaterStateMachine.process_event(disablementEvent);
    }

    /**
    * Receive a activation event and invoke state machine
    * @param event      Activation Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveActivationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto activationEvent = ValidateEvent<Mol::Event::ActivationEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::ACTIVATION
                                                                            );
        if((nullptr == activationEvent ) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(activationEvent);
    }

private:

    uint64_t m_pointId;

    SerialPortStateMachine<SerialPortStateHandler> m_pointStateMachine;

    boost::sml::sm<SerialPortStateMachine<SerialPortStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;

    PhysicalGroupFaultEventStateHandler<SerialPortStateHandler> m_faultEventHandler;

    DisableCommandHandler<SerialPortStateHandler> m_disableCommandHandler;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_SERIAL_PORT_H
