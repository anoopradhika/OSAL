/******************************************************************************//**
*
* @file   ControlOutputStateHandler.h
* @brief  State handler for ControlOutput
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_CONTROL_OUTPUT_H
#define FIRESYSTEM_STATE_HANDLER_CONTROL_OUTPUT_H

#include <queue>

#include "DOL/Entities/Point/ControlOutput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/ControlOutputPointStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include "StateHandler/DelayOperationHandler.h"
#include "Mol/Requests/MultiObjectQuery.h"
#include "Mol/Responses/MultiObjectData.h"

namespace fireSystemState
{

/**
* @brief ControlOutputStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
class ControlOutputStateHandler: public Dol::Entities::ControlOutput, public StateHandler<ControlOutputStateHandler>
{
public:
    /**
    * Prepare the State Machine and base objects
    * @param[in] id         DomainObjectId
    * @param[in] element    configuration about a child or children
    */
    ControlOutputStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
        ControlOutput(id)
        ,m_pointId{id}
        ,m_pointStateMachine(*this)
        ,m_updaterStateMachine{m_pointStateMachine}
        ,m_faultEventHandler(*this)
        ,m_disableCommandHandler(*this)
        ,m_delayOperationHandler(*this)
    {
        SetLastOperation(Dol::CONTROL_OPERATION::END_OF_LIST);
    }

    ~ControlOutputStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION,reference,this,&ControlOutputStateHandler::ReceiveActivationEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&ControlOutputStateHandler::ReceiveDisablementevent);

        auto parentZones = GetParentZones();
        for(auto& parent: parentZones )
        {
//LCOV_EXCL_START
            auto parentReference = Mol::DataType::ObjectReference{parent->GetID(),parent->GetObjectType()};
            PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::ACTIVATION,parentReference,this,&ControlOutputStateHandler::ReceiveActivationEvent);
            PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE,parentReference,this,&ControlOutputStateHandler::ReceiveZoneActivateCommand);
            PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE,parentReference,this,&ControlOutputStateHandler::ReceiveZoneDeactivateCommand);
//LCOV_EXCL_STOP
        }
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ACTIVATE,reference,this,&ControlOutputStateHandler::ReceiveActivateCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DEACTIVATE,reference,this,&ControlOutputStateHandler::ReceiveDeactivateCommand);

        uint64_t managedAreaId = 0;
        for(auto& parent: parentZones )
        {
//LCOV_EXCL_START
            if(managedAreaId != parent->GetManagedAreaId())
            {
                managedAreaId = parent->GetManagedAreaId();
                auto managedAreaReference = Mol::DataType::ObjectReference{managedAreaId,Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA};
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,managedAreaReference,this, &ControlOutputStateHandler::ReceiveFunctionDisableEvent);
                PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,managedAreaReference,this, &ControlOutputStateHandler::ReceiveFunctionEnableEvent);
            }
//LCOV_EXCL_STOP
        }

        m_communicator.m_request.Subscribe<Mol::Request::MultiObjectQuery>(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
		m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY)->Connect(this, &ControlOutputStateHandler::ReceiveMultiObjectQuery);
		
	    m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &ControlOutputStateHandler::TroubleClearedEventReceived);	

        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
        m_delayOperationHandler.SetupSignal();
    }

    void EnableAction()
    {

        if(CheckLastOperation(Dol::CONTROL_OPERATION ::ACTIVATE))
        {
            auto activate = std::make_shared<Mol::Command::Activate>();
            activate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
            SendCommand(activate,PROC_ADDRESS::BROADCAST);
            return;
        }
        /*else if(CheckLastOperation(Dol::CONTROL_OPERATION ::DEACTIVATE))
        {
            auto deactivate = std::make_shared<Mol::Command::Deactivate>();
            deactivate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
            SendCommand(deactivate,PROC_ADDRESS::BROADCAST);
            return;
        }*/
        else{
        	/* Do nothing */
        }
    }

protected:
	/**
    * Receive a MultiObjectQuery Request and invoke state machine
    * @param event      MultiObjectQuery Request
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of request
    */
    void ReceiveMultiObjectQuery(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, uint64_t id, PROC_ADDRESS address)
    {
        auto MultiObjectQueryRequest = ValidateRequest<Mol::Request::MultiObjectQuery>(request, Mol::Request::REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
        if(nullptr == MultiObjectQueryRequest)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlOutputStateHandler:ReceiveMultiObjectQuery:MultiObjectQuery Request is null");
            return;
        }

        auto sourceRef = MultiObjectQueryRequest->GetSource();
        auto targetRef = MultiObjectQueryRequest->GetTarget();
        auto source = MultiObjectQueryRequest->GetSourceTarget();
        if(targetRef.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT || targetRef.GetObjectId() != this->GetID())
        {
            DEBUGPRINT(DEBUG_INFO,"ControlOutputStateHandler:ReceiveMultiObjectQuery:Type or id doesn't match. Device id of the object[{0}] DOMAIN OBJECT TYPE[{1}] DOMAIN OBJECT ID[{2}]",(long int)this->GetID(), (int)targetRef.GetObjectType(), (long int)targetRef.GetObjectId());
            return;
        }

        auto statusRequest = std::static_pointer_cast<Mol::Request::MultiObjectQuery>(request);
        auto queryType = statusRequest->GetRequestCode();
		if(queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED && queryType !=  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
            return;
        }
		
#ifndef UT_TARGET
		auto ControlOutputObj = std::static_pointer_cast<Dol::Entities::ControlOutput>(shared_from_this());
		bool statusFlag = false;
#else
		auto ControlOutputObj = std::make_shared<Dol::Entities::ControlOutput>();
		bool statusFlag = true;
#endif
        if(nullptr == ControlOutputObj)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlOutputStateHandler:ReceiveMultiObjectQuery:ControlOutput object is null");
            return;
        }
        if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::DISABLED)
        {
            if(ControlOutputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
        else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::IN_FAULT)
        {
            if(ControlOutputObj->IsFault())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::ENABLED)
        {
            if(!ControlOutputObj->IsDisabled())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::OUTPUT_ACTIVATED)
        {
            if(ControlOutputObj->IsActivated())
            {
                statusFlag = true;
            }
        }
		else if(queryType ==  Mol::Request::MULTI_OBJECT_QUERY_CODE::SUB_ADDRESS)
        {
			std::cout<<"in sub address case\n";
            auto deviceUniqueId = Mol::DeviceUniqueID{targetRef.GetObjectId()};
			std::cout<<"target obj id bef:"<<(uint64_t)targetRef.GetObjectId()<<std::endl;
            uint8_t channelNum = deviceUniqueId.GetChannelNumber();
            if(channelNum != 0)
            {
                deviceUniqueId.SetChannelNumber(0);
                Mol::DataType::ObjectReference ObjectReference{deviceUniqueId.Get(),targetRef.GetObjectType()};
                targetRef = ObjectReference;
				std::cout<<"target obj id bef 1:"<<(uint64_t)targetRef.GetObjectId()<<std::endl;
                statusFlag = true;
            }
        }
        else
        {
            /*nothing to do*/
        }
        if(!statusFlag)
        {
            return;
        }

        auto MultiObjectDataResponse = std::make_shared<Mol::Response::MultiObjectData>(Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT,Mol::Response::RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
        if(nullptr == MultiObjectDataResponse)
        {
            DEBUGPRINT(DEBUG_INFO,"ControlOutputStateHandler:ReceiveMultiObjectQuery:MultiObjectdataResponse object is null");
            return;
        }
	 	MultiObjectDataResponse->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, *ControlOutputObj);
		
		//Setting source and target for the response
        MultiObjectDataResponse->SetTarget(sourceRef);
        MultiObjectDataResponse->SetSource(targetRef);
        MultiObjectDataResponse->SetResponseTarget(source);

        SendResponse(MultiObjectDataResponse, PROC_ADDRESS::MAINLOOP);
        DEBUGPRINT(DEBUG_INFO,"ControlOutputStateHandler:ReceiveMultiObjectQuery:Multi Object Data response sent");
    }
    /**
    * Receive Function ReceiveDisablementevent event and process the event
    * @param event      Disablementevent event
    * @param id         Object ID
    * @param address    Originator of event
    */
    void ReceiveDisablementevent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event, Mol::Event::EVENT_CATEGORY::DISABLEMENT);
		
        if(nullptr == disablementEvent)
        {
            return;
        }

        m_updaterStateMachine.process_event(disablementEvent);
    }
    /**
    * Receive Function functionDisablement event and process the event
    * @param event      functionDisablement event
    * @param id         Object ID
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::FunctionDisable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,Mol::FUNCTION_CODE::CONTROL_OUTPUTS);
        if(nullptr == disablementEvent)
        {
            return;
        }

        m_updaterStateMachine.process_event(disablementEvent);
    }

    /**
    * Receive Function functionEnablement event and process the event
    * @param event      functionEnablement event
    * @param id         Object ID
    * @param address    Originator of event
    */
    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionEnable = ValidateEvent<Mol::Event::FunctionEnable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,Mol::FUNCTION_CODE::CONTROL_OUTPUTS);
        if(! functionEnable)
        {
            return;
        }
        m_updaterStateMachine.process_event(functionEnable);
    }

    /**
    * Receive a activation event and invoke state machine
    * @param event      Activation Event
    * @param id         Object ID
    * @param address    Originator of event
    */
    void ReceiveActivationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto activationEvent = ValidateEvent<Mol::Event::ActivationEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::ACTIVATION
                                                                            );
        if((nullptr == activationEvent ) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_updaterStateMachine.process_event(activationEvent);
    }

    void ReceiveActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto activate = ValidateCommand<Mol::Command::Activate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::ACTIVATE
                                                        );
        if((nullptr == activate) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
             return;
        }

        m_activationCounter++;
		
        SetLastOperation(Dol::CONTROL_OPERATION::ACTIVATE);
		
        if(IsActivated())
		{
			return;
		}
		
        if(!IsDisabled())
        {
            SendCommand(activate,PROC_ADDRESS::BROADCAST);
        }
    }

    void ReceiveDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command
                                                        , Mol::Command::COMMAND_CATEGORY::DEACTIVATE
                                                        );
        if(! deactivate)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
             return;
        }
		
		if(m_activationCounter) //this is defensive code, not to decrement if m_activationCounter is already zero
		{
		   m_activationCounter--;
		   	if(0 == m_activationCounter)
			{
				SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
			}
		}

        if(!IsDisabled())
        {
			if(0 == m_activationCounter)
			{
               SendCommand(deactivate,PROC_ADDRESS::BROADCAST);
			}
        }
    }
    void ReceiveZoneActivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto activate = ValidateCommand<Mol::Command::Activate>(command, Mol::Command::COMMAND_CATEGORY::ACTIVATE);
        if ((nullptr == activate) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        m_zoneactivationCounter++;
    }

    void ReceiveZoneDeactivateCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto deactivate = ValidateCommand<Mol::Command::Deactivate>(command, Mol::Command::COMMAND_CATEGORY::DEACTIVATE);
        if ((!deactivate) || address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        if (m_zoneactivationCounter > 0) // this is defensive code, not to decrement if m_activationCounter is already zero
        {
            m_zoneactivationCounter--;
        }

        if (0 == m_zoneactivationCounter)
        {
            m_activationCounter = 0;
            SetLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE);
        }
    }

	void TroubleClearedEventReceived(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
	{
		if((nullptr == event) || (PROC_ADDRESS::MODULE_APP != address))
		{
			return;
		}

		auto troublecleared = std::static_pointer_cast <Mol::Event::FaultClearedEvent> (event);

		if(troublecleared->GetEventCode()!= Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
		{
			return;
		}

        Mol::DeviceUniqueID faultuniqueid(troublecleared->GetSource().GetObjectId());
		Mol::DeviceUniqueID thisuniqueid(GetID());

		if(thisuniqueid.GetModuleID() == faultuniqueid.GetModuleID())
		{
			if( 0 != m_activationCounter )
			{
                auto activate = std::make_shared<Mol::Command::Activate>();
                activate->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                SendCommand(activate,PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::ControlOutputStateHandler::TroubleClearedEventReceived: activate command sent");
			}
			
			if(m_disableCommandHandler.m_disablementCount > 0)
			{
				auto disable = std::make_shared<Mol::Command::Disable>();
                disable->SetCommandTarget(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
                SendCommand(disable,PROC_ADDRESS::BROADCAST);
			    DEBUGPRINT(DEBUG_INFO,"FDA::ControlOutputStateHandler::TroubleClearedEventReceived: disable command sent");
			}
		}
	}

private:
    uint64_t m_pointId;

    ControlOutputPointStateMachine<ControlOutputStateHandler> m_pointStateMachine;

    boost::sml::sm<ControlOutputPointStateMachine<ControlOutputStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;
    FaultEventStateHandler<ControlOutputStateHandler> m_faultEventHandler;
    DisableCommandHandler<ControlOutputStateHandler> m_disableCommandHandler;
    DelayOperationHandler<ControlOutputStateHandler> m_delayOperationHandler;
	uint16_t m_activationCounter = 0;
	uint16_t m_zoneactivationCounter=0;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_CONTROL_OUTPUT_H
