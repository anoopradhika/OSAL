/******************************************************************************//**
*
* @file   ManagedArea.h
* @brief  State handler for Managed Area.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_MANAGEDAREA_H
#define FIRESYSTEM_STATE_HANDLER_MANAGEDAREA_H

#include "DOL/Entities/ManagedArea.h"
#include "Mol/Events/FunctionDisable.h"
#include "Mol/Events/FunctionEnable.h"
#include "Mol/Commands/ReSynchronization.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "DomainConfiguration/DomainConfiguration.h"
#include "StateObjectFactory/StateObjectFactory.h"
#include "StateObjectFactory/ZoneStateObjectList.h"
#include "StateHandler/StateHandler.h"
#include "StateSetup/ZoneStateSetup.h"

#include "Mol/Requests/GeneralIndicatorServiceRequest.h"
#include "Mol/Responses/GeneralIndicatorServiceResponse.h"

#include <set>
#include  <bitset>
#include "Timer/Timer.hpp"
#define noop (void)0

namespace fireSystemState
{

/**
* @brief ManagedAreaStateHandler is created from configuration file. It used for receiving event and command.
* Based on events.
*/
class ManagedAreaStateHandler: public Dol::Entities::ManagedArea, public StateHandler<ManagedAreaStateHandler>
{
public:
    struct PanelFunctionDisablmentTraking
    {
        uint64_t panelID;
        Mol::FUNCTION_CODE code = Mol::FUNCTION_CODE::END_OF_LIST;
        mutable bool isFaulty = false;
        bool operator == (const PanelFunctionDisablmentTraking& element) const
        {
            return( (panelID == element.panelID) &&  (code == element.code) );
        }
        size_t operator()(const PanelFunctionDisablmentTraking& t) const
        {
            return t.panelID;
        }
    };

    explicit ManagedAreaStateHandler(XmlElementConfig& element):
    ManagedArea(element.id)
    ,m_element{element}
    {
    }

    ~ManagedAreaStateHandler() override = default;

    /**
    * Prepare the signal for receive commands and event
    * Prepare zone staehandler for managedArea
    */
    void Prepare() override
    {
        try
        {
            ZoneConfig(m_element,m_zonesConfigs);
        }
        catch( tinyxml2::XmlException &e )
        {
            std::cerr << e .what() << std::endl;
			DEBUGPRINT(DEBUG_ERROR, "ManagedAreaStateHandler: Tinyxml Exception thrown - {}", e.what());
			noop;						//To fix sonarqube vulnerability
        }
        catch(...)
        {
            std::cerr << "Unknown exception while reading XML file" << std::endl;
			DEBUGPRINT(DEBUG_ERROR, "ManagedAreaStateHandler: Tinyxml Exception while reading the file ");
			noop;						//To fix sonarqube vulnerability
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Zone configuration:[{0}]",time(nullptr));
        for(auto zone: m_zonesConfigs)
        {
            std::cout<<"*****Zone id "<<zone.id<<"Zone type "<<(uint32_t)zone.pointType<<std::endl;
            //auto zoneState = std::make_shared<StateHandlerType>(zone);
            auto zoneState = StateObjectFactory<Dol::Entities::Zone,ZoneStateObjectTypes>::Create(zone);
            // auto zoneState = StateObjectFactory<StateHandler<ManagedAreaStateHandler,Dol::Entities::Zone>,ZoneStateObjectTypes>::Create(zone);

            if(zoneState != nullptr)
            {
                ZoneStatePrepare(zoneState);
                zoneState->AddManagedArea(shared_from_this());
                AddZone(zoneState);
            }
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Zone Objects:[{0}]",time(nullptr));
        MangedAreaPointConfig(m_element,m_pointRefConfig);
        DEBUGPRINT(DEBUG_INFO,"Loaded Managed Area Point Config:[{0}]",time(nullptr));
        for(auto pointConfig: m_pointRefConfig)
        {
            auto pointState = StateObjectFactory<Dol::Entities::Point,PointStateObjectTypes>::Create(pointConfig);
            if(pointState)
            {
                DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler: Prepare() add point id[{0}], type[{1}]",
                                    (uint64_t)pointConfig.id, (uint8_t)pointConfig.pointType);

                PointStatePrepare(pointState);
                PointSignalSetup(pointState);
                pointState->AddManagedArea(shared_from_this());
                AddPoint(pointState);
            }
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Managed Area Point Objects:[{0}]",time(nullptr));

        notifier.Connect(this, &ManagedAreaStateHandler::ResetTimeout);
        m_timer = Platform::Timer<>(RESET_MONITOR_INTERVAL, GlobalDataType::Timer::AlarmType::SINGLE_SHOT, notifier);
        m_resyncNotifier.Connect(this, &ManagedAreaStateHandler::SendReSynchronizationCmd);
        m_resyncCmdTimer = Platform::Timer<>(RESYN_CMD_DELAY, GlobalDataType::Timer::AlarmType::SINGLE_SHOT, m_resyncNotifier);
        DEBUGPRINT(DEBUG_INFO,"Initializing SendReSynchronizationCmd timer:[{0}]",time(nullptr));

        Platform::Notifier timeResendZoneCommand;
        timeResendZoneCommand.Connect(this,&ManagedAreaStateHandler::ResendZoneCommand);
        m_timeResendZoneCommand = Platform::Timer<>((uint64_t)5000,GlobalDataType::Timer::AlarmType::PERIODIC,timeResendZoneCommand);

    }
    void ResendZoneCommand()
    {
        DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler:Try to Resend Zone Command at:[{0}]",time(nullptr));
		if((m_silenceState == false) && (m_EvacuationState == false))
		{
			for(auto zoneState: GetZoneHandler())
			{
				zoneState->ResendCommand();       
			}
		}
        DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler:Resent Zone Command at:[{0}]",time(nullptr));
    }
    void SetupSignal() override
    {

        DEBUGPRINT(DEBUG_INFO,"Setup Managed Area Signal:[{0}]",time(nullptr));
        for(auto& zone : m_zones)
        {
            ZoneSignalSetup(zone);
        }
        DEBUGPRINT(DEBUG_INFO,"Setup zone Signal:[{0}]",time(nullptr));
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE,reference,this,&ManagedAreaStateHandler::ReceiveFunctionDisableEvent);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE,reference,this, &ManagedAreaStateHandler::ReceiveFunctionEnableEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET,reference,this, &ManagedAreaStateHandler::ReceiveResetCommand);
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::USER_OPERATION,reference,this,&ManagedAreaStateHandler::UserOperationEvent);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::FUNCTION_DISABLE,reference,this, &ManagedAreaStateHandler::ReceiveFunctionDisableCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::FUNCTION_ENABLE,reference,this, &ManagedAreaStateHandler::ReceiveFunctionEnableCommand);
        m_communicator.m_response.Subscribe<Mol::Response::GeneralIndicatorServiceResponse>(Mol::Response::RESPONSE_CATEGORY::GENERAL_INDICATOR_SERVICE_RESPONSE);
        m_communicator.m_response.getService(Mol::Response::RESPONSE_CATEGORY::GENERAL_INDICATOR_SERVICE_RESPONSE)->Connect(this, &ManagedAreaStateHandler::ReceiveFireStatus);
        DEBUGPRINT(DEBUG_INFO,"1st level service:[{0}]",time(nullptr));
        RequestGeneralIndicatorStatus();
        DEBUGPRINT(DEBUG_INFO,"RequestGeneralIndicatorStatus:[{0}]",time(nullptr));
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESOUND,reference,this, &ManagedAreaStateHandler::ReceiveResoundCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SILENCE,reference,this, &ManagedAreaStateHandler::ReceiveSilenceCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::CANCEL_BUZZER,reference,this, &ManagedAreaStateHandler::ReceiveCancelBuzzerCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::EXTEND_DELAYS,reference,this, &ManagedAreaStateHandler::ReceiveExtendDelaysCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::OVERRIDE_DELAYS,reference,this, &ManagedAreaStateHandler::ReceiveOverrideDelaysCommand);
		PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::EVACUATION_ON,reference,this, &ManagedAreaStateHandler::ReceiveEvacuationOnCommand);
		PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::EVACUATION_OFF,reference,this, &ManagedAreaStateHandler::ReceiveEvacuationOffCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_DAY_NIGHT_MODE,reference,this, &ManagedAreaStateHandler::ReceiveSetDayNightModeCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE,reference,this,&ManagedAreaStateHandler::ReceiveSensitivityCommand);
        PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESYNC,reference,this,&ManagedAreaStateHandler::ReceiveResyncCommand);
        DEBUGPRINT(DEBUG_INFO,"2nd Level service:[{0}]",time(nullptr));
        //we need to subscribe to all object reference fault/fault cleared events and then process only
        //NO_REPLY/COMMUNICATIONS_STOPPED coming from FIRE_PANEL object type
        FaultEventSubscribe<Mol::Event::FaultClearedEvent,fireSystemState::EventType>(fireSystemState::EventType::TROUBLE_CLEARED);
        FaultEventSubscribe<Mol::Event::FaultEvent,fireSystemState::EventType>(fireSystemState::EventType::TROUBLE);
        DEBUGPRINT(DEBUG_INFO,"Subscribe Fault Event:[{0}]",time(nullptr));

        m_timeResendZoneCommand.Start();
    }
    void Stop()
    {
        m_timeResendZoneCommand.Stop();
    }
protected:

    /**
    * Template to Subscribe all type mol events
    */
    template<typename event, typename eventType>
    void FaultEventSubscribe(eventType eventTypeId)
    {
        m_communicator.m_event.Subscribe<event>(eventTypeId);
        m_communicator.m_event.getServiceWithApplicationType(eventTypeId)->Connect(this, &ManagedAreaStateHandler::ReceiveFaultEvent<event>);
    }

    /**
    * @brief If a panel goes offline, then when it subsequently goes back online,
    * it must synchronize the status of all zones and points within this managed area.
    */
    void RequestGeneralIndicatorStatus()
    {
        auto generalRequest = std::make_shared<Mol::Request::GeneralIndicatorServiceRequest>(Mol::IndicatorServiceCode::ADD, Mol::SubscriberList::FDA);
        generalRequest->SetSourceTarget({GetID(), Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE});
        m_communicator.m_request.Send(generalRequest, PROC_ADDRESS::FIRE_DOMAIN_APP,0,0,true);
    }

    /**
    * @brief Request for General Indicator status
    */
    void SendReSynchronizationCmd()
    {
        auto reSyncCmd = std::make_shared<Mol::Command::ReSynchronization>();
        reSyncCmd->SetCommandTarget({GetID(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
        SendCommand(reSyncCmd, PROC_ADDRESS::CMCAPP);
        SendCommand(reSyncCmd, PROC_ADDRESS::MOL_RECEIVER);//Dragon debug purpose

    }
    /**
     * @brief Store fire status
     * @param messageBase   GeneralIndicatorService Response
     * @param senderID      the origin of the event
     */
    void ReceiveFireStatus(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> messageBase, uint64_t senderID)
    {
        if(nullptr == messageBase)
        {
            return;
        }
        auto indicatorResponse = std::static_pointer_cast<Mol::Response::GeneralIndicatorServiceResponse>(messageBase);
        std::bitset<32> indicatorBits(indicatorResponse->GetResponseCode());
        if( indicatorBits.test(Mol::Response::GeneralIndicatorSnapshot::Alarm) )
        {
            m_fire = true;

            DEBUGPRINT(DEBUG_INFO, "FDA ManualCallPointStateHandler: GeneralIndicatorService Response fire {}",m_fire);
        }
        else
        {
            m_fire = false;

            DEBUGPRINT(DEBUG_INFO, "FDA ManualCallPointStateHandler: GeneralIndicatorService Response fire {}",m_fire);
        }
    }

    /**
    * Receive Function functionDisablement event and process the event
    * @param event      functionDisablement
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto functionDisablement = ValidateEvent<Mol::Event::FunctionDisable>(event, Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE);
        if(! functionDisablement)
        {
            return;
        }

        std::cout<<"Here 1.1 code "<< (uint32_t)functionDisablement->GetEventCode()<<std::endl;
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
        auto search = m_functionCodeMap.find(functionDisablement->GetEventCode());
        if(search == m_functionCodeMap.end())
        {
            //@todo add error log here
            return;
        }
        std::cout<<"Here 2"<<std::endl;

        if(IsFunctionDisablementActive(search->second))
        {
            return;
        }

        AddFunctionDisablement(search->second);
        if(IsItFromNetwork(functionDisablement))
        {
            //we are only interested about function disablment events coming from other panels in the network
            //convert module ID (s200, loop module) to its panel ID
            auto panelID =  GetPanelRefFromEvent(functionDisablement);
            //save from wich panel this function disablment code is coming

            m_listOfPanelsFuncDisablment.insert(PanelFunctionDisablmentTraking{panelID,functionDisablement->GetEventCode(), false});
        }
        SendEvent(functionDisablement,PROC_ADDRESS::BROADCAST, true);
    }

    /**
    * Receive Function functionEnablement event and process the event
    * @param event      functionDisablement
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionEnableEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto enableEvent = ValidateEvent<Mol::Event::FunctionEnable>(event,Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE);
        if(! enableEvent)
        {
            return;
        }

        auto search = m_functionCodeMap.find(enableEvent->GetEventCode());
        if(search == m_functionCodeMap.end())
        {
            //@todo add error log here
            return;
        }
		if(!IsFunctionDisablementActive(search->second))
		{
			return;
		}
        ClearFunctionDisablement(search->second);
        SendEvent(enableEvent,PROC_ADDRESS::BROADCAST, true);
    }

    /**
    * Receive Sensitivity Profile command and process
    * @param command    SetSensitivityProfile command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveSensitivityCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto setProfile = ValidateCommand<Mol::Command::SetSensitivityProfile>(command
                                                        , Mol::Command::COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE
                                                        );

        if((nullptr == setProfile) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        if(setProfile->GetCommandCode() == Mol::Command::SET_SENSITIVITY_PROFILE_CODE::ALTERNATE && !IsSensitivityProfileOverridden())
        {
            DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler:Receive Sensitivity Profile Alternate Command");
            SetSensitivityProfile(true);
            SendCommand(setProfile,PROC_ADDRESS::BROADCAST);
        }
        else if(setProfile->GetCommandCode() == Mol::Command::SET_SENSITIVITY_PROFILE_CODE::DEFAULT && IsSensitivityProfileOverridden())
        {
            DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler:Receive Sensitivity Profile Default Command");
            SetSensitivityProfile(false);
            SendCommand(setProfile,PROC_ADDRESS::BROADCAST);
        }
        else
        {
            return;
        }
    }

    /**
    * Receive Resync command and process
    * @param command    Resync command
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResyncCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto resyncCmd = ValidateCommand<Mol::Command::ReSynchronization>(command
                                                        , Mol::Command::COMMAND_CATEGORY::RESYNC
                                                        );

        if((nullptr == resyncCmd) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        DEBUGPRINT(DEBUG_INFO,"ReceiveResyncCommand: and forward tobEVENTLOGAPP and  EVENT_PROVIDERAPP");
        //we should avoid broadcast so that it return back to the network
        //only EVENT_PROVIDERAPP is interested about this command, EVENTLOGAPP for logging only
        SendCommand(resyncCmd,PROC_ADDRESS::EVENTLOGAPP);
        SendCommand(resyncCmd,PROC_ADDRESS::EVENT_PROVIDERAPP);
    }
    /**
    * Receive reset command and forwarding
    * @param command    reset
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        std::cout<<"ReceiveResetCommand"<<std::endl;
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto reset = ValidateCommand<Mol::Command::Reset>( command
                                                         , Mol::Command::COMMAND_CATEGORY::RESET
                                                         , reference);
        if(! reset)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        if(!m_resetInProgress)
        {
            SendReset(reset);
            m_unprocessedResetCommand = nullptr;
            m_resetInProgress = true;
            ProcessDisconnectedPanelsFuncDisablment();
        }
        else
        {
            m_unprocessedResetCommand = reset;
            m_ResetProcessed = false;
        }

        if(m_timer.Elapsed() > 0 )
        {
            m_timer.Stop();
        }

        m_timer.Start();

    }

    void SendReset(std::shared_ptr<Mol::Command::Reset> reset)
    {
        SendCommand(reset, PROC_ADDRESS::BROADCAST);
        m_ResetProcessed = true;
    }

    /**
    * Receive Silence command and forwarding
    * @param command    Silence
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveSilenceCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto silence = ValidateCommand<Mol::Command::Silence>( command
                                                         , Mol::Command::COMMAND_CATEGORY::SILENCE);
		m_silenceState = true;
        if(! silence)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        SendCommand(silence, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive Evacuation on command and forwarding
    * @param command    Evacuation on
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveEvacuationOnCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
		m_EvacuationState = true;
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto evacuationon = ValidateCommand<Mol::Command::EvacauationOn>( command
                                                         , Mol::Command::COMMAND_CATEGORY::EVACUATION_ON);
        if(! evacuationon)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        SendCommand(evacuationon, PROC_ADDRESS::BROADCAST);
    }

	/**
    * Receive Evacuation off command and forwarding
    * @param command    Evacuation off
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveEvacuationOffCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto evacuationoff = ValidateCommand<Mol::Command::EvacauationOff>( command
                                                         , Mol::Command::COMMAND_CATEGORY::EVACUATION_OFF);
        if(! evacuationoff)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        SendCommand(evacuationoff, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive Resound command and forwarding
    * @param command    Resound
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveResoundCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto resound = ValidateCommand<Mol::Command::Resound>( command
                                                         , Mol::Command::COMMAND_CATEGORY::RESOUND);
		m_silenceState = false;
        if(! resound)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }

        SendCommand(resound, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive Cancel Buzzer command and forwarding
    * @param command    CancelBuzzer
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveCancelBuzzerCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto cancelBuzzer = ValidateCommand<Mol::Command::CancelBuzzer>( command
                                                         , Mol::Command::COMMAND_CATEGORY::CANCEL_BUZZER);
        if((nullptr == cancelBuzzer) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        //https://acsjira.honeywell.com/browse/FSNPNL-17868
        //Discussed in Architecture meeting and confirmed that Buzzer off
        //should have impact to all panels in same Managed Area.

        SendCommand(cancelBuzzer, PROC_ADDRESS::BROADCAST);
        BroadcastEvent<Mol::Event::UserOperationEvent>(Mol::Event::USER_OPERATION_EVENT_CODE::CANCEL_BUZZER);
    }

    /**
    * Receive ExtendDelays command and forwarding
    * @param command    ExtendDelays
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveExtendDelaysCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto extendDelays = ValidateCommand<Mol::Command::ExtendDelays>( command
                                                         , Mol::Command::COMMAND_CATEGORY::EXTEND_DELAYS);
        if(nullptr == extendDelays)
        {
            return;
        }
        SendCommand(extendDelays, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive Override delays command and forwarding
    * @param command    OverrideDelays
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveOverrideDelaysCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto overrideDelays = ValidateCommand<Mol::Command::OverrideDelays>( command
                                                         , Mol::Command::COMMAND_CATEGORY::OVERRIDE_DELAYS);
        if(nullptr == overrideDelays)
        {
            return;
        }
        SendCommand(overrideDelays, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive SetDayNightMode command and forwarding
    * @param command    SetDayNightMode
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveSetDayNightModeCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto setDayNightModeCmd = ValidateCommand<Mol::Command::SetDayNightMode>( command
                                                         , Mol::Command::COMMAND_CATEGORY::SET_DAY_NIGHT_MODE);
        if(nullptr == setDayNightModeCmd)
        {
            return;
        }
        SendCommand(setDayNightModeCmd, PROC_ADDRESS::BROADCAST);
    }

    /**
    * Receive Function UserOperation event and process the event
    * @param event      User Operation Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void UserOperationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto useroperation = ValidateEvent<Mol::Event::UserOperationEvent>(event,Mol::Event::EVENT_CATEGORY::USER_OPERATION);
        if(! useroperation)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
		
		if(useroperation->GetEventCode()  == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_OFF)
		{
			m_EvacuationState = false;
		}

        SendEvent(useroperation,PROC_ADDRESS::BROADCAST,true);
    }

    bool BreakInterlockingMechanism(std::shared_ptr<Mol::Command::FunctionEnable> command )
    {
        return(!m_InterlockingIsAlwaysActive
                && m_fire
                && MatchParameterString(command,"FBF"));
    }

    /**
    * Receive reset command and forwarding
    * @param command    FunctionEnable
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionEnableCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto functionEnable = ValidateCommand<Mol::Command::FunctionEnable>( command
                                                         , Mol::Command::COMMAND_CATEGORY::FUNCTION_ENABLE
                                                         , reference);
        if(! functionEnable)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
		
		//FindModuleObjectType can be removed,
        auto dolType = DomainConfiguration::FindModuleObjectType(id);
        if(Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST == dolType)
        {
            DEBUGPRINT(DEBUG_ERROR,"ReceiveFunctionEnableCommand: incorrect dol type for ID[{}]", id);
            return;
        }
        // interlocking mechanism is by dol type, and only 2 types are supported for the moment:
        // from FIRE_BRIGADE_CONTROL_PANEL
        // from CPU_MODULE, FIRE_PANEL which is considered as CPU_MODULE
        // from panel in the network "NETWORK_MODULE" which is considered as CPU_MODULE
        dolType = (true == MatchParameterString(functionEnable,"FBF")) ? Dol::DOMAIN_OBJECT_TYPE::FIRE_BRIGADE_CONTROL_PANEL : Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE;
        switch ( functionEnable->GetCommandCode() )
        {
            case Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING:
                m_fareDisabled.erase(dolType);
                if ( m_fareDisabled.empty() )
                {
                    // Last disablement removed
                    SendCommand(functionEnable, PROC_ADDRESS::BROADCAST);
                }
                break;

            case  Mol::FUNCTION_CODE::FIRE_PROTECTION:
                m_fpeDisabled.erase(dolType);
                if ( m_fpeDisabled.empty() )
                {
                    // Last disablement removed
                    SendCommand(functionEnable, PROC_ADDRESS::BROADCAST);
                }
                break;
            case Mol::FUNCTION_CODE::CONTROL_OUTPUTS:
                m_controlOutputDisabled.erase(dolType);
                if( m_controlOutputDisabled.empty() )
                {
                    // Last disablement removed
                    SendCommand(functionEnable, PROC_ADDRESS::BROADCAST);
                }
                break;

            case Mol::FUNCTION_CODE::ALARM_DEVICES:
                {
                    if(BreakInterlockingMechanism(functionEnable))
                    {
                        for(auto& alarmDecive : m_alarmDeviceDisabled)
                        {
                            (void)alarmDecive;
                            SendCommand(functionEnable, PROC_ADDRESS::FIRE_DOMAIN_APP);
                        }
                        m_alarmDeviceDisabled.clear();
                    }
                    else
                    {
                        m_alarmDeviceDisabled.erase(dolType);
                    }
                    if ( m_alarmDeviceDisabled.empty() )
                    {
                        // Last disablement removed
                        SendCommand(functionEnable, PROC_ADDRESS::BROADCAST);
                    }
                }
                break;

            default:
                SendCommand(functionEnable, PROC_ADDRESS::BROADCAST);

				//to handle function disable
				const auto result = std::find_if(m_functionDisableCommands.begin(), m_functionDisableCommands.end(), [functionEnable](auto other)
                {
                    return (functionEnable->GetCommandCode() == other->GetCommandCode() &&
                            (functionEnable->GetCommandTarget().GetObjectId() == other->GetCommandTarget().GetObjectId()));
                });

                if (result != m_functionDisableCommands.end())
                {
                    m_functionDisableCommands.erase(result);
                }

                break;
        }

    }

    /**
    * Receive reset command and forwarding
    * @param command    FunctionDisable
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    void ReceiveFunctionDisableCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        auto functionDisable = ValidateCommand<Mol::Command::FunctionDisable>( command
                                                         , Mol::Command::COMMAND_CATEGORY::FUNCTION_DISABLE
                                                         , reference);
        if(! functionDisable)
        {
            return;
        }

        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
		
		//FindModuleObjectType can be removed
        auto dolType = DomainConfiguration::FindModuleObjectType(id);
        if(Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST == dolType)
        {
            DEBUGPRINT(DEBUG_ERROR,"ReceiveFunctionEnableCommand: incorrect dol type for ID[{}]", id);
            return;
        }
        // interlocking mechanism is by dol type, and only 2 types are supported for the moment:
        // from FIRE_BRIGADE_CONTROL_PANEL
        // from CPU_MODULE, FIRE_PANEL which is considered as CPU_MODULE
        // from panel in the network "NETWORK_MODULE" which is considered as CPU_MODULE
		
		//FBF commands will have FBF string as parameter, maincpu will not have any parameter
        dolType = (true == MatchParameterString(functionDisable,"FBF")) ? Dol::DOMAIN_OBJECT_TYPE::FIRE_BRIGADE_CONTROL_PANEL : Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE;
        switch ( functionDisable->GetCommandCode() )
        {
            case Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING:
                if ( m_fareDisabled.empty() )
                {
                    // First disablement
                    SendCommand(functionDisable, PROC_ADDRESS::BROADCAST);
                }
                m_fareDisabled.insert(dolType);
                break;

            case Mol::FUNCTION_CODE::FIRE_PROTECTION:
                if ( m_fpeDisabled.empty() )
                {
                    // First disablement
                    SendCommand(functionDisable, PROC_ADDRESS::BROADCAST);
                }
                m_fpeDisabled.insert(dolType);
                break;

            case Mol::FUNCTION_CODE::ALARM_DEVICES:
                if ( m_alarmDeviceDisabled.empty() )
                {
                    SendCommand(functionDisable, PROC_ADDRESS::BROADCAST);
                }
                m_alarmDeviceDisabled.insert(dolType);
                break;

            case Mol::FUNCTION_CODE::CONTROL_OUTPUTS:
                if( m_controlOutputDisabled.empty() )
                {
                    SendCommand(functionDisable, PROC_ADDRESS::BROADCAST);
                }
                m_controlOutputDisabled.insert(dolType);
                break;

            default:
                //  forwards all other commands
                SendCommand(functionDisable, PROC_ADDRESS::BROADCAST);
				m_functionDisableCommands.insert(functionDisable); // to handle persistance of disablement
                break;
        }

    }


    /** Receive a Fault/FaultCleared event and invoke state machine
    * @param event      Fault/FaultClearedEvent Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    template<typename FaultEventType>
    void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        Mol::Event::EVENT_CATEGORY category = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
        bool isNetworkModuleReady = false;
        bool isPanelFailOverFault = false;
        Mol::DataType::ObjectReference source;
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
        if(std::is_same<FaultEventType, Mol::Event::FaultClearedEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler: FaultClearedEvent managed area ID[{}]", GetID());
            category = Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED;

			//to handle persistance of disablement
			auto fltclrevent = std::static_pointer_cast<Mol::Event::FaultClearedEvent> (event);
			auto type = fltclrevent->GetSource().GetObjectType();

			if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS == fltclrevent->GetEventCode() )
			{
				if(((type == Dol::DOMAIN_OBJECT_TYPE::IO_MODULE) || (type == Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE)) && (!m_alarmDeviceDisabled.empty()))
				{
					auto alarmfuncDisable = std::make_shared<Mol::Command::FunctionDisable>(Mol::FUNCTION_CODE::ALARM_DEVICES);
                    alarmfuncDisable->SetCommandTarget({GetID(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
                    SendCommand(alarmfuncDisable, PROC_ADDRESS::CMCAPP);
                    SendCommand(alarmfuncDisable, PROC_ADDRESS::MOL_RECEIVER);//Dragon debug purpose
				}

				if(((type == Dol::DOMAIN_OBJECT_TYPE::IO_MODULE) || (type == Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE)) && (!m_controlOutputDisabled.empty()))
				{
					auto controlfuncDisable = std::make_shared<Mol::Command::FunctionDisable>(Mol::FUNCTION_CODE::CONTROL_OUTPUTS);
                    controlfuncDisable->SetCommandTarget({GetID(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
                    SendCommand(controlfuncDisable, PROC_ADDRESS::CMCAPP);
                    SendCommand(controlfuncDisable, PROC_ADDRESS::MOL_RECEIVER);//Dragon debug purpose
				}

				if(((type == Dol::DOMAIN_OBJECT_TYPE::IO_MODULE) || (type == Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE)) && (!m_fpeDisabled.empty()))
				{
					auto fpefuncDisable = std::make_shared<Mol::Command::FunctionDisable>(Mol::FUNCTION_CODE::FIRE_PROTECTION);
                    fpefuncDisable->SetCommandTarget({GetID(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
                    SendCommand(fpefuncDisable, PROC_ADDRESS::CMCAPP);
                    SendCommand(fpefuncDisable, PROC_ADDRESS::MOL_RECEIVER);//Dragon debug purpose
				}

				if((type == Dol::DOMAIN_OBJECT_TYPE::FARE_FRE_MODULE) && (!m_fareDisabled.empty()))
				{
					auto fpefuncDisable = std::make_shared<Mol::Command::FunctionDisable>(Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
                    fpefuncDisable->SetCommandTarget({GetID(), Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
                    SendCommand(fpefuncDisable, PROC_ADDRESS::CMCAPP);
                    SendCommand(fpefuncDisable, PROC_ADDRESS::MOL_RECEIVER);//Dragon debug purpose
				}

				for(auto funcdisable : m_functionDisableCommands)
				{
				    SendCommand(funcdisable, PROC_ADDRESS::CMCAPP);
                    SendCommand(funcdisable, PROC_ADDRESS::MOL_RECEIVER);//Dragon debug purpose
				}
			}
        }
        else if(std::is_same<FaultEventType, Mol::Event::FaultEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler: FaultEvent, managed area ID[{}]", GetID());
            category = Mol::Event::EVENT_CATEGORY::TROUBLE;
        }
        else
        {
            //Do Nothing
        }
        auto faultEvent = ValidateEvent<FaultEventType>(event, category, Mol::Event::FAULT_EVENT_CODE::NO_REPLY, Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE);
        isPanelFailOverFault = (nullptr != faultEvent);
        if(! faultEvent)
        {
            faultEvent = ValidateEvent<FaultEventType>(event, category, Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED, Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
            isPanelFailOverFault = (nullptr != faultEvent);
        }
        if(! faultEvent)
        {
            faultEvent = ValidateEvent<FaultEventType>(event, category, Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS, Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE);
            isNetworkModuleReady = ((nullptr != faultEvent) && (Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED == category));
        }
        if(! faultEvent)
        {
            return;
        }
        if(isPanelFailOverFault && (Mol::Event::EVENT_CATEGORY::TROUBLE == category))
        {
            for (auto& element : m_listOfPanelsFuncDisablment)
            {
                if(m_listOfPanelsFuncDisablment.empty())
                {
                    break;
                }
                DEBUGPRINT(DEBUG_INFO,"ManagedAreaStateHandler: ReceiveFaultEvent TROUBLE element.panelID[{0:#x}], "
                                        "faultEvent ID[{0:#x}]", element.panelID,faultEvent->GetSource().GetObjectId());
                Mol::DataType::ObjectReference source = faultEvent->GetSource();
                source.PrepareDeviceUniqueID();
                //now panelID is provided as 1, 2, 3 .. Node ID, but for future compatibility both case are tested here
                if (element.panelID == source.GetObjectId() || source.GetNodeID() == element.panelID)
                {
                    element.isFaulty = true;
                }
            }
        }
        else if(isPanelFailOverFault && (Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED == category))
        {
            //send RESYNC cmd after some times (10s), give some time to clear remote events
            m_resyncCmdTimer.Stop();
            m_resyncCmdTimer.Start();
        }
        else if(isNetworkModuleReady && !sendResyncCmdOnStartup)
        {
            sendResyncCmdOnStartup = true;
            //send RESYNC cmd after some times (10s)
            SendReSynchronizationCmd();
        }
        else
        {
            //Do Nothing
        }
    }

    /**
     * @brief    SendEventToModule: Broadcast event to so it can be retrieved later by FAT/FBF and comms module
     * @param code: the event code to send.
     */
    template <typename EventType, typename CodeType>
    void BroadcastEvent(CodeType code)
    {
        auto event = std::make_shared <EventType> (code);
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        event->SetSource(Mol::DataType::ObjectReference{GetID(),GetObjectType()});
        m_communicator.m_event.Send(event, PROC_ADDRESS::BROADCAST);
        m_communicator.m_event.Send(event, PROC_ADDRESS::FIRE_DOMAIN_APP);
        DEBUGPRINT(DEBUG_INFO, "ManagedArea: BroadcastEvent with code [{}]", (uint32_t)code);
    }

    void ResetTimeout()
    {
        if((!m_ResetProcessed)  && (nullptr != m_unprocessedResetCommand))
        {
            SendReset(m_unprocessedResetCommand);
        }
        m_resetInProgress = false;
    }

    void ProcessDisconnectedPanelsFuncDisablment()
    {
        for (auto& element : m_listOfPanelsFuncDisablment)
        {
            if (element.isFaulty)
            {
                element.isFaulty = false;
                auto enableEvent = std::make_shared<Mol::Event::FunctionEnable>(element.code);
                enableEvent->SetSource(Mol::DataType::ObjectReference{GetID(), GetObjectType()});
                enableEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
                //Send it only to FDA so that it will process the event and forward afterward
                SendEvent(enableEvent, PROC_ADDRESS::FIRE_DOMAIN_APP, true);
            }
        }
    }

	template<class T>
	bool MatchParameterString(T MolMessage, std::string value)
	{
		bool retVal = false;
	    try{
		    auto parameters = MolMessage->GetParameters();

			if(parameters.empty())
			{
				return retVal;
			}

		    for (auto &iterator: parameters )
		    {
		        if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
		        {
                    std::string valstring = iterator.template GetValue<std::string>();
                    
					if(valstring == value)
					{
                        return true;
					}
			    }
		    }
		}
		catch(...)
		{
			DEBUGPRINT(DEBUG_ERROR,"ManagedAreaStateHandler::MatchParameterString Cant get the molparameter parameter");
		}
		
		return retVal;
	}

    XmlElementConfig& m_element;
    static constexpr uint64_t RESET_MONITOR_INTERVAL = 3000; /// 3 second
    static constexpr uint64_t RESYN_CMD_DELAY = 10000; /// 10 second

    private:

    std::vector<XmlElementConfig> m_zonesConfigs;

    std::map<Mol::FUNCTION_CODE,Dol::FUNCTION> m_functionCodeMap{
            {Mol::FUNCTION_CODE::CONTROL_OUTPUTS,Dol::FUNCTION::CONTROL_OUTPUTS}
            ,{Mol::FUNCTION_CODE::ALARM_DEVICES,Dol::FUNCTION::ALARM_DEVICES}
            ,{Mol::FUNCTION_CODE::FIRE_PROTECTION,Dol::FUNCTION::FIRE_PROTECTION}
            ,{Mol::FUNCTION_CODE::FAULT_ROUTING,Dol::FUNCTION::FAULT_ROUTING}
            ,{Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING,Dol::FUNCTION::FIRE_ALARM_ROUTING}
            ,{Mol::FUNCTION_CODE::RELEASING,Dol::FUNCTION::RELEASING}
            ,{Mol::FUNCTION_CODE::FIRE_DETECTION,Dol::FUNCTION::FIRE_DETECTION}
            ,{Mol::FUNCTION_CODE::CONTROL_INPUTS,Dol::FUNCTION::CONTROL_INPUTS}
            ,{Mol::FUNCTION_CODE::TECHNICAL_ALARM_DETECTION,Dol::FUNCTION::TECHNICAL_ALARM_DETECTION}
            };

    // sets to track the diablement states
    std::set<Dol::DOMAIN_OBJECT_TYPE> m_fareDisabled;

    std::set<Dol::DOMAIN_OBJECT_TYPE> m_fpeDisabled;

    std::set<Dol::DOMAIN_OBJECT_TYPE> m_alarmDeviceDisabled;

    std::set<Dol::DOMAIN_OBJECT_TYPE> m_controlOutputDisabled;

	std::set<std::shared_ptr<Mol::Command::FunctionDisable>> m_functionDisableCommands;// to handle persistance of disablement

    bool m_fire = false;
    bool m_resetInProgress = false;
    bool m_ResetProcessed = false;
    std::shared_ptr<Mol::Command::Reset> m_unprocessedResetCommand = nullptr;
    Platform::Timer<> m_timer;
    Platform::Timer<> m_resyncCmdTimer;
    Platform::Notifier notifier;
    Platform::Notifier m_resyncNotifier;
    bool m_InterlockingIsAlwaysActive = false;
    std::vector<XmlElementConfig> m_pointRefConfig;
	uint64_t m_lastPanelFaultID = 0;
	bool sendResyncCmdOnStartup = false;
	std::unordered_set  <PanelFunctionDisablmentTraking, PanelFunctionDisablmentTraking> m_listOfPanelsFuncDisablment;
    Platform::Timer<> m_timeResendZoneCommand;
	bool m_silenceState = false;
	bool m_EvacuationState = false;

};

}

#endif //FIRESYSTEM_STATE_HANDLER_MANAGEDAREA_H
