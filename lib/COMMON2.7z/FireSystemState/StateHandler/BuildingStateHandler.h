/******************************************************************************//**
*
* @file   BuildingStateHandler.h
* @brief  State handler for Building
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_BUILDING_H
#define FIRESYSTEM_STATE_HANDLER_BUILDING_H

#include "DOL/Entities/Building.h"

#include "Component/Component.h"

#include "Mol/Events/Event.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/AccessEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/AlarmSignalEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/InputChangeEvent.h"
#include "Mol/Events/MaintenanceEvent.h"
#include "Mol/Events/Reset.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/WarningEvent.h"

#include "Mol/Commands/Command.h"
#include "Mol/Commands/Activate.h"
#include "Mol/Commands/Deactivate.h"
#include "Mol/Commands/ApplyConfiguration.h"
#include "Mol/Commands/CancelBuzzer.h"
#include "Mol/Commands/DelayOff.h"
#include "Mol/Commands/DelayOn.h"
#include "Mol/Commands/Disable.h"
#include "Mol/Commands/Enable.h"
#include "Mol/Commands/ExtendDelays.h"
#include "Mol/Commands/MeasureReferenceResistance.h"
#include "Mol/Commands/ModuleReboot.h"
#include "Mol/Commands/ModuleShutdown.h"
#include "Mol/Commands/OverrideDelays.h"
#include "Mol/Commands/Reset.h"
#include "Mol/Commands/ClearCounter.h"
#include "Mol/Commands/Resound.h"
#include "Mol/Commands/ServiceMode.h"
#include "Mol/Commands/Silence.h"
#include "Mol/Commands/EarthFaultMonitoring.h"
#include "Mol/Commands/SoftwareCenterCommands.h"
#include "Mol/Commands/SetAlarmSignal.h"
#include "Mol/Commands/SetDayNightMode.h"
#include "Mol/Commands/BatteryOperation.h"
#include "Mol/Commands/TestZoneStart.h"
#include "Mol/Commands/TestZoneStop.h"
#include "Mol/Commands/StartIndicatorTest.h"
#include "Mol/Commands/StopIndicatorTest.h"
#include "Mol/Commands/SetDebugLevel.h"
#include "Mol/Commands/FunctionDisable.h"
#include "Mol/Commands/FunctionEnable.h"
#include "Mol/Commands/EvacuationOn.h"
#include "Mol/Commands/EvacuationOff.h"
#include "Mol/Commands/FareTest.h"



#include "StateHandler/ManagedAreaStateHandler.h"
#include "DomainConfiguration/DomainConfiguration.h"

#include "Utility.h"

#ifdef UT_TARGET
#define private protected
#endif

namespace fireSystemState
{

/**
* BuildingStateHandler is a Component. It handles Dol Building status and children status
* It receive all Mol API and forwatd to children
*/

class BuildingStateHandler: public Dol::Entities::Building,  public Platform::Component, public DomainConfiguration
{
public:
    /**
    * Setup Dol Building
    */
    explicit BuildingStateHandler(const Dol::DomainObjectID id):
    Building(id)
    {

    }

    ~BuildingStateHandler() override = default;

    /**
    * Collect ManagedArea configuration
    * Add managedArea StateHandler to building
    */
    void Prepare() override
    {
        Platform::Component::Prepare();

        ManagedAreaConfig(m_managedAreaConfig);
        DEBUGPRINT(DEBUG_INFO,"Loaded Managed Area Configuration:[{0}]",time(nullptr));

        for(auto managedAreaConfig : m_managedAreaConfig)
        {
            auto managedAreaStateHandler = std::make_shared<ManagedAreaStateHandler>(managedAreaConfig);
            AddManagedArea(managedAreaStateHandler);
            managedAreaStateHandler->Prepare();
            managedAreaStateHandler->SetupSignal();
        }
        DEBUGPRINT(DEBUG_INFO,"Loaded Managed Area objects:[{0}]",time(nullptr));

    }

private:
    std::vector<XmlElementConfig> m_managedAreaConfig;
};

}

#endif // FIRESYSTEM_STATE_HANDLER_BUILDING_H
