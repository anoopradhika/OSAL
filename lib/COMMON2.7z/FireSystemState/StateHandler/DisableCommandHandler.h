/******************************************************************************//**
*
* @file   DisableCommandHandler.h
* @brief
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_DISABLE_COMMAND_H
#define FIRESYSTEM_STATE_HANDLER_DISABLE_COMMAND_H


#include "CommonDef.h"
#include "Mol/Commands/Disable.h"
#include "Mol/Commands/Enable.h"
#include "Helper/FSHelper.h"

namespace fireSystemState
{

/**
* @brief DisableCommandHandler is receives disable command.
* if entity is not disabled it forward the disable command, else it reject the command
*/
template<typename HANDLER>
class DisableCommandHandler
{
public:
    explicit DisableCommandHandler(HANDLER& handler ):
     m_handler(handler)
    {
    }

    ~DisableCommandHandler() = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal()
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        m_handler.PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::DISABLE,reference,this,&DisableCommandHandler<HANDLER>::ReceiveDisableCommand);
        m_handler.PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::ENABLE,reference,this,&DisableCommandHandler<HANDLER>::ReceiveEnableCommand);
    }
	
    uint16_t m_disablementCount=0;

protected:
    void ReceiveDisableCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        auto disable = ValidateCommand<Mol::Command::Disable>(command
                                                        , Mol::Command::COMMAND_CATEGORY::DISABLE
                                                        ,reference
                                                        );
        if(! disable)
        {
            return;
        }
		
		if(address != PROC_ADDRESS::FIRE_DOMAIN_APP)
		{
		    m_disablementCount++;
		}
		
        if((m_handler.IsDisabled() && (Utility::GetEventResetMode()!= EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }

        m_handler.SendCommand(disable,PROC_ADDRESS::BROADCAST);
    }

    void ReceiveEnableCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        auto enable = ValidateCommand<Mol::Command::Enable>(command
                                                        , Mol::Command::COMMAND_CATEGORY::ENABLE
                                                        , reference
                                                        );
        if(! enable)
        {
            return;
        }

        if(m_disablementCount>0 && address != PROC_ADDRESS::FIRE_DOMAIN_APP)
		{
            m_disablementCount--;
		}

		if((!m_handler.IsDisabled() && (Utility::GetEventResetMode()!= EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
        m_handler.SendCommand(enable,PROC_ADDRESS::BROADCAST);
    }
private:
    HANDLER& m_handler;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_DISABLE_COMMAND_H
