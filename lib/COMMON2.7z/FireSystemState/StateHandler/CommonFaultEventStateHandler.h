/******************************************************************************//**
*
* @file   CommonFaultEventStateHandler.h
* @brief  State handler for FPO
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_COMMON_FAULT_EVENT_H
#define FIRESYSTEM_STATE_HANDLER_COMMON_FAULT_EVENT_H

#include <queue>

#include "boost/sml.hpp"
#include "StateMachine/FaultEventStateMachine.h"
#include "StateHandler/StateHandler.h"

#include "Mol/Events/FaultEvent.h"
#include "DOL/Entities/Zone/Zone.h"
namespace fireSystemState
{

/**
* @brief CommonFaultEventStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
template<typename HANDLER>
class CommonFaultEventStateHandler
{
public:
    /**
     * @brief specifies the different service types
     */
    enum class ERROR_CODE : uint8_t
    {
        NULL_RESET_CMD,
        NULL_FAULT_EVENT,
        IGNOR_INTERNAL_EVENT,
        NO_ERROR,
        END_OF_LIST
    };

    explicit CommonFaultEventStateHandler(HANDLER& handler ):
     m_handler(handler)
    ,m_faultEventStateMachine(*this)
    ,m_faultEventupdaterStateMachine{m_faultEventStateMachine}
    {
        faultHandledByReset = m_handler.isFaultHandledByReset();
        //we need to ignore panel lost logic for a fire panel !
        if(Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL != m_handler.GetObjectType())
        {
            //if this entity belonging to the current panel, then we should not subscribe to panel failure fault event later.
            m_isFromThisPanel = PointFromThisPanel(m_handler.GetID(), m_myPanelObjectRef);
            m_myObjectRef = Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()};
            if(! m_isFromThisPanel)
            {
                m_myCPUModuleObjectRef = Mol::DataType::ObjectReference{m_handler.GetCPUModuleIDFromPanelID(m_myPanelObjectRef.GetObjectId()), Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
            }
        }
    }

    ~CommonFaultEventStateHandler() = default;

    bool PointFromThisPanel(uint64_t pointID, Mol::DataType::ObjectReference& pointPanelRef)
    {
        auto nodeID = Mol::DeviceUniqueID(pointID).GetNodeID();
        auto domainID = Mol::DeviceUniqueID(pointID).GetDomainID();
        pointPanelRef =  Mol::DataType::PointReferenceHelper::Create(domainID, nodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        auto m_thisPanelID = Utility::ReadPanelID();
        auto thisPanelNodeID = Mol::DeviceUniqueID(m_thisPanelID).GetNodeID();
        auto thisPanelDomainID = Mol::DeviceUniqueID(m_thisPanelID).GetDomainID();
        auto m_thisPanelObjRef =  Mol::DataType::PointReferenceHelper::Create(thisPanelDomainID, thisPanelNodeID,0,0,Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL);
        return  (pointPanelRef == m_thisPanelObjRef);
    }

    void SetupSignalCommon()
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        //panel failover is compatible only for fusion panel, just like fault cleared event
        //@note later we may have a dedicated function to check which panel (fusion/ID3K) is
        if(!m_handler.isFaultHandledByReset())
        {
            m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,reference,this,&CommonFaultEventStateHandler<HANDLER>::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
            //Subscribe for my originating panel's fault no_reply or COMMUNICATIONS_STOPPED code, to clear my faulty state only in HMI/ActiveEventlist
            //only compatible with Fusion panel, not ID3K
            if(! m_isFromThisPanel)//register only for entities connected to other panels in the network (ignore for this one)
            {
                m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myPanelObjectRef,this,&CommonFaultEventStateHandler<HANDLER>::ReceiveFaultEvent< Mol::Event::FaultEvent>);
                //@TODO remove later when we ensure they don't change their mind agin
                //m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myPanelObjectRef,this,&CommonFaultEventStateHandler<HANDLER>::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
                if(m_myCPUModuleObjectRef.GetObjectId())
                {
                    m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,m_myCPUModuleObjectRef,this,&CommonFaultEventStateHandler<HANDLER>::ReceiveFaultEvent< Mol::Event::FaultEvent>);
                    //@TODO remove later when we ensure they don't change their mind agin
                    //BASE_HANDLER::PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED,m_myCPUModuleObjectRef,this,&BASE_HANDLER::ReceiveFaultEvent< Mol::Event::FaultClearedEvent>);
                }
            }
        }
        //Subscribe for entity fault/fault cleared events
        m_handler.PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::TROUBLE,reference,this,&CommonFaultEventStateHandler<HANDLER>::ReceiveFaultEvent< Mol::Event::FaultEvent>);
    }

   void SetFault(bool faultActive)
   {
       m_handler.SetFault(faultActive);
   }
   bool IsFault()
   {
       return m_handler.IsFault();
   }
    void SendFaultEvent(std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
    {
        m_handler.SendEvent(faultEvent,PROC_ADDRESS::BROADCAST,true);
    }

    void SendFaultClearedEvent(std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
    {
        //@todo may need to added parent
        m_handler.SendEvent(faultClearedEvent,PROC_ADDRESS::BROADCAST,true);
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_myPanelObjectRef;
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()};
    }

    //@notes ByCommand is the one we had to match the ID3K behavior.
    //or in case of panel failure to clear all faults for that panel
    void ReceiveResetCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        //SetFault(false);
        auto reset = ValidateCommand<Mol::Command::Reset>(command
                                                        , Mol::Command::COMMAND_CATEGORY::RESET
                                                        );
        if(! reset)
        {
            currentErrorCode = ERROR_CODE::NULL_RESET_CMD;
            return;
        }
        //@notes ByCommand is the one we had to match the ID3K behavior
		auto resetCommand = std::static_pointer_cast<Mol::Command::Reset>(command);
        Mol::Command::RESET_TYPE_CODE code = resetCommand->GetCommandCode();
		
		if((code != Mol::Command::RESET_TYPE_CODE::GENERAL) && (code != Mol::Command::RESET_TYPE_CODE::TROUBLE))
		{
			return;
		}
        m_faultEventupdaterStateMachine.process_event(reset);
        m_faultEventupdaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "CommonFaultEventStateHandler for [{0:#x}]is now in state[{1}]", m_handler.GetID(), state.c_str());
                });
        currentErrorCode = ERROR_CODE::NO_ERROR;
    }

    bool faultHandledByReset = false;
    ERROR_CODE currentErrorCode = ERROR_CODE::END_OF_LIST;
//protected:

    /** Receive a Fault/FaultCleared event and invoke state machine
    * @param event      Fault/FaultClearedEvent Event
    * @param id         senderID - Unique id of the sender
    * @param address    Originator of event
    */
    template<typename FaultEventType>
    void ReceiveFaultEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        Mol::Event::EVENT_CATEGORY category = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
        if(std::is_same<FaultEventType, Mol::Event::FaultClearedEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"CommonFaultEventStateHandler: FaultClearedEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED;
        }
        else if(std::is_same<FaultEventType, Mol::Event::FaultEvent>::value)
        {
            DEBUGPRINT(DEBUG_INFO,"CommonFaultEventStateHandler: FaultEvent");
            category = Mol::Event::EVENT_CATEGORY::TROUBLE;
        }
        else
        {
            //Do nothing
        }

        auto faultEvent = ValidateEvent<FaultEventType>(event, category);
        if(! faultEvent)
        {
            return;
        }
        if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
        {
            return;
        }
        if(IsItMine(faultEvent, m_myObjectRef))//Ignore faults event from my panel
        {
            for (auto &parentReferences : m_parentReferences)
            {
                faultEvent->AddParent(parentReferences);
            }
        }
        m_faultEventupdaterStateMachine.process_event(faultEvent);
        m_faultEventupdaterStateMachine.visit_current_states([this](auto state){
            DEBUGPRINT(DEBUG_INFO, "BaseFireDetectionPointStateHandler:ReceiveFaultEvent for [{0:#x}]is now in state[{1}]", m_handler.GetID(), state.c_str());
                });
    }
    template<typename FaultEventType>
    void ReceiveFaultEventUT(std::shared_ptr<FaultEventType> event, uint64_t id, PROC_ADDRESS address)
    {
        auto base = std::static_pointer_cast<Mol::Message<Mol::Event::EVENT_CATEGORY>>(event);
        ReceiveFaultEvent<FaultEventType>(base, id, address);
    }
    HANDLER& m_handler;

    FaultEventStateMachine<CommonFaultEventStateHandler> m_faultEventStateMachine;
    Mol::DataType::ObjectReference m_myPanelObjectRef;
    Mol::DataType::ObjectReference m_myCPUModuleObjectRef;
    Mol::DataType::ObjectReference m_myObjectRef;
    boost::sml::sm<FaultEventStateMachine<CommonFaultEventStateHandler>, boost::sml::process_queue<std::queue>> m_faultEventupdaterStateMachine;
    std::set<Mol::DataType::ObjectReference> m_parentReferences;
    bool m_isFromThisPanel = false;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_COMMON_FAULT_EVENT_H
