/******************************************************************************//**
*
* @file   FaultEventStateHandler.h
* @brief  State handler for FPO
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_FAULT_EVENT_H
#define FIRESYSTEM_STATE_HANDLER_FAULT_EVENT_H

#include "StateHandler/CommonFaultEventStateHandler.h"

namespace fireSystemState
{

/**
* @brief FaultEventStateHandler is created from configuration file. It used for receiving event and command.
* Based on events and command it control its state machine.
*/
template<typename HANDLER>
class FaultEventStateHandler : public CommonFaultEventStateHandler<HANDLER>
{
public:
    explicit FaultEventStateHandler(HANDLER& handler ):
        CommonFaultEventStateHandler<HANDLER>(handler)
    {
    }

    ~FaultEventStateHandler() = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal()
    {
		std::cout<<"FaultEventStateHandler SetupSignal"<<std::endl;
        auto parentZones = CommonFaultEventStateHandler<HANDLER>::m_handler.GetParentZones();
        uint64_t managedAreaId = 0;
        for (auto &parent : parentZones)
        {
            if (managedAreaId != parent->GetManagedAreaId())
            {
                managedAreaId = parent->GetManagedAreaId();
                auto managedAreaReference = Mol::DataType::ObjectReference { managedAreaId, Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA };
                //need managed area info to add it to faults events later
                CommonFaultEventStateHandler<HANDLER>::m_parentReferences.emplace(managedAreaReference);
                //@notes ByCommand is the one we had to match the ID3K behavior.
                //or in case of panel failure to clear all faults for that panel
                CommonFaultEventStateHandler<HANDLER>::m_handler.PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::RESET, managedAreaReference, this, &CommonFaultEventStateHandler<HANDLER>::ReceiveResetCommand);
            }
        }

        CommonFaultEventStateHandler<HANDLER>::SetupSignalCommon();
    }
	

};

}

#endif //FIRESYSTEM_STATE_HANDLER_FAULT_EVENT_H
