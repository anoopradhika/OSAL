/******************************************************************************//**
*
* @file   ZoneTestCommandHandler.h
* @brief
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_ZONE_TEST_COMMAND_H
#define FIRESYSTEM_STATE_HANDLER_ZONE_TEST_COMMAND_H

#include "CommonDef.h"
#include "Helper/FSHelper.h"
#include "Mol/Commands/TestZoneStop.h"
#include "Mol/Commands/TestZoneStart.h"

namespace fireSystemState
{

/**
* @brief ZoneTestCommandHandler is receives disable command.
* if entity is not disabled it forward the disable command, else it reject the command
*/
template<typename HANDLER>
class ZoneTestCommandHandler
{
public:
    explicit ZoneTestCommandHandler(HANDLER& handler ):
     m_handler(handler)
    {
    }

    ~ZoneTestCommandHandler() = default;

    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal()
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()};
        m_handler.PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::TEST_ZONE_START,reference,this,&ZoneTestCommandHandler<HANDLER>::ReceiveZoneTestStartCommand);
        m_handler.PrepareSignalExtended(Mol::Command::COMMAND_CATEGORY::TEST_ZONE_STOP,reference,this,&ZoneTestCommandHandler<HANDLER>::ReceiveZoneTestStopCommand);
    }

protected:

    void ReceiveZoneTestStartCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        auto zoneTest = ValidateCommand<Mol::Command::TestZoneStart>(command, Mol::Command::COMMAND_CATEGORY::TEST_ZONE_START,reference);
		
		if(nullptr == zoneTest)
		{
			return;
		}
		
		if(Utility::GetEventResetMode()== EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)
		{
			if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
			{
				return;
			}
		}
        else if((m_handler.IsDisabled()) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
		else
		{
			//do nothing
		}
        m_handler.SendCommand(zoneTest, PROC_ADDRESS::BROADCAST);
    }

    void ReceiveZoneTestStopCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, uint64_t id, PROC_ADDRESS address)
    {
        auto reference = Mol::DataType::ObjectReference{m_handler.GetID(),m_handler.GetObjectType()};
        auto zoneTest = ValidateCommand<Mol::Command::TestZoneStop>(command, Mol::Command::COMMAND_CATEGORY::TEST_ZONE_STOP,reference);
		
		if(nullptr == zoneTest)
		{
			return;
		}
		
		if(Utility::GetEventResetMode()== EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)
		{
			if(address == PROC_ADDRESS::FIRE_DOMAIN_APP)
			{
				return;
			}
		}
        else if((m_handler.IsDisabled()) || (address == PROC_ADDRESS::FIRE_DOMAIN_APP))
        {
            return;
        }
		else
		{
			//do nothing
		}
		
        m_handler.SendCommand(zoneTest, PROC_ADDRESS::BROADCAST);
    }

    HANDLER& m_handler;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_ZONE_TEST_COMMAND_H
