/******************************************************************************//**
*
* @file   ConfirmationInputStateHandler.h
* @brief  State handler for Confirmation Input
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_CONFIRMATION_INPUT_H
#define FIRESYSTEM_STATE_HANDLER_CONFIRMATION_INPUT_H

#include "DOL/Entities/Point/ConfirmationInput.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "EventDispatcher/EventDispatcher.h"
#include "Signal/Signal.h"

#include "Mol/Events/EventCategory.h"

#include "boost/sml.hpp"
#include "StateMachine/ConfirmationInputStateMachine.h"
#include "StateHandler/StateHandler.h"
#include "StateHandler/FaultEventStateHandler.h"
#include "StateHandler/DisableCommandHandler.h"
#include <queue>

namespace fireSystemState
{

/**
* @brief FieldDevice is created from configuration file. It used for receiveing event and command.
* Based on events and command it control its state meachine.
*/
class ConfirmationInputStateHandler: public Dol::Entities::ConfirmationInput, public StateHandler<ConfirmationInputStateHandler>
{
public:
    /**
    * Prepare the StateMeachain and base objects
    * @param[in] id: DomainObjectId
    * @param[in] element:configuration about a child or children
    */
    ConfirmationInputStateHandler(const Dol::DomainObjectID id,XmlElementConfig element):
     ConfirmationInput(id),
     m_pointStateMachine(*this),
     m_updaterStateMachine{m_pointStateMachine},
     m_faultEventHandler(*this),
     m_disableCommandHandler(*this)
    {
    }
//  LCOV_EXCL_START
    ~ConfirmationInputStateHandler() = default;
//  LCOV_EXCL_STOP
    /**
    * Prepare the signal for receive commands and event
    */
    void SetupSignal() override
    {
        DEBUGPRINT(DEBUG_INFO, "ConfirmationInputStateHandler: ID[{0}], Type[{1}]", GetID(), static_cast<int>(GetObjectType()));
        auto reference = Mol::DataType::ObjectReference{GetID(),GetObjectType()};
        PrepareSignalExtended(Mol::Event::EVENT_CATEGORY::DISABLEMENT,reference,this,&ConfirmationInputStateHandler::ReceiveDisablementEvent);
        m_faultEventHandler.SetupSignal();
        m_disableCommandHandler.SetupSignal();
    }
protected:
    /**
    * Receive a disablementEvent and invaoke state mechine
    * @param event : DisablementEvent
    */
    void ReceiveDisablementEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, uint64_t id, PROC_ADDRESS address)
    {
        auto disablementEvent = ValidateEvent<Mol::Event::DisablementEvent>(event
                                                                            , Mol::Event::EVENT_CATEGORY::DISABLEMENT
                                                                            );
        if(nullptr == disablementEvent)
        {
            return;
        }
        m_updaterStateMachine.process_event(disablementEvent);
    }

private:
    ConfirmationInputStateMachine<ConfirmationInputStateHandler> m_pointStateMachine;

    boost::sml::sm<ConfirmationInputStateMachine<ConfirmationInputStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;
    FaultEventStateHandler<ConfirmationInputStateHandler> m_faultEventHandler;
    DisableCommandHandler<ConfirmationInputStateHandler> m_disableCommandHandler;

};

}

#endif //FIRESYSTEM_STATE_HANDLER_CONFIRMATION_INPUT_H
