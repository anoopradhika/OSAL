/******************************************************************************//**
*
* @file   StateHandler.h
* @brief  based State handler
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_HANDLER_H
#define FIRESYSTEM_STATE_HANDLER_H

#include <memory>

#include "Mol/DataType/ObjectReference.h"

#include "MessageCommunicator/MessageCommunicator.h"
#include "DomainConfiguration/DomainConfiguration.h"
#include "Helper/FSHelper.h"


namespace fireSystemState
{

template<typename STATE_ENTITIE>
class StateHandler: public MessageCommunicator, public DomainConfiguration, public std::enable_shared_from_this<STATE_ENTITIE>
{
public:
    using EVENT_CATEGORY = Mol::Event::EVENT_CATEGORY;
    using COMMAND_CATEGORY = Mol::Command::COMMAND_CATEGORY;
    StateHandler() = default;

    virtual ~StateHandler() = default;

    /**
    * Prepare the signal for receive commands and event
    */
    virtual void Prepare()
    {
        //Do Nothing
    }

    virtual void SetupSignal() = 0;
    template<typename ELEMENT, typename FUNC>
    void PrepareSignalExtended(EVENT_CATEGORY eventType, Mol::DataType::ObjectReference objectReference, ELEMENT* element,FUNC method)
    {
        auto key = Signal::EventSignalKey{objectReference
        ,eventType};
        const auto&  eventsignalext = m_signal.EventSignalExtended.find(key);

        if(eventsignalext == m_signal.EventSignalExtended.end())
        {
            auto addedsignal = m_signal.EventSignalExtended.emplace(key
            ,Signal::EventSignalExtendedType{});
            if(addedsignal.second)
            {
                addedsignal.first->second.Connect(element,method);
            }
            return;
        }

        eventsignalext->second.Connect(element,method);
    }

    template<typename ELEMENT, typename FUNC>
    void PrepareSignalExtended(COMMAND_CATEGORY commandType, Mol::DataType::ObjectReference objectReference, ELEMENT* element,FUNC method)
    {
        auto key = Signal::CommandSignalKey{objectReference
        ,commandType};
        const auto& cmdsignalext = m_signal.CommandSignalExtended.find(key);

        if(cmdsignalext == m_signal.CommandSignalExtended.end())
        {
            auto addedsignal = m_signal.CommandSignalExtended.emplace(key
            ,Signal::CommandSignalExtendedType{});
            if(addedsignal.second)
            {
                addedsignal.first->second.Connect(element,method);
            }
            return;
        }
        cmdsignalext->second.Connect(element,method);
    }

    const std::string& GetCurrentState() const
    {
        return m_currentState;
    }

    void SetCurrentState(const std::string& currentState)
    {
        m_currentState = currentState;
    }

    const STATE_ERROR GetLastError() const
    {
        return m_lastError;
    }

    void SetLastError(const STATE_ERROR currentState)
    {
        m_lastError = currentState;
    }

private:
    std::string m_currentState;
    STATE_ERROR m_lastError;
};

}

#endif //FIRESYSTEM_STATE_HANDLER_MANAGEDAREA_H
