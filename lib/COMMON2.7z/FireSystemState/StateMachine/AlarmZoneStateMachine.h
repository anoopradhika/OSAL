/******************************************************************************//**
*
* @file   AlarmZoneStateMachine.h
* @brief  State handler for Alarm zone.
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_ALARM_ZONE_H
#define FIRESYSTEM_STATE_MACHINE_ALARM_ZONE_H

#include "DOL/Entities/Zone/AlarmZone.h"
#include "boost/sml.hpp"
#define EVACUATION_SIGNAL 255 //255 is evacuation signal

namespace fireSystemState
{

/**
*
@startuml

title Simple Composite State Model
title SetAlarmSignal/Disable/Enable/Reset/Silence/Resound/Evacuate of Alarm Zone
[*] --> ZoneAvailable
state ZoneAvailable
note left of ZoneAvailable: Deactivate and Activate commands are \n Not applicable in Alarm zone
state "Alarm  Zone is Available for\n operations" as ZoneAvailable {
  state Quiescent
  state Annunciation
  state Silence
  state Disabled
  [*] -> Quiescent
  *Quiescent --> Annunciation :SetAlarmSignal(id) \n Action: Activate Fire\nAlarm Device Point\nwith alarm signal id\n store the signal ID
  Annunciation --> Silence : Silence/Action:\n Do action based\nof alarm profile\nsilence id\n Set the silence flag
  Silence --> Annunciation: Resound
  Silence --> Annunciation: :SetAlarmSignal(id) \n Action: Activate Fire\nAlarm Device Point\nwith alarm signal id\n store the signal ID

  Quiescent --> Disabled : Disable/ \n Action: Generate DisablementEvent(APPLIED, Zone id) \nAction: clear Signal ID
  Annunciation --> Disabled : Disable/ \nAction: Generate DisablementEvent(APPLIED, Zone id) \n Action: Deactivate Fire \nAlarm Device point\n Action: clear Signal ID
  Silence --> Disabled: Disable/ \nAction: Generate DisablementEvent(APPLIED, Zone id) \n Action: Deactivate Fire Alarm\nDevice point \nAction: clear Signal ID
  Disabled --> Quiescent: Enable / \nAction: EnableEvent(APPLIED, Zone id)
  1*Annunciation --> Quiescent: SetAlarmSignal(id) [signal ID == 0] \n Action: Deactivate Fire\nAlarm Device Point\nwith alarm signal id\n store the signal ID
  *Silence --> Quiescent: SetAlarmSignal(id)[signal ID == 0] \n Action: Deactivate Fire\nAlarm Device Point\nwith alarm signal id\n store the signal ID

  Quiescent --> Quiescent: Fault: Set fault\n attribute
  Annunciation -left-> Annunciation: Fault: Set\nfault attribute
  Annunciation -left-> Annunciation: SetAlarmSignal(id)\n Action: Activate Fire\nAlarm Device Point\nwith alarm signal id\nstore the signal ID
  Silence --> Silence: Fault: Set fault\nattribute
  Disabled --> Disabled: Fault: Set fault\nattribute


  Quiescent --> Annunciation :Evacuation \n Action: Activate Fire\nAlarm Device Point\n with proper signal id\nstore the profile ID
  Annunciation --> Annunciation :Evacuation \n Action: Activate Fire\nAlarm Device Point\n with proper signal id\nstore the profile ID
  *Silence --> Annunciation :Evacuation \n Action: Activate Fire\nAlarm Device Point\n with proper signal id\nstore the profile ID\n clear the silence flag
  Disabled --> Disabled : No action on\nEvacuation or\nSetAlarmSignal or \nSilence or \nResound \nReset
  Disabled --> Disabled: [if owner of the zone]/ Action: once all point in the zone is disabled  DisablementEvent(COMPLETED, Zone id)
}

@enduml

*/
template<typename Handler>
class AlarmZoneStateMachine
{
public:
    AlarmZoneStateMachine() = delete;

    AlarmZoneStateMachine(AlarmZoneStateMachine&& other) = delete;

    explicit AlarmZoneStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~AlarmZoneStateMachine() = default;
    AlarmZoneStateMachine(const AlarmZoneStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> disablementEvent)
        {
            Disable(disablementEvent);
			SendDeactivateEventToHMI();
        };
		
		auto DisabledStateUpdateforZone = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            SendZoneEnablementEvent(disablementEvent, Dol::Entities::Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED);
            DisableZone(disablementEvent);
        };
		
		auto PartialZoneDisabledEventUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            SendZoneEnablementEvent(disablementEvent, Dol::Entities::Zone::DISABLEMENT_STATE::DISABLED);
            PartialDisableZoneSendEvent(disablementEvent);
        };
		
		auto EnabledStateUpdateforZone = [this] (std::shared_ptr<Mol::Event::DisablementEvent> enablementEvent)
        {
            EnableZone(enablementEvent);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionEnable> disablementEvent)
        {
            Enable(disablementEvent);
        };

        auto NoResoundEnabledStateUpdate = [this] ()
        {
            NoResoundEnable();
        };

        const auto SetAlarmZoneSignalEventAction = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            SetAlarmZoneSignalEvent(alarmSignal);
        };

        const auto SwitchToOperationAction = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            SwitchToOperation(userOperation);
			SendEventtoHMI(userOperation);
        };

        const auto NeedActivate = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            if(IsZoneNeedActivate(alarmSignal))
            {
                return true;
            }
            else if(AreChildrenActivated(alarmSignal))
            {
                return true;
            }
            return false;
        };

        const auto NeedZoneDeactivation = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            return IsZoneNeedDeactivate(alarmSignal);
        };

        const auto NeedDeactivate = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            return CheckForDeactivation(alarmSignal);
        };

        const auto NeedSilence = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return AlarmeZoneNeedSilence(userOperation);
        };
		
		const auto NeedEvacuationOff = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return AlarmeZoneNeedEvacuation(userOperation);
        };
		
		const auto NeedEvacuationOff_Reset = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return AlarmeZoneNeedEvacuation_Reset(userOperation);
        };
		
		const auto NeedEvacuationOff_Silence = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return AlarmeZoneNeedEvacuation_Silence(userOperation);
        };
		
		
        const auto NeedResound = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return AlarmeZoneNeedResound(userOperation);
        };

        const auto IsEvacuationSignal = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            return EvacuationSignal(alarmSignal);
        };

        const auto IsDisablementEvent = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementevent)
        {
            return IsDisablementEventCall(disablementevent);
        };

        const auto IsEnablementEvent = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementevent)
        {
            return IsEnablementEventCall(disablementevent);
        };
	
		auto ForwardEvacuationoffSignal = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
             ForwardEvacuationoffSignalAction(userOperation);
        };
		
		auto EvacuationResound = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
		{
			EvacuationResoundAction(userOperation);
		};
		
		auto EvacuationReset = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
		{
			EvacuationResetAction(userOperation);
		};
		

        /**
          Check if option "ResoundOption" from config has value "NoResound"
          @retval true xml config has "ResoundOption" value "NoResound"
          @retval false xml config has NOT "ResoundOption" value "NoResound"
          */
        const auto OptNoResound = [this] ()
        {
            return GetOptNoResound();
        };
		
        const auto IsPartialDisablementEvent = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementevent)
        {
            return IsPartialDisablementEventCall(disablementevent);
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s           + event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                                   / DisabledStateUpdate = "disabled"_s
		,"quiescent"_s           + event<std::shared_ptr<Mol::Event::DisablementEvent>   > [IsDisablementEvent]                              / DisabledStateUpdateforZone = "disabledzone"_s
        ,"quiescent"_s           + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedZoneDeactivation]                            / SetAlarmZoneSignalEventAction = "quiescent"_s
        ,"disabled"_s            + event<std::shared_ptr<Mol::Event::FunctionEnable> >                                                       / EnabledStateUpdate = "quiescent"_s
        ,"quiescent"_s           + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [!IsEvacuationSignal && NeedActivate && !OptNoResound ] / SetAlarmZoneSignalEventAction = "annunciation"_s
        ,"quiescent"_s           + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [!IsEvacuationSignal && NeedActivate &&  OptNoResound ] / SetAlarmZoneSignalEventAction = "no_resound"_s

        //id3k Partial Disablement State Handling
        ,"disabledzone"_s        + event<std::shared_ptr<Mol::Event::DisablementEvent>   > [IsPartialDisablementEvent]                       / PartialZoneDisabledEventUpdate = "Partialdisabledzone"_s
        ,"quiescent"_s           + event<std::shared_ptr<Mol::Event::DisablementEvent>   > [IsPartialDisablementEvent]                       / PartialZoneDisabledEventUpdate = "Partialdisabledzone"_s
		,"Partialdisabledzone"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>   > [IsDisablementEvent]                              / DisabledStateUpdateforZone = "disabledzone"_s
		,"Partialdisabledzone"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> >   [IsEnablementEvent]                               / EnabledStateUpdateforZone = "quiescent"_s
		                                                     
		
		
        //Annunciation --> Annunciation :Evacuation \n Action: Activate Fire\nAlarm Device Point\n with proper signal id\nstore the profile ID
        ,"annunciation"_s        + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                 / SetAlarmZoneSignalEventAction = "quiescent"_s
        //Annunciation -left-> Annunciation: SetAlarmSignal(id)\n Action: Activate Fire\nAlarm Device Point\nwith alarm signal id\nstore the signal ID
        ,"annunciation"_s        + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [!IsEvacuationSignal && NeedActivate]                   / SetAlarmZoneSignalEventAction = "annunciation"_s
        ,"annunciation"_s        + event<std::shared_ptr<Mol::Event::UserOperationEvent> > [NeedSilence]                    / SwitchToOperationAction = "silence"_s
        ,"annunciation"_s        + event<std::shared_ptr<Mol::Event::FunctionDisable> >                                     / DisabledStateUpdate = "disabled"_s
		,"annunciation"_s        + event<std::shared_ptr<Mol::Event::DisablementEvent> >   [IsDisablementEvent]             / DisabledStateUpdateforZone = "disabledzone"_s

        ,"no_resound"_s          + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                 / SetAlarmZoneSignalEventAction = "quiescent"_s
        ,"no_resound"_s          + event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                  / DisabledStateUpdate = "disabled"_s
        ,"no_resound_disabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable>     >                                  / NoResoundEnabledStateUpdate = "no_resound"_s
		,"no_resound"_s          + event<std::shared_ptr<Mol::Event::DisablementEvent> >   [IsDisablementEvent]             / DisabledStateUpdateforZone = "disabledzone"_s

        ,"silence"_s             + event<std::shared_ptr<Mol::Event::UserOperationEvent> > [NeedResound]                    / SwitchToOperationAction = "annunciation"_s
        ,"silence"_s             + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedActivate]                   / SetAlarmZoneSignalEventAction = "annunciation"_s
        ,"silence"_s             + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                 / SetAlarmZoneSignalEventAction = "quiescent"_s
        ,"silence"_s             + event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                  / DisabledStateUpdate = "disabled"_s
	    ,"silence"_s             + event<std::shared_ptr<Mol::Event::DisablementEvent> >   [IsDisablementEvent]             / DisabledStateUpdateforZone = "disabledzone"_s
		,"disabledzone"_s        + event<std::shared_ptr<Mol::Event::DisablementEvent> >   [IsEnablementEvent]              / EnabledStateUpdateforZone = "quiescent"_s


        //Evacuation functionality
        ,"quiescent"_s              + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>    [IsEvacuationSignal]                          / SetAlarmZoneSignalEventAction = "evacuation"_s
        ,"disabled"_s               + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>    [IsEvacuationSignal]                          / SetAlarmZoneSignalEventAction = "disabled_evacuation"_s
        ,"disabled_evacuation"_s    + event<std::shared_ptr<Mol::Event::UserOperationEvent>>  [NeedEvacuationOff]                           / ForwardEvacuationoffSignal = "disabled"_s
        ,"evacuation"_s             + event<std::shared_ptr<Mol::Event::UserOperationEvent>>  [NeedEvacuationOff]                           / ForwardEvacuationoffSignal = "quiescent"_s
        ,"annunciation"_s           + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>    [IsEvacuationSignal]                          / SetAlarmZoneSignalEventAction = "alarm_evacuation"_s
        ,"alarm_evacuation"_s       + event<std::shared_ptr<Mol::Event::UserOperationEvent>>  [NeedEvacuationOff_Reset]                     / EvacuationReset = "quiescent"_s
	    ,"alarm_evacuation"_s       + event<std::shared_ptr<Mol::Event::UserOperationEvent>>  [NeedEvacuationOff_Silence]                   / ForwardEvacuationoffSignal = "alarm_evacuation_silence"_s
	    ,"alarm_evacuation_silence"_s + event<std::shared_ptr<Mol::Event::UserOperationEvent>> [NeedResound]                                / EvacuationResound   = "annunciation"_s
        ,"alarm_evacuation_silence"_s + event<std::shared_ptr<Mol::Event::FunctionDisable>>                                                 / DisabledStateUpdate   = "disabled"_s
        ,"alarm_evacuation_silence"_s + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>  [NeedZoneDeactivation]                        / SetAlarmZoneSignalEventAction = "quiescent"_s
        ,"no_resound"_s             + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>    [IsEvacuationSignal]                          / SetAlarmZoneSignalEventAction = "alarm_evacuation"_s
        ,"silence"_s                + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>    [IsEvacuationSignal]                          / SetAlarmZoneSignalEventAction = "evacuation"_s

		//Module will send Evacuation off and alarm_signal(0) both the events in case evacuation off..to address sequencing issue following code is added
		//We have to remove alarm, silence condition(if it exists before evacuation) in case module sends ALARM_SIGNAL(0) after evacuation
		//if zone is disabled, then it will go to disabled state
        ,"evacuation"_s             + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>  [NeedZoneDeactivation]                           / SetAlarmZoneSignalEventAction = "quiescent"_s
        ,"disabled_evacuation"_s    + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>  [NeedZoneDeactivation]                           / SetAlarmZoneSignalEventAction = "disabled"_s
        ,"alarm_evacuation"_s       + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>  [NeedZoneDeactivation]                           / SetAlarmZoneSignalEventAction = "quiescent"_s
        ,"silence_evacuation"_s     + event<std::shared_ptr<Mol::Event::AlarmSignalEvent>>  [NeedZoneDeactivation]                           / SetAlarmZoneSignalEventAction = "quiescent"_s
		
        );
    }

protected:
    bool CheckForDeactivation(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: CheckForDeactivation() {} ",m_handler.GetAlarmSignalId());
        if(IsZoneNeedDeactivate(alarmSignal))
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: CheckForDeactivation() 1 [{}]", alarmSignal->GetSource().GetObjectId());
            return m_handler.NoRemoteAlarmSignalPending();
        }
        return false;
    }
    bool IsZoneNeedActivate(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        if(alarmSignal->GetSource() == Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() })//is Zone
        {
            return (alarmSignal->GetEventCode() != 0);//need activate
        }
        //is child
        return false;
    }

    bool IsZoneNeedDeactivate(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        if(alarmSignal->GetSource() == Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() })//is Zone
        {
			if(alarmSignal->GetEventCode() == 0)
			{
              return true;
            }
        }

        return false;
    }


    bool AreChildrenActivated(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        return m_handler.AreChildrenActivated();
    }

    bool AreChildrenDeactivated(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        return !m_handler.AreChildrenActivated();
    }

    bool AlarmeZoneNeedSilence(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        return(userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE);
    }

    bool AlarmeZoneNeedEvacuation(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        if(userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_OFF)
		{
			m_handler.SetEvacuationState(false);
			return true;
		}
		return false;
    }

    bool AlarmeZoneNeedEvacuation_Reset(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
	{
		DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine:AlarmeZoneNeedEvacuation_Reset");
        if(userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_OFF)
		{
			m_handler.SetEvacuationState(false);
			
            if(MatchParameterString(userOperation,"RST"))
			{
				DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine:AlarmeZoneNeedEvacuation_Reset RST");
				return true;
			}
		}
		return false;
	}

	bool AlarmeZoneNeedEvacuation_Silence(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
	{
		DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine:AlarmeZoneNeedEvacuation_Silence called");
        if(userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::MANUAL_EVACUATION_OFF)
		{
			m_handler.SetEvacuationState(false);
			
            if(MatchParameterString(userOperation,"SIL"))
			{
				DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine:AlarmeZoneNeedEvacuation_Silence SIL");
				return true;
			}
		}
		return false;
	}
	
	template<class T>
	bool MatchParameterString(T MolMessage, std::string value)
	{
		bool retVal = false;
	    try{
		    auto parameters = MolMessage->GetParameters();

			if(parameters.empty())
			{
				return retVal;
			}

		    for (auto &iterator: parameters )
		    {
		        if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
		        {
                    std::string valstring = iterator.template GetValue<std::string>();
                    
					if(valstring == value)
					{
                        return true;
					}
			    }
		    }
		}
		catch(...)
		{
			DEBUGPRINT(DEBUG_ERROR,"AlarmZoneStateMachine::MatchParameterString Cant get the molparameter parameter");
		}
		
		return retVal;
	}
	

    bool AlarmeZoneNeedResound(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        return(userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND);
    }
    /**
    * If the event is not addressing to zone, then check if this valid for children.
    * if so validate zone children Disablement.
    * @param functionDisable    Mol DisablementEvent
    * @return                   true if all children are disabled information, else false
    */
    bool AreChildrenDisabled(std::shared_ptr<Mol::Event::FunctionDisable> functionDisable)
    {
        if (functionDisable->GetSource() == Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() })
        {
            //destinated to us so we just execute it
            return true;
        }
        return m_handler.AreChildrenDisabled();
    }

    void NoResoundEnable()
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: Enable()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::ENABLED);
    }

    void SetAlarmZoneSignalEvacuationEvent(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        std::cout<<"SetAlarmZoneSignalEvent  ID  ---------------------- "<<m_handler.GetID()<<std::endl;
        std::cout<<"SetAlarmZoneSignalEvent  Type  ---------------------- "<<(uint32_t)m_handler.GetObjectType()<< std::endl;
        m_handler.SetAlarmSignalId(m_handler.GetAlarmSignalId()); //Change Evacuation to alert signal, not to eventcode which is zero
        m_handler.SendEvent(alarmSignal,PROC_ADDRESS::BROADCAST,true);
        m_handler.SetLastAlarmSignalId(m_handler.GetAlarmSignalId());//Change Evacuation to alert signal, not to eventcode which is zero
		m_handler.lastAlarmSignalEvent = nullptr;
        m_handler.lastAlarmSignalEvent = alarmSignal;
    }

    /**
      check if NoResound option is set in configuration
      @retval true NoResound option is set
      @retval false NoResound option is NOT set
      */
    bool GetOptNoResound() const 
    {
        return ( m_handler.GetResoundOption() == "NoResound" );
    }

    bool EvacuationSignal(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        return (alarmSignal->GetEventCode() == EVACUATION_SIGNAL);
		m_handler.lastAlarmSignalEvent = nullptr;
        m_handler.lastAlarmSignalEvent = alarmSignal;
    }
	
	bool IsDisablementEventCall(std::shared_ptr<Mol::Event::DisablementEvent> disablementevent)
    {
        return (disablementevent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
    }

    bool IsPartialDisablementEventCall(std::shared_ptr<Mol::Event::DisablementEvent> disablementevent)
    {
        return (disablementevent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
    }

    bool IsEnablementEventCall(std::shared_ptr<Mol::Event::DisablementEvent> enablementevent)
    {
        return (enablementevent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
    }

    void ForwardEvacuationoffSignalAction(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        m_handler.SendEvent(userOperation,PROC_ADDRESS::BROADCAST,true);
		m_handler.SendEvacuationDeactiveEventtoHMI();
    }

    /**
    * Prepare the DisablementEvent event with code ENABLED and Broadcast it
    * @param functionEnable     disablement Event from sender
    */
    void Enable(std::shared_ptr<Mol::Event::FunctionEnable> functionEnable)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: Enable()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::ENABLED);
        m_handler.EnableAction();
    }

    /**
    * Prepare the DisablementEvent event with code DISABLED and Broadcast it
    * @param functionDisable    disablement Event from sender
    */
    void Disable(std::shared_ptr<Mol::Event::FunctionDisable> functionDisable)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: Disable()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::DISABLED);
        //auto event = std::make_shared<Mol::Event::AlarmSignalEvent>(0);
        //event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        //event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        //m_handler.SendEvent(event,PROC_ADDRESS::BROADCAST,true);
    }
	
	void SendDeactivateEventToHMI()
	{
		DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine::SendDeactivateEventToHMI()");

        if(nullptr != m_handler.lastAlarmSignalEvent && m_handler.GetAlarmSignalId() > 0)
        {
            auto event = CreateEventFromEvent<Mol::Event::AlarmSignalEvent, Mol::Event::AlarmSignalEvent, uint32_t>(m_handler.lastAlarmSignalEvent, 0);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
        }
	}
	
	void DisableZone(std::shared_ptr<Mol::Event::DisablementEvent> Disable)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: DisableZone()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::DISABLED);
        m_handler.SendEvent(Disable,PROC_ADDRESS::BROADCAST,true);
    }
    void PartialDisableZoneSendEvent(std::shared_ptr<Mol::Event::DisablementEvent> PartialDisable)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: PartialDisableZone()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED);		
        m_handler.SendEvent(PartialDisable, PROC_ADDRESS::BROADCAST, true);		
		m_handler.EnableAction();
    }

    void SendZoneEnablementEvent(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent, Dol::Entities::Zone::DISABLEMENT_STATE checkState)
    {
        /* Here we need to Send Enable Event first to HMI & EVENT PROVIDER to clear the Current disablement.
        Then send the new Disablement Event. This will prevent duplicate entries in those applications */
        if(m_handler.GetDisablement() == checkState)
        {
            DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine: SendZoneEnablementEvent()");

            auto srcId = disablementEvent->GetSource().GetObjectId();
            auto srcType = disablementEvent->GetSource().GetObjectType();
            auto zoneEnablementEvent = std::make_shared < Mol::Event::DisablementEvent > (Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
            zoneEnablementEvent->SetSource(Mol::DataType::ObjectReference { srcId, srcType });
            zoneEnablementEvent->SetEventApplication(disablementEvent->GetEventApplication());

            auto parents = disablementEvent->GetParents();
            for(auto &parent : parents)
            {
                zoneEnablementEvent->AddParent(parent);
            }

            auto labels = disablementEvent->GetLabels();
            for(auto &label : labels)
            {
                zoneEnablementEvent->AddLabel(label);
            }

            // Send the Events to HMI, Event Provider and Dragon
            m_handler.SendEvent(zoneEnablementEvent, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(zoneEnablementEvent, PROC_ADDRESS::EVENT_PROVIDERAPP, true);
            m_handler.SendEvent(zoneEnablementEvent, PROC_ADDRESS::MOL_RECEIVER, true);
        }
    }

    void EnableZone(std::shared_ptr<Mol::Event::DisablementEvent> Enable)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: EnableZone()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::ENABLED);
        m_handler.SendEvent(Enable,PROC_ADDRESS::BROADCAST,true);
		m_handler.EnableAction();
    }

    void SetAlarmZoneSignalEvent(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
		if(alarmSignal->GetEventCode() != EVACUATION_SIGNAL)
		{
            std::cout<<"SetAlarmZoneSignalEvent  ID  ---------------------- "<<m_handler.GetID()<<std::endl;
            std::cout<<"SetAlarmZoneSignalEvent  Type  ---------------------- "<<(uint32_t)m_handler.GetObjectType()<< std::endl;
            m_handler.SetAlarmSignalId(alarmSignal->GetEventCode());
            m_handler.SetLastAlarmSignalId(alarmSignal->GetEventCode());
		}
		else
		{
			m_handler.SetEvacuationState(true);
		}
		
		if(alarmSignal->GetSource() == Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() })
		{
		    m_handler.SendEvent(alarmSignal,PROC_ADDRESS::BROADCAST,true);
		}
		m_handler.lastAlarmSignalEvent = nullptr;
        m_handler.lastAlarmSignalEvent = alarmSignal;
    }

    void SwitchToOperation(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        auto operation = userOperation->GetEventCode();
        DEBUGPRINT(DEBUG_INFO, "AlarmZoneStateMachine: SwitchToOperation() operation code[{}]",(int)operation);
        if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE)
        {
            m_handler.SetSilenced(true);
        }
		else if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND)
        {
            m_handler.SetSilenced(false);
        }
        else
        {
            //Do nothing
        }

    }
	
	void SendEventtoHMI(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        auto operation = userOperation->GetEventCode();
        if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE)
        {
			m_handler.SendDeactiveEventtoHMI();
        }
		else if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND)
        {
			m_handler.SendActiveEventtoHMI();
        }
        else
        {
            //Do nothing
        }

    }
	
    void EvacuationResoundAction(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
		DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine:EvacuationResoundAction");
		SwitchToOperation(userOperation);
		m_handler.EnableAction();
	}
	
	void EvacuationResetAction(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
		DEBUGPRINT(DEBUG_INFO,"AlarmZoneStateMachine:EvacuationResetAction");
		ForwardEvacuationoffSignalAction(userOperation);
		m_handler.EnableAction();
	}
    //! handle to zone State handle
    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_ALARM_ZONE_H
