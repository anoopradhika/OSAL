/******************************************************************************//**
*
* @file   FaultRoutingOutputPointStateMachine.h
* @brief  State machine for fault routing output point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MECHAIN_FRE_OUTPUT_POINT_H
#define FIRESYSTEM_STATE_MECHAIN_FRE_OUTPUT_POINT_H

#include "Mol/Events/DisablementEvent.h"
#include "boost/sml.hpp"
namespace fireSystemState
{
namespace FROSMEvents
{
struct Fault{};
struct FaultCleared{};
}

template<typename Handler>
class FaultRoutingOutputPointStateMachine
{
public:
    FaultRoutingOutputPointStateMachine() = delete;

    FaultRoutingOutputPointStateMachine(FaultRoutingOutputPointStateMachine&& other) = delete;

    explicit FaultRoutingOutputPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~FaultRoutingOutputPointStateMachine() = default;
    FaultRoutingOutputPointStateMachine(const FaultRoutingOutputPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;

        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisableStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> event)
        {
            FunctionDisable(event);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionEnable> event)
        {
            FunctionEnable(event);
        };

        auto SendActivateStateUpdate = [this] ()
        {
            SendActivateCommand();
        };

        auto SendDeactivateStateUpdate = [this] ()
        {
            SendDeactivateCommand();
        };

        const auto IsActivation = [this] (std::shared_ptr<Mol::Event::ActivationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
            {
                std::cout<<"FRESM: IsActivation true"<< std::endl;
                return true;
            }
            return false;
        };

        const auto IsDeactivation = [this] (std::shared_ptr<Mol::Event::ActivationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
            {
                std::cout<<"FRESM: IsDeactivation true"<< std::endl;
                return true;
            }
            return false;
        };

        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Activate(activation);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Deactivate(activation);
        };

        auto DeactivatedDisableStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> event)
        {
            FunctionDisable(event);
            DisableDeactivate();
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<FROSMEvents::Fault> / SendActivateStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FunctionDisable>> / DisableStateUpdate = "disabled"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent>> [IsActivation] / ActivatedStateUpdate = "activated"_s

        ,"disabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable>> / EnabledStateUpdate = "quiescent"_s

        ,"activated"_s + event<std::shared_ptr<Mol::Event::ActivationEvent>> [IsDeactivation]/ DeactivatedStateUpdate = "quiescent"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::FunctionDisable>> / DeactivatedDisableStateUpdate = "disabled"_s // Send Deactivate event and clear Deactivate
        ,"activated"_s + event<FROSMEvents::FaultCleared> / SendDeactivateStateUpdate = "activated"_s
        );
    }

protected:

    void FunctionDisable(std::shared_ptr<Mol::Event::FunctionDisable> event)
    {
        std::cout<<"FRESM: Function Enabled: "<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SetDisabled(true);
    }

    void FunctionEnable(std::shared_ptr<Mol::Event::FunctionEnable> event)
    {
        std::cout<<"FRESM: Function Disabled: "<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SetDisabled(false);
        if(m_handler.GetFaultStatus())
        {
            SendActivateCommand();
        }
    }

    void SendActivateCommand()
    {
        std::cout<<"FRESM: SendActivateCommand ID: "<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SendActivateCommand();
    }

    void SendDeactivateCommand()
    {
        std::cout<<"FRESM: SendDeactivateCommand ID: "<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SendDeactivateCommand();
    }

    void Activate(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
        std::cout<<"FRESM:Activated ID: "<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SetActivationStatus(true);
		
		if(!(isCMCForwarded(activation)))
		{
            m_handler.SendEvent(activation, PROC_ADDRESS::BROADCAST, true);
		}
    }
	
	bool isCMCForwarded(std::shared_ptr<Mol::Event::ActivationEvent> activateEvent)
	{
		auto parameters = activateEvent->GetParameters();
		
		try{
		for (auto &iterator: parameters )
		{
		    if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
		    {
                auto str = iterator.template GetValue<std::string>();
				if(str == "CMC")
				{
					return true;
				}
			}
		}
		}
		catch(...)
		{
			DEBUGPRINT(DEBUG_ERROR,"FaultRoutingOutputPointStateMachine:isCMCForwarded: CMC event crashed");
		}
	    return false;
	}

    void DisableDeactivate()
    {
        std::cout<<"FRESM:Deactivated ID:"<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SetActivationStatus(false);

         SendEvent<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);

    }

    void Deactivate(std::shared_ptr<Mol::Event::ActivationEvent> event)
     {
         std::cout<<"FRESM:Deactivated ID:"<< std::hex << m_handler.GetID() <<std::endl;
         m_handler.SetActivationStatus(false);

        if(!(isCMCForwarded(event)))
		{
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
		}


         if(m_handler.GetFaultStatus())
         {
             SendActivateCommand();
         }
     }

    template<typename EVENT,typename CODE>
    void SendEvent(CODE code)
    {
        auto event = std::make_shared < EVENT > (code);
        event->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        auto parentZones = m_handler.GetParentZones();
        for (auto& parentZone : parentZones)
        {
            event->AddParent(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });
        }
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }

    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MECHAIN_FRE_OUTPUT_POINT_H
