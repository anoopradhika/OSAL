/******************************************************************************//**
*
* @file   FPOStateMachine.h
* @brief  State handler for Fire protection equipment point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_FPO_H
#define FIRESYSTEM_STATE_MACHINE_FPO_H

#include "Mol/Events/DisablementEvent.h"

#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class FPOStateMachine
{
public:
    FPOStateMachine() = delete;

    FPOStateMachine(FPOStateMachine&& other) = delete;

    explicit FPOStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~FPOStateMachine() = default;
    FPOStateMachine(const FPOStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> event)
        {
            Disable(event);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionEnable> event)
        {
            Enable(event);
        };

        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activationEvent)
        {
            Activate(activationEvent);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activationEvent)
        {
            Deactivate(activationEvent);
        };

        auto DeactivatedDisableStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> event)
        {
            Disable(event);
            Deactivate();
			SendDeactivateEventToHMI();
        };

        const auto IsActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            return IsPointActivation(activation);
        };

        const auto IsNotActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            return IsPointDeActivation(activation);
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> > / DisabledStateUpdate = "disabled"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable> > / EnabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsActivated]/ ActivatedStateUpdate = "activated"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsNotActivated]/ DeactivatedStateUpdate = "quiescent"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> > / DeactivatedDisableStateUpdate = "disabled"_s
        );
    }

protected:
    void Enable(std::shared_ptr<Mol::Event::FunctionEnable> event)
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine Enable is called");
        std::cout<<"FPO enable"<<std::endl;
        m_handler.SetDisabled(false);
        if(m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine check last operation is true");
            m_handler.SendActivate();
        }
    }
    void Disable(std::shared_ptr<Mol::Event::FunctionDisable> event)
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine Disable is called");
        std::cout<<"FPO disable"<<std::endl;
        m_handler.SetDisabled(true);
    }

    bool IsPointActivation(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointActivation is called");
        auto source = activation->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointActivation return false source is not same as handler");
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointActivation return true event code is activate");
            std::cout<<"IsActivated true"<<std::endl;
            return true;
        }

        return false;
    }
	
	bool IsPointDeActivation(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointDeActivation is called");
        auto source = activation->GetSource();
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointDeActivation return false source is not same as handler");
            return false;
        }
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointDeActivation return true source is same as handler");
            std::cout<<"IsActivated true"<<std::endl;
            return true;
        }

        return false;
    }

    bool IsPointActivated()
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine IsPointActivated called");
        return m_handler.IsActivated();
    }

    void Activate(std::shared_ptr<Mol::Event::ActivationEvent> activationEvent)
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine Activate is called");
        std::cout<<"***********FPO activated*************"<<std::endl;
        m_handler.SetActivated(true);

		auto source = activationEvent->GetSource();
		if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine Activate return as source is not same as handler");
            return;
        }

        m_handler.SendEvent(activationEvent,PROC_ADDRESS::BROADCAST,true);
		lastActivationEvent = nullptr;
		lastActivationEvent = activationEvent;
    }

    void Deactivate(std::shared_ptr<Mol::Event::ActivationEvent> activationEvent)
    {
		DEBUGPRINT(DEBUG_INFO,"FPOStateMachine Deactivate is called");
        auto source = activationEvent->GetSource();
		if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO,"FPOStateMachine Deactivate return as source is not same as handler");
            return;
        }
        
		m_handler.SetActivated(false);
        m_handler.SendEvent(activationEvent,PROC_ADDRESS::BROADCAST,true);
		lastActivationEvent = nullptr;
		lastActivationEvent = activationEvent;
    }
	
	void SendDeactivateEventToHMI()
	{
		DEBUGPRINT(DEBUG_INFO, "FPOStateMachine::SendDeactivateEventToHMI() is called");

        if(nullptr != lastActivationEvent && m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
			DEBUGPRINT(DEBUG_INFO, "FPOStateMachine::SendDeactivateEventToHMI() sending deactivate event to HMI");
            auto event = CreateEventFromEvent<Mol::Event::ActivationEvent, Mol::Event::ActivationEvent, Mol::Event::ACTIVATION_EVENT_CODE>(lastActivationEvent, Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
        }
	}
	
    void Deactivate()
    {
		DEBUGPRINT(DEBUG_INFO, "FPOStateMachine::Deactivate() is called");
        m_handler.SetActivated(false);
        SendEvent<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
		lastActivationEvent = nullptr;
    }

    template<typename EVENT, typename CODE>
    void SendEvent(CODE code)
    {
		DEBUGPRINT(DEBUG_INFO," FPOStateMachine::SendEvent FPO Activate event is created here ");
        auto event = std::make_shared<EVENT>(code);
        event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        auto parentZones = m_handler.GetParentZones();
        for(auto& parentZone : parentZones )
        {
            event->AddParent(Mol::DataType::ObjectReference{parentZone->GetID(), parentZone->GetObjectType()});
        }

        //@todo may need to added parent
        m_handler.SendEvent(event,PROC_ADDRESS::BROADCAST,true);
    }
    Handler& m_handler;
	std::shared_ptr<Mol::Event::ActivationEvent> lastActivationEvent = nullptr;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_FPO_H
