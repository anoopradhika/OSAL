/******************************************************************************//**
*
* @file   TechAlarmPointStateMachine.h
* @brief  State handler for Tech Alarm point.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_TECH_ALARM_POINT_H
#define FIRESYSTEM_STATE_MACHINE_TECH_ALARM_POINT_H

#include "DOL/Entities/Zone/AlarmZone.h"

#include "Mol/Events/DisablementEvent.h"
#include "LabelConfiguration/LabelConfiguration.h"

#include "boost/sml.hpp"
namespace fireSystemState
{
/**
*@startuml
[*] --> QuiescentState
QuiescentState: DeviceAlarmSignal /\Generate Event From Parent Zone State (See flowchart)
QuiescentState --> Disabled: Disable(PointID)
QuiescentState --> DisabledAlarm: AlarmEvent(DISABLED_ALARM)
Disabled: DeviceAlarmSignal / Generate AlarmEvent(DISABLED_ALARM)
Disabled --> DisabledAlarm: AlarmEvent(DISABLED_ALARM)
Disabled --> QuiescentState: Enable(PointId)
DisabledAlarm: Reset / If device is out of alarm, send RETURN_FROM_ALARM
DisabledAlarm --> Disabled: AlarmEvent(RETURN_FROM_ALARM)
DisabledAlarm --> QuiescentState: Enable(PointId) [Parent Zone disabled== false]
DisabledAlarm --> QuiescentState: Enable(ParentZoneId) [Point disabled== false]
QuiescentState --> TestAlarm: AlarmEvent(TEST_ALARM)
TestAlarm: Reset / If device is out of alarm, send AlarmEvent(RETURN_FROM_ALARM)
TestAlarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
TestAlarm --> QuiescentState: TestModeOff(ParentZoneID)
QuiescentState --> ConfirmingAlarm: AlarmEvent(UNCONFIRMED)
ConfirmingAlarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm --> Alarm: AlarmEvent(ALARM)
ConfirmingAlarm: AlarmSignalFromDevice[Reset Timer is running] / Send AlarmEvent(ALARM)
ConfirmingAlarm: MultiDependencyThresholdReached(GroupID) / Send AlarmEvent(ALARM)
ConfirmingAlarm: Reset Time Expired / Send AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm: Reset / send AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm --> Disabled: Disable(PointId) / Stop Reset Timer and send AlarmEvent(RETURN_FROM_ALARM)
Alarm --> DisabledAlarm: Disable(PointId) / AlarmEvent(RETURN_FROM_ALARM)
QuiescentState --> Alarm: AlarmEvent(ALARM)
Alarm: Reset / If device is out of alarm, send AlarmEvent(RETURN_FROM_ALARM)
Alarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
Alarm --> DisabledAlarm: Disable(Parent Zone Id) [check config] / AlarmEvent(RETURN_FROM_ALARM)
@enduml
*/

namespace FPSMEvent
{
struct TechAlarmZoneDisabled{};
struct TechAlarmPointDisabled{};
}

template<typename Handler>
class TechAlarmPointStateMachine
{
public:
    TechAlarmPointStateMachine() = delete;

    TechAlarmPointStateMachine(TechAlarmPointStateMachine&& other) = delete;

    explicit TechAlarmPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~TechAlarmPointStateMachine() = default;
    TechAlarmPointStateMachine(const TechAlarmPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;

        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> event, auto &sm, auto &deps, auto &subs)
        {
            std::cout<<"FPSM:DisabledStateUpdate disablement: "<< std::hex << GetID() <<std::endl;
            std::cout<<"FPSM:DisabledStateUpdate disablement: "<< std::hex << event->GetSource().GetObjectId() <<" Type: "<<(int)event->GetSource().GetObjectType() << std::endl;
            if(IsEventFromPoint(event))
            {
                std::cout<<"FPSM:DisabledStateUpdate point disablement: "<< std::hex << GetID() <<std::endl;
                Disable(event);
                sm.process_event(FPSMEvent::TechAlarmPointDisabled{}, deps, subs);
                return;
            }
            else if(IsEventFromParent(event))
            {
                // process zone disablement
                std::cout<<"FPSM:DisabledStateUpdate zone disablement: "<< std::hex << GetID() <<std::endl;
                sm.process_event(FPSMEvent::TechAlarmZoneDisabled{}, deps, subs);
                m_handler.lastZoneDisablementEvent = nullptr;
                m_handler.lastZoneDisablementEvent = event;
                return;
            }
            else
            {
                // do nothing
            }
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable(disablementEvent);
        };

        auto SelfEnablementStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            SelfEnablement(disablementEvent);
        };

        auto AlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessAlarm(alarmEvent);
        };

        auto ReturnAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessReturnFromAlarm(alarmEvent);
        };

        /*auto ResetCmdStateUpdate = [this] (std::shared_ptr<Mol::Command::Reset> resetCommand)
        {
            ProcessReset();
        };*/

        auto TestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestStart(testEvent);
        };

        auto TestAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> testAlarmEvent)
        {
            ProcessTestAlarm(testAlarmEvent);
        };

        auto EndZoneTestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestEnd(testEvent);
        };

        auto ClearTestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestEnd(testEvent);

        };

        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"FPSM:IsDisabled true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
                return false;
        };

        const auto IsZoneDisablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"FPSM:IsZoneDisablement true : "<< std::hex << GetID() <<std::endl;
                return IsEventFromParent(disablementEvent);
            }
                return false;
        };

        const auto IsZoneEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"FPSM:IsZoneEnablement true : "<< std::hex << GetID() <<std::endl;
                return IsEventFromParent(disablementEvent);
            }
                return false;
        };

        const auto IsPointEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"FPSM:IsZoneEnablement true : "<< std::hex << GetID() <<std::endl;
                return (IsEventFromPoint(disablementEvent) || IsEventFromParent(disablementEvent));
            }
                return false;
        };

        const auto IsFireAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::ALARM)
            {
                std::cout<<"FPSM:IsFireAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsReturnFromAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM)
            {
                std::cout<<"FPSM:IsReturnFromAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };
		
		const auto IsLegacyPanel = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            return IsLegacyPanelcall();
        };

        ///@todo check config for reset behaviour
        /*const auto IsAlarmReset = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            auto code = reset->GetCommandCode();
            if(code == Mol::Command::RESET_TYPE_CODE::FIRE_ALARM || code == Mol::Command::RESET_TYPE_CODE::GENERAL)
            {
                std::cout<<"FPSM:IsAlarmReset true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };*/

        const auto IsZoneTestStart = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            if(testEvent->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST)
            {
                std::cout<<"FPSM:IsZoneTestStart true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsZoneTestEnd = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            if(testEvent->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST)
            {
                std::cout<<"FPSM:IsZoneTestEnd true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsTestAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::TEST_ALARM)
            {
                std::cout<<"FPSM:IsTestAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };
		
		const auto QuicentStateupdate = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ResetAllstates();
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsDisabled]/ DisabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<FPSMEvent::TechAlarmZoneDisabled> = "zone_disabled"_s
        ,"quiescent"_s + event<FPSMEvent::TechAlarmPointDisabled> = "point_disabled"_s

        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZoneEnablement]/SelfEnablementStateUpdate = "quiescent"_s

        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsPointEnablement]/ EnabledStateUpdate = "quiescent"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZoneDisablement]/ EnabledStateUpdate = "zone_disabled"_s

        // Alarm Event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm] / AlarmStateUpdate = "alarm"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "quiescent"_s
		,"alarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsLegacyPanel] / QuicentStateupdate = "quiescent"_s
        //Reset command need not be handled as it will cause a return to quiescent mode and RetrunFromAlarm will not be handled
        //,"alarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsAlarmReset] / ResetCmdStateUpdate = "quiescent"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsDisabled]/ DisabledStateUpdate = "alarm"_s
        ,"alarm"_s + event<FPSMEvent::TechAlarmZoneDisabled> = "zone_disabled"_s
        ,"alarm"_s + event<FPSMEvent::TechAlarmPointDisabled> = "point_disabled"_s
        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "zone_disabled"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "point_disabled"_s
        // Coincidence Handling
//      ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFirstAlarm] / FirstAlarmStateUpdate = "FirstAlarm"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm] / AlarmStateUpdate = "FirstAlarm"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "quiescent"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsAlarmReset] / ResetCmdStateUpdate = "quiescent"_s

        // Test mode event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestStart] / TestStateUpdate = "test"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsTestAlarm] / TestAlarmStateUpdate = "test_alarm"_s
        ,"test_alarm"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestEnd] / ClearTestStateUpdate = "quiescent"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestEnd] / EndZoneTestStateUpdate = "quiescent"_s
        );
    }

protected:

    bool IsEventFromParent(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        return m_handler.IsEventFromParent(event->GetSource());
    }

    bool IsEventFromPoint(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        if((event->GetSource().GetObjectId() == m_handler.GetID()) && (event->GetSource().GetObjectType() == m_handler.GetConcreteObjectType()))
        {
            return true;
        }
        return false;
    }

    bool IsitMine(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        auto source = disablementEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return true;
        }
        return false;
    }
	
	void ResetAllstates()
	{
		m_handler.SetAlarmDetected(false);
	}

    uint64_t GetID()
    {
        return m_handler.GetID();
    }

    std::shared_ptr<Mol::Event::DisablementEvent> CreatSendEnablementEvent(std::shared_ptr<Mol::Event::DisablementEvent> event, Mol::Event::DISABLEMENT_EVENT_CODE code, bool toHMIOnly = false)
    {
        auto pointDisablementEvent = std::make_shared < Mol::Event::DisablementEvent > (code);
        pointDisablementEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        pointDisablementEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        Dol::Label label;

        auto parentZones = m_handler.GetParentZones();
        for (auto &parentZone : parentZones)
        {
            pointDisablementEvent->AddParent(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });
        }
        pointDisablementEvent->GetLabels().clear();
        uint64_t objectID = pointDisablementEvent->GetSource().GetObjectId();
        label.SetLabel(m_lableHandle.FindDeviceLabel(static_cast<uint64_t>(objectID)));
        label.SetLabelType(Dol::Label::LABEL_TYPE::POINT);
        pointDisablementEvent->AddLabel(label);

        for (auto &parent: pointDisablementEvent->GetParents())
        {
            switch (parent.GetObjectType())
            {
            case Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::GENERAL_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::RELEASING_ZONE:
            {
                label.SetLabel(m_lableHandle.FindZoneLabel(parent.GetObjectId(),parent.GetObjectType()));
                label.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
                pointDisablementEvent->AddLabel(label);
            }
            default:
            {
                break;
            }
            }
        }
        pointDisablementEvent->SetZonePointReference(m_handler.GetZonePointReference());
        if(toHMIOnly)
        {
            //we send only to network to clear previous disablment, now zone is disabled and point is still in disabled state (zone_disabled)
            //but in HMI only zone disablment will be displayed
            //to do this logic in HMI, is like re implementation another FDA in HMI
            //others HMIs in the network will also be updated by there own FDAs in MainCPU
            m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon as always for debuging
        }
        else
        {
            m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::BROADCAST, true);
        }
        //enablment is sent so we clean disablment
        m_handler.lastPointDisablementEvent = nullptr;
        return pointDisablementEvent;     
    }


    void Enable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        std::cout << "FPSM:Fire Point call test enable : " << std::hex << m_handler.GetID() << std::endl;
        if (!IsitMine(event)) //my zone disablment
        {
            CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED,true);
            return;
        }
        else//my enablment
        {
            m_handler.SetDisabled(false);
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        }
    }

    void SelfEnablement(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:TechAlarmPointStateMachine: SelfEnablement : for ID[{0:#x}]",m_handler.GetID());
        if (!IsitMine(event)) //my zone disablment
        {
            if(m_handler.IsDisabled())
            {
                m_handler.SetDisabled(false);
                CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
                return;
            }			
        }
    }

    void Disable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        std::cout << "FPSM: Fire point all test disable : " << std::hex << m_handler.GetID() << std::endl;
        m_handler.SetDisabled(true);
        if (!IsitMine(event)) //my zone disablment
        {
            m_handler.lastZoneDisablementEvent  = nullptr;
            m_handler.lastZoneDisablementEvent = CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
            return;
        }
        else//my enablment
        {
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastPointDisablementEvent = nullptr;
            m_handler.lastPointDisablementEvent = event;
        }
    }

    void ProcessAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(!m_handler.IsAlarmDetected())
        {
            std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessAlarm : "<< std::hex << m_handler.GetID() <<std::endl;
            m_handler.SetAlarmDetected(true);
            m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
        }
    }

    void ProcessReturnFromAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(m_handler.IsAlarmDetected())
        {
            std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessReturnFromAlarm : "<< std::hex << m_handler.GetID() <<std::endl;
            m_handler.SetAlarmDetected(false);
            m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
        }
    }

    void ProcessReset()
    {
        std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessReset : "<< std::hex << m_handler.GetID() <<std::endl;
        m_handler.SetAlarmDetected(false);
    }

    void ProcessTestStart(std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
    {
        std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessTestStart : "<< std::hex << m_handler.GetID() <<std::endl;
        auto source = testEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            m_handler.SendEvent(testEvent, PROC_ADDRESS::BROADCAST, true);
        }
    }

    void ProcessTestAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessTestAlarm : "<< std::hex << m_handler.GetID() <<std::endl;
        //m_handler.SetTestFire(true);
        m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
    }

    void ProcessTestEnd(std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
    {
        std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessTestEnd : "<< std::hex << m_handler.GetID() <<std::endl;
        //m_handler.SetTestFire(false);
        auto source = testEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            m_handler.SendEvent(testEvent, PROC_ADDRESS::BROADCAST, true);
        }
    }
	
	bool IsLegacyPanelcall()
    {
		if(Utility::GetEventResetMode()== EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)
		{
			return true;
		}
        return false;
    }

    void SendReturnFromAlarm()
    {
        std::cout<<"FPSM:TechAlarmPointStateMachine: ProcessTestEnd : "<< std::hex << m_handler.GetID() <<std::endl;
        auto returnFromAlarm = std::make_shared < Mol::Event::AlarmEvent > (Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM);
        returnFromAlarm->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        returnFromAlarm->SetEventApplication(Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS);
        auto parentZones = m_handler.GetParentZones();
        for (auto& parentZone : parentZones)
        {
            returnFromAlarm->AddParent(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });
        }
        m_handler.SendEvent(returnFromAlarm, PROC_ADDRESS::BROADCAST, true);
    }

private:

    Handler& m_handler;
    fireSystemState::LabelConfigurationHandle &m_lableHandle = fireSystemState::LabelConfigurationHandle::GetInstance();
};

}

#endif //FIRESYSTEM_STATE_MACHINE_TECH_ALARM_POINT_H
