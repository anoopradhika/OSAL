/******************************************************************************//**
*
* @file   FaultEventStateMachine.h
* @brief  State machine for Fault Event.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_FAULT_EVENT_H
#define FIRESYSTEM_STATE_MACHINE_FAULT_EVENT_H

#include "CommonDef.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "boost/sml.hpp"
#include "Mol/Commands/Reset.h"
#include "Helper/FSHelper.h"
namespace fireSystemState
{

template<typename Handler>
class FaultEventStateMachine
{
public:
    FaultEventStateMachine() = delete;

    FaultEventStateMachine(FaultEventStateMachine&& other) = delete;

    explicit FaultEventStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~FaultEventStateMachine() = default;
    FaultEventStateMachine(const FaultEventStateMachine& other) :
        m_handler{other.m_handler}
    {
    }


    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;
		
        const auto IsFaultAlreadyPresent = [this] (std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return( m_faults.end() != m_faults.find(faultEvent->GetEventCode()));
        };

        const auto IsFaultToClearAlreadyPresent = [this] (std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
			std::cout<<"in IsFaultToClearAlreadyPresent"<<std::endl;
            return( m_faults.end() != m_faults.find(faultClearedEvent->GetEventCode()));
        };

        const auto IsMoreThenOneFaultInEntity = [this] (std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return IsMoreThenOneFaultInEntityCall(faultClearedEvent);
        };
	
		const auto ClearAllFault = [this] (std::shared_ptr<Mol::Command::Reset>  reset)
        {
            ResetFaultmap();
        };

        const auto FaultClearedEventAction = [this] (std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
			std::cout<<"in FaultClearedEventAction"<<std::endl;
            ReducefaultCount(faultClearedEvent);
        };
		
        const auto SetFault = [this] (std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            SetFaultAndForwardEvent(faultEvent);
        };
		
		const auto ForwardFault = [this] (std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            ForwardEvent(faultEvent);
        };

        const auto IsItMineFault_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return IsItMine(faultEvent, GetmyObjectRef());
        };

        const auto IsItMineFaultCleared_ = [this](std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return IsItMine(faultClearedEvent, GetmyObjectRef());
        };

        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return (!isAFirePanel() && IsItMyPanelFailure(faultEvent,GetmyPanelObjectRef()));
        };

        const auto IsMyPanelFailureCleared_ = [this](std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return IsItMyPanelFailure(faultClearedEvent,GetmyPanelObjectRef());
        };

        const auto IsFaultHandledByReset_ = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            return IsFaultHandledByReset();
        };

        const auto ClearAllEntityFaultsAction = [this] (std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            ClearAllEntityFaults(faultClearedEvent);
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent> > [IsItMineFault_]/ SetFault = "fault"_s
        ,"fault"_s + event<std::shared_ptr<Mol::Event::FaultEvent> > [IsItMineFault_ && IsFaultAlreadyPresent]/ ForwardFault = "fault"_s
		,"fault"_s + event<std::shared_ptr<Mol::Event::FaultEvent> > [IsItMineFault_ && !IsFaultAlreadyPresent]/ SetFault = "fault"_s
        ,"fault"_s + event<std::shared_ptr<Mol::Command::Reset> > [IsFaultHandledByReset_]/ ClearAllFault = "quiescent"_s
        ,"fault"_s + event<std::shared_ptr<Mol::Event::FaultClearedEvent> > [IsItMineFaultCleared_ && IsFaultToClearAlreadyPresent && IsMoreThenOneFaultInEntity]/ FaultClearedEventAction = "fault"_s
        ,"fault"_s + event<std::shared_ptr<Mol::Event::FaultClearedEvent> > [IsItMineFaultCleared_ && IsFaultToClearAlreadyPresent && ! IsMoreThenOneFaultInEntity]/ FaultClearedEventAction = "quiescent"_s

        ,"fault"_s + event<std::shared_ptr<Mol::Event::FaultEvent> > [IsMyPanelFailure_] = "unreachable"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent> > [IsMyPanelFailure_] = "unreachable"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset> > / ClearAllEntityFaultsAction = "quiescent"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Event::FaultClearedEvent> > [IsMyPanelFailureCleared_]/ ClearAllEntityFaultsAction = "quiescent"_s
        );
    }

protected:
    void SetFaultAndForwardEvent(std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
    {
		std::cout<<"in SetFaultAndForwardEvent"<<std::endl;
        m_faults.emplace(faultEvent->GetEventCode(), faultCounter{faultEvent,1});
        m_handler.SetFault(true);
		
		if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS == faultEvent->GetEventCode()
			 && !isCMCForwarded(faultEvent))
		{
            m_handler.SendFaultEvent(faultEvent);
		}
		else if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS != faultEvent->GetEventCode())
		{
			m_handler.SendFaultEvent(faultEvent);
		}
		else
		{
			//do nothing
		}
		
        DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: SetFaultAndForwardEvent() number of faults[{}]", m_faults.size());
    }
    
	void ForwardEvent(std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
    {
		std::cout<<"in ForwardEvent"<<std::endl;
		auto fcounstruct = m_faults[faultEvent->GetEventCode()];
		fcounstruct.count++;	
		m_faults[faultEvent->GetEventCode()] = fcounstruct;	
        
		if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS == faultEvent->GetEventCode()
			 && !isCMCForwarded(faultEvent))
		{
            m_handler.SendFaultEvent(faultEvent);
		}
		else if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS != faultEvent->GetEventCode())
		{
			m_handler.SendFaultEvent(faultEvent);
		}
		else
		{
			//do nothing
		}
		
        DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: ForwardEvent() number of faults[{}]", m_faults.size());
    }

    bool isCMCForwarded(std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
	{
		try{
		auto parameters = faultEvent->GetParameters();
		for (auto &iterator: parameters )
		{
		    if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
		    {
                auto str = iterator.template GetValue<std::string>();
				if(str == "CMC")
				{
					return true;
				}
			}
		}
		}
		catch(...)
		{
			DEBUGPRINT(DEBUG_ERROR,"FaultEventStateMachine:isCMCForwarded: CMC event crashed");
		}
	    return false;
	}

    void UpdateFaultState(std::shared_ptr<Mol::Event::FaultClearedEvent>  faultClearedEvent)
    {
		std::cout<<"in UpdateFaultState"<<std::endl;
        if(m_faults.empty())
        {
            m_handler.SetFault(false);
        }
        m_handler.SendFaultClearedEvent(faultClearedEvent);
        DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: UpdateFaultState() number of faults[{}]", m_faults.size());
    }

    template<typename EventType>
    void ClearAllEntityFaults(EventType  event = nullptr)
    {
        DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: ClearAllEntityFaults() number of faults[{}]", m_faults.size());
        for(auto fault : m_faults) {
          // fault cleared is by RESET command, so loop on all faults for this point and send cleared to HMI
            auto faultClearedEvent = CreateEventFromEvent<Mol::Event::FaultEvent,Mol::Event::FaultClearedEvent, Mol::Event::FAULT_EVENT_CODE>(fault.second.faultptr, fault.first);
            if(nullptr != faultClearedEvent)
            {
                m_handler.SendFaultClearedEvent(faultClearedEvent);
            }

        }
        m_handler.SetFault(false);
        m_faults.clear();
    }
	
	void ResetFaultmap()
	{
		m_handler.SetFault(false);
        m_faults.clear();
	}
	
	void ReducefaultCount(std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
	{
		std::cout<<"In ReducefaultCount"<<std::endl;
		DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: ReducefaultCount() number of faults[{}]", m_faults.size());
        auto fcounstruct = m_faults[faultClearedEvent->GetEventCode()];
		
		if(fcounstruct.count > 1)
		{
			std::cout<<"In ReducefaultCount if case"<<std::endl;
			fcounstruct.count--;
			m_faults[faultClearedEvent->GetEventCode()] = fcounstruct;
			
			//for debug
			auto str = m_faults[faultClearedEvent->GetEventCode()];
			DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: ReducefaultCount() number of individual faults[{}]", str.count);
		}
		else
		{
			std::cout<<"In ReducefaultCount else case"<<std::endl;
			m_faults.erase(faultClearedEvent->GetEventCode());
		}
		UpdateFaultState(faultClearedEvent);
	}
	
	bool IsMoreThenOneFaultInEntityCall(std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
	{
	    std::cout<<"In IsMoreThenOneFaultInEntityCall"<<std::endl;
		DEBUGPRINT(DEBUG_INFO, "FaultEventStateMachine: IsMoreThenOneFaultInEntityCall() number of faults[{}]", m_faults.size());
        auto fcounstruct = m_faults[faultClearedEvent->GetEventCode()];
		
		if(fcounstruct.count > 1)
		{
		    return true;
		}
		else
		{
			return (m_faults.size() > 1);
		}
	}

    bool IsFaultHandledByReset()
    {
        //return m_handler.faultHandledByReset;
		
		if(Utility::GetEventResetMode()== EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)
		{
		    return true;
		}
        	return false;
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return m_handler.GetmyObjectRef();
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_handler.GetmyPanelObjectRef();
    }

    bool isAFirePanel()
    {
        return (Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL == m_handler.GetmyObjectRef().GetObjectType());
    }
    Handler& m_handler;
private:
    using faultCounter = struct {std::shared_ptr<Mol::Event::FaultEvent> faultptr; uint16_t count;} ;
    std::map<Mol::Event::FAULT_EVENT_CODE, faultCounter> m_faults;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_FAULT_EVENT_H
