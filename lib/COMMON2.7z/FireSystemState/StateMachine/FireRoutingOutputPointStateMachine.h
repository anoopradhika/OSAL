/******************************************************************************//**
*
* @file   FireRoutingOutputPointStateMachine.h
* @brief  State machine for fire routing output point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MECHAIN_FARE_OUTPUT_POINT_H
#define FIRESYSTEM_STATE_MECHAIN_FARE_OUTPUT_POINT_H

#include "Mol/Events/DisablementEvent.h"
#include "StateHandler/StateHandler.h"
#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class FireRoutingOutputPointStateMachine
{
public:
    FireRoutingOutputPointStateMachine() = delete;

    FireRoutingOutputPointStateMachine(FireRoutingOutputPointStateMachine&& other) = delete;

    explicit FireRoutingOutputPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~FireRoutingOutputPointStateMachine() = default;
    FireRoutingOutputPointStateMachine(const FireRoutingOutputPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;

        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisableStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> event)
        {
            FunctionDisable(event);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionEnable> event)
        {
            FunctionEnable(event);
        };

        const auto IsActivation = [this] (std::shared_ptr<Mol::Event::ActivationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
            {
                std::cout<<"FARESM: IsActivation true"<< std::endl;
                return true;
            }
            return false;
        };

        const auto IsDeactivation = [this] (std::shared_ptr<Mol::Event::ActivationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
            {
                std::cout<<"FARESM: IsDeactivation true"<< std::endl;
                return true;
            }
            return false;
        };

        const auto IsFARETestEnd = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_REMOVED_FROM_TEST)
            {
                std::cout<<"FARESM: IsFARETestEnd true"<< std::endl;
                return true;
            }
            return false;
        };

        const auto IsFARETestStart = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_TEST)
            {
                std::cout<<"FARESM: IsFARETestStart true"<< std::endl;
                return true;
            }
            return false;
        };

        auto ActivatedStateUpdate = [this] ( std::shared_ptr<Mol::Event::ActivationEvent> event )
        {
            Activate( event );
        };

        auto DeactivatedStateUpdate = [this] ( std::shared_ptr<Mol::Event::ActivationEvent> event)
        {
            Deactivate( event );
        };

        auto DeactivatedDisableStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> event)
        {
            FunctionDisable(event);
            Deactivate();
        };

        auto FARETestEventsUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> event)
        {
            FARETestEvents(event);
        };

        auto FARETestEndEventsUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> event)
        {
            FARETestEndEvents(event);
        };

        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return IsItMyPanelFailure(faultEvent,GetmyPanelObjectRef());
        };

        auto ProcessClearAlarmTestAndDesiblement = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ClearTestWhenReachable();
            ClearDesiblementWhenReachable();
        };
        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::FunctionDisable>> / DisableStateUpdate = "disabled"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent>> [IsActivation] / ActivatedStateUpdate = "activated"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsFARETestStart] / FARETestEventsUpdate = "test"_s

        ,"test"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsFARETestEnd] / FARETestEndEventsUpdate = "quiescent"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable>> / EnabledStateUpdate = "quiescent"_s

        ,"activated"_s + event<std::shared_ptr<Mol::Event::ActivationEvent>> [IsDeactivation]/ DeactivatedStateUpdate = "quiescent"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::FunctionDisable>> / DeactivatedDisableStateUpdate = "disabled"_s

        //Networked Panels - Node Failure Scenario https://acsjira.honeywell.com/browse/FUSION-4514
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset>> / ProcessClearAlarmTestAndDesiblement = "quiescent"_s
        );
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return m_handler.GetmyObjectRef();
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_handler.GetmyPanelObjectRef();
    }
protected:

    void FARETestEvents(std::shared_ptr<Mol::Event::TestOperationEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:FARETestEvents: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastTestEvent = nullptr;
        m_handler.lastTestEvent = event;
    }

    void FARETestEndEvents(std::shared_ptr<Mol::Event::TestOperationEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:FARETestEndEvents: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastTestEvent = nullptr;
    }

    void FunctionDisable(std::shared_ptr<Mol::Event::FunctionDisable> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:FunctionDisable: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetDisabled(true);
        m_handler.lastFunctionDisableEvent = nullptr;
        m_handler.lastFunctionDisableEvent = event;
    }

    void FunctionEnable(std::shared_ptr<Mol::Event::FunctionEnable> event)
    {
        std::cout<<"FARESM: Function Enabled : "<< std::hex << m_handler.GetID() <<std::endl;
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:FARETestEndEvents: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetDisabled(false);
        m_handler.lastFunctionDisableEvent = nullptr;
        if(m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
            m_handler.SendActivate();
        }
    }

    void Activate()
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:Activate: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetActivated(true);
        SendEvent<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
        if(m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE))
        {
            m_handler.SendDeactivate();
        }
    }

    void Deactivate()
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:Deactivate: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetActivated(false);
        SendEvent<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
        if(m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
            m_handler.SendActivate();
        }
    }

    /**
      handle activation and forwrd already existing event
      @param[in] event event to forward

      background info: We need to keep the original event data to break a loop over multiple
      networks.
      */
    void Activate( std::shared_ptr<Mol::Event::ActivationEvent> event )
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:Activate: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetActivated(true);
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        if(m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::DEACTIVATE))
        {
            m_handler.SendDeactivate();
        }
    }

    /**
      handle deactivation and forward already existing event
      @param[in] event event to forward

      background info: We need to keep the original event data to break a loop over multiple
      networks.
      */
    void Deactivate( std::shared_ptr<Mol::Event::ActivationEvent> event )
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:Deactivate: for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetActivated(false);
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        if(m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
            m_handler.SendActivate();
        }
    }

    template<typename EVENT, typename CODE>
    void SendEvent(CODE code)
    {
        auto event = std::make_shared<EVENT>(code);
        event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        auto parentZones = m_handler.GetParentZones();
        for(auto& parentZone : parentZones )
        {
            event->AddParent(Mol::DataType::ObjectReference{parentZone->GetID(), parentZone->GetObjectType()});
        }
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }

    void ClearTestWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:ClearTestWhenReachable");
        if(nullptr != m_handler.lastTestEvent)
        {
            auto event = CreateEventFromEvent<Mol::Event::TestOperationEvent,Mol::Event::TestOperationEvent,Mol::Event::TEST_OPERATION_EVENT_CODE>(m_handler.lastTestEvent, Mol::Event::TEST_OPERATION_EVENT_CODE::FARE_REMOVED_FROM_TEST);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
            m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            m_handler.lastTestEvent = nullptr;
            DEBUGPRINT(DEBUG_INFO,"FPSM:ClearTestWhenReachable SendEvent: FARE_REMOVED_FROM_TEST");
        }
    }

    void ClearDesiblementWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:ClearDesiblementWhenReachable: m_handler.IsDisabled()[{0}]",static_cast<int>(m_handler.IsDisabled()));
        if(m_handler.IsDisabled())
        {
            m_handler.SetDisabled(false);
            if(nullptr != m_handler.lastFunctionDisableEvent)
            {
                auto event = CreateEventFromEvent<Mol::Event::FunctionDisable, Mol::Event::FunctionEnable, Mol::FUNCTION_CODE>(m_handler.lastFunctionDisableEvent, Mol::FUNCTION_CODE::FIRE_ALARM_ROUTING);
                m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
                m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
                m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
                DEBUGPRINT(DEBUG_INFO,"FireRoutingOutputPointStateMachine:ClearDesiblementWhenReachable SendEvent: Point DISABLEMENT_EVENT_CODE::ENABLED");
            }
        }
    }
    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MECHAIN_FARE_OUTPUT_POINT_H
