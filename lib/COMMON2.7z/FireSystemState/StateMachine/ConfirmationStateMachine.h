/******************************************************************************//**
*
* @file   ConfirmationStateMachine.h
* @brief  State handler for confirmation handling.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_CONFIRMATION_H
#define FIRESYSTEM_STATE_MACHINE_CONFIRMATION_H


#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class ConfirmationStateMachine
{
public:
    ConfirmationStateMachine() = delete;

    ConfirmationStateMachine(ConfirmationStateMachine&& other) = delete;

    explicit ConfirmationStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~ConfirmationStateMachine() = default;
    ConfirmationStateMachine(const ConfirmationStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;

        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        const auto IsConfirmed = [this] (std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
        {
            return CheckConfirmation(informationEvent);
        };

        const auto IsConfirmationNotReceivedEvent = [this] (std::shared_ptr<Mol::Event::InformationEvent> event)
        {
            if(event->GetEventCode() == Mol::Event::INFORMATION_EVENT_CODE::CONFIRMATION_NOT_RECEIVED)
            {
                return true;
            }
            return false;
        };

        const auto IsConfirmationReseted = [this] (std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
        {
            return (CheckResetConfirmation(informationEvent) );
        };

        auto ConfirmedStateUpdate = [this] (std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
        {
            Confirmed(informationEvent);
        };

        auto ResetConfirmation = [this] (std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
        {
            ClearConfirmation(informationEvent);
        };

        auto InformationStateUpdate = [this] (std::shared_ptr<Mol::Event::InformationEvent> event)
        {
            InformationUpdate(event);
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::InformationEvent> > [IsConfirmed]/ ConfirmedStateUpdate = "confirmed"_s
        ,"confirmed"_s + event<std::shared_ptr<Mol::Event::InformationEvent> > [IsConfirmationReseted]/ ResetConfirmation = "quiescent"_s
        ,"confirmed"_s + event<std::shared_ptr<Mol::Event::InformationEvent> > [IsConfirmationNotReceivedEvent]/ InformationStateUpdate = "not_confirmed"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::InformationEvent> > [IsConfirmationNotReceivedEvent]/ InformationStateUpdate = "not_confirmed"_s
        ,"not_confirmed"_s + event<std::shared_ptr<Mol::Event::InformationEvent> > [IsConfirmed]/ ConfirmedStateUpdate = "confirmed"_s
        ,"not_confirmed"_s + event<std::shared_ptr<Mol::Event::InformationEvent> > [IsConfirmationReseted]/ ResetConfirmation = "quiescent"_s
        );
    }

protected:

    void Confirmed(std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
    {
        m_handler.SetConfirmation(true);
        m_handler.SendEvent(informationEvent,PROC_ADDRESS::BROADCAST,true);
    }

    void ClearConfirmation(std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
    {
        m_handler.SetConfirmation(false);
        m_handler.SendEvent(informationEvent,PROC_ADDRESS::BROADCAST,true);
    }

    void InformationUpdate(std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
    {
        m_handler.SendEvent(informationEvent,PROC_ADDRESS::BROADCAST,true);
    }

    bool CheckConfirmation(std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
    {
        if((informationEvent->GetEventCode() == Mol::Event::INFORMATION_EVENT_CODE::RECEIVED_CONFIRMATION_SIGNAL)
            &&
            (!m_handler.IsConfirmed()))
        {
            return true;
        }
        return false;
    }

    bool CheckResetConfirmation(std::shared_ptr<Mol::Event::InformationEvent> informationEvent)
    {
        if((informationEvent->GetEventCode() == Mol::Event::INFORMATION_EVENT_CODE::CONFIRMATION_SIGNAL_RESET)
            &&
            (m_handler.IsConfirmed()))
        {
            return true;
        }
        return false;
    }

    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_FPO_H
