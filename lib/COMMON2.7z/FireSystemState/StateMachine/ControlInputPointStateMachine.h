/******************************************************************************//**
*
* @file   ControlInputPointStateMachine.h
* @brief  State handler for Control input point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_CONTROL_INPUT_POINT_H
#define FIRESYSTEM_STATE_MACHINE_CONTROL_INPUT_POINT_H

#include "Mol/Events/DisablementEvent.h"
#include "Helper/FSHelper.h"
#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class ControlInputPointStateMachine
{
public:
    ControlInputPointStateMachine() = delete;

    ControlInputPointStateMachine(ControlInputPointStateMachine&& other) = delete;

    explicit ControlInputPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~ControlInputPointStateMachine() = default;
    ControlInputPointStateMachine(const ControlInputPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Disable(disablementEvent);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable(disablementEvent);
        };
        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"IsDisabled true"<<std::endl;
                return true;
            }
                return false;
        };

        const auto IsEnabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"IsEnabled true"<<std::endl;
                return true;
            }
                return false;
        };

        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::InputChangeEvent> event)
        {
            Activate(event);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::InputChangeEvent> event)
        {
            Deactivate(event);
        };

        auto DeactivatedDisableStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Disable(disablementEvent);
            Deactivate();
        };

        const auto IsActivated = [this] (std::shared_ptr<Mol::Event::InputChangeEvent> activation)
        {
            if(IsPointDisabled())
            {
                return false;
            }
            
            if(IsPointActivated(activation))
            {
                return true;
            }

            return false;
        };

        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return IsItMyPanelFailure(faultEvent,GetmyPanelObjectRef());
        };

        auto ClearAllWhenReachableUpdate = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ClearDesiblementWhenReachable();
            ClearInputChangeEventWhenReachable();
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsDisabled]/ DisabledStateUpdate = "disabled"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsEnabled]/ EnabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::InputChangeEvent> > [IsActivated]/ ActivatedStateUpdate = "activated"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::InputChangeEvent> > [!IsActivated]/ DeactivatedStateUpdate = "quiescent"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsDisabled]/ DeactivatedDisableStateUpdate = "disabled"_s

        //Networked Panels - Node Failure Scenario https://acsjira.honeywell.com/browse/FUSION-4514
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset>> / ClearAllWhenReachableUpdate = "quiescent"_s
        );
    }

protected:

    void ClearDesiblementWhenReachable()
     {
         DEBUGPRINT(DEBUG_INFO,"ControlInputPointStateMachine:ClearDesiblementWhenReachable: m_handler.IsDisabled()[{0}]",static_cast<int>(m_handler.IsDisabled()));
         if(m_handler.IsDisabled())
         {
             m_handler.SetDisabled(false);
             if(nullptr != m_handler.lastPointDisablementEvent)
             {
                 auto event = CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>(m_handler.lastPointDisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
                 m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
                 m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
                 m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
                 DEBUGPRINT(DEBUG_INFO,"ControlInputPointStateMachine:ClearDesiblementWhenReachable SendEvent: Point DISABLEMENT_EVENT_CODE::ENABLED");
             }
         }
     }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return m_handler.GetmyObjectRef();
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_handler.GetmyPanelObjectRef();
    }

    void Enable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        m_handler.SetDisabled(false);
        m_handler.lastPointDisablementEvent = nullptr;
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }

    void Disable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        m_handler.SetDisabled(true);
        m_handler.lastPointDisablementEvent = nullptr;
        m_handler.lastPointDisablementEvent = event;
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }


    bool IsPointActivated(std::shared_ptr<Mol::Event::InputChangeEvent> activation)
    {
        auto source = activation->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::INPUT_CHANGE_EVENT_CODE::ACTIVATED)
        {
            std::cout<<"IsActivated true"<<std::endl;
            return true;
        }

        return false;
    }

    void Activate(std::shared_ptr<Mol::Event::InputChangeEvent> event)
    {
        std::cout<<"***********CI actived*************"<<std::endl;
        m_handler.SetActive(true);
        m_handler.lastInputChangeEvent = nullptr;
        m_handler.lastInputChangeEvent = event;
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }

    void Deactivate()
    {
        std::cout<<"***********CI Deactivated*************"<<std::endl;
        m_handler.SetActive(false);
        m_handler.lastInputChangeEvent = nullptr;
        SendEvent<Mol::Event::InputChangeEvent>(Mol::Event::INPUT_CHANGE_EVENT_CODE::RELEASED);
    }

    void Deactivate(std::shared_ptr<Mol::Event::InputChangeEvent> event)
    {
        std::cout<<"***********CI Deactivated*************"<<std::endl;
        m_handler.SetActive(false);
        m_handler.lastInputChangeEvent = nullptr;
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }

    void ClearInputChangeEventWhenReachable()
     {
        DEBUGPRINT(DEBUG_INFO,"ControlInputPointStateMachine:DeactivateWhenReachable: m_handler.IsActive()[{0}]",static_cast<int>(m_handler.IsActive()));
        if(m_handler.IsActive())
        {
            m_handler.SetActive(false);
            if(nullptr != m_handler.lastInputChangeEvent)
            {
                auto event = CreateEventFromEvent<Mol::Event::InputChangeEvent, Mol::Event::InputChangeEvent, Mol::Event::INPUT_CHANGE_EVENT_CODE>(m_handler.lastInputChangeEvent, Mol::Event::INPUT_CHANGE_EVENT_CODE::RELEASED);
                m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
                m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
                m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
                DEBUGPRINT(DEBUG_INFO,"ControlInputPointStateMachine:DeactivateWhenReachable SendEvent: Point DISABLEMENT_EVENT_CODE::ENABLED");
            }
        }
     }

    bool IsPointDisabled()
    {
        if( m_handler.IsDisabled())
        {
            return true;
        }
        if(m_handler.IsFunctionDisablementActive(Dol::FUNCTION::CONTROL_INPUTS))
        {
            return true;
        }
        return false;
    }
    
    template<typename EVENT, typename CODE>
    void SendEvent(CODE code)
    {
		DEBUGPRINT(DEBUG_INFO,"FDA::ControlInputPointStateMachine::SendEvent::New event is created");
        auto event = std::make_shared<EVENT>(code);
        event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        auto parentZones = m_handler.GetParentZones();
        for(auto& parentZone : parentZones )
        {
            event->AddParent(Mol::DataType::ObjectReference{parentZone->GetID(), parentZone->GetObjectType()});
        }

        //@todo may need to added parent
        m_handler.SendEvent(event,PROC_ADDRESS::BROADCAST,true);
    }
    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_CONTROL_INPUT_POINT_H
