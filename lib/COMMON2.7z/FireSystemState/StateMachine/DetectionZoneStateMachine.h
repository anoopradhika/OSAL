/******************************************************************************//**
*
* @file   DetectionZoneStateMachine.h
* @brief  State handler for Detection zone.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_DETECTION_ZONE_H
#define FIRESYSTEM_STATE_MACHINE_DETECTION_ZONE_H

#include "DOL/Entities/Zone/DetectionZone.h"

#include "Mol/Events/DisablementEvent.h"
#include "LabelConfiguration/LabelConfiguration.h"

#include "boost/sml.hpp"
namespace fireSystemState
{
/**
*
@startuml
title Detection Zone state chart
[*] --> ZoneMain
state ZoneMain
state "Detection Zone State" as ZoneMain {
  state Determine_Initial_State
  state mEnabled as "Enabled"
  state TestMode
  state Disabled {
      [*] --> PermanentlyDisabled
      TimedDisabled --> PermanentlyDisabled : DisablePermanently(ZoneID)
      TimedDisabled --> mEnabled: TimedOut / \nAction: Send Enable(ZoneID)
      TimedDisabled -down-> mEnabled : Enable / \nAction: send EnableEvent(COMPLETED, ZoneID)
      PermanentlyDisabled --> TimedDisabled : DisableTemporary(ZoneID)
      PermanentlyDisabled -down-> mEnabled : Enable / \nAction: send EnableEvent(COMPLETED, ZoneID)
  }

  [*] -> Determine_Initial_State
  Determine_Initial_State --> PermanentlyDisabled: Based on last stored disable/enable state\n or from configuration data
  Determine_Initial_State --> mEnabled: Based on last stored disable/enable state\n or from configuration data
  mEnabled -up-> PermanentlyDisabled: DisablePermanently(ZoneID) / \nAction: send DisableEvent(COMPLETED, ZoneID))
  mEnabled -down-> TimedDisabled: DisableTemporary(ZoneID) / \nAction: send DisableEvent(COMPLETED, ZoneID))
  mEnabled: AlarmEvent(ALARM) / Action: Forward event to FireState
  mEnabled: AlarmEvent(DISABLED_ALARM) / Action: Forward event to DisabledFireState
  mEnabled: FaultEvent / Action: Forward event to FaultState
  Disabled: AlarmEvent(DISABLED_ALARM) / Action: Forward event to DisabledFireState
  TestMode--> mEnabled: TestModeOff
  mEnabled --> TestMode: TestModeOn[FireState==No Fire]
  TestMode: AlarmEvent(TEST_ALARM) / Action: Forward event to TestState
  TestMode: FaultEvent / Action: Forward event to FaultState

  --

  state FireState {
    state "No Fire" as e_fireNotDetected
    state "Fire(s)" as e_fireDetected
    [*] --> e_fireNotDetected
    e_fireNotDetected --> e_fireDetected: AlarmEvent(ALARM) / Increment AlarmCount
    e_fireDetected: AlarmEvent(ALARM) / Increment AlarmCount
    e_fireDetected: AlarmEvent(RETURN_FROM_ALARM) / Decrement AlarmCount
    e_fireDetected --> e_fireNotDetected: AlarmEvent(RETURN_FROM_ALARM)[AlarmCount==1] /\nDecrement AlarmCount
  }

  --

  state FaultState {
    state "No Fault" as t_faultNotDetected
    state "Fault(s)" as t_faultDetected
    [*] --> t_faultNotDetected
    t_faultNotDetected --> t_faultDetected: FaultEvent / Increment FaultCount
    t_faultDetected: FaultEvent / Increment FaultCount
    t_faultDetected: FaultCleared / Decrement FaultCount
    t_faultDetected --> t_faultNotDetected: FaultCleared[FaultCount==1] /\nDecrement FaultCount
  }

  --

  state TestState {
    state "No Fire" as t_fireNotDetected
    state "Test Fire(s)" as t_fireDetected
    [*] --> t_fireNotDetected
    t_fireNotDetected --> t_fireDetected: AlarmEvent(ALARM) / Increment AlarmCount
    t_fireDetected: AlarmEvent(TEST_ALARM) / Increment AlarmCount
    t_fireDetected: AlarmEvent(RETURN_FROM_ALARM) / Decrement AlarmCount
    t_fireDetected --> t_fireNotDetected: AlarmEvent(RETURN_FROM_ALARM)[AlarmCount==1] /\nDecrement AlarmCount
  }

  --

  state DisabledFireState {
    state "No Fire" as d_fireNotDetected
    state "Disabled Fire(s)" as d_fireDetected
    [*] --> d_fireNotDetected
    d_fireNotDetected --> d_fireDetected : AlarmEvent(DISABLED_ALARM) / Increment AlarmCount
    d_fireDetected: AlarmEvent(DISABLED_ALARM) / Increment AlarmCount
    d_fireDetected: AlarmEvent(RETURN_FROM_ALARM) / Decrement AlarmCount
    d_fireDetected --> d_fireNotDetected: AlarmEvent(RETURN_FROM_ALARM)[AlarmCount==1] /\nDecrement AlarmCount
  }
}

state MultiDependencyFireState {
  state "No Unconfirmed Fire" as c_noFire
  state "Unconfirmed Fire(s)" as c_unconfirmed
  state "Confirmed Fires" as c_fireDetected
  [*] --> c_noFire
  c_noFire -> c_unconfirmed: AlarmEvent(UNCONFIRMED, pointId) / Increment AlarmCount
  c_unconfirmed: AlarmEvent(UNCONFIRMED, pointId) / Increment AlarmCount
  c_unconfirmed: AlarmEvent(RETURN_FROM_ALARM, pointId) / Decrement AlarmCount
  c_unconfirmed --> c_noFire: AlarmEvent(RETURN_FROM_ALARM, pointId)[AlarmCount==1] / Decrement AlarmCount
  c_unconfirmed --> c_fireDetected : AlarmEvent(UNCONFIRMED, pointId)[AlarmCount==Threshold-1]  / Increment AlarmCount
  c_fireDetected: OnEntry / Send EventMultiDependencyTriggered(GroupID)
  c_fireDetected: OnExit / Send EventMultiDependencyReset(GroupID)
  c_fireDetected : AlarmEvent(RETURN_FROM_ALARM, pointId) / Decrement AlarmCount
  c_fireDetected --> c_noFire: AlarmEvent(RETURN_FROM_ALARM, pointId)[AlarmCount==1] / Decrement AlarmCount
}

@enduml
*/
template<typename Handler>
class DetectionZoneStateMachine
{
public:
    DetectionZoneStateMachine() = delete;

    DetectionZoneStateMachine(DetectionZoneStateMachine&& other) = delete;

    explicit DetectionZoneStateMachine(Handler& handler):
    m_handler(handler)
    {
    }

    ~DetectionZoneStateMachine() = default;

    DetectionZoneStateMachine(const DetectionZoneStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;
		using boost::sml::operator||;
		
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            SendZoneEnablementEvent(disablementEvent, Dol::Entities::Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED);
            Disable(disablementEvent);
        };

        auto PartialDisabledStateUpdate = [this](std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            SendZoneEnablementEvent(disablementEvent, Dol::Entities::Zone::DISABLEMENT_STATE::DISABLED);
            PartialDisable(disablementEvent);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable(disablementEvent);
        };

        const auto AlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessAlarm(alarmEvent);
        };
		
		const auto ForwardFirstAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessFirstAlarm(alarmEvent);
        };
		
		const auto ForwardFirstReturnAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessFirstRetAlarm(alarmEvent);
        };
		
		const auto PreAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessPreAlarm(alarmEvent);
        };

        const auto ReturnFromAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessReturnFromAlarm(alarmEvent);
        };
		
		const auto QuicentStateupdate = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ResetAllstates();
        };

        /*auto ResetCmdStateUpdate = [this] (std::shared_ptr<Mol::Command::Reset> resetCommand)
        {
            ProcessFireReset();
        };*/

        auto TestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestStart(testEvent);
        };

        auto TestAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> testAlarmEvent)
        {
            ProcessTestAlarm(testAlarmEvent);
        };

        auto EndZoneTestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestEnd(testEvent);
        };

        const auto IsZoneOrAllChildrenDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(IsZoneDisabled(disablementEvent))
            {
                return true;
            }
            else if(AreChildrenDisabled(disablementEvent))
            {
                return true;
            }
            return false;
        };

        const auto IsthisZoneDisablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(IsZoneDisablement(disablementEvent))
            {
                return true;
            }
            return false;
        };

        const auto IsthisZoneEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(IsZoneEnablement(disablementEvent))
            {
                return true;
            }
            return false;
        };

        const auto IsFireAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            return IsFireAlarmNotDetected(alarmEvent);
        };
		
		const auto IsFirstAlarmFromID3K = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            return IsFirstAlarmFromID3KAction(alarmEvent);
        };
		
		const auto IsTechAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            return IsTechAlarmNotDetected(alarmEvent);
        };

        const auto IsPreAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            return IsPreAlarmNotDetected(alarmEvent);
        };

        const auto IsZoneReturnFromAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            return IsZoneReturnFromAlarmCall(alarmEvent);
        };
		
		const auto IsLegacyPanel = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            return IsLegacyPanelcall();
        };

        ///@todo check config for reset behaviour
        /*const auto IsAlarmReset = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            auto code = reset->GetCommandCode();
            if(code == Mol::Command::RESET_TYPE_CODE::FIRE_ALARM || code == Mol::Command::RESET_TYPE_CODE::GENERAL)
            {
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsAlarmReset() true");
                return true;
            }
            return false;
        };*/

        const auto IsZoneTestStart = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            if(testEvent->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST)
            {
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsZoneTestStart() true");
                return true;
            }
            return false;
        };

        const auto IsZoneTestEnd = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            if(testEvent->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST)
            {
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsZoneTestEnd() true");
                return true;
            }
            return false;
        };

        const auto IsTestAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::TEST_ALARM)
            {
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsTestAlarm() true");
                return true;
            }
            return false;
        };
        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return OriginatedRemotePanelLost();
        };

        auto ProcessClearRemoteEvents = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
			DEBUGPRINT(DEBUG_ERROR,"DetectionZoneStateMachine:ProcessClearRemoteEvents Panel lost clearing messages");
            ClearFireWhenReachable();
            ClearTestWhenReachable();
            ClearDesiblementWhenReachable();
        };

        const auto IsZonePartialDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
           if (disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED)
           {
             DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateMachine: IsZoneDisabled() true");
             return true;
            }
        return false;
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        /* In quiescent state, "IsZoneOrAllChildrenDisabled" is checked, so that when this statemachine is called for point disablement and last point is disabled, zone will get disabled.
             @TODO: This implementation needs to be checked against "DisableZoneWithDisabledChildren" in FirePointStateMachine, because both are intended for zone disblement on last point disablement */

        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsZoneOrAllChildrenDisabled && IsthisZoneDisablement] / DisabledStateUpdate = "disabled"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [!IsZoneOrAllChildrenDisabled && IsthisZoneEnablement]/ EnabledStateUpdate = "quiescent"_s
       
        //ID3K Partial disablement
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>>        [IsZonePartialDisabled] / PartialDisabledStateUpdate = "Partialdisabled"_s
        ,"quiescent"_s       + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZonePartialDisabled] / PartialDisabledStateUpdate = "Partialdisabled"_s
        ,"Partialdisabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsthisZoneDisablement]/ DisabledStateUpdate = "disabled"_s
        ,"Partialdisabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsthisZoneEnablement]/ EnabledStateUpdate = "quiescent"_s
		
		//id3k first alarm
    	,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFirstAlarmFromID3K] / ForwardFirstAlarm = "firstalarm"_s
		,"firstalarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm || IsTechAlarm] / AlarmStateUpdate = "alarm"_s
		,"firstalarm"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsLegacyPanel && IsthisZoneDisablement]/ DisabledStateUpdate = "disabled"_s
		,"firstalarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsLegacyPanel] / QuicentStateupdate= "quiescent"_s
		,"firstalarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsZoneReturnFromAlarm] / ForwardFirstReturnAlarm = "quiescent"_s

        // Alarm Event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm || IsTechAlarm] / AlarmStateUpdate = "alarm"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsZoneReturnFromAlarm] / ReturnFromAlarmStateUpdate= "quiescent"_s
		,"alarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsLegacyPanel] / QuicentStateupdate= "quiescent"_s
		// Pre Alarm Event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsPreAlarm] / PreAlarmStateUpdate = "prealarm"_s
        ,"prealarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsZoneReturnFromAlarm] / ReturnFromAlarmStateUpdate= "quiescent"_s
		,"prealarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsLegacyPanel] / QuicentStateupdate= "quiescent"_s
	    ,"prealarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm || IsTechAlarm] / AlarmStateUpdate = "alarm"_s
        //Reset command need not be handled as it will cause a return to quiescent mode and RetrunFromAlarm will not be handled
        //,"alarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsAlarmReset] / ResetCmdStateUpdate = "quiescent"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsZoneOrAllChildrenDisabled && ! IsthisZoneDisablement]/ DisabledStateUpdate = "disabled"_s
        ,"prealarm"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsZoneOrAllChildrenDisabled && ! IsthisZoneDisablement]/ DisabledStateUpdate = "disabled"_s
	
        // Coincidence Handling
//      ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFirstAlarm] / FirstAlarmStateUpdate = "FirstAlarm"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm || IsTechAlarm] / AlarmStateUpdate = "FirstAlarm"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "quiescent"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsAlarmReset] / ResetCmdStateUpdate = "quiescent"_s

        // Test mode event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestStart] / TestStateUpdate = "test"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsTestAlarm] / TestAlarmStateUpdate = "test_alarm"_s
        ,"test_alarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsTestAlarm] / TestAlarmStateUpdate = "test_alarm"_s
        ,"test_alarm"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestEnd] / EndZoneTestStateUpdate = "quiescent"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestEnd] / EndZoneTestStateUpdate = "quiescent"_s

        //Networked Panels - Node Failure Scenario https://acsjira.honeywell.com/browse/FUSION-4514
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"test_alarm"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
		,"firstalarm"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset>> / ProcessClearRemoteEvents = "quiescent"_s


        );
    }

protected:

    bool IsZoneDisabled(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        auto source = disablementEvent->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return false;
        }
#endif
        if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsZoneDisabled() true");
            return true;
        }
        return false;
    }
    bool IsZoneDisablement(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
        {
            auto source = disablementEvent->GetSource();
#ifndef UT_TARGET
            if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
#endif
            {
                return true;
            }

        }
        return false;
    }

    bool IsZoneEnablement(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
        {
            auto source = disablementEvent->GetSource();
            if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
            {
                return true;
            }

        }
        return false;
    }

    bool AreChildrenDisabled(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        auto source = disablementEvent->GetSource();
#ifndef UT_TARGET
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
#endif
        {
            return false;
        }
        return m_handler.AreChildrenDisabled();
    }

    bool IsZoneReturnFromAlarmCall(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM)
        {
            if (alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::FIRE    ||
			   (alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS))
            {
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsZoneReturnFromAlarm() true");
                return (!m_handler.AreChildrenInAlarm());
            }
        }
        return false;
    };

	bool IsLegacyPanelcall()
    {
		if(Utility::GetEventResetMode()== EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)
		{
			return true;
		}
        return false;
    };

    bool IsFireAlarmNotDetected(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::ALARM)
        {
        	if (alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::FIRE)
        	{
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsFireAlarm() true");
                return (!m_handler.IsFireDetected());
        	}
        }
        return false;
    };
	
	bool IsFirstAlarmFromID3KAction(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(IsItfromLegacyPanel(alarmEvent) && alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::FIRST_ALARM)
        {
        	if (alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::FIRE
			    || alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS)
        	{
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsFirstAlarmFromID3KAction");			
				return true;
        	}
        }
        return false;
    };
	
    bool IsTechAlarmNotDetected(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::ALARM)
        {
        	if (alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS)
        	{
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsTechAlarm() true");
                return (!m_handler.IsTechAlarmDetected()); 
        	}
        }
        return false;
    };
	
	bool IsPreAlarmNotDetected(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::PRE_ALARM)
        {
        	if (alarmEvent->GetEventApplication() == Mol::Event::EVENT_APPLICATION::FIRE)
        	{
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: IsPreAlarmNotDetected() true");
                return (!m_handler.IsPreAlarmDetected());
        	}
        }
        return false;
    };

    void Enable(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: Enable()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::ENABLED);
        if(!IsItMine(disablementEvent))
        {
            auto zoneDisablementEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
            zoneDisablementEvent->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
            zoneDisablementEvent->SetEventApplication(disablementEvent->GetEventApplication());

            auto parent = Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()};
            zoneDisablementEvent->AddParent(parent);

            std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(),m_handler.GetObjectType());
            Dol::Label dolLabel;
            dolLabel.SetLabel(label);
            dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
            zoneDisablementEvent->AddLabel(dolLabel);
            m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::FIRE_DOMAIN_APP, true);
            m_handler.lastZoneDisablementEvent = nullptr;
            return;
        }
        m_handler.SendEvent(disablementEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastZoneDisablementEvent = nullptr;

    }

    void Disable(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: Disable()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::DISABLED);
        if (!IsItMine(disablementEvent))
        {
            /* This condition is added to check if the event is from point. In this case, we are executing this only when all children are disabled
            Hence this will send zone disablement for last point disablement */
            //@TODO: This part of code is suspected to be a dead code currently because of condition "IsThisZoneDisablement". This needs to be checked in future

            auto zoneDisablementEvent = std::make_shared < Mol::Event::DisablementEvent > (Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
            zoneDisablementEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
            zoneDisablementEvent->SetEventApplication(disablementEvent->GetEventApplication());

            auto parent = Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() };
            zoneDisablementEvent->AddParent(parent);

            std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(),m_handler.GetObjectType());
            Dol::Label dolLabel;
            dolLabel.SetLabel(label);
            dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
            zoneDisablementEvent->AddLabel(dolLabel);
            m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::FIRE_DOMAIN_APP, true);
            m_handler.lastZoneDisablementEvent = zoneDisablementEvent;
            return;
        }
        m_handler.SendEvent(disablementEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastZoneDisablementEvent = disablementEvent;
    }

    void SendZoneEnablementEvent(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent, Dol::Entities::Zone::DISABLEMENT_STATE checkState)
    {
        /* Here we need to Send Enable Event first to HMI & EVENT PROVIDER to clear the Current disablement.
        Then send the new Disablement Event. This will prevent duplicate entries in those applications */
        if(m_handler.GetDisablement() == checkState)
        {
            if(IsItMine(disablementEvent))
            {
                DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: SendZoneEnablementEvent()");

                auto srcId = disablementEvent->GetSource().GetObjectId();
                auto srcType = disablementEvent->GetSource().GetObjectType();
                auto zoneEnablementEvent = std::make_shared < Mol::Event::DisablementEvent > (Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
                zoneEnablementEvent->SetSource(Mol::DataType::ObjectReference { srcId, srcType });
                zoneEnablementEvent->SetEventApplication(disablementEvent->GetEventApplication());

                auto parents = disablementEvent->GetParents();
                for(auto &parent : parents)
                {
                    zoneEnablementEvent->AddParent(parent);
                }

                auto labels = disablementEvent->GetLabels();
                for(auto &label : labels)
                {
                    zoneEnablementEvent->AddLabel(label);
                }

                // Send the Events to HMI, Event Provider and Dragon
                m_handler.SendEvent(zoneEnablementEvent, PROC_ADDRESS::NETWORK, true);
                m_handler.SendEvent(zoneEnablementEvent, PROC_ADDRESS::EVENT_PROVIDERAPP, true);
                m_handler.SendEvent(zoneEnablementEvent, PROC_ADDRESS::MOL_RECEIVER, true);
            }
        }
    }

    void PartialDisable(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateMachine: Disable()");
        m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::PARTIALLY_DISABLED);
        if (!IsItMine(disablementEvent))
        {
            auto zoneDisablementEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::PARTIALLY_DISABLED);
            zoneDisablementEvent->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
            zoneDisablementEvent->SetEventApplication(disablementEvent->GetEventApplication());

            auto parent = Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()};
            zoneDisablementEvent->AddParent(parent);

            std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(), m_handler.GetObjectType());
            Dol::Label dolLabel;
            dolLabel.SetLabel(label);
            dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
            zoneDisablementEvent->AddLabel(dolLabel);
            m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::FIRE_DOMAIN_APP, true);
            m_handler.lastZoneDisablementEvent = zoneDisablementEvent;
            return;
        }
        m_handler.SendEvent(disablementEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastZoneDisablementEvent = disablementEvent;
    }

    void ProcessAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
    {		
        DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateMachine: ProcessAlarm()");
        if (ProcessNetworkAlarm(event) && !IsitFusionNetworkAlarm(event) && !m_handler.IsFireDetected()) //FDA should create and send zone alarm for 
        {                                                                 //Fusion to Fusion network, and local point fire
		    return;                                                       //by network module, for legacy(ID3K) panel not required
        }
		
		if (event->GetEventApplication() == Mol::Event::EVENT_APPLICATION::FIRE)
        {
           // Send zone in fire event
            m_handler.SetFireDetected(true);
        }
        else if(event->GetEventApplication() == Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS)
        {
            m_handler.SetTechAlarmDetected(true);
        }
        else
        {
            //Do nothing
        }
		
        // Send zone in fire event
        auto alarmEvent = std::make_shared < Mol::Event::AlarmEvent > (Mol::Event::ALARM_EVENT_CODE::ALARM);
        alarmEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        alarmEvent->SetEventApplication(event->GetEventApplication());
        std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(),m_handler.GetObjectType());
        Dol::Label dolLabel;
        dolLabel.SetLabel(label);
        dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
        alarmEvent->AddLabel(dolLabel);//parent
        for(auto parent: event->GetParents())
        {
            alarmEvent->AddParent(parent);
        }

        //Add dependency type and discription parameter to zone fire
        std::vector<Mol::DataType::Parameter> parameters = event->GetParameters();
        try
        {
            for (auto &iterator: parameters )
            {
                if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DEPENDENCY_TYPE)
                {
					 auto str = iterator.GetValue<std::string>();
                    if(str == "A" || str == "B" || str == "C" )
                    {
                        alarmEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DEPENDENCY_TYPE,str);
                    }
                }
                
                if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
                {
                  auto strg = iterator.GetValue<std::string>();
                  
                  alarmEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION,strg);
                }
                
            }
        }
        catch (...)
        {
            DEBUGPRINT(DEBUG_ERROR,"FDA::DetectionZoneStateMachine::ProcessAlarm Failed to get parameter value");
        }
		
        m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastAlarmEvent = nullptr;
        m_handler.lastAlarmEvent = alarmEvent;
    }
	
	void ProcessFirstAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
	{
        std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(),m_handler.GetObjectType());
        Dol::Label dolLabel;
        dolLabel.SetLabel(label);
        dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
        event->AddLabel(dolLabel);//parent
		m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastAlarmEvent = nullptr;
        m_handler.lastAlarmEvent = event;
	}
	
	void ProcessFirstRetAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
	{
        std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(),m_handler.GetObjectType());
        Dol::Label dolLabel;
        dolLabel.SetLabel(label);
        dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
        event->AddLabel(dolLabel);//parent
		m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastAlarmEvent = nullptr;
	}
	
	void ProcessPreAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateMachine: ProcessPreAlarm()");
        if (ProcessNetworkAlarm(event) && !IsitFusionNetworkPreAlarm(event) && !m_handler.IsPreAlarmDetected())
        {
            return;
        }
        // Send zone in fire event
        m_handler.SetPreAlarmDetected(true);
        auto prealarmEvent = std::make_shared < Mol::Event::AlarmEvent > (Mol::Event::ALARM_EVENT_CODE::PRE_ALARM);
        prealarmEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        prealarmEvent->SetEventApplication(event->GetEventApplication());
        std::string label = m_lableHandle.FindZoneLabel(m_handler.GetID(),m_handler.GetObjectType());
        Dol::Label dolLabel;
        dolLabel.SetLabel(label);
        dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
        prealarmEvent->AddLabel(dolLabel);//parent
        for(auto parent: event->GetParents())
        {
            prealarmEvent->AddParent(parent);
        }

        //Add dependency type and description parameter to zone fire
        std::vector<Mol::DataType::Parameter> parameters = event->GetParameters();
        try
        {
            for (auto &iterator: parameters )
            {
                if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DEPENDENCY_TYPE)
                {
				    auto str = iterator.GetValue<std::string>();
                    if(str == "A" || str == "B" || str == "C" )
                    {
                        prealarmEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DEPENDENCY_TYPE,str);
                    }
                }
               
                if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
                {
                   auto strg = iterator.GetValue<std::string>();
                  
                   prealarmEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION,strg);
                }
                
            }
        }
        catch (...)
        {
            DEBUGPRINT(DEBUG_ERROR,"FDA::DetectionZoneStateMachine::ProcessAlarm Failed to get parameter value");
        }

        m_handler.SendEvent(prealarmEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastAlarmEvent = nullptr;
        m_handler.lastAlarmEvent = prealarmEvent;
    }

    void ProcessReturnFromAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
    {
        if (ProcessNetworkAlarm(event) && !IsitFusionNetworkAlarm(event))
        {
            return;
        }
        DEBUGPRINT(DEBUG_INFO, "DetectionZoneStateMachine: ProcessReturnFromAlarm()");
        m_handler.SetFireDetected(false);
		m_handler.SetPreAlarmDetected(false);
		m_handler.SetTechAlarmDetected(false);
        auto alarmEvent = std::make_shared < Mol::Event::AlarmEvent > (Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM);
        alarmEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        alarmEvent->SetEventApplication(event->GetEventApplication());
        for(auto parent: event->GetParents())
        {
            alarmEvent->AddParent(parent);
        }
        
       //Add dependency type and description parameter to zone fire
        std::vector<Mol::DataType::Parameter> parameters = event->GetParameters();
        try
        {
            for (auto &iterator: parameters )
            {
                if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DEPENDENCY_TYPE)
                {
				    auto str = iterator.GetValue<std::string>();
                    if(str == "A" || str == "B" || str == "C" )
                    {
                        alarmEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DEPENDENCY_TYPE,str);
                    }
                }
               
                if(iterator.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
                {
                   auto strg = iterator.GetValue<std::string>();
                  
                   alarmEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION,strg);
                }
                
            }
        }
        catch (...)
        {
            DEBUGPRINT(DEBUG_ERROR,"FDA::DetectionZoneStateMachine::ProcessReturnfromAlarm Failed to get parameter value");
        }
    
        m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastAlarmEvent = nullptr;

    }
	
	void ResetAllstates()
	{
		m_handler.SetFireDetected(false);
		m_handler.SetPreAlarmDetected(false);
		m_handler.SetTechAlarmDetected(false);
		m_handler.lastAlarmEvent = nullptr;
	}

    bool ProcessNetworkAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
    {
        if(IsItFromNetwork(event) && ! IsItMine(event))
        {
            return true;
        }
        if(IsItFromNetwork(event) && IsItMine(event) && !m_handler.IsFireDetected())
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: ProcessAlarm() it is from network, just broadcast locally");
			
			auto code = event->GetEventCode();
			auto app = event->GetEventApplication();

			if((Mol::Event::ALARM_EVENT_CODE::ALARM == code) && (Mol::Event::EVENT_APPLICATION::FIRE == app))
			{
                m_handler.SetFireDetected(true);
			}
			else if((Mol::Event::ALARM_EVENT_CODE::PRE_ALARM == code) && (Mol::Event::EVENT_APPLICATION::FIRE == app))
			{
                m_handler.SetPreAlarmDetected(true);
			}
			else if((Mol::Event::ALARM_EVENT_CODE::ALARM == code) && (Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS == app))
			{
                m_handler.SetTechAlarmDetected(true);
			}
            else
            {
                //Do nothing
            }
			
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastAlarmEvent = nullptr;
            m_handler.lastAlarmEvent = event;
            return true;
        }

		else if(IsItFromNetwork(event) && IsItMine(event) && (Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM == event->GetEventCode()))
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: ProcessAlarm()..for return from alarm it is from network, just broadcast locally");

			m_handler.SetFireDetected(false);
			m_handler.SetPreAlarmDetected(false);
			m_handler.SetTechAlarmDetected(false);
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastAlarmEvent = nullptr;
            m_handler.lastAlarmEvent = event;
            return true;
        }
        return false;
    }

    bool IsitFusionNetworkAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
    {
        if(IsItMyZone(event) && IsItFromNetwork(event) && !IsItfromLegacyPanel(event))
        {
            return true;
        }
		return false;
    }
	
	bool IsitFusionNetworkPreAlarm(std::shared_ptr<Mol::Event::AlarmEvent> event)
    {
        if(IsItMyZone(event) && IsItFromNetwork(event) && !IsItfromLegacyPanel(event))
        {
            return true;
        }
		return false;
    }

    void ProcessFireReset()
    {
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: ProcessFireReset()");
        m_handler.SetFireDetected(false);
    }

    void ProcessTestStart(std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: ProcessTestStart()");
        m_handler.SetUnderTest(true);
        m_handler.SendEvent(testEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastTestEvent = nullptr;
        m_handler.lastTestEvent = testEvent;
    }

    void ProcessTestAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: ProcessTestAlarm()");
        if(!m_handler.IsFireDetected())
        {
            DEBUGPRINT(DEBUG_INFO,"DetectionZoneStateMachine: ProcessTestAlarm()");
            // Send zone in fire event
            m_handler.SetFireDetected(true);
        }
        auto source = alarmEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastAlarmEvent = nullptr;
            m_handler.lastAlarmEvent = alarmEvent;
        }
    }

    void ProcessTestEnd(std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
    {
        m_handler.SetUnderTest(false);
        m_handler.SetFireDetected(false);
        m_handler.SendEvent(testEvent, PROC_ADDRESS::BROADCAST, true);
        m_handler.lastTestEvent = nullptr;
    }

    void ClearDesiblementWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"ClearDesiblementWhenReachable: m_handler.IsDisabled()[{0}]",static_cast<int>(m_handler.IsDisabled()));
        if(nullptr != m_handler.lastZoneDisablementEvent && m_handler.IsDisabled())
        {
            auto event = CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>(m_handler.lastZoneDisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
            m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            m_handler.SetDisablement(Dol::Entities::Zone::DISABLEMENT_STATE::ENABLED);
            m_handler.ClearRemotePanelLost();
            DEBUGPRINT(DEBUG_INFO,"FPSM:ClearDesiblementWhenReachable SendEvent: Zone DISABLEMENT_EVENT_CODE::ENABLED");
        }
    }

    void ClearFireWhenReachable()//
    {
        DEBUGPRINT(DEBUG_INFO,"ClearFireWhenReachable: m_handler.IsFireDetected()[{0}]",static_cast<int>(m_handler.IsFireDetected()));
        if((m_handler.IsFireDetected()) || (m_handler.IsPreAlarmDetected()) || (m_handler.IsTechAlarmDetected()))
        {
            m_handler.SetFireDetected(false);
			m_handler.SetPreAlarmDetected(false);
			m_handler.SetTechAlarmDetected(false);
			
            if(nullptr != m_handler.lastAlarmEvent)
            {
                auto event = CreateEventFromEvent<Mol::Event::AlarmEvent, Mol::Event::AlarmEvent, Mol::Event::ALARM_EVENT_CODE>(m_handler.lastAlarmEvent, Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM);
                m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
                m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);
                m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            }
        }
    }

    void ClearTestWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"ClearTestWhenReachable:m_handler.UnderTest[{0}]",static_cast<int>(m_handler.IsUnderTest()));
        if(nullptr != m_handler.lastTestEvent)
        {
            auto event = CreateEventFromEvent<Mol::Event::TestOperationEvent,Mol::Event::TestOperationEvent,Mol::Event::TEST_OPERATION_EVENT_CODE>(m_handler.lastTestEvent, Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST);
            m_handler.SendEvent(event, PROC_ADDRESS::FIRE_DOMAIN_APP, true);//update Detection Zone State Handler
            m_handler.SetUnderTest(false);
            m_handler.lastTestEvent = nullptr;
            DEBUGPRINT(DEBUG_INFO,"FPSM:ClearTestAndDesiblementWhenReachable SendEvent: ZONE_REMOVED_FROM_TEST");
        }
    }

    template<typename Message>
    bool IsItFromNetwork(Message message)
    {
        auto parameters = message->GetParameters();
        std::string discription;
        for(auto& parameter : parameters)
        {
            if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
            {
                if(parameter.template GetValue<std::string>() == "ID2NET_Network")
                {
                    return true;
                }
            }
        }
        return false;
    }
	
	template<typename Message>
    bool IsItfromLegacyPanel(Message message)
    {
        auto parameters = message->GetParameters();
        std::string discription;
        for(auto& parameter : parameters)
        {
            if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
            {
                if(parameter.template GetValue<std::string>() == "Legacy")
                {
                    return true;
                }
            }
        }
        return false;
    }


    template<typename EventType>
    bool IsItMine(EventType event)
    {
        auto source = event->GetSource();
#ifndef UT_TARGET
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return true;
        }
#endif
        return false;
    }
	
	template<typename EventType>
    bool IsItMyZone(EventType event)
    {
        auto parents = event->GetParents();
#ifndef UT_TARGET
        for(auto& parent : parents)
        {
            if( parent.GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE)
            {
                if(parent.GetObjectId() == m_handler.GetID())
                {
                    return true;
                }
            }
        }
#endif
        return false;
    }

    bool  OriginatedRemotePanelLost()
    {
        return m_handler.OriginatedRemotePanelLost();
    }

    fireSystemState::LabelConfigurationHandle &m_lableHandle = fireSystemState::LabelConfigurationHandle::GetInstance();

private:

    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_DETECTION_ZONE_H
