/******************************************************************************//**
*
* @file   ConfirmationInputStateMachine.h
* @brief  State machine for Confirmation Input.
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_CONFIRMATION_INPUT_H
#define FIRESYSTEM_STATE_CONFIRMATION_INPUT_H

#include "Mol/Events/DisablementEvent.h"

#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class ConfirmationInputStateMachine
{
public:
    ConfirmationInputStateMachine() = delete;

    ConfirmationInputStateMachine(ConfirmationInputStateMachine&& other) = delete;

    explicit ConfirmationInputStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~ConfirmationInputStateMachine() = default;
    ConfirmationInputStateMachine(const ConfirmationInputStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Disable(disablementEvent);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable(disablementEvent);
        };

        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            return (disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsDisabled]/ DisabledStateUpdate = "disabled"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [!IsDisabled]/ EnabledStateUpdate = "quiescent"_s
        );
    }

protected:
    void Enable(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        m_handler.SetDisabled(false);
        SendEvent(disablementEvent);
    }
    void Disable(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        m_handler.SetDisabled(true);
        SendEvent(disablementEvent);
    }

    void SendEvent(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        m_handler.SendEvent(disablementEvent,PROC_ADDRESS::BROADCAST,true);
    }
    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_CONFIRMATION_INPUT_H
