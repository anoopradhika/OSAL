/******************************************************************************//**
*
* @file   FaultInputStateMachine.h
* @brief  State handler for Fire point.
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_FAULT_INPUT_H
#define FIRESYSTEM_STATE_MACHINE_FAULT_INPUT_H

#include "DOL/Entities/Zone/AlarmZone.h"

#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Commands/Reset.h"

#include "boost/sml.hpp"
namespace fireSystemState
{
/**
*@startuml
[*] --> QuiescentState
QuiescentState: DeviceAlarmSignal /\Generate Event From Parent Zone State (See flowchart)
QuiescentState --> Disabled: Disable(PointID)
QuiescentState --> DisabledAlarm: AlarmEvent(DISABLED_ALARM)
Disabled: DeviceAlarmSignal / Generate AlarmEvent(DISABLED_ALARM)
Disabled --> DisabledAlarm: AlarmEvent(DISABLED_ALARM)
Disabled --> QuiescentState: Enable(PointId)
DisabledAlarm: Reset / If device is out of alarm, send RETURN_FROM_ALARM
DisabledAlarm --> Disabled: AlarmEvent(RETURN_FROM_ALARM)
DisabledAlarm --> QuiescentState: Enable(PointId) [Parent Zone disabled== false]
DisabledAlarm --> QuiescentState: Enable(ParentZoneId) [Point disabled== false]
QuiescentState --> TestAlarm: AlarmEvent(TEST_ALARM)
TestAlarm: Reset / If device is out of alarm, send AlarmEvent(RETURN_FROM_ALARM)
TestAlarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
TestAlarm --> QuiescentState: TestModeOff(ParentZoneID)
QuiescentState --> ConfirmingAlarm: AlarmEvent(UNCONFIRMED)
ConfirmingAlarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm --> Alarm: AlarmEvent(ALARM)
ConfirmingAlarm: AlarmSignalFromDevice[Reset Timer is running] / Send AlarmEvent(ALARM)
ConfirmingAlarm: MultiDependencyThresholdReached(GroupID) / Send AlarmEvent(ALARM)
ConfirmingAlarm: Reset Time Expired / Send AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm: Reset / send AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm --> Disabled: Disable(PointId) / Stop Reset Timer and send AlarmEvent(RETURN_FROM_ALARM)
Alarm --> DisabledAlarm: Disable(PointId) / AlarmEvent(RETURN_FROM_ALARM)
QuiescentState --> Alarm: AlarmEvent(ALARM)
Alarm: Reset / If device is out of alarm, send AlarmEvent(RETURN_FROM_ALARM)
Alarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
Alarm --> DisabledAlarm: Disable(Parent Zone Id) [check config] / AlarmEvent(RETURN_FROM_ALARM)
@enduml
*/

namespace FISMEvent
{
struct ZoneDisabled{};
struct PointDisabled{};
}

template<typename Handler>
class FaultInputStateMachine
{
public:
    FaultInputStateMachine() = delete;

    FaultInputStateMachine(FaultInputStateMachine&& other) = delete;

    explicit FaultInputStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~FaultInputStateMachine() = default;
    FaultInputStateMachine(const FaultInputStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
        using boost::sml::operator""_s;
        using boost::sml::v1_1_2::event;

        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> event, auto &sm, auto &deps, auto &subs)
        {
            std::cout<<"FPSM:DisabledStateUpdate disablement: "<< std::hex << GetID() <<std::endl;
            std::cout<<"FPSM:DisabledStateUpdate disablement: "<< std::hex << event->GetSource().GetObjectId() <<" Type: "<<(int)event->GetSource().GetObjectType() << std::endl;
            if(IsEventFromPoint(event))
            {
                std::cout<<"FPSM:DisabledStateUpdate point disablement: "<< std::hex << GetID() <<std::endl;
                Disable(event);
                sm.process_event(FISMEvent::PointDisabled{}, deps, subs);
                return;
            }
            else if(IsEventFromParent(event))
            {
                // process zone disablement
                std::cout<<"FPSM:DisabledStateUpdate zone disablement: "<< std::hex << GetID() <<std::endl;
                sm.process_event(FISMEvent::ZoneDisabled{}, deps, subs);
                m_handler.lastZoneDisablementEvent = nullptr;
                m_handler.lastZoneDisablementEvent = event;
                return;
            }
            else
            {
                // do nothing
            }
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable(disablementEvent);
        };


        auto ClearDesiblementWhenReachableUpdate = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ClearDesiblementWhenReachable();
        };


        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"FPSM:IsDisabled true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
                return false;
        };

        const auto IsZoneDisablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"FPSM:IsZoneDisablement true : "<< std::hex << GetID() <<std::endl;
                return IsEventFromParent(disablementEvent);
            }
                return false;
        };

        const auto IsZoneEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"FPSM:IsZoneEnablement true : "<< std::hex << GetID() <<std::endl;
                return IsEventFromParent(disablementEvent);
            }
                return false;
        };

        const auto IsPointEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"FPSM:IsZoneEnablement true : "<< std::hex << GetID() <<std::endl;
                return (IsEventFromPoint(disablementEvent) || IsEventFromParent(disablementEvent));
            }
                return false;
        };

        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return IsItMyPanelFailure(faultEvent,GetmyPanelObjectRef());
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsDisabled]/ DisabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<FISMEvent::ZoneDisabled> = "zone_disabled"_s
        ,"quiescent"_s + event<FISMEvent::PointDisabled> = "point_disabled"_s

        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZoneEnablement] = "quiescent"_s

        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsPointEnablement]/ EnabledStateUpdate = "quiescent"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZoneDisablement]/ EnabledStateUpdate = "zone_disabled"_s

        //Networked Panels - Node Failure Scenario https://acsjira.honeywell.com/browse/FUSION-4514
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset>> / ClearDesiblementWhenReachableUpdate = "quiescent"_s

        );
    }

protected:

    bool IsEventFromParent(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        return m_handler.IsEventFromParent(event->GetSource());
    }

    bool IsEventFromPoint(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        if((event->GetSource().GetObjectId() == m_handler.GetID()) && (event->GetSource().GetObjectType() == m_handler.GetConcreteObjectType()))
        {
            return true;
        }
        return false;
    }

    bool IsitMine(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        auto source = disablementEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return true;
        }
        return false;
    }

    uint64_t GetID()
    {
        return m_handler.GetID();
    }

    std::shared_ptr<Mol::Event::DisablementEvent> CreatSendEnablementEvent(std::shared_ptr<Mol::Event::DisablementEvent> event, Mol::Event::DISABLEMENT_EVENT_CODE code)
    {
        auto pointDisablementEvent = std::make_shared < Mol::Event::DisablementEvent > (code);
        pointDisablementEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        pointDisablementEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);

        auto parentZones = m_handler.GetParentZones();
        for (auto &parentZone : parentZones)
        {
            pointDisablementEvent->AddParent(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });
        }
        auto labels = event->GetLabels();
        for (auto &label : labels)
        {
            pointDisablementEvent->AddLabel(label);
        }
        m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::BROADCAST, true);
        return pointDisablementEvent;
    }

    void Enable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FaultInputStateMachine: Enable : for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetDisabled(false);
        if (!IsitMine(event))
        {
            CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
            return;
        }
        m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
    }

    void Disable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FaultInputStateMachine: Disable : for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetDisabled(true);
        if (!IsitMine(event))
        {
            m_handler.lastPointDisablementEvent = nullptr;
            m_handler.lastPointDisablementEvent = CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);;
            return;
        }
        else
        {
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastZoneDisablementEvent = nullptr;
            m_handler.lastZoneDisablementEvent = event;
        }
    }

    void ClearDesiblementWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"ClearDesiblementWhenReachable: m_handler.IsDisabled()[{0}]",static_cast<int>(m_handler.IsDisabled()));
        if(m_handler.IsDisabled())
        {
            m_handler.SetDisabled(false);
            if(nullptr != m_handler.lastPointDisablementEvent)
            {
                auto event = CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>(m_handler.lastPointDisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
                m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
                m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
                m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
                DEBUGPRINT(DEBUG_INFO,"FPSM:ClearDesiblementWhenReachable SendEvent: Point DISABLEMENT_EVENT_CODE::ENABLED");
            }
        }
        if(nullptr != m_handler.lastZoneDisablementEvent)
        {
            auto event = CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>(m_handler.lastZoneDisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
            m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            DEBUGPRINT(DEBUG_INFO,"FPSM:ClearDesiblementWhenReachable SendEvent: Zone DISABLEMENT_EVENT_CODE::ENABLED");
        }
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return m_handler.GetmyObjectRef();
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_handler.GetmyPanelObjectRef();
    }
private:

    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_FAULT_INPUT_H
