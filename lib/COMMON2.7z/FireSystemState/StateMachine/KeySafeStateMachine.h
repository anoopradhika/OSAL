/******************************************************************************//**
*
* @file   KeySafeStateMachine.h
* @brief  State machine for key safe point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef FIRESYSTEM_STATE_MACHINE_KEY_SAFE_H
#define FIRESYSTEM_STATE_MACHINE_KEY_SAFE_H

#include "Mol/Events/DisablementEvent.h"
#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class KeySafeStateMachine
{
public:
    KeySafeStateMachine() = delete;

    KeySafeStateMachine(KeySafeStateMachine&& other) = delete;

    explicit KeySafeStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~KeySafeStateMachine() = default;
    KeySafeStateMachine(const KeySafeStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator!;
        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Activate(activation);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
        {
            Deactivate(deactivation);
        };

        const auto IsUnlocked = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            return (activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsUnlocked]/ ActivatedStateUpdate = "unlocked"_s
        ,"unlocked"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [!IsUnlocked]/ DeactivatedStateUpdate = "quiescent"_s
        );
    }

protected:

    void Activate(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
        m_handler.SetLockStatus(false);
        m_handler.SendEvent(activation,PROC_ADDRESS::BROADCAST,true);
    }

    void Deactivate(std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
    {
        m_handler.SetLockStatus(true);
        m_handler.SendEvent(deactivation,PROC_ADDRESS::BROADCAST,true);
    }

    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_KEY_SAFE_H
