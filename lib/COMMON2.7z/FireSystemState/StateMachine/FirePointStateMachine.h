/******************************************************************************//**
*
* @file   FirePointStateMachine.h
* @brief  State handler for Fire point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_FIRE_POINT_H
#define FIRESYSTEM_STATE_MACHINE_FIRE_POINT_H

#include "DOL/Entities/Zone/AlarmZone.h"

#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Commands/Reset.h"
#include "LabelConfiguration/LabelConfiguration.h"

#include "boost/sml.hpp"
namespace fireSystemState
{
/**
*@startuml
[*] --> QuiescentState
QuiescentState: DeviceAlarmSignal /\Generate Event From Parent Zone State (See flowchart)
QuiescentState --> Disabled: Disable(PointID)
QuiescentState --> DisabledAlarm: AlarmEvent(DISABLED_ALARM)
Disabled: DeviceAlarmSignal / Generate AlarmEvent(DISABLED_ALARM)
Disabled --> DisabledAlarm: AlarmEvent(DISABLED_ALARM)
Disabled --> QuiescentState: Enable(PointId)
DisabledAlarm: Reset / If device is out of alarm, send RETURN_FROM_ALARM
DisabledAlarm --> Disabled: AlarmEvent(RETURN_FROM_ALARM)
DisabledAlarm --> QuiescentState: Enable(PointId) [Parent Zone disabled== false]
DisabledAlarm --> QuiescentState: Enable(ParentZoneId) [Point disabled== false]
QuiescentState --> TestAlarm: AlarmEvent(TEST_ALARM)
TestAlarm: Reset / If device is out of alarm, send AlarmEvent(RETURN_FROM_ALARM)
TestAlarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
TestAlarm --> QuiescentState: TestModeOff(ParentZoneID)
QuiescentState --> ConfirmingAlarm: AlarmEvent(UNCONFIRMED)
ConfirmingAlarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm --> Alarm: AlarmEvent(ALARM)
ConfirmingAlarm: AlarmSignalFromDevice[Reset Timer is running] / Send AlarmEvent(ALARM)
ConfirmingAlarm: MultiDependencyThresholdReached(GroupID) / Send AlarmEvent(ALARM)
ConfirmingAlarm: Reset Time Expired / Send AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm: Reset / send AlarmEvent(RETURN_FROM_ALARM)
ConfirmingAlarm --> Disabled: Disable(PointId) / Stop Reset Timer and send AlarmEvent(RETURN_FROM_ALARM)
Alarm --> DisabledAlarm: Disable(PointId) / AlarmEvent(RETURN_FROM_ALARM)
QuiescentState --> Alarm: AlarmEvent(ALARM)
Alarm: Reset / If device is out of alarm, send AlarmEvent(RETURN_FROM_ALARM)
Alarm --> QuiescentState: AlarmEvent(RETURN_FROM_ALARM)
Alarm --> DisabledAlarm: Disable(Parent Zone Id) [check config] / AlarmEvent(RETURN_FROM_ALARM)
@enduml
*/

namespace FPSMEvent
{
struct ZoneDisabled{};
struct PointDisabled{};
}

template<typename Handler>
class FirePointStateMachine
{
public:
    FirePointStateMachine() = delete;

    FirePointStateMachine(FirePointStateMachine&& other) = delete;

    explicit FirePointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~FirePointStateMachine() = default;
    FirePointStateMachine(const FirePointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;

        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> event, auto &sm, auto &deps, auto &subs)
        {
            std::cout<<"FPSM:DisabledStateUpdate disablement - Object ID: "<< std::hex << GetID() <<std::endl;
            std::cout<<"FPSM:DisabledStateUpdate disablement - Event Object ID: "<< std::hex << event->GetSource().GetObjectId() <<" Type: "<<(int)event->GetSource().GetObjectType() << std::endl;
            if(IsEventFromPoint(event))
            {
                std::cout<<"FPSM:DisabledStateUpdate point disablement: "<< std::hex << GetID() <<std::endl;
                Disable(event);
                DisableZoneWithDisabledChildren(event);
                sm.process_event(FPSMEvent::PointDisabled{}, deps, subs);
                return;
            }
            else if(IsEventFromParent(event))
            {
                // process zone disablement
                std::cout<<"FPSM:DisabledStateUpdate zone disablement: "<< std::hex << GetID() <<std::endl;
                sm.process_event(FPSMEvent::ZoneDisabled{}, deps, subs);
                m_handler.lastZoneDisablementEvent = event;
                return;
            }
            else
            {
                // do nothing
            }
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable(disablementEvent);
        };

        auto ForwardRecevedEvent = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ForwardRecevedAlarmEvent(alarmEvent);
        };

		auto SelfEnablementStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            SelfEnablement(disablementEvent);
        };

        auto AlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessAlarm(alarmEvent);
        };
		
		auto PreAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessPreAlarm(alarmEvent);
        };

        auto ReturnAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            ProcessReturnFromAlarm(alarmEvent);
        };
		
		auto ResetAlarmState = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ProcessReset();
        };

        /*auto ResetCmdStateUpdate = [this] (std::shared_ptr<Mol::Command::Reset> resetCommand)
        {
            ProcessReset();
        };*/

        auto TestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestStart(testEvent);
        };

        auto TestAlarmStateUpdate = [this] (std::shared_ptr<Mol::Event::AlarmEvent> testAlarmEvent)
        {
            ProcessTestAlarm(testAlarmEvent);
        };

        auto EndZoneTestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestEnd(testEvent);
        };

        auto ClearTestStateUpdate = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            ProcessTestEnd(testEvent);

        };

        auto ProcessClearRemoteEvents = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ClearFireWhenReachable();
            ClearTestWhenReachable();
            ClearDesiblementWhenReachable();
        };


        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"FPSM:IsDisabled true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
                return false;
        };

        const auto IsZoneDisablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"FPSM:IsZoneDisablement true : "<< std::hex << GetID() <<std::endl;
                return IsEventFromParent(disablementEvent);
            }
                return false;
        };

        const auto IsZoneEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"FPSM:IsZoneEnablement true : "<< std::hex << GetID() <<std::endl;
                return IsEventFromParent(disablementEvent);
            }
                return false;
        };

        const auto IsPointEnablement = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
                std::cout<<"FPSM:IsZoneEnablement true : "<< std::hex << GetID() <<std::endl;
                return (IsEventFromPoint(disablementEvent) || IsEventFromParent(disablementEvent));
            }
                return false;
        };

        const auto IsFireAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::ALARM)
            {
                std::cout<<"FPSM:IsFireAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

		const auto IsPreAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::PRE_ALARM)
            {
                std::cout<<"FPSM:IsFireAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsReturnFromAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM)
            {
                std::cout<<"FPSM:IsReturnFromAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

		const auto IsDisabledAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::DISABLED_ALARM)
            {
                return true;
            }
            return false;
        };

        ///@todo check config for reset behaviour
        /*const auto IsAlarmReset = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            auto code = reset->GetCommandCode();
            if(code == Mol::Command::RESET_TYPE_CODE::FIRE_ALARM || code == Mol::Command::RESET_TYPE_CODE::GENERAL)
            {
                std::cout<<"FPSM:IsAlarmReset true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };*/

        const auto IsZoneTestStart = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            if(testEvent->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_IN_TEST)
            {
                std::cout<<"FPSM:IsZoneTestStart true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsZoneTestEnd = [this] (std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
        {
            if(testEvent->GetEventCode() == Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST)
            {
                std::cout<<"FPSM:IsZoneTestEnd true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsTestAlarm = [this] (std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
        {
            if(alarmEvent->GetEventCode() == Mol::Event::ALARM_EVENT_CODE::TEST_ALARM)
            {
                std::cout<<"FPSM:IsTestAlarm true : "<< std::hex << GetID() <<std::endl;
                return true;
            }
            return false;
        };

        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return IsItMyPanelFailure(faultEvent,GetmyPanelObjectRef());
        };

		const auto IsSubSystemInit = [this](std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return IsItSubSystemInit(faultClearedEvent);
        };

		const auto SendPointDisablement = [this](std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return SendPointDisablementCommand();
        };

		const auto SendZoneDisablement = [this](std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return SendZoneDisablementCommand();
        };

        const auto SendZoneInTest = [this](std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
        {
            return SendZoneInTestCommand();
        };

		const auto IslegacyPanel = [this] (std::shared_ptr<Mol::Command::Reset> resetCommand)
        {
            return FindIsLegacypanel();
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsDisabled]/ DisabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<FPSMEvent::ZoneDisabled> = "zone_disabled"_s
        ,"quiescent"_s + event<FPSMEvent::PointDisabled> = "point_disabled"_s

        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZoneEnablement]/SelfEnablementStateUpdate = "quiescent"_s

        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsPointEnablement]/ EnabledStateUpdate = "quiescent"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsZoneDisablement]/ EnabledStateUpdate = "zone_disabled"_s

		 //Start :  to handle Persistence of disablement
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::FaultClearedEvent>> [IsSubSystemInit]/ SendPointDisablement = "point_disabled"_s
        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::FaultClearedEvent>> [IsSubSystemInit]/ SendZoneDisablement = "zone_disabled"_s
		//End :  to handle Persistence of disablement

        //Start :  to handle Persistence of Test Event
        ,"test"_s + event<std::shared_ptr<Mol::Event::FaultClearedEvent>> [IsSubSystemInit]/ SendZoneInTest = "test"_s
		//End :  to handle Persistence of Test Event

		 //Start :  to handle disabled alarm
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsDisabledAlarm]/ ForwardRecevedEvent = "point_disabled_alarm"_s
        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsDisabledAlarm]/ ForwardRecevedEvent = "zone_disabled_alarm"_s
	    ,"point_disabled_alarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm]/ ForwardRecevedEvent = "point_disabled"_s
        ,"zone_disabled_alarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm]/ ForwardRecevedEvent = "zone_disabled"_s
		//End :  to handle disabled alarm

        // Alarm Event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm] / AlarmStateUpdate = "alarm"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "quiescent"_s
		,"alarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IslegacyPanel] / ResetAlarmState = "quiescent"_s
		//Prealarm event handling
		,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsPreAlarm] / PreAlarmStateUpdate = "prealarm"_s
        ,"prealarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "quiescent"_s
		,"prealarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IslegacyPanel] / ResetAlarmState = "quiescent"_s
		,"prealarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm] / AlarmStateUpdate = "alarm"_s
        //Reset command need not be handled as it will cause a return to quiescent mode and RetrunFromAlarm will not be handled
        //,"alarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsAlarmReset] / ResetCmdStateUpdate = "quiescent"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsDisabled]/ DisabledStateUpdate = "alarm"_s
		,"prealarm"_s + event<std::shared_ptr<Mol::Event::DisablementEvent>> [IsDisabled]/ DisabledStateUpdate = "prealarm"_s
        ,"alarm"_s + event<FPSMEvent::ZoneDisabled> = "zone_disabled"_s
        ,"alarm"_s + event<FPSMEvent::PointDisabled> = "point_disabled"_s
        ,"prealarm"_s + event<FPSMEvent::ZoneDisabled> = "zone_disabled"_s
        ,"prealarm"_s + event<FPSMEvent::PointDisabled> = "point_disabled"_s
        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "zone_disabled"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "point_disabled"_s
        // Coincidence Handling
//      ,"quiescent"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFirstAlarm] / FirstAlarmStateUpdate = "FirstAlarm"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsFireAlarm] / AlarmStateUpdate = "FirstAlarm"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsReturnFromAlarm] / ReturnAlarmStateUpdate = "quiescent"_s
//      ,"FirstAlarm"_s + event<std::shared_ptr<Mol::Command::Reset>> [IsAlarmReset] / ResetCmdStateUpdate = "quiescent"_s

        // Test mode event handling
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestStart] / TestStateUpdate = "test"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::AlarmEvent>> [IsTestAlarm] / TestAlarmStateUpdate = "test_alarm"_s
        ,"test_alarm"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestEnd] / ClearTestStateUpdate = "quiescent"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::TestOperationEvent>> [IsZoneTestEnd] / EndZoneTestStateUpdate = "quiescent"_s

        //Networked Panels - Node Failure Scenario https://acsjira.honeywell.com/browse/FUSION-4514
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"zone_disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"point_disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"alarm"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
		,"prealarm"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"test"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"test_alarm"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
        ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset>> / ProcessClearRemoteEvents = "quiescent"_s

        );
    }

protected:

    bool IsEventFromParent(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        return m_handler.IsEventFromParent(event->GetSource());
    }

    bool IsEventFromPoint(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        if((event->GetSource().GetObjectId() == m_handler.GetID()) && (event->GetSource().GetObjectType() == m_handler.GetConcreteObjectType()))
        {
            return true;
        }
        return false;
    }
	
	bool FindIsLegacypanel()
	{
		if(Utility::GetEventResetMode()== EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE)
		{
			return true;
		}

        return false;
	}

    bool IsitMine(std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
    {
        auto source = disablementEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return true;
        }
        return false;
    }

    //Panel id check is performed in state handler..no need to check here again
	bool IsItSubSystemInit(std::shared_ptr<Mol::Event::FaultClearedEvent> faultClearedEvent)
    {
        if(faultClearedEvent->GetEventCode() == Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS)
        {
            return true;
        }
        return false;
    }


    uint64_t GetID()
    {
        return m_handler.GetID();
    }


    std::shared_ptr<Mol::Event::DisablementEvent> CreatSendEnablementEvent(std::shared_ptr<Mol::Event::DisablementEvent> event, Mol::Event::DISABLEMENT_EVENT_CODE code, bool toHMIOnly = false)
    {
        auto pointDisablementEvent = std::make_shared < Mol::Event::DisablementEvent > (code);
        pointDisablementEvent->SetSource(Mol::DataType::ObjectReference { m_handler.GetID(), m_handler.GetObjectType() });
        pointDisablementEvent->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        Dol::Label label;

        auto parentZones = m_handler.GetParentZones();
        for (auto &parentZone : parentZones)
        {
            pointDisablementEvent->AddParent(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });
        }
        //applying labels to event
        pointDisablementEvent->GetLabels().clear();
        uint64_t objectID = pointDisablementEvent->GetSource().GetObjectId();
        label.SetLabel(m_lableHandle.FindDeviceLabel(static_cast<uint64_t>(objectID)));
        label.SetLabelType(Dol::Label::LABEL_TYPE::POINT);
        pointDisablementEvent->AddLabel(label);

        for (auto &parent: pointDisablementEvent->GetParents())
        {
            switch (parent.GetObjectType())
            {
            case Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::GENERAL_ZONE:
            case Dol::DOMAIN_OBJECT_TYPE::RELEASING_ZONE:
            {
                label.SetLabel(m_lableHandle.FindZoneLabel(parent.GetObjectId(),parent.GetObjectType()));
                label.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
                pointDisablementEvent->AddLabel(label);
            }
            default:
            {
                break;
            }
            }
        }
        pointDisablementEvent->SetZonePointReference(m_handler.GetZonePointReference());
        if(toHMIOnly)
        {
            //we send only to network to clear previous disablment, now zone is disabled and point is still in disabled state (zone_disabled)
            //but in HMI only zone disablment will be displayed
            //to do this logic in HMI, is like re implementation another FDA in HMI
            //others HMIs in the network will also be updated by there own FDAs in MainCPU
            m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon as always for debuging
        }
        else
        {
            m_handler.SendEvent(pointDisablementEvent, PROC_ADDRESS::BROADCAST, true);
        }
        //enablment is sent so we clean disablment
        m_handler.lastPointDisablementEvent = nullptr;
        return pointDisablementEvent;
    }

    void Enable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: Enable : for ID[{0:#x}]",m_handler.GetID());
        if (!IsitMine(event)) //my zone disablment
        {
            CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED,true);
            return;
        }
        else//my enablment
        {
            m_handler.SetDisabled(false);
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
        }
    }

	void SelfEnablement(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: SelfEnablement : for ID[{0:#x}]",m_handler.GetID());
        if (!IsitMine(event)) //my zone disablment
        {
            if(m_handler.IsDisabled())  //added condition not to send point enablment while enable zone 
            {
                m_handler.SetDisabled(false);
                CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
                return;
            }			
        }
    }

	bool SendPointDisablementCommand()
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:SendPointDisablementCommand");
		auto pointDisablementCommand = std::make_shared <Mol::Command::Disable> (Mol::Command::DISABLE_TYPE_CODE::TARGET);
		pointDisablementCommand->SetCommandTarget((Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()}));

		MessageCommunicator msgComm;
		msgComm.SendCommand(pointDisablementCommand,PROC_ADDRESS::CMCAPP);
		return true;
    }

    bool SendZoneDisablementCommand()
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:SendZoneDisablementCommand");
		auto zoneDisablementCommand = std::make_shared <Mol::Command::Disable> (Mol::Command::DISABLE_TYPE_CODE::TARGET);

		auto parentZones = m_handler.GetParentZones();
        for (auto &parentZone : parentZones)
        {
            zoneDisablementCommand->SetCommandTarget(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });

			MessageCommunicator msgComm;
			msgComm.SendCommand(zoneDisablementCommand,PROC_ADDRESS::CMCAPP);
        }
		return true;
	}

    bool SendZoneInTestCommand()
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:SendZoneInTestCommand");
		auto zoneInTestCommand = std::make_shared <Mol::Command::TestZoneStart> ();

		auto parentZones = m_handler.GetParentZones();
        for (auto &parentZone : parentZones)
        {
            zoneInTestCommand->SetCommandTarget(Mol::DataType::ObjectReference { parentZone->GetID(), parentZone->GetObjectType() });

			MessageCommunicator msgComm;
			msgComm.SendCommand(zoneInTestCommand,PROC_ADDRESS::CMCAPP);
        }
		return true;
	}
    
    void DisableZoneWithDisabledChildren(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: DisableZoneWithDisabledChildren : for ID[{0:#x}]",m_handler.GetID());
        //Get the Parent
        auto parentZones = m_handler.GetParentZones();
        for (auto &parentZone : parentZones)
        {
            if (parentZone->AreChildrenDisabled())
            {
                // If Children as disabled, send Zone Disablement Event
                auto zoneDisablementEvent = std::make_shared<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
                zoneDisablementEvent->SetSource(Mol::DataType::ObjectReference{parentZone->GetID(), parentZone->GetObjectType()});
                zoneDisablementEvent->AddParent(Mol::DataType::ObjectReference{parentZone->GetManagedAreaId(),Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA});
                zoneDisablementEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION,std::string("LPD"));  // LPD: LastPointDisabled
                zoneDisablementEvent->SetEventApplication(event->GetEventApplication());
                std::string label = m_lableHandle.FindZoneLabel(parentZone->GetID(),parentZone->GetObjectType());
                Dol::Label dolLabel;
                dolLabel.SetLabel(label);
                dolLabel.SetLabelType(Dol::Label::LABEL_TYPE::ZONE);
                zoneDisablementEvent->AddLabel(dolLabel);
                m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::FIRE_DOMAIN_APP, true); // To FDA to trigger Zone Disablement
                m_handler.SendEvent(zoneDisablementEvent, PROC_ADDRESS::MOL_RECEIVER, true); //Send to Dragon as well for debuging
                m_handler.lastZoneDisablementEvent = zoneDisablementEvent;
            }
        }
    }
    
    void Disable(std::shared_ptr<Mol::Event::DisablementEvent> event)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: Disable : for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetDisabled(true);
        if (!IsitMine(event)) //my zone disablment
        {
            m_handler.lastZoneDisablementEvent  = nullptr;
            m_handler.lastZoneDisablementEvent = CreatSendEnablementEvent(event, Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
            return;
        }
        else//my enablment
        {
            m_handler.SendEvent(event, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastPointDisablementEvent = nullptr;
            m_handler.lastPointDisablementEvent = event;
        }
    }

    void ProcessAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(!m_handler.IsFireDetected())
        {
            DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessAlarm : for ID[{0:#x}]",m_handler.GetID());
            m_handler.SetFireDetected(true);
			m_handler.SetPreAlarmDetected(false); // A point cannot be in fire and pre alarm both
            m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastAlarmEvent = nullptr;
            m_handler.lastAlarmEvent = alarmEvent;
        }
    }

	void ForwardRecevedAlarmEvent(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:ForwardRecevedAlarmEvent: ProcessAlarm : for ID[{0:#x}]",m_handler.GetID());
        m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
    }

    void ProcessPreAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(!m_handler.IsPreAlarmDetected())
        {
            DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessPreAlarm : for ID[{0:#x}]",m_handler.GetID());
            m_handler.SetPreAlarmDetected(true);
			m_handler.SetFireDetected(false); //A point cannot be in fire and pre alarm both
            m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastAlarmEvent = nullptr;
            m_handler.lastAlarmEvent = alarmEvent;
        }
    }

    void ProcessReturnFromAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        if(m_handler.IsFireDetected() || m_handler.IsPreAlarmDetected())
        {
            DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessReturnFromAlarm : for ID[{0:#x}]",m_handler.GetID());
            m_handler.SetFireDetected(false);
			m_handler.SetPreAlarmDetected(false);
            m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.lastAlarmEvent = nullptr;
        }
    }

    void ProcessReset()
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessReset : for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetFireDetected(false);
		m_handler.SetPreAlarmDetected(false);
		m_handler.lastAlarmEvent = nullptr;
    }

    void ProcessTestStart(std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessTestStart : for ID[{0:#x}]",m_handler.GetID());
        m_handler.lastTestEvent = nullptr;
        m_handler.lastTestEvent = testEvent;
        auto source = testEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            m_handler.SendEvent(testEvent, PROC_ADDRESS::BROADCAST, true);
        }
    }

    void ProcessTestAlarm(std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessTestAlarm : for ID[{0:#x}]",m_handler.GetID());
        m_handler.SetTestFire(true);
        m_handler.SendEvent(alarmEvent, PROC_ADDRESS::BROADCAST, true);
    }

    void ProcessTestEnd(std::shared_ptr<Mol::Event::TestOperationEvent> testEvent)
    {
        DEBUGPRINT(DEBUG_INFO,"FPSM:FirePointStateMachine: ProcessTestEnd : for ID[{0:#x}]",m_handler.GetID());
        auto source = testEvent->GetSource();
        if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            m_handler.SendEvent(testEvent, PROC_ADDRESS::BROADCAST, true);
            m_handler.SetTestFire(false);
            m_handler.lastTestEvent = nullptr;
        }
    }

    void ClearDesiblementWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"ClearDesiblementWhenReachable: m_handler.IsDisabled()[{0}]",static_cast<int>(m_handler.IsDisabled()));
        if(m_handler.IsDisabled())
        {
            m_handler.SetDisabled(false);
            if(nullptr != m_handler.lastPointDisablementEvent)
            {
                auto event = CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>(m_handler.lastPointDisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
                m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
                m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
                m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
                DEBUGPRINT(DEBUG_INFO,"FPSM:ClearDesiblementWhenReachable SendEvent: Point DISABLEMENT_EVENT_CODE::ENABLED");
            }
        }
        if(nullptr != m_handler.lastZoneDisablementEvent)
        {
            auto event = CreateEventFromEvent<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE>(m_handler.lastZoneDisablementEvent, Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);//HMI
            m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);//FAT-FBF + Serial comms or repeater panel
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            DEBUGPRINT(DEBUG_INFO,"FPSM:ClearDesiblementWhenReachable SendEvent: Zone DISABLEMENT_EVENT_CODE::ENABLED");
        }
    }

    void ClearTestWhenReachable()
    {
        DEBUGPRINT(DEBUG_INFO,"ClearTestWhenReachable:m_handler.IsTestFire[{0}]",static_cast<int>(m_handler.IsTestFire()));
        if(nullptr != m_handler.lastTestEvent)
        {
            auto event = CreateEventFromEvent<Mol::Event::TestOperationEvent,Mol::Event::TestOperationEvent,Mol::Event::TEST_OPERATION_EVENT_CODE>(m_handler.lastTestEvent, Mol::Event::TEST_OPERATION_EVENT_CODE::ZONE_REMOVED_FROM_TEST);
            m_handler.SendEvent(event, PROC_ADDRESS::FIRE_DOMAIN_APP, true);//update Detection Zone State Handler
            m_handler.SetTestFire(false);
            m_handler.lastTestEvent = nullptr;
            DEBUGPRINT(DEBUG_INFO,"FPSM:ClearTestAndDesiblementWhenReachable SendEvent: ZONE_REMOVED_FROM_TEST");
        }
    }

    void ClearFireWhenReachable()//
    {
        DEBUGPRINT(DEBUG_INFO,"ClearFireWhenReachable: m_handler.IsFireDetected()[{0}]",static_cast<int>(m_handler.IsFireDetected()));
        if(m_handler.IsFireDetected() ||m_handler.IsPreAlarmDetected() )
        {
            m_handler.SetFireDetected(false);
			m_handler.SetPreAlarmDetected(false);
            if(nullptr != m_handler.lastAlarmEvent)
            {
                auto event = CreateEventFromEvent<Mol::Event::AlarmEvent, Mol::Event::AlarmEvent, Mol::Event::ALARM_EVENT_CODE>(m_handler.lastAlarmEvent, Mol::Event::ALARM_EVENT_CODE::RETURN_FROM_ALARM);
                m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
                m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);
                m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
            }
        }
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return m_handler.GetmyObjectRef();
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_handler.GetmyPanelObjectRef();
    }
private:

    Handler& m_handler;
    fireSystemState::LabelConfigurationHandle &m_lableHandle = fireSystemState::LabelConfigurationHandle::GetInstance();
};

}

#endif //FIRESYSTEM_STATE_MACHINE_FIRE_POINT_H
