/******************************************************************************//**
*
* @file   ChargerPointStateMachine.h
* @brief  State machine for charger point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MECHAIN_CHARGER_POINT_H
#define FIRESYSTEM_STATE_MECHAIN_CHARGER_POINT_H

#include "Mol/Events/DisablementEvent.h"

#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class ChargerPointStateMachine
{
public:
    ChargerPointStateMachine() = delete;

    ChargerPointStateMachine(ChargerPointStateMachine&& other) = delete;

    explicit ChargerPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~ChargerPointStateMachine() = default;
    ChargerPointStateMachine(const ChargerPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] ()
        {
            Disable();
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable();
        };

        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
                std::cout<<"IsDisabled true"<<std::endl;
                return true;
            }
                return false;
        };

        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Activate(activation);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
        {
            Deactivate(deactivation);
        };

        auto DeactivatedDisableStateUpdate = [this] ()
        {
            Disable();
            Deactivate();
        };

        const auto IsActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            if(IsPointDisabled())
            {
                return false;
            }

            if(IsPointActivated(activation))
            {
                return true;
            }

            return false;
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsDisabled]/ DisabledStateUpdate = "disabled"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [!IsDisabled]/ EnabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsActivated]/ ActivatedStateUpdate = "activated"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [!IsActivated]/ DeactivatedStateUpdate = "quiescent"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsDisabled]/ DeactivatedDisableStateUpdate = "disabled"_s
        );
    }

protected:
    void Enable()
    {
        std::cout<<"CO enable"<<std::endl;
        m_handler.SetDisabled(false);
        SendEvent<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
    }
    void Disable()
    {
        std::cout<<"CO disable"<<std::endl;
        m_handler.SetDisabled(true);
        SendEvent<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED);
    }

    bool IsPointActivated(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
        auto source = activation->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
        {
            std::cout<<"IsActivated true"<<std::endl;
            return true;
        }

        return false;
    }

    void Activate(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
        std::cout<<"***********CO actived*************"<<std::endl;
        m_handler.SetOperationalMode(Dol::Entities::CHARGER_MODE::CHARGING);
        m_handler.SendEvent(activation,PROC_ADDRESS::BROADCAST,true);
    }

    void Deactivate(std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
    {
        std::cout<<"***********CO Deactivated*************"<<std::endl;
        m_handler.SetOperationalMode(Dol::Entities::CHARGER_MODE::OFF);
        m_handler.SendEvent(deactivation,PROC_ADDRESS::BROADCAST,true);
    }
	
	void Activate()
    {
        std::cout<<"***********CO actived*************"<<std::endl;
        m_handler.SetOperationalMode(Dol::Entities::CHARGER_MODE::CHARGING);
        SendEvent<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE);
    }

    void Deactivate()
    {
        std::cout<<"***********CO Deactivated*************"<<std::endl;
        m_handler.SetOperationalMode(Dol::Entities::CHARGER_MODE::OFF);
        SendEvent<Mol::Event::ActivationEvent>(Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
    }

    bool IsPointDisabled()
    {
        if( m_handler.IsDisabled())
        {
            return true;
        }
        return false;
    }

    template<typename EVENT, typename CODE>
    void SendEvent(CODE code)
    {
        auto event = std::make_shared<EVENT>(code);
        event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        auto parentZones = m_handler.GetParentZones();
        for(auto& parentZone : parentZones )
        {
            event->AddParent(Mol::DataType::ObjectReference{parentZone->GetID(), parentZone->GetObjectType()});
        }

        //@todo may need to added parent
        m_handler.SendEvent(event,PROC_ADDRESS::BROADCAST,true);
    }
    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MECHAIN_CHARGER_POINT_H
