/******************************************************************************//**
*
* @file   ControlZoneStateMachine.h
* @brief  State Machine for Control zone.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_CONTROL_ZONE_H
#define FIRESYSTEM_STATE_MACHINE_CONTROL_ZONE_H

//#include "DOL/Entities/Zone/DetectionZone.h"

#include "Mol/Events/DisablementEvent.h"

#include "boost/sml.hpp"
namespace fireSystemState
{
/**
@startuml
title /Disable/Enable/Activate/Deactivate of Control Zone
[*] --> ZoneAvailable
state ZoneAvailable
state "Control Zone is Available for\n operations" as ZoneAvailable {
  State Quiescent
  state Activated
  state Disabled
  [*] -> Quiescent
  Quiescent --> Activated :Activate(Zoneid)/ \n Action: All Activate Control\n output Point
  Activated --> Quiescent :Deactivate(Zoneid)/ \n Action: Deactivate Control\n output Point
  Activated --> Disabled : Disable(Zoneid)/ \nAction:\n  Deactivate all control output
  Quiescent --> Disabled : Disable(Zoneid)/ \nAction:\n Deactivate all control output
  Disabled --> Quiescent : Enable(ZoneID)


@enduml
*/

template<typename Handler>
class ControlZoneStateMachine
{
public:
    ControlZoneStateMachine() = delete;

    ControlZoneStateMachine(ControlZoneStateMachine&& other) = delete;

    explicit ControlZoneStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~ControlZoneStateMachine() = default;
    ControlZoneStateMachine(const ControlZoneStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */

        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Activate(activation);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Deactivate(activation);
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionEnable> enableementEvent)
        {
			//state handler is performing all the actions, need to move it here
        };

        auto DisabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable> disablementEvent)
        {
			//state handler is performing all the actions, need to move it here
        };

        const auto IsActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            if(IsZoneActivated(activation))
            {
                return true;
            }
            return false;
        };
		
		const auto IsNotActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            if(IsZoneNotActivated(activation))
            {
                return true;
            }
            return false;
        };

        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsActivated] / ActivatedStateUpdate = "activated"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsNotActivated] / DeactivatedStateUpdate = "quiescent"_s
		,"disabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable> > / EnabledStateUpdate = "quiescent"_s
		,"quiescent"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> > / DisabledStateUpdate = "disabled"_s
		,"activated"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> > / DisabledStateUpdate = "disabled"_s
        );
    }

protected:
    bool IsZoneActivated(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneActivated called");
        auto source = activation->GetSource();

#ifndef UT_TARGET	
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneActivated return false source is not same as handler");
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneActivated return true code is activate");
            std::cout<<"IsActivated true"<<std::endl;
            return true;
        }

        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneActivated return false code is deactivate");
            std::cout<<"IsActivated false"<<std::endl;
            return false;
        }

        return false;
    }

    bool IsZoneNotActivated(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneNotActivated called");
    auto source = activation->GetSource();

#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneNotActivated return false source is not same as handler");
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneActivated return false code is activate");
            std::cout<<"IsActivated true"<<std::endl;
            return false;
        }

        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:IsZoneActivated return true code is DEACTIVATE");
            std::cout<<"IsActivated false"<<std::endl;
            return true;
        }

        return false;
    }

    void Activate(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:Activate called");
        std::cout<<"***********CZ disable*************"<<std::endl;
        
        auto source = activation->GetSource();
        m_handler.SetActivationConfirmed(true); 
        
#ifndef UT_TARGET        
       if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
         {
		   DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:Activate send event");
           m_handler.SendEvent(activation,PROC_ADDRESS::BROADCAST,true);
		   m_handler.lastActivationEvent = activation;
         }
#endif
    }

    void Deactivate(std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
    {
		DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:Deactivate called");
        std::cout<<"***********CZ disable*************"<<std::endl;
        
        auto source = deactivation->GetSource();
        m_handler.SetActivationConfirmed(false);
        
#ifndef UT_TARGET        
       if(source == Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
         {
			DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:Deactivate send event");
            m_handler.SendEvent(deactivation,PROC_ADDRESS::BROADCAST,true);
			m_handler.lastActivationEvent = deactivation;
         }
#endif             
    }

    template<typename EVENT, typename CODE>
    void SendEvent(CODE code)
    {
		DEBUGPRINT(DEBUG_INFO,"ControlZoneStateMachine:SendEvent called");
        auto event = std::make_shared<EVENT>(code);
        event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        //@todo may need to added parent
        m_handler.SendEvent(event,PROC_ADDRESS::BROADCAST,true);
    }
    Handler& m_handler;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_CONTROL_ZONE_H
