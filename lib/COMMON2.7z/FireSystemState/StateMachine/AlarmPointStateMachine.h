/******************************************************************************//**
*
* @file   AlarmPointStateMachine.h
* @brief  State handler for Alarm point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_ALARM_POINT_H
#define FIRESYSTEM_STATE_MACHINE_ALARM_POINT_H

#include "DOL/Entities/Zone/AlarmZone.h"
#include "boost/sml.hpp"
#include "Communicator/Communicator.hpp"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Commands/Reset.h"
#include "Helper/FSHelper.h"

#ifdef UT_TARGET

#ifndef protected
#define protected public
#endif

#endif

namespace fireSystemState
{
/**
* Template state Machine for handling Alarm points
@startuml

title SetAlarmSignal/Disable/Enable/Reset/Silence/Resound/Evacuate of Alarm point
[*] --> PointAvailable
state PointAvailable
state "Point Available for\n operation" as PointAvailable {
state Quiescent
state Annunciation
state Silence
state Disabled
[*] -> Quiescent

Quiescent --> Annunciation :NeedActivate(previews and current saved signal id not 0 and not equal)
Annunciation --> Annunciation :NeedActivate(previews and current saved signal id not 0 and not equal)
Annunciation --> Silence : NeedSilence(receive silence userOperation)
Silence --> Annunciation: NeedResound(receive resound userOperation)
Quiescent --> Quiescent: NeedDeactivate(previews saved signal id not 0 and new one is 0)
Quiescent --> Disabled : FunctionDisable received
Annunciation --> Disabled : FunctionDisable received
Silence --> Disabled: FunctionDisable received
Disabled --> Quiescent: FunctionEnable received
Annunciation --> Quiescent: NeedDeactivate(previews saved signal id not 0 and new one is 0)
Silence --> Quiescent: NeedDeactivate(previews saved signal id not 0 and new one is 0)
Silence --> Annunciation : NeedResound(receive resound userOperation)


Annunciation: Activate Fire Alarm Device Point with proper signal id store the profile ID
Annunciation: Alarm is resounded and set silence value to fault
Annunciation:Evacuation is announced


Disabled: Evacuation / Nothing
Disabled: SetAlarmSignal / Nothing
Disabled: Silence / Nothing
Disabled: Resound /Nothing
Disabled: Reset Nothing

Quiescent: Device is enabled
Quiescent: Alarm is deactivated and Signal id is 0

Silence: Alarm is silenced and set silence value to true
}

@enduml
*/
#define EVACUATION_SIGNAL 255 //255 is evacuation signal
template<typename Handler>
class AlarmPointStateMachine
{
public:
    AlarmPointStateMachine() = delete;

    AlarmPointStateMachine(AlarmPointStateMachine&& other) = delete;

    explicit AlarmPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~AlarmPointStateMachine() = default;
    AlarmPointStateMachine(const AlarmPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;
        auto DisabledStateUpdate = [this] ()
        {
            Disable();
        };

		auto ActiveAndDisabledStateUpdate = [this] ()
        {
            Disable();
			SendDeactivateEventToHMI();
        };

        auto EnabledStateUpdate = [this] ()
        {
            Enable();
        };

        auto NoResoundEnabledStateUpdate = [this] ()
        {
            NoResoundEnable();
        };
        const auto NeedActivate = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            return CheckForAactivation(alarmSignal);
        };

        const auto NeedDeactivate = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            return CheckForDeactivation(alarmSignal);
        };

        const auto NeedDeactivateDueToParent = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
        {
            return CheckForParentDeactivation(alarmSignal);
        };

        const auto SetAlarmSignalEvent = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal, auto &sm, auto &deps, auto &subs)
        {
            AlarmSignalEvent(alarmSignal,sm,deps,subs);
        };
        const auto SetAlarmSignalEventForParent = [this] (std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal, auto &sm, auto &deps, auto &subs)
        {
            AlarmSignalEventForParent(alarmSignal,sm,deps,subs);
        };

        const auto NeedSilence = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return (userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE);
        };

        const auto NeedResound = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            return (userOperation->GetEventCode() == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND);
        };

        const auto SwitchToOperationAction = [this] (std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
        {
            SwitchToOperation(userOperation);
			SendEventtoHMI(userOperation);
        };

        const auto IsMyPanelFailure_ = [this](std::shared_ptr<Mol::Event::FaultEvent> faultEvent)
        {
            return IsItMyPanelFailure(faultEvent,GetmyPanelObjectRef());
        };

        auto ProcessClearRemoteEvents_ = [this] (std::shared_ptr<Mol::Command::Reset> reset)
        {
            ProcessClearRemoteEvents();
        };
        /**
          Check if option "ResoundOption" from config has value "NoResound"
          @retval true xml config has "ResoundOption" value "NoResound"
          @retval false xml config has NOT "ResoundOption" value "NoResound"
          */
        const auto OptNoResound = [this] ()
        {
            return GetOptNoResound();
        };


        // State machine transition table
        return boost::sml::make_transition_table(
        *"quiescent"_s +           event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                 / DisabledStateUpdate = "disabled"_s
        ,"quiescent"_s +           event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                / SetAlarmSignalEvent = "quiescent"_s
        ,"disabled"_s +            event<std::shared_ptr<Mol::Event::FunctionEnable>     >                                 / EnabledStateUpdate = "quiescent"_s
        ,"quiescent"_s +           event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedActivate && !OptNoResound] / SetAlarmSignalEvent = "annunciation"_s
        ,"quiescent"_s +           event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedActivate &&  OptNoResound] / SetAlarmSignalEvent = "no_resound"_s
        ,"annunciation"_s +        event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedActivate]                  / SetAlarmSignalEvent = "annunciation"_s
        ,"annunciation"_s +        event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                / SetAlarmSignalEvent = "quiescent"_s
        ,"annunciation"_s +        event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivateDueToParent]     / SetAlarmSignalEventForParent = "quiescent"_s
        ,"annunciation"_s +        event<std::shared_ptr<Mol::Event::UserOperationEvent> > [NeedSilence]                   / SwitchToOperationAction = "silence"_s
        ,"annunciation"_s +        event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                 / ActiveAndDisabledStateUpdate = "disabled"_s
        ,"no_resound"_s +          event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                / SetAlarmSignalEvent = "quiescent"_s
        ,"no_resound"_s +          event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                 / ActiveAndDisabledStateUpdate = "disabled"_s
	    ,"no_resound"_s +          event<std::shared_ptr<Mol::Event::UserOperationEvent> > [NeedSilence]                   / SwitchToOperationAction = "silence"_s
        ,"no_resound_disabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable>     >                                 / NoResoundEnabledStateUpdate = "no_resound"_s
        ,"silence"_s +             event<std::shared_ptr<Mol::Event::UserOperationEvent> > [NeedResound]                   / SwitchToOperationAction = "annunciation"_s
        ,"silence"_s +             event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedActivate]                  / SetAlarmSignalEvent = "annunciation"_s
        ,"silence"_s +             event<std::shared_ptr<Mol::Event::AlarmSignalEvent>   > [NeedDeactivate]                / SetAlarmSignalEvent = "quiescent"_s
        ,"silence"_s +             event<std::shared_ptr<Mol::Event::FunctionDisable>    >                                 / ActiveAndDisabledStateUpdate = "disabled"_s

        //Networked Panels - Node Failure Scenario https://acsjira.honeywell.com/browse/FUSION-4514
       ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
       ,"annunciation"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
       ,"no_resound"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
       ,"no_resound_disabled"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
       ,"silence"_s + event<std::shared_ptr<Mol::Event::FaultEvent>> [IsMyPanelFailure_] = "unreachable"_s
       ,"unreachable"_s + event<std::shared_ptr<Mol::Command::Reset>> / ProcessClearRemoteEvents_ = "quiescent"_s
        );
    }

protected:

    bool CheckForAactivation(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        if(alarmSignal->GetSource() != Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() })
        {
			//check if the parent matches ths activation
		    auto parentZoneRefs = m_handler.GetZones();
            bool isAMatchFound = false;
            for(auto& parent: parentZoneRefs)
            {
                if(alarmSignal->GetSource() == Mol::DataType::ObjectReference {parent.GetObjectId(), parent.GetObjectType() })
                {
                    isAMatchFound = true;
					m_activatedDuetoparent = true;
                    break;
				}
            }
 
            if(!isAMatchFound)
            {
               return false;
            }
        }

        return (alarmSignal->GetEventCode() != 0) ;
    }

    bool CheckForDeactivation(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: CheckForDeactivation() {}",m_handler.GetAlarmSignalId());
        if(alarmSignal->GetSource() != Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() })
        {
            return false;
        }
        
		m_activatedDuetoparent = false;
        return ((alarmSignal->GetEventCode() == 0)
                &&
                (m_handler.GetAlarmSignalId() != 0));
    }

    bool CheckForParentDeactivation(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: CheckForParentDeactivation() {}",m_handler.GetAlarmSignalId());
        // Process parent events as well
        auto parentZoneRefs = m_handler.GetZones();
        bool isAMatchFound = false;
        for(auto& parent: parentZoneRefs)
        {
            if(alarmSignal->GetSource() == Mol::DataType::ObjectReference {parent.GetObjectId(), parent.GetObjectType() })
            {
                isAMatchFound = true;
				m_activatedDuetoparent = false;
                break;
            }
        }
        if(!isAMatchFound)
        {
            return false;
        }

        return ((alarmSignal->GetEventCode() == 0)
                &&
                (m_handler.GetAlarmSignalId() != 0));
    }

    bool ValidateParentDisablement()
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: IsParentDisabledTest()");
        return m_handler.IsParentDisabled();
    }

    void Enable()
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: Enable()");
        m_handler.SetDisabled(false);
        m_handler.EnableAction();
    }

    void NoResoundEnable()
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: Enable()");
        m_handler.SetDisabled(false);
    }

    void Disable()
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: Disable()");
        m_handler.SetDisabled(true);
        //SendAlarmSignal(0);
    }
	
	void SendDeactivateEventToHMI()
	{
		DEBUGPRINT(DEBUG_INFO, "SendDeactivateEventToHMI()");

        if(nullptr != m_handler.lastAlarmSignalEvent && m_handler.GetAlarmSignalId() > 0)
        {
            auto event = CreateEventFromEvent<Mol::Event::AlarmSignalEvent, Mol::Event::AlarmSignalEvent, uint32_t>(m_handler.lastAlarmSignalEvent, 0);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
        }
	}
    
	void SendEventtoHMI(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {
        auto operation = userOperation->GetEventCode();
        if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE)
        {
			m_handler.SendDeactiveEventtoHMI();
        }
		else if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND)
        {
			m_handler.SendActiveEventtoHMI();
        }
        else
        {
            //Do nothing
        }

    }
	
    template < typename SM, typename DEPS, typename SUBS >
    void AlarmSignalEvent(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal, SM &sm, DEPS &deps, SUBS &subs)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: AlarmSignalEvent(profileId[{}])",alarmSignal->GetEventCode());

		if(alarmSignal->GetEventCode() != EVACUATION_SIGNAL)
		{
            SendAlarmSignal(alarmSignal);
            m_handler.SetAlarmSignalId(alarmSignal->GetEventCode());
            m_handler.SetLastAlarmSignalId(alarmSignal->GetEventCode());
		}

        if(m_noResound)
        {
            sm.process_event(NoResound{}, deps, subs);
        }
    }

    template < typename SM, typename DEPS, typename SUBS >
    void AlarmSignalEventForParent(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal, SM &sm, DEPS &deps, SUBS &subs)
    {
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: AlarmSignalEventForParent (profileId[{}])",alarmSignal->GetEventCode());

        auto alarmSignalEvent = std::make_shared<Mol::Event::AlarmSignalEvent>(0);
        alarmSignalEvent->SetSource(Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() });
        DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: AlarmSignalEventForParent ID[{}] TYPE[{}]", m_handler.GetID(), static_cast<uint32_t>(m_handler.GetObjectType()));
        alarmSignalEvent->AddParent(alarmSignal->GetSource());
		
		if(!m_activatedDuetoparent) //to avoid many unnecessary events
		{
            m_handler.SendEvent(alarmSignalEvent,PROC_ADDRESS::BROADCAST,true);
		}
        m_handler.lastAlarmSignalEvent = nullptr;
        m_handler.lastAlarmSignalEvent = alarmSignalEvent;
        m_handler.SetAlarmSignalId(alarmSignal->GetEventCode());
        m_handler.SetLastAlarmSignalId(alarmSignal->GetEventCode());
    }


    void SendAlarmSignal(std::shared_ptr<Mol::Event::AlarmSignalEvent> alarmSignal)
    {
        //clean memory for the last pointer
        m_handler.lastAlarmSignalEvent = nullptr;
        m_handler.lastAlarmSignalEvent = alarmSignal;

		if(alarmSignal->GetSource() == Mol::DataType::ObjectReference {m_handler.GetID(), m_handler.GetObjectType() })
		{
			//no need to send zone events from point state machine, zone state machine will handle this.
            m_handler.SendEvent(alarmSignal,PROC_ADDRESS::BROADCAST,true);
		}
    }
    void SwitchToOperation(std::shared_ptr<Mol::Event::UserOperationEvent> userOperation)
    {

        auto operation = userOperation->GetEventCode();
        if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::SILENCE)
        {
            m_handler.SetSilenced(true);
            DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: Switch To Use rOperation SILENCE)");
        }else if(operation == Mol::Event::USER_OPERATION_EVENT_CODE::RESOUND)
        {
            m_handler.SetSilenced(false);
            DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: Switch To Use rOperation RESOUND)");
        }
        else
        {
            DEBUGPRINT(DEBUG_INFO, "AlarmPointStateMachine: SwitchToUserOperation(profileId[{0}])",(int)operation);
            return;
        }

    }


    void ProcessClearRemoteEvents()
    {
        DEBUGPRINT(DEBUG_INFO, "ProcessClearRemoteEvents()");
        m_handler.SetDisabled(false);
        if(nullptr != m_handler.lastAlarmSignalEvent && m_handler.GetAlarmSignalId() > 0)
        {
            auto event = CreateEventFromEvent<Mol::Event::AlarmSignalEvent, Mol::Event::AlarmSignalEvent, uint32_t>(m_handler.lastAlarmSignalEvent, 0);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(event, PROC_ADDRESS::EVENT_PROVIDERAPP, true);
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
        }
        m_handler.SetAlarmSignalId(Dol::Entities::FireAlarmDevicePoint::INVALID_SIGNAL_ID);
        m_handler.SetLastAlarmSignalId(Dol::Entities::FireAlarmDevicePoint::INVALID_SIGNAL_ID);
        m_handler.SetSilenced(false);
    }
    /**
      check if NoResound option is set in configuration
      @retval true NoResound option is set
      @retval false NoResound option is NOT set
      */
    bool GetOptNoResound() const
    {
        return ( m_handler.GetResoundOption() == "NoResound" );
    }

    Mol::DataType::ObjectReference GetmyObjectRef()
    {
        return m_handler.GetmyObjectRef();
    }

    Mol::DataType::ObjectReference GetmyPanelObjectRef()
    {
        return m_handler.GetmyPanelObjectRef();
    }

    Handler& m_handler;

private:

    bool m_noResound = true;
	bool m_activatedDuetoparent = false; //if the point is activated because of zone event, no need to send that event to other applications
};

}

#endif //FIRESYSTEM_STATE_MACHINE_ALARM_POINT_H
