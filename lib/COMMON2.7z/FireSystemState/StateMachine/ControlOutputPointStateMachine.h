/******************************************************************************//**
*
* @file   ControlOutputPointStateMachine.h
* @brief  State machine for control output point.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#ifndef FIRESYSTEM_STATE_MACHINE_CONTROL_OUTPUT_POINT_H
#define FIRESYSTEM_STATE_MACHINE_CONTROL_OUTPUT_POINT_H

#include "Mol/Events/DisablementEvent.h"

#include "boost/sml.hpp"
namespace fireSystemState
{

template<typename Handler>
class ControlOutputPointStateMachine
{
public:
    ControlOutputPointStateMachine() = delete;

    ControlOutputPointStateMachine(ControlOutputPointStateMachine&& other) = delete;

    explicit ControlOutputPointStateMachine(Handler& handler):
    m_handler(handler)
    {

    }

    ~ControlOutputPointStateMachine() = default;
    ControlOutputPointStateMachine(const ControlOutputPointStateMachine& other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator!;
        /**
         * @brief    Starts MainCPU firmware update sequence
         */
        auto DisabledStateUpdate = [this] ()
        {
            Disable();
        };

        auto EnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            Enable();
        };

        auto FunDisabledStateUpdate = [this] ()
        {
            Disable();
        };

        auto FunEnabledStateUpdate = [this] (std::shared_ptr<Mol::Event::FunctionEnable> disablementEvent)
        {
            Enable();
        };
/*
     * Module                             HMI 
	   point->disable                     pointEnable 
       Point -> Enable                    PointDisable
	   At the Above Senario when a Function Disable request for Managed Area comea then 
       Module needs to send the pointEnable to HMI explicitly . This is Achived in this state	  
       
	   Funtion->Disable              
                         --------------->  pointEnable  	   
	 *@brief Module has to send the ENABLED when module receive the FuntionDisableEvent. 
  */
       auto FunctionDisableDisabledUpdate = [this] (std::shared_ptr<Mol::Event::FunctionDisable>DisablementEvent) 
        {
       
          SendEvent<Mol::Event::DisablementEvent>(Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED);
  
        };
        auto ActivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            Activate(activation);
        };

        auto DeactivatedStateUpdate = [this] (std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
        {
            Deactivate(deactivation);
        };

        auto DeactivatedDisableStateUpdate = [this] ()
        {
            Disable();
            Deactivate();
			SendDeactivateEventToHMI();
        };
        const auto IsDisabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::DISABLED)
            {
             
                return true;
            }
                return false;
        };

        const auto IsEnabled = [this] (std::shared_ptr<Mol::Event::DisablementEvent> disablementEvent)
        {
            if(disablementEvent->GetEventCode() == Mol::Event::DISABLEMENT_EVENT_CODE::ENABLED)
            {
               
                return true;
            }
                return false;
        };
        const auto IsActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            if(IsPointDisabled())
            {
                return false;
            }

            if(IsPointActivated(activation))
            {
                return true;
            }

            return false;
        };

		const auto IsNotActivated = [this] (std::shared_ptr<Mol::Event::ActivationEvent> activation)
        {
            if(IsPointDisabled())
            {
                return false;
            }

            if(IsPointNotActivated(activation))
            {
                return true;
            }

            return false;
        };

        // State machine transition table
        return boost::sml::make_transition_table(
		*"quiescent"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsDisabled]/ DisabledStateUpdate = "disabled"_s
        ,"disabled"_s + event<std::shared_ptr<Mol::Event::DisablementEvent> > [IsEnabled]/ EnabledStateUpdate= "quiescent"_s
		,"disabled"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> >   / FunctionDisableDisabledUpdate= "fundisabled"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> > / FunDisabledStateUpdate  = "fundisabled"_s
        ,"fundisabled"_s + event<std::shared_ptr<Mol::Event::FunctionEnable> > / FunEnabledStateUpdate = "quiescent"_s
        ,"quiescent"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsActivated]/ ActivatedStateUpdate = "activated"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::ActivationEvent> > [IsNotActivated]/ DeactivatedStateUpdate = "quiescent"_s
        ,"activated"_s + event<std::shared_ptr<Mol::Event::FunctionDisable> > / DeactivatedDisableStateUpdate = "fundisabled"_s
        );
    }

protected:
    void Enable()
    {
		DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::Enable() is called ");
        std::cout<<"CO enable"<<std::endl;
        m_handler.SetDisabled(false);
        m_handler.EnableAction();
    }
    void Disable()
    {
		DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::Disable() is called ");
        std::cout<<"CO disable"<<std::endl;
        m_handler.SetDisabled(true);
    }

    bool IsPointActivated(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::IsPointActivated() is called ");
        auto source = activation->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::IsPointActivated() return false as source is not same as handler");
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::ACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::IsPointActivated() return true as code is activate");
            std::cout<<"IsActivated true"<<std::endl;
            return true;
        }

        return false;
    }

	bool IsPointNotActivated(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::IsPointNotActivated() is called");
        auto source = activation->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::IsPointNotActivated() return false as source is not same as handler");
            return false;
        }
#endif
        if(activation->GetEventCode() == Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE)
        {
			DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::IsPointNotActivated() return true code is deactivate");
            std::cout<<"IsNotActivated true"<<std::endl;
            return true;
        }

        return false;
    }

    void Activate(std::shared_ptr<Mol::Event::ActivationEvent> activation)
    {
		DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::Activate() is called");
        m_handler.SetActivated(true);

		auto source = activation->GetSource();
#ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::Activate return as source is not same as handler");
            return;
        }
#endif
		m_handler.SendEvent(activation,PROC_ADDRESS::BROADCAST,true);
		lastActivationEvent = nullptr;
		lastActivationEvent = activation;
    }

    void Deactivate(std::shared_ptr<Mol::Event::ActivationEvent> deactivation)
    {
		DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::Deactivate is called");
        m_handler.SetActivated(false);
        
        auto source = deactivation->GetSource();
        
        #ifndef UT_TARGET
        if(source != Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()})
        {
			DEBUGPRINT(DEBUG_INFO," ControlOutputPointStateMachine::return as source is not same as handler");
            return;
        }
        #endif 
        m_handler.SendEvent(deactivation,PROC_ADDRESS::BROADCAST,true);
		lastActivationEvent = nullptr;
		lastActivationEvent = deactivation;
    }
	
	void SendDeactivateEventToHMI()
	{
		DEBUGPRINT(DEBUG_INFO, "ControlOutputPointStateMachine::SendDeactivateEventToHMI()");

        if(nullptr != lastActivationEvent && m_handler.CheckLastOperation(Dol::CONTROL_OPERATION::ACTIVATE))
        {
			DEBUGPRINT(DEBUG_INFO, "ControlOutputPointStateMachine::SendDeactivateEventToHMI() events sent");
            auto event = CreateEventFromEvent<Mol::Event::ActivationEvent, Mol::Event::ActivationEvent, Mol::Event::ACTIVATION_EVENT_CODE>(lastActivationEvent, Mol::Event::ACTIVATION_EVENT_CODE::DEACTIVATE);
            m_handler.SendEvent(event, PROC_ADDRESS::NETWORK, true);
            m_handler.SendEvent(event, PROC_ADDRESS::MOL_RECEIVER, true);//Dragon for debugging
        }
	}

    void Deactivate()
    {
		DEBUGPRINT(DEBUG_INFO, "ControlOutputPointStateMachine::Deactivate() is called");
		m_handler.SetActivated(false);
    }

    bool IsPointDisabled()
    {
		DEBUGPRINT(DEBUG_INFO, "ControlOutputPointStateMachine::IsPointDisabled() is called");
        if( m_handler.IsDisabled())
        {
			DEBUGPRINT(DEBUG_INFO, "ControlOutputPointStateMachine::IsPointDisabled() return is disabled true");
            return true;
        }
        return false;
    }

    template<typename EVENT, typename CODE>
    void SendEvent(CODE code)
    {
		DEBUGPRINT(DEBUG_INFO,"ControlOutputPointStateMachine::SendEvent Event is created");
        auto event = std::make_shared<EVENT>(code);
        event->SetSource(Mol::DataType::ObjectReference{m_handler.GetID(), m_handler.GetObjectType()});
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        auto parentZones = m_handler.GetParentZones();
        for(auto& parentZone : parentZones )
        {
            event->AddParent(Mol::DataType::ObjectReference{parentZone->GetID(), parentZone->GetObjectType()});
        }

        //@todo may need to added parent
        m_handler.SendEvent(event,PROC_ADDRESS::BROADCAST,true);
    }
    Handler& m_handler;
	std::shared_ptr<Mol::Event::ActivationEvent> lastActivationEvent = nullptr;
};

}

#endif //FIRESYSTEM_STATE_MACHINE_CONTROL_OUTPUT_POINT_H
