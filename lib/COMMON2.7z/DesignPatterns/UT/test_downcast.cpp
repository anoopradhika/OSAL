#include <gmock/gmock.h>
#include <sstream>
#include <memory>

#include "../downcast/downcast.h"

namespace 
{
static std::string mockCheckString;

class D1;
class D2;

class Base
{
    private:
        int type ;

    public:
        Base( int _type ): type{ _type } {}

        enum TYPES
        {
            TYPE_D1,
            TYPE_D2
        };

        virtual void VFunc() = 0;

        auto GetId() { return type; }
};

class Base2: public Base
{
    public:
        using Base::Base;
        void Base2Func() { mockCheckString = "Base2Func"; }
};

class Base3: public Base2
{
    public:
        using Base2::Base2;
        void Base3Func() { mockCheckString = "Base3Func"; }
};

class D1: public Base2
{
    public:
        D1(): Base2{ TYPE_D1 } {}
        void VFunc() override { mockCheckString = "VFuncD1"; } 
        static constexpr TYPES SGetId() { return TYPE_D1; }
        void SpecificD1() { mockCheckString = "SpecificD1"; }
        int SpecificD1Ret() { mockCheckString= "SpecificD1Ret"; return 123; }
        int TakesInt( int i ) { mockCheckString= "TakesIntD1"; return i*3; }
};

class D2: public Base3
{
    public:
        D2(): Base3{ TYPE_D2 } {}
        void VFunc() override { mockCheckString = "VFuncD2"; } 
        static constexpr TYPES SGetId() { return TYPE_D2; }
        int TakesInt( int i ) { mockCheckString= "TakesIntD2"; return i*6; }
};


void FreeFunc( D1* ) { mockCheckString = "FreeFunc"; }
void AnyFunc( Base3* ) { mockCheckString = "AnyFunc"; }
int FuncWithInt(D1*, int i) { mockCheckString = "FuncWithInt"; return i*2;}
void FuncWithIntFloat(int,float) { mockCheckString = "FuncWithIntFloat"; }
void NoParms() { mockCheckString = "NoParms"; }

struct Action1
{
    void operator()(D2*){ mockCheckString = "Action1"; }
};

struct ActionWithReturn
{
    int operator()(D2*){ mockCheckString = "ActionWithReturn"; return 42; }
};

struct Action2
{
    template <typename T>
        void operator()(T*){ mockCheckString = "Action2"; }
};

// global internal errno only for testing here

int lastError = 0;

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class Example_DowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::SGetId(); }

        template < typename PTR >
            static auto DynamicGetId( PTR base_ptr ) { return base_ptr->GetId(); }

        static void Error( int i ) { lastError = i; }
};


// Instances of CallAndCheck -> objects under test
using TYPES = std::tuple<D1,D2>;
using CAC_Tuple = Platform::CastAndCall< Example_DowncastAdapter, Base, TYPES >;
using CAC_List  = Platform::CastAndCall< Example_DowncastAdapter, Base, D1, D2 >;
D1 d1;
D2 d2;
} // end anonymous namespace

// Checking type trait "is_callable"
TEST( DOWNCAST, IS_CALLABLE )
{
    // check sfinae for callable objects for free functions
    EXPECT_TRUE ( (is_callable< decltype(FreeFunc), D1*  >::value) );
    EXPECT_FALSE( (is_callable< decltype(FreeFunc), D2*  >::value) );

    // check implicit upcast D2->Base3 which is valid
    EXPECT_TRUE ( (is_callable< decltype(AnyFunc), D2*  >::value) );

    // check implicit try to upcast from D1->Base3 NOT possible!
    EXPECT_FALSE( (is_callable< decltype(AnyFunc), D1*  >::value) );

    // check multiple parms
    EXPECT_TRUE ( (is_callable< decltype(FuncWithIntFloat), float, int  >::value) );

    // check one parameter automatic casts to a valid type implicit
    EXPECT_TRUE ( (is_callable< decltype(FuncWithIntFloat), float, float  >::value) );
    EXPECT_TRUE ( (is_callable< decltype(FuncWithIntFloat), int, int  >::value) );

    // check fail if a parameter can not be imlicit casted:
    EXPECT_FALSE ( (is_callable< decltype(FuncWithIntFloat), float, std::string  >::value) );
    EXPECT_FALSE ( (is_callable< decltype(FuncWithIntFloat), std::string, int  >::value) );

    // check for no parms
    EXPECT_TRUE ( (is_callable< decltype(NoParms)>::value) );
}

// checking member function calls
TEST( DOWNCAST, CAST_AND_CALL_MEMBER )
{
    using ERR = CAC_Tuple::ERROR_T;
    // check with tuple generated CastAndCall
    CAC_Tuple::Do( &d1, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "SpecificD1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    // check with direct list generated CastAndCall
    CAC_List::Do( &d1, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "SpecificD1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    // no function SpecificD1 in D2->fails
    CAC_Tuple::Do( &d2, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do( &d2, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    // check for calls to methods upper in the hirarchy
    CAC_List::Do( &d1, &Base2::Base2Func );
    EXPECT_EQ( mockCheckString, "Base2Func" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do( &d2, &Base2::Base2Func );
    EXPECT_EQ( mockCheckString, "Base2Func" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    // Base3 is not base of d1 -> fails
    CAC_List::Do( &d1, &Base3::Base3Func );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do( &d2, &Base3::Base3Func );
    EXPECT_EQ( mockCheckString, "Base3Func" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();
}

// checking member function calls
TEST( DOWNCAST, CAST_AND_CALL_MEMBER_WITH_SHARED_PTR )
{
    std::shared_ptr< Base > d1s{ new D1{} } ;
    std::shared_ptr< Base > d2s{ new D2{} } ;

    using ERR = CAC_Tuple::ERROR_T;
    // check with tuple generated CastAndCall
    CAC_Tuple::Do( d1s, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "SpecificD1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    // check with direct list generated CastAndCall
    CAC_List::Do( d1s, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "SpecificD1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    // no function SpecificD1 in D2->fails
    CAC_Tuple::Do( d2s, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do( d2s, &D1::SpecificD1 );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    // check for calls to methods upper in the hirarchy
    CAC_List::Do( d1s, &Base2::Base2Func );
    EXPECT_EQ( mockCheckString, "Base2Func" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do( d2s, &Base2::Base2Func );
    EXPECT_EQ( mockCheckString, "Base2Func" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    // Base3 is not base of d1 -> fails
    CAC_List::Do( d1s, &Base3::Base3Func );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do( d2s, &Base3::Base3Func );
    EXPECT_EQ( mockCheckString, "Base3Func" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();
}

// Check for getting return values
TEST( DOWNCAST, CAST_AND_CALL_RETVALS )
{
    using ERR = CAC_Tuple::ERROR_T;
    {
        auto ret = CAC_List::Do( &d1, &D1::TakesInt, 22 );
        EXPECT_EQ( ret, 66 );
        EXPECT_EQ( mockCheckString, "TakesIntD1" );
        EXPECT_EQ( lastError, 0 );
        lastError = 0;
        mockCheckString.clear();
    }

    // even if we have the same signature the wrong object type must be result in a failure
    {
        auto ret = CAC_List::Do( &d1, &D2::TakesInt, 22 );
        EXPECT_EQ( ret, 0 );    // default value!
        EXPECT_EQ( mockCheckString, "" ); // no function called
        EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
        lastError = 0;
        mockCheckString.clear();
    }

    // now the same with d2 method
    {
        auto ret = CAC_List::Do( &d2, &D2::TakesInt, 22 );
        EXPECT_EQ( ret, 132 );
        EXPECT_EQ( mockCheckString, "TakesIntD2" );
        EXPECT_EQ( lastError, 0 );
        lastError = 0;
        mockCheckString.clear();
    }

    // even if we have the same signature the wrong object type must be result in a failure
    {
        auto ret = CAC_List::Do( &d2, &D1::TakesInt, 22 );
        EXPECT_EQ( ret, 0 );    // default value!
        EXPECT_EQ( mockCheckString, "" ); // no function called
        EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
        lastError = 0;
        mockCheckString.clear();
    }
}

// Checking free function calls
TEST( DOWNCAST, CAST_AND_CALL_FREE_FUNCTIONS )
{
    using ERR = CAC_Tuple::ERROR_T;

    // template lambda allows all kind of objects
    // for using historic compilers we can not define that we need a pointer...
    auto lambda1 = []( auto obj )
    {
        obj->VFunc();
    };

    // template 
    auto lambda2 = []( D1* obj )
    {
        obj->VFunc();
    };

    CAC_List::Do<D1>( &d1, lambda1 );
    EXPECT_EQ( mockCheckString, "VFuncD1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do<D1>( &d2, lambda1 );
    EXPECT_EQ( mockCheckString, "VFuncD2" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    CAC_List::Do<D1>( &d1, lambda2 );
    EXPECT_EQ( mockCheckString, "VFuncD1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    {
        auto ret = CAC_Tuple::Do<D1>( &d1, FuncWithInt, 42 );
        EXPECT_EQ( mockCheckString, "FuncWithInt");
        EXPECT_EQ( ret, 84 ); 
        EXPECT_EQ( lastError, 0 );
        lastError = 0;
        mockCheckString.clear();
    }

    // non templated lambda only accepts d1 objects -> fail
    CAC_List::Do<D1>( &d2, lambda2 );
    EXPECT_EQ( mockCheckString, "" );
    EXPECT_EQ( lastError, ERR::FUNCTION_PARAMETER_MISMATCH );
    lastError = 0;
    mockCheckString.clear();

    Action1 ac1;
    Action2 ac2;
    ActionWithReturn acret;

    CAC_Tuple::Do<D2>( &d2, ac1 );
    EXPECT_EQ( mockCheckString, "Action1" );
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    {
        auto ret = CAC_Tuple::Do<D2>( &d2, acret );
        EXPECT_EQ( ret, 42 );
        EXPECT_EQ( mockCheckString, "ActionWithReturn");
        EXPECT_EQ( lastError, 0 );
        lastError = 0;
        mockCheckString.clear();
    }

    //using templated functor should work always
    CAC_Tuple::Do<D2>( &d2, ac2 );
    EXPECT_EQ( mockCheckString, "Action2");
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();

    CAC_Tuple::Do<D2>( &d1, ac2 );
    EXPECT_EQ( mockCheckString, "Action2");
    EXPECT_EQ( lastError, 0 );
    lastError = 0;
    mockCheckString.clear();
}

