/********************************************************************************
 *
 * @file   test_factory.h
 * @brief  testing factory pattern
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#include <gmock/gmock.h>
#include <sstream>
#include <memory>

#include "../factory/factory.h"

namespace 
{

// Provide some simple types to check factory can generate them
class Base
{
    public:
        virtual void Do( std::ostream& ) = 0;

        enum TYPE_ID
        {
            TYPE_A,
            TYPE_B
        };
};

class Any{};

class A: public Base
{
    private:
        int i;

    public:
        static constexpr auto SGetId() { return TYPE_A; }
        A( int _i ):i{_i}{}
        A( Any& ): i{222}{} // indication lvalue
        A( Any&& ): i{333}{} // indication rvalue

        void Do( std::ostream& os ) override { os << "A:" << i; }
};

class B: public Base
{
    private:
        std::string s;

    public:
        static constexpr auto SGetId() { return TYPE_B; }
        B( const std::string& _s ): s{_s} {}
        B( char c1, char c2, char c3 ): s{ c1,c2,c3 }{}

        void Do( std::ostream& os ) override { os << "B:" << s; }
};

/*
   Provide adapter for factory

   using shared_ptr as return type!
   */

template <typename BASE, typename OBJ_TYPE>
class Example_FactoryAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::SGetId(); }

        template <typename ... ARGS>
            static std::shared_ptr<BASE> Create( ARGS&& ... args ) { return std::make_shared<OBJ_TYPE>( std::forward<ARGS>( args )...); }

        static auto CreateInvalid( ) { return std::shared_ptr<BASE>{}; }
};

// Define the type of the factory for our example classes:

using ExampleFactory = Platform::Factory< Example_FactoryAdapter, Base, std::tuple< A,B >>;



} // end of anonymous namespace

TEST( FACTORY1, GENERATE1 )
{

    // try create an object
    {
        std::ostringstream os;
        auto obj = ExampleFactory::Create( Base::TYPE_A, 100 );
        EXPECT_TRUE( (bool)obj ); // we want to see a valid shared_ptr here
        obj->Do( os );
        EXPECT_EQ( os.str(), "A:100" );
    }

    // try second object type
    {
        std::ostringstream os;
        auto obj = ExampleFactory::Create( Base::TYPE_B, "Hallo" );
        EXPECT_TRUE( (bool)obj ); // we want to see a valid shared_ptr here
        obj->Do( os );
        EXPECT_EQ( os.str(), "B:Hallo" );
    }

    // try second object type with constructor overload resolution
    {
        std::ostringstream os;
        auto obj = ExampleFactory::Create( Base::TYPE_B, 'a','b','c' );
        EXPECT_TRUE( (bool)obj ); // we want to see a valid shared_ptr here
        obj->Do( os );
        EXPECT_EQ( os.str(), "B:abc" );
    }

    // take a look if rvalue is handled correctly with forwarding
    {
        std::ostringstream os;
        auto obj = ExampleFactory::Create( Base::TYPE_A, Any{} );
        EXPECT_TRUE( (bool)obj ); // we want to see a valid shared_ptr here
        obj->Do( os );
        EXPECT_EQ( os.str(), "A:333" );
    }

    // take a look if lvalue is handled correctly with forwarding
    {
        std::ostringstream os;
        Any any;
        auto obj = ExampleFactory::Create( Base::TYPE_A, any );
        EXPECT_TRUE( (bool)obj ); // we want to see a valid shared_ptr here
        obj->Do( os );
        EXPECT_EQ( os.str(), "A:222" );
    }

    // now try to create a object with wrong parms set
    {
        std::ostringstream os;
        Any any;
        auto obj = ExampleFactory::Create( Base::TYPE_B, any ); // TYPE_B did not accept type Any!
        EXPECT_FALSE( (bool)obj ); // we want to see an invalid shared_ptr here
    }

    // the following test should result in static assert as no type accepts parameter ostringstream
    {
        // if you enable the following line the compiler will assert with "No object can be created with given parms!"
        //auto obj = ExampleFactory::Create( TYPE_B, std::ostringstream{} ); // no type accepts ostringstream -> assert!
    }

}
