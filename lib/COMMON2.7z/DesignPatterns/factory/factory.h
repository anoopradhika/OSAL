#ifndef DESIGNPATTERNS_FACTORY_H
#define DESIGNPATTERNS_FACTORY_H

/********************************************************************************
 *
 * @file   factory.h
 * @brief  simple generic factory implementation
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#include <tuple>
#include <utility>
#include <type_traits>

namespace detail { // private namespace, please do not anything directly from here!

/**
  hidden implementation details of factory pattern. DO NOT CREATE MANUAL INSTANCE OF XXX_IMPL templates!

  Functionality

  it takes a list ( std::tuple ) of types which can be generated which must be inherit a common base class.
  The implementation ignores all types which can NOT be generated from the given set of argumens ( ARGS ).
  If there is no type which can be created from the given ARGS a static assert will emmit a compile time error.

  If there is at least one type which can be generated from the given ARGS set, all types will be checked against the given
  ID. If ID matches, the type will be constructed with given ARGS.
  */

template < int COUNT, template <typename,typename> class ADAPTER, typename BASE, typename ID_TYPE, typename ... TYPES >
    class Factory_Impl;

template < int COUNT, template <typename, typename> class ADAPTER, typename BASE, typename ID_TYPE, typename HEAD, typename ... TYPES >
    class Factory_Impl< COUNT, ADAPTER, BASE, ID_TYPE, HEAD, TYPES...>
    {
        public:
            // check if id matches with the id provided by the given type, but only if type can be constructed from
            // given parameter set (ARGS)
            template < typename ... ARGS >
                static auto Create( typename std::enable_if< std::is_constructible< HEAD, ARGS... >::value, ID_TYPE>::type id, ARGS&& ... args  )
                {
                    if ( id == ADAPTER<BASE,HEAD>::StaticGetId() )
                    {
                        return ADAPTER<BASE,HEAD>::Create( std::forward<ARGS>( args)... );
                    }
                    else
                    {
                        return Factory_Impl< COUNT+1, ADAPTER, BASE, ID_TYPE, TYPES...>::Create( id, std::forward<ARGS>( args)... );
                    }
                }

            // if type can not be constructed with given ARGS, don't try it, don't compare given id as it makes no sense
            template < typename ... ARGS >
                static auto Create( typename std::enable_if< !std::is_constructible< HEAD, ARGS... >::value, ID_TYPE>::type id, ARGS&& ... args )
                {
                    return Factory_Impl< COUNT, ADAPTER, BASE, ID_TYPE, TYPES...>::Create( id, std::forward<ARGS>( args)... );
                }
    };

/**
  end of unrolled type list, provide default return value for unmatched id.

  additionial compile time check if none of the given types can be generated with set of ARGS
  */

template < int COUNT, template <typename,typename> class ADAPTER, typename BASE, typename ID_TYPE>
    class Factory_Impl< COUNT, ADAPTER, BASE, ID_TYPE >
    {
        public:
            static_assert( COUNT != 0, "No object can be created with given parms!" );

            template < typename ... ARGS >
                static auto Create( ID_TYPE, ARGS&& ... )
                {
                    return ADAPTER<BASE,BASE>::CreateInvalid();
                }
    };

template < template <typename,typename> class ADAPTER, typename BASE, typename HEAD, typename ... TYPES >
    class FactoryImpl2: public Factory_Impl< 0, ADAPTER, BASE, decltype(ADAPTER<BASE,HEAD>::StaticGetId()), HEAD, TYPES...>
{};

} // end of private namespace

/**
  Simple generic factory

  @tparam ADAPTER It can be used by simply providing an ADAPTER class which has to provide:
  1) a method with the signature "static auto StaticGetId()" which return the ID of the type.
  2) a creation method which do the final creation of an object with the signature "static std::shared_ptr<BASE> Create( ARGS&& ... args )"
  3) a method for creating an invalid result like a nullptr if non of the id/parameter sets fit to the constructor. Signature: "static auto CreateInvalid ( )"
  All return values must fit to the given types!

  @tparam The BASE class is the typically the base class of all types have derived from.

  @tparam TYPES Give all the TYPES as a std::tuple list of types.

  Use cases and examples: See unit tests in UT folder!
  */

namespace Platform
{

template < template <typename,typename> class ADAPTER, typename BASE, typename ... TYPES >
class Factory;

template < template <typename,typename> class ADAPTER, typename BASE, typename ... TYPES >
class Factory< ADAPTER, BASE, std::tuple<TYPES...>>: public detail::FactoryImpl2< ADAPTER, BASE, TYPES...>
{
};

} // end namespace Platform

#endif // DESIGNPATTERNS_FACTORY_H
