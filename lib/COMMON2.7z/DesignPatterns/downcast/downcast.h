#ifndef DESIGNPATTERNS_DOWNCAST_H
#define DESIGNPATTERNS_DOWNCAST_H
/********************************************************************************
 *
 * @file   downcast.h
 * @brief  helper for downcasting objects based on user definied type id's.
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#include <utility>

/**
  SFINAE helper is_callable 

  checks if a call to a given function can be done with the given arguments

  For use cases take a look at unit tests in UT folder
  */

template<typename F, typename...Args> struct is_callable {
    template<typename F2, typename...Args2> static constexpr std::true_type
        test(decltype(std::declval<F2>()(std::declval<Args2>()...)) *) { return {}; }

    template<typename F2, typename...Args2> static constexpr std::false_type
        test(...) { return {}; }

    static constexpr bool value = decltype(test<F, Args...>(nullptr))::value;
};

// ####################################################################

namespace detail { // nobody should use the content directly!

/**
  Helper to make "return type void" available for generic implementations

  Problem to solve:
  you can not write a template with generic return type if the type deduces to void.
  so here is simply a specialization for void to get the "void" type back.
  In addition we need also to provide a reference back, so we create in that case a static instance
  of the type and return the ref to it.
  */

template < typename RET, typename std::enable_if< std::is_reference< RET >::value >::type* = nullptr >
    inline auto DummyRet() -> RET
    {
        std::cout << "ref" << std::endl;
        static typename std::remove_reference<RET>::type dummy{};
        return dummy;
    }

template < typename RET, typename std::enable_if< !std::is_same< void, RET >::value && !std::is_reference< RET >::value >::type* = nullptr >
    inline auto DummyRet() -> RET
    {
        std::cout << "rvalue" << std::endl;
        return RET{};
    }

template< typename RET, typename RET_USED = typename std::enable_if< std::is_same< void, RET >::value >::type >
    void DummyRet(){ std::cout << "void" << std::endl;}

/**
  recursive unroll loop over all given types.
  if static type of current object ( static type id ) is same as given run time type
  the implementation tries to call the given function or method.
  if this is not possible, error handler is called
  */

template < template <typename,typename> class ADAPTER, typename BASE, typename ERNO, typename ... TYPES >
    class CastAndCallImpl;

template < template <typename,typename> class ADAPTER, typename BASE, typename ERNO >
    class CastAndCallImpl< ADAPTER, BASE, ERNO >
    {
        public:
            // use pointer
            template < typename EXPECTED, typename FUNC, typename ... ARGS >
                static auto Do( BASE*, FUNC&&, ARGS&& ... )->
                decltype( std::declval<FUNC>()( std::declval<EXPECTED*>(),std::declval<ARGS>()...))
                {
                    ADAPTER<BASE,EXPECTED>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<decltype( std::declval<FUNC>()( std::declval<EXPECTED*>(),std::declval<ARGS>()...))>();
                }

            // use shared_ptr
            template < typename EXPECTED, typename FUNC, typename ... ARGS >
                static auto Do( std::shared_ptr<BASE>&, FUNC&&, ARGS&& ... )->
                decltype( std::declval<FUNC>()( std::declval<std::shared_ptr<EXPECTED>>(),std::declval<ARGS>()...))
                {
                    ADAPTER<BASE,EXPECTED>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<decltype( std::declval<FUNC>()( std::declval<std::shared_ptr<EXPECTED>>(),std::declval<ARGS>()...))>();
                }

            // user pointer and member function to non const obj
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static RET Do( BASE* , RET (CLASS::*)( ARGS...), ARGS2&& ... )
                {
                    ADAPTER<BASE,BASE>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<RET>();
                }

            // use shared_ptr and member function to non const obj
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2>
                static RET Do( std::shared_ptr<BASE>& , RET (CLASS::*)( ARGS...), ARGS2&& ... )
                {
                    ADAPTER<BASE,BASE>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<RET>();
                }

            // user pointer and member function to CONST obj
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static RET Do( BASE* , RET (CLASS::*)( ARGS...) const, ARGS2&& ... )
                {
                    ADAPTER<BASE,BASE>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<RET>();
                }

            // use shared_prt and member function to CONST obj
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static RET Do( std::shared_ptr<BASE>& , RET (CLASS::*)( ARGS...) const, ARGS2&& ... )
                {
                    ADAPTER<BASE,BASE>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<RET>();
                }
    };



template < template  <typename,typename> class ADAPTER, typename BASE, typename ERNO, typename HEAD, typename ... TYPES >
    class CastAndCallImpl<ADAPTER, BASE, ERNO, HEAD, TYPES...>: public CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >
    {
        public:
            using ERROR_T = ERNO;

            // ptr to obj, call with function ptr
            template < typename EXPECTED, typename FUNC, typename ... ARGS >
                static auto Do( typename std::enable_if< is_callable< FUNC, HEAD*, ARGS ... >::value, BASE*>::type base_ptr, FUNC&& f, ARGS&& ... args )
                {
                    if ( ADAPTER<BASE, HEAD>::DynamicGetId( base_ptr ) == ADAPTER<BASE, HEAD>::StaticGetId() )
                    {
                        return f( static_cast< HEAD* >( base_ptr ), std::forward<ARGS>(args)... );
                    }
                    else
                    {
                        return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do< EXPECTED>( base_ptr, f, std::forward<ARGS>(args)... );
                    }
                }

            template < typename EXPECTED, typename FUNC, typename ... ARGS >
                static auto Do( typename std::enable_if< !is_callable< FUNC, HEAD*, ARGS ... >::value, BASE*>::type base_ptr, FUNC&& f, ARGS&& ... args )
                {
                    return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do< EXPECTED>( base_ptr, f, std::forward<ARGS>(args)... );
                }

            // ######################

            // shared_ptr to obj, call with function ptr
            template < typename EXPECTED, typename FUNC, typename ... ARGS >
                static auto Do( typename std::enable_if< is_callable< FUNC, std::shared_ptr<HEAD>, ARGS ... >::value, std::shared_ptr<BASE>&>::type base_ptr, FUNC&& f, ARGS&& ... args )
                {
                    if ( ADAPTER<BASE, HEAD>::DynamicGetId( base_ptr ) == ADAPTER<BASE, HEAD>::StaticGetId() )
                    {
                        return f( std::static_pointer_cast<HEAD>( base_ptr ), std::forward<ARGS>(args)... );
                    }
                    else
                    {
                        return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do< EXPECTED>( base_ptr, f, std::forward<ARGS>(args)... );
                    }
                }

            template < typename EXPECTED, typename FUNC, typename ... ARGS >
                static auto Do( typename std::enable_if< !is_callable< FUNC, std::shared_ptr<HEAD>, ARGS ... >::value, std::shared_ptr<BASE>&>::type base_ptr, FUNC&& f, ARGS&& ... args )
                {
                    return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do< EXPECTED>( base_ptr, f, std::forward<ARGS>(args)... );
                }

            // ######################
            // call pointer to obj and member function for non const object
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static auto Do( BASE* base_ptr, RET (CLASS::*mem_ptr)( ARGS...), ARGS2&& ... args )->RET
                {
                    if ( ADAPTER<BASE, HEAD>::DynamicGetId( base_ptr ) == ADAPTER<BASE, HEAD>::StaticGetId() )
                    {
                        return CallMem( base_ptr, mem_ptr, std::forward<ARGS2>(args)... );
                    }
                    else
                    {
                        return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do( base_ptr, mem_ptr, std::forward<ARGS2>(args)... );
                    }
                }

            // use shared_prt and member function
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static auto Do( std::shared_ptr<BASE>& base_ptr, RET (CLASS::*mem_ptr)( ARGS...), ARGS2&& ... args )->RET
                {
                    if ( ADAPTER<BASE, HEAD>::DynamicGetId( base_ptr ) == ADAPTER<BASE, HEAD>::StaticGetId() )
                    {
                        return CallMem( base_ptr.get(), mem_ptr, std::forward<ARGS2>(args)... );
                    }
                    else
                    {
                        return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do( base_ptr, mem_ptr, std::forward<ARGS2>(args)... );
                    }
                }

            // ######################
            // call pointer to obj and member function for CONST object
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static auto Do( BASE* base_ptr, RET (CLASS::*mem_ptr)( ARGS...) const, ARGS2&& ... args )->RET
                {
                    if ( ADAPTER<BASE, HEAD>::DynamicGetId( base_ptr ) == ADAPTER<BASE, HEAD>::StaticGetId() )
                    {
                        return CallMem( base_ptr, mem_ptr, std::forward<ARGS2>(args)... );
                    }
                    else
                    {
                        return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do( base_ptr, mem_ptr, std::forward<ARGS2>(args)... );
                    }
                }

            // use shared_prt and member function
            template < typename CLASS, typename RET, typename ... ARGS, typename ... ARGS2 >
                static auto Do( std::shared_ptr<BASE>& base_ptr, RET (CLASS::*mem_ptr)( ARGS...) const, ARGS2&& ... args )->RET
                {
                    if ( ADAPTER<BASE, HEAD>::DynamicGetId( base_ptr ) == ADAPTER<BASE, HEAD>::StaticGetId() )
                    {
                        return CallMem( base_ptr.get(), mem_ptr, std::forward<ARGS2>(args)... );
                    }
                    else
                    {
                        return CastAndCallImpl< ADAPTER, BASE, ERNO, TYPES... >::template Do( base_ptr, mem_ptr, std::forward<ARGS2>(args)... );
                    }
                }
        private:
            // for member functions to non const objects
            template < typename RET, typename CLASSI, typename ... ARGS, typename ... ARGS2 >
                static auto CallMem( BASE* base_ptr, RET (CLASSI::*mem_ptr)( ARGS...), ARGS2&& ... args ) ->
                typename std::enable_if
                <
                std::is_convertible< HEAD*, CLASSI*>::value, RET
                >::type
                {
                    return (static_cast<CLASSI*>(base_ptr)->*mem_ptr)( std::forward<ARGS2>(args)...);
                }

            template < typename RET, typename CLASSI, typename ... ARGS, typename ... ARGS2 >
                static auto CallMem( BASE* , RET (CLASSI::*)( ARGS...), ARGS2&& ... ) ->
                typename std::enable_if
                <
                !std::is_convertible< HEAD*, CLASSI*>::value, RET
                >::type
                {
                    ADAPTER<BASE,HEAD>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<RET>();
                }

            // for member functions to CONST objects
            template < typename RET, typename CLASSI, typename ... ARGS, typename ... ARGS2 >
                static auto CallMem( BASE* base_ptr, RET (CLASSI::*mem_ptr)( ARGS...) const, ARGS2&& ... args ) ->
                typename std::enable_if
                <
                std::is_convertible< HEAD*, CLASSI*>::value, RET
                >::type
                {
                    return (static_cast<CLASSI*>(base_ptr)->*mem_ptr)( std::forward<ARGS2>(args)...);
                }

            template < typename RET, typename CLASSI, typename ... ARGS, typename ... ARGS2 >
                static auto CallMem( BASE* , RET (CLASSI::*)( ARGS...) const , ARGS2&& ... ) ->
                typename std::enable_if
                <
                !std::is_convertible< HEAD*, CLASSI*>::value, RET 
                >::type
                {
                    ADAPTER<BASE,HEAD>::Error( ERNO::FUNCTION_PARAMETER_MISMATCH );
                    return DummyRet<RET>();
                }
    };

/**
  error numbers which will be send to error handler in fault case
  */

struct ErrorNumbers
{
    // it is intended to have a implicit int convertable enum without a name!
    // so no enum class is in use here!
    enum 
    {
        NONE,
        FUNCTION_PARAMETER_MISMATCH
    };
};

} // detail

namespace Platform
{

/**
  call a specified method or function for a given base pointer to an object.

  @tparam ADATPTER
  User has to provide a ADAPTER to interface to user type as follows:
  1) a method which returns the corrosponding ID for a given type, signature: static auto StaticGetId()
  2) a method which returns the id of the current working object, signature auto DynamicGetId( BASE* base_ptr ) 
  3) error handler method with signature: void Error( int i )
  All methods are static! No need for handler object creation!

  @tparam BASE is the type of the base class of all objects to be handled
  @tparam TYPES is the list of all types to downcast to

  For real world use cases and examples see unit tests in folder UT
  */

template < template <typename,typename> class ADAPTER, typename BASE, typename ... TYPES >
    class CastAndCall: public detail::CastAndCallImpl< ADAPTER, BASE, detail::ErrorNumbers, TYPES... >
{};

template < template <typename,typename> class ADAPTER, typename BASE, typename ... TYPES >
class CastAndCall<ADAPTER, BASE, std::tuple< TYPES...>>: public detail::CastAndCallImpl< ADAPTER, BASE, detail::ErrorNumbers, TYPES...>
{};

} // end namespace Platform
#endif // DESIGNPATTERNS_DOWNCAST_H

