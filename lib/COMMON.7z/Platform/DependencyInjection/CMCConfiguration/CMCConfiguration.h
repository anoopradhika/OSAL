/*****************************************************************//**
 *
 * @file    CMCConfiguration.h
 * @brief   CMC Application specific configuration infromation are available in this
 * class
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef CMC_CONFIGURATION_H
#define CMC_CONFIGURATION_H

#include <cereal/cereal.hpp>

namespace Platform
{

/**
*    CMCConfiguration is used for configure CMC application
*    supported configuration:
*        - application_address
*        - broker_address
*        - unicast_port
*        - module_unicast_port
*        - multicast_port
*        - network_interface
*        - application_name
*/
class CMCConfiguration
{
public:
    CMCConfiguration() = default;
    CMCConfiguration(PROC_ADDRESS applicationAddress
                    , PROC_ADDRESS brokerAddress
                    , uint16_t unicastPort
                    , uint16_t moduleUnicastPort
                    , uint16_t multicastPort
                    , const std::string& networkInterface
                    , const std::string& appName
                ):m_applicationAddress{applicationAddress}
                , m_brokerAddress{brokerAddress}
                , m_unicastPort{unicastPort}
                , m_moduleUnicastPort{moduleUnicastPort}
                , m_multicastPort{multicastPort}
                , m_networkInterface{networkInterface}
                , m_appName{appName}
    {

    }

    PROC_ADDRESS GetApplicationAddress()
    {
        return m_applicationAddress;
    }

    PROC_ADDRESS GetBrokerAddress()
    {
        return m_brokerAddress;
    }

    uint16_t GetUnicastPort()
    {
        return m_unicastPort;
    }

    uint16_t GetModuleUnicastPort()
    {
        return m_moduleUnicastPort;
    }

    uint16_t GetMulticastPort()
    {
        return m_multicastPort;
    }

    std::string GetAppName()
    {
        return m_appName;
    }

    std::string GetNetworkInterfae()
    {
        return m_networkInterface;
    }
    CMCConfiguration& operator = (const CMCConfiguration& otherCMCConfiguration) = default;
    ~CMCConfiguration() = default;

private:
    PROC_ADDRESS m_applicationAddress{PROC_ADDRESS::END_OF_LIST};
    PROC_ADDRESS m_brokerAddress{PROC_ADDRESS::END_OF_LIST};
    uint16_t m_unicastPort{0};
    uint16_t m_moduleUnicastPort{0};
    uint16_t m_multicastPort{0};
    std::string m_networkInterface{};
    std::string m_appName{};
    //! Allow cereal to access this class
    friend class cereal::access;

    //! Member shall be added here for serialization
    template<class Archive>
    void serialize(Archive& archive)
    {
        archive( m_applicationAddress
               , m_brokerAddress
               , m_unicastPort
               , m_moduleUnicastPort
               , m_multicastPort
               , m_networkInterface
               , m_appName
               );
    }
};

}

#endif //CMC_CONFIGURATION_H
