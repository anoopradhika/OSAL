/*****************************************************************//**
 *
 * @file    ApplicationConfiguration.h
 * @brief   Application specif configuration infromation are available in this
 * class
 *
 * @copyright Copyright 20178by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef APPLICATION_CONFIGURATION_H
#define APPLICATION_CONFIGURATION_H

#include <cereal/cereal.hpp>
#include "CMCConfiguration/CMCConfiguration.h"

namespace Platform
{

/**
*    ApplicationConfiguration is a master class to keep all application
*    configuration.
*    supported applications:
*        --CMCApplication
*/
class ApplicationConfiguration
{
public:
    ApplicationConfiguration() = default;
    ~ApplicationConfiguration() = default;

    /**
    * Get panel iD from configuation
    * @return  Panel ID
    */
    uint64_t GetPanelID()
    {
        return m_panelId;
    }
    void SetPanelID(uint64_t id)
    {
        m_panelId = id;
    }
    void SetCMCConfiguration(CMCConfiguration& cmcConfiguration)
    {
        m_CMCConfiguration = cmcConfiguration;
    }
    auto GetCMCConfiguration()
    {
        return m_CMCConfiguration;
    }
private:
    uint64_t m_panelId{0};
    CMCConfiguration m_CMCConfiguration{};
    //! Allow cereal to access this class
    friend class cereal::access;

    //! Member shall be added here for serialization
    template<class Archive>
    void serialize(Archive& archive)
    {
        archive( m_panelId
               , m_CMCConfiguration
               );
    }
};

}

#endif //APPLICATION_CONFIGURATION_H
