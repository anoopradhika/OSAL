/*****************************************************************//**
 *
 * @file    ConfigurationInjector.h
 * @brief   Application specif configuration infromation are available in this
 * class
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef CONFIGURATION_INJECTOR_H
#define CONFIGURATION_INJECTOR_H

#include <fstream>      // std::ofstreamt

#include <cereal/archives/json.hpp>

namespace Platform
{

/**
*    ConfigurationInjector creates configuration classs from configuration file
*/
class ConfigurationInjector
{
public:

    /**
    * Singleton interface to get configurationInjector
    */
    static ConfigurationInjector& GetInjector(const std::string& filename)
    {
        static ConfigurationInjector configurationInjector{filename};
        return configurationInjector;
    }

    /**
    * Get configuration object
    * @tparam ObjectType: type of configuration class
    * @param[out] object: object is populated with configuration information
    */
    template<typename ObjectType>
    void Get(ObjectType& object)
    {
        std::ifstream istrm(m_filename, std::ios::binary);
        istrm.seekg (0, istrm.end);
        int length = istrm.tellg();
        istrm.seekg (0, istrm.beg);
        char * buffer = new char [length];
        istrm.read (buffer,length);
        std::stringstream is(buffer);
        cereal::JSONInputArchive archive_in(is);
        archive_in(object);
    }
private:
    /**
    * Constructor
    * @param filename: configuation file name
    */
    ConfigurationInjector(const std::string& filename)
    :m_filename{filename}
    {

    }
    ~ConfigurationInjector() = default;

    /// Configuation file name
    std::string m_filename{};
};

}

#endif //CONFIGURATION_INJECTOR_H
