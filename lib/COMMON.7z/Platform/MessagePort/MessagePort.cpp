#include"MessagePort.h"
#include <iostream>
#include <unistd.h>
#include <chrono>


namespace Platform
{

const std::string MessagePort::IPC_URL  = "ipc:///tmp/prot:";
const int32_t MessagePort::m_PollingTimeOutMS  = 10000;

MessagePort& MessagePort::getMessagePort()
{
  static MessagePort messagePort;
  return messagePort;
}

void MessagePort::Prepare(Protocol protocol, Platform::MessagePortID publisherId)
{
    if(PUBLISH_SUBSCRIBE == protocol)
    {
        m_PublishDescriptor  = nn_socket (AF_SP, NN_PUB);
        std::string publisherUrl = IPC_URL+std::to_string(static_cast<uint32_t>(publisherId));
        nn_bind (m_PublishDescriptor, publisherUrl.c_str());

        m_SubscribeDescriptor  = nn_socket (AF_SP, NN_SUB);
        usleep(100000);
        
        m_PairDescriptor = -1;
        m_pollFd.fd = m_SubscribeDescriptor;
        m_pollFd.events = NN_POLLIN;
    }
    else
    {
      // error message
    }
    
}


void MessagePort::Start()
{
    m_active = true;
    CppThread::Start();
}

void MessagePort::Stop()
{
    CppThread::Detach();
    CppThread::Stop();
    m_active = false;
}

void MessagePort::Shutdown()
{
    nn_close(m_PublishDescriptor);
    nn_close(m_SubscribeDescriptor);
}


int32_t MessagePort::Connect(Platform::MessagePortID subscriberId)
{
    std::string subscriberUrl = IPC_URL+std::to_string(static_cast<uint32_t>(subscriberId));
    const int32_t endPoint = nn_connect (m_SubscribeDescriptor, subscriberUrl.c_str());
    nn_setsockopt(m_SubscribeDescriptor, NN_SUB, NN_SUB_SUBSCRIBE, "", 0);
    return endPoint;
}


void MessagePort::Disconnect(Platform::MessagePortID subscriberId, int32_t endPoint)
{
    nn_shutdown(m_SubscribeDescriptor,endPoint);
}




void* MessagePort::Run(void* const args)
{
    
    while(m_active)
    {
        const int32_t pollingStatus = nn_poll (&m_pollFd, 1, m_PollingTimeOutMS);
        if((0 != pollingStatus) && (-1 != pollingStatus))
        {
            char* message;
            const int32_t receivedbytes =  nn_recv(m_SubscribeDescriptor,&message,NN_MSG,NN_DONTWAIT);
            if(-1 != receivedbytes)
            {
                
                Distributer(std::string(message,receivedbytes));
                nn_freemsg(message);
            }
        }
    }
    return (void*)1;
}
}