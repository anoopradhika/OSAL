/**
 * @file   Message.h
 * @Author Anoop Chandran (anoop.chandran@honeywell.com)
 * @brief  messageport to send and receive message
 *
 */
 
#ifndef MESSAGEPORT_INCLUDE_H
#define MESSAGEPORT_INCLUDE_H

#include <stdint.h>
#include <string>
#include <cstring>
#include <iostream>

#include "nanomsg/nn.h"
#include "nanomsg/pubsub.h"
#include "Dispatcher/Dispatcher.h"
#include "CppThread.h"

namespace Platform
{

/**
    MessagePort combine with Nanomsg lib provides a bus system.
    which is used to send and receive message among processes. 
*/
class MessagePort: public Dispatcher, CppThread
{

    public:
        /**
            Protocol type used for messageport comminuication.
        */
        typedef enum
        {
            PUBLISH_SUBSCRIBE,
            PAIR,
            INVALID
        }Protocol;

        /**
            Wait type used in message receive.
        */
        typedef enum:int32_t
        {
          WAIT,
          DONTWAIT
        }WaitType;

        /**
            Method to send message
            @param sendData: Data to send
            @param length: Length of the data in bytes
            @return number of bytes send. -1 for failure
        */
        template<typename SendDataType>
        int32_t Send(SendDataType& sendData,uint32_t length );

        /**
            Method to receive message
            @param sendData: Data to receive
            @param length: Length of the data in bytes
            @param waitType: default is DONTWAIT
            @return number of bytes received. -1 for failure
        */
        template<typename ReceiveDataType>
        int32_t Receive(ReceiveDataType& receiveData, uint32_t lenghByte, WaitType waitType = DONTWAIT );

        /**
            Prepare socket with required protoc0l and 
            bind it with port ID
            @param protocol: Type of protocol 
            @param publisherId: ID of Publisher, 
                   only one publisher Id per process
        */
        void Prepare(Protocol protocol, Platform::MessagePortID publisherId);

        /**
            Start Cppthread to activate dispatcher
        */
        void Start();

        /**
            Stop Cppthread to stop dispatcher
        */
        void Stop();

        /**
            Connect to specific message port to receive message
            @param subscriberId: ID to receive message
            @return connected endPoint ID, -1 on failure 
        */
        int32_t Connect(Platform::MessagePortID subscriberId);

        /**
            Disconnect from specific message port.No more message 
            can receive after this operation from the specified messageport
            @param subscriberId: ID to receive message
            @param endPoint: endPoint received on connection 
        */
        void Disconnect(Platform::MessagePortID subscriberId, int32_t endPoint);

        /**
            Close publisher and subscriber port.
        */
        void Shutdown();

        /**
            Singleton to get MessagePort instance.
            This is to make sure that only one MessagePort is
            created per process
        */
        static MessagePort& getMessagePort();

        /**
            IPC_URL is append with MessagePortID  to create 
            MessagePort URL
        */
        static const std::string IPC_URL;

        /**
            Timeout used for message polling dispatcher thread
        */
        static const int32_t m_PollingTimeOutMS;

    private:
        /**
            A default constructor. Constructor is placed 
            under private to avoid MessagePort creation.
        */
        MessagePort() = default;

        /**
            A default constructor 
        */
        ~MessagePort() = default;

        /**
            Dispatcher thread.
            Polling method is used for receives messages.
            Later is dispatch to registered software components.
        */
        virtual void* Run(void* const args);

        /**
            Publisher socket descriptor store to m_PublishDescriptor 
            after publisher socket creation. 
        */
        int32_t m_PublishDescriptor;

        /**
            Subscriber socket descriptor store to m_PublishDescriptor 
            after socket subscriber creation. 
        */
        int32_t m_SubscribeDescriptor;

        /**
            Pair socket descriptor store to m_PublishDescriptor 
            after socket pair creation. 
        */
        int32_t m_PairDescriptor;

        /**
            Force full termination of dispatcher thread
        */
        bool m_active;
        
        /**
            Pooling file descriptor holds the type message watching and 
            socket ID. Both are updated in Prepare method.
        */
        struct nn_pollfd m_pollFd;

};


template<typename SendDataType>
int32_t MessagePort::Send(SendDataType& sendData,uint32_t length )
{
    return nn_send(m_PublishDescriptor,&sendData,length,NN_DONTWAIT);
}


template<typename ReceiveDataType>
int32_t MessagePort::Receive(ReceiveDataType& receiveData,uint32_t lenghByte, WaitType waitType )
{
    return nn_recv(m_SubscribeDescriptor,&receiveData,lenghByte,waitType);
}
}
#endif //MESSAGEPORT_INCLUDE_H
