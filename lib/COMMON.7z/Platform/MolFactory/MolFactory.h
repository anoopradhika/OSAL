#ifndef MOL_FACTORY_H
#define MOL_FACTORY_H
/*****************************************************************//**
 *
 * @file    MolFactory.h
 * @brief   factory for Command objects
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

// framework
namespace Platform {

/**
  Adapter for MOL factoy
  @tparam BASE base type of a class hirarchy
  @tparam OBJ_TYPE obj type to create
  */

template <typename BASE, typename OBJ_TYPE>
class MolFactoryAdapter
{
    public:
        /**
          Get the static type id of the type OBJ_TYPE
          @retval returns the static ID of the referenced OBJ_TYPE
          */
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }

        /**
          Create new instance of OBJ_TYPE
          @param[in] args forward all input parameters to factory which forward to constructor
          @retval shared_ptr for new instance
          */
          template <typename ... ARGS>
            static std::shared_ptr<BASE> Create( ARGS&& ... args ) {
                auto message = std::make_shared<OBJ_TYPE>( std::forward<ARGS>( args )...);
                 return message;
              }

          /**
            Create a default instance of pointer to BASE type which is intentional an invalid std::shared_ptr
            @retval invalid instance of a shared_ptr to BASE type
            */
        static auto CreateInvalid( ) { return std::shared_ptr<BASE>{}; }
};

} // end namespace
#endif
