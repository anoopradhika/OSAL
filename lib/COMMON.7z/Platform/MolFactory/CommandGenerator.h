#ifndef COMMAND_GENERATOR_H
#define COMMAND_GENERATOR_H
/*****************************************************************//**
 *
 * @file    CommandGenerator.h
 * @brief   Class to create Command objects and send
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

// framework
#include "Mol/Commands/Command.h"
#include "Mol/Commands/CommandTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"

namespace Platform {

using CommandFactory = Platform::Factory< MolFactoryAdapter, Mol::Message<Mol::Command::COMMAND_CATEGORY>, CommandObjectTypes >;

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class CommandDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i ) 
        {
           // Intentionally unimplemented...
        }
};
struct CommandSender {
    CommandSender(PROC_ADDRESS address,uint64_t id)
                : m_address{address}
                , m_id{id}
    {}
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message )
    {
        Platform::Communicator{}.m_command.Send(message, m_address, m_id);
    }
    PROC_ADDRESS m_address;
    uint64_t m_id;
};

auto SendCommand = [](auto command,PROC_ADDRESS address,uint64_t id)
{
    using CommandCaster = Platform::CastAndCall< CommandDowncastAdapter,  Mol::Message<Mol::Command::COMMAND_CATEGORY>, CommandObjectTypes >;
    CommandCaster::Do<Mol::Command::CommandDefault>(command,CommandSender{address,id});
};
} // end namespace
#endif
