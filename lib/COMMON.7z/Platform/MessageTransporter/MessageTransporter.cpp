
/******************************************************************************//**
* @file MessageTransporter.cpp
* @brief MessageTransporter send, receive and subscriber messages .
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#include"MessageTransporter/MessageTransporter.h"
#include "CommonDef.h"
#include <iostream>
#include <cerrno>
#include <cstring>

namespace Platform
{


MessageTransporter& MessageTransporter::GetMessageTransporter()
{
    static MessageTransporter messageTransporter;
    return messageTransporter;
}


void MessageTransporter::Prepare(PROC_ADDRESS publisherId)
{
    if(m_publisherId == PROC_ADDRESS::UNINITIALIZED)
    {
        m_publisherId = publisherId;
        m_Workers.push_back(publisherId);
        AddListener(publisherId,GlobalDataType::MessageQueue::BlockType::BLOCK);
    }
}


void MessageTransporter::Shutdown()
{
    QueueDeregistration(m_publisherId);
}


void MessageTransporter::Connect(PROC_ADDRESS subscriberId)
{
    if(PROC_ADDRESS::BROADCAST == subscriberId)
    {
        RetrieveSendQueueIDs();
    }
    else
    {
        AddPublisher(subscriberId,GlobalDataType::MessageQueue::BlockType::NON_BLOCK);
    }
}

void MessageTransporter::Connect(const std::set<PROC_ADDRESS>& subscriberIds)
{
    for(auto& subscriberId : subscriberIds)
    {
        if(m_broadcastQueues.end() == m_broadcastQueues.find(subscriberId))
        {
            m_broadcastQueues[subscriberId] = Platform::MessageQueue<>{m_processMap[subscriberId].c_str()
            ,GlobalDataType::MessageQueue::BlockType::NON_BLOCK};
        }
        else
        {
               DEBUGPRINT(DEBUG_ERROR, "Publisher exists %s\n", m_processMap[subscriberId].c_str());
        }
    }
}

void MessageTransporter::NeedBrokerSupport(PROC_ADDRESS publisherId)
{
    m_Workers.push_back(publisherId);
    m_brokerId = publisherId;
    AddListener(publisherId,GlobalDataType::MessageQueue::BlockType::BLOCK);
}


void MessageTransporter::Disconnect(const std::set<PROC_ADDRESS>& subscriberIds)
{
    for(auto& subscriberId : subscriberIds)
    {
        QueueDeregistration(subscriberId);
    }
}

void MessageTransporter::Disconnect(PROC_ADDRESS subscriberId, int32_t endPoint)
{
    if(PROC_ADDRESS::BROADCAST == subscriberId)
    {
        for(auto &iterator : m_publisherQueues)
        {
            if(m_publisherId != subscriberId) //Cross checking not a self application
            {
                QueueDeregistration(iterator.first);
            }
        }
    }
    else
    {
        QueueDeregistration(subscriberId);
    }

}


void MessageTransporter::Start() {
     m_active = true;

}


void MessageTransporter::Stop() {
    m_active = false;
}


bool  MessageTransporter::Send(std::string& message,const PROC_ADDRESS destinationAddress,uint32_t waitTimeMs,bool toFront)/*uint32_t waitTimeMs =0,bool toFront=false*/
                                                                                                                            /*both are default parameters*/
{
    bool returnCode = false;
    if(m_processMap.empty())
    {
        return returnCode;
    }

    if(destinationAddress == PROC_ADDRESS::BROADCAST)
    {
        returnCode = true;
        bool BroadcastSuccess = false;
        if(!m_broadcastQueues.empty())
        {
            for(auto &iterator : m_broadcastQueues)
            {

                if((PROC_ADDRESS::UNINITIALIZED != m_brokerId ) && (m_brokerId == iterator.first))
                {
                    //skip send for local/own broker
                }
                else
                {
                    Platform::MessageQueue<>& sendQueue = iterator.second; //Send to all applications on broadcast
                    BroadcastSuccess = sendQueue.Send(message,waitTimeMs,toFront);
                    if(!BroadcastSuccess)
                    {
                        returnCode = false;
                    }
                }
            }
        }
        else
        {
            for(auto &iterator : m_publisherQueues)
            {

                if((PROC_ADDRESS::UNINITIALIZED != m_brokerId ) && (m_brokerId == iterator.first))
                {
                    //skip send for local/own broker
                }
                else
                {
                    Platform::MessageQueue<>& sendQueue = iterator.second; //Send to all applications on broadcast
                    BroadcastSuccess = sendQueue.Send(message,waitTimeMs,toFront);
                    if(!BroadcastSuccess)
                    {
                        returnCode = false;
                    }
                }
            }
        }


    }
    //Sends only to specific application
    else
    {
        if(m_publisherQueues.end() != m_publisherQueues.find(destinationAddress))
        {
            Platform::MessageQueue<>& sendQueue = m_publisherQueues.at(destinationAddress);
            returnCode = sendQueue.Send(message,waitTimeMs,toFront);
        }
        else
        {
#ifndef CCL_OSSELECT_NXP_K66_FREE_RTOS
            DEBUGPRINT(DEBUG_ERROR,"MessageTransporter::SendMessage sendQueue with destinationAddress %d not found\n",(uint32_t)destinationAddress);
#else
            DEBUGPRINT(DEBUG_ERROR,"MessageTransporter::SendMessage sendQueue with destinationAddress %lu not found\n",(uint32_t)destinationAddress);
#endif
        }
    }
    return returnCode;
}


std::string MessageTransporter::Receive()
{

    char receivedMessage[MaxPacketSize] {};

    int32_t size = ReceiveMessage((char*)receivedMessage,MaxPacketSize);
    if( (-1 != size) &&((int32_t)MaxPacketSize < size))
    {
        return std::string();
    }
    return std::string(receivedMessage,size);
}


int MessageTransporter::RetrieveSendQueueIDs()
{
    if(m_processMap.find(m_thisApp) == m_processMap.end())
    {
#ifndef CCL_OSSELECT_NXP_K66_FREE_RTOS
        DEBUGPRINT(DEBUG_ERROR, "MessageTransporter::RetrieveSendQueueIDs m_thisApp  ID %d is not found in m_processMap\n", (uint32_t)m_thisApp);
#else
        DEBUGPRINT(DEBUG_ERROR, "MessageTransporter::RetrieveSendQueueIDs m_thisApp  ID %lu is not found in m_processMap\n", (uint32_t)m_thisApp);
#endif
        return ERROR_VALUE;
    }

    std::string thisQueueName = m_processMap.at(m_thisApp);

    m_publisherQueues.clear();

    //Parse through the map and create/retrieve queue ids of other applications

    for(auto &iterator : m_processMap)
    {
        std::string queueName = (iterator.second);
        if(queueName != thisQueueName) //Cross checking not a self application
        {
            m_publisherQueues[iterator.first] = Platform::MessageQueue<>{queueName,
                    GlobalDataType::MessageQueue::BlockType::BLOCK};
        }
    }

    if(m_publisherQueues.empty())
    {
        DEBUGPRINT(DEBUG_ERROR,"MessageTransporter::RetrieveSendQueueIDs m_publisherQueues is empty");
        return ERROR_VALUE;
    }

    return SUCCESS;
}


bool MessageTransporter::SendMessage(const char * const data, const uint16_t dataLength, const PROC_ADDRESS destinationAddress)
{
    bool returnCode = false;

    if(m_processMap.empty())
    {
        return returnCode;
    }

    if(destinationAddress == PROC_ADDRESS::BROADCAST)
    {
        returnCode = true;
        bool BroadcastSuccess = false;
        for(auto &iterator : m_publisherQueues)
        {
            Platform::MessageQueue<>& sendQueue = iterator.second; //Send to all applications on broadcast
            std::string message(data,dataLength);
            BroadcastSuccess = sendQueue.Send(message);
            if(!BroadcastSuccess)
            {
                returnCode = false;
            }
        }
    }
    //Sends only to specific application
    else
    {
        if(m_publisherQueues.end() != m_publisherQueues.find(destinationAddress))
        {
            Platform::MessageQueue<>& sendQueue = m_publisherQueues.at(destinationAddress);
            std::string message(data,dataLength);
            returnCode = sendQueue.Send(message);
        }
        else
        {
#ifndef CCL_OSSELECT_NXP_K66_FREE_RTOS
            DEBUGPRINT(DEBUG_ERROR, "MessageTransporter::SendMessage destinationAddress  ID %d is not found\n", (uint32_t)destinationAddress);
#else
            DEBUGPRINT(DEBUG_ERROR, "MessageTransporter::SendMessage destinationAddress  ID %lu is not found\n", (uint32_t)destinationAddress);
#endif
        }
    }


    return returnCode;

}

void MessageTransporter::AddListener(PROC_ADDRESS subscriberId, GlobalDataType::MessageQueue::BlockType blockType)
{
    if(m_listenerQueues.end() == m_listenerQueues.find(subscriberId))
    {
        m_listenerQueues[subscriberId] = Platform::MessageQueue<>{m_processMap[subscriberId].c_str(),
                                                                  blockType};
        if(subscriberId == m_brokerId)
        {
            m_listenerQueues[subscriberId].Registration([this](const std::string& Message)
                                                        {
                                                            BrokerDistributer(Message);
                                                        }
                                                    );
        }
        else
        {
            m_listenerQueues[subscriberId].Registration([this](const std::string& Message)
                                                        {
                                                            Distributer(Message);
                                                        }
                                                    );
        }
    }
    else
    {
           DEBUGPRINT(DEBUG_ERROR, "Listener exists %s\n", m_processMap[subscriberId].c_str());
    }
}

void MessageTransporter::AddPublisher(PROC_ADDRESS subscriberId, GlobalDataType::MessageQueue::BlockType blockType)
{

    if(m_publisherQueues.end() == m_publisherQueues.find(subscriberId))
    {
        m_publisherQueues[subscriberId] = Platform::MessageQueue<>{m_processMap[subscriberId].c_str(),
        blockType};
    }
    else
    {
           DEBUGPRINT(DEBUG_ERROR, "Publisher exists %s\n", m_processMap[subscriberId].c_str());
    }
}


void MessageTransporter::QueueDeregistration(PROC_ADDRESS publisherId)
{
    m_publisherQueues.erase(publisherId);
}

int32_t MessageTransporter::ReceiveMessage(char *data, const uint16_t datalength, const uint32_t waitTime)
{
    std::string Message = m_publisherQueues[m_thisApp].Receive();
    Message.copy(data,Message.size());
    return Message.size();
}
}// end of Platform
