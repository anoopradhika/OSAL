
/******************************************************************************//**
* @file MessageTransporter.h
* @brief MessageTransporter send, receive and subscriber messages .
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MESSAGE_TRANSPORTER_H
#define PLATFORM_MESSAGE_TRANSPORTER_H

#include "Dispatcher/Dispatcher.h"
#include "PlatformType/PlatformType.h"
#include "MessageQueue/MessageQueue.hpp"

#include "CommonDef.h"

namespace Platform
{

class MessageTransporter : public  Dispatcher
{
public:

        static MessageTransporter &GetMessageTransporter();
        /**
            Method to send message
            @param sendData: Data to send
            @param destinationAddress:  Address to send Message
            @return number of bytes send. -1 for failure
        */
        bool Send(std::string& message,const PROC_ADDRESS destinationAddress,uint32_t waitTimeMs = 0,bool toFront = false);

        /**
            Method to receive message
            @return data received
        */
        std::string Receive();

    /**
        Prepare MessageTransporter with PROC_ADDRESS
        @param publisherId: ID of Publisher,
               only one publisher Id per process
    */
    void Prepare(PROC_ADDRESS publisherId);
    /**
        Start Cppthread to activate dispatcher
    */
    void Start();
    /**
        Stop Cppthread to stop dispatcher
    */
    void Stop();
    /**
        Close publisher and subscriber port.
    */
    void Shutdown();

    /**
        Connect to specific MessageTransporter to receive message
        @param subscriberId: ID to receive message
    */
    void Connect(PROC_ADDRESS subscriberId);

    /**
        Connect to specific set of MessageTransporter to receive message
        @param subscriberId: ID to receive message
    */
    void Connect(const std::set<PROC_ADDRESS>& subscriberIds);

    /**
        Disconnect from specific message port.No more message
        can receive after this operation from the specified messageport
        @param subscriberId: ID to receive message
        @param endPoint: endPoint received on connection
    */
    void Disconnect(PROC_ADDRESS subscriberId, int32_t endPoint = 0);

    /**
        Disconnect from specific set of MessageTransporter from receive message
        @param subscriberId: ID to stop receive message
    */
    void Disconnect(const std::set<PROC_ADDRESS>& subscriberIds);

    /**
        Use if the application is using internal broker,
        Add Transport facility for broker
        @param publisherId: Publisher ID used by broker
    */
    void NeedBrokerSupport(PROC_ADDRESS publisherId);
private:
    MessageTransporter() = default;
    ~MessageTransporter()
    {
        m_processMap.clear();
        m_publisherQueues.clear();
        m_listenerQueues.clear();
    }
    /**
        Dispatcher thread.
        Polling method is used for receives messages.
        Later is dispatch to registered software components.
    */
    void Receiver(PROC_ADDRESS id);

    bool SendMessage(const char* const data,const uint16_t dataLength,const PROC_ADDRESS destinationAddress=PROC_ADDRESS::BROADCAST);
    int32_t ReceiveMessage(char* data,const uint16_t datalength,const uint32_t waitTime=0);

    PROC_ADDRESS m_publisherId = PROC_ADDRESS::UNINITIALIZED;
    PROC_ADDRESS m_brokerId = PROC_ADDRESS::UNINITIALIZED;
    bool m_active = false;
    static const uint32_t MaxPacketSize = 256;
    int RetrieveSendQueueIDs();
    void AddListener(PROC_ADDRESS publisherId,GlobalDataType::MessageQueue::BlockType blockType);
    void AddPublisher(PROC_ADDRESS publisherId,GlobalDataType::MessageQueue::BlockType blockType);
    void QueueDeregistration(PROC_ADDRESS publisherId);
    PROC_ADDRESS m_thisApp = PROC_ADDRESS::UNINITIALIZED;

    Platform::MessageQueue<> m_recvQueue;
    std::map<PROC_ADDRESS,Platform::MessageQueue<>> m_publisherQueues;
    std::map<PROC_ADDRESS,Platform::MessageQueue<>> m_broadcastQueues;
    std::map<PROC_ADDRESS,Platform::MessageQueue<>> m_listenerQueues;
    std::vector<PROC_ADDRESS> m_Workers;

    //This can be read or generate statically from some configuration or static file..//TODO:Check in future for more applications
    #if IS_LINUX_PLATFORM()
    std::map<PROC_ADDRESS,std::string> m_processMap = {
                                                        {PROC_ADDRESS::MAINLOOP,"ProcMainloopMQ"},
                                                        {PROC_ADDRESS::CMCAPP,"ProcCMCAppMQ"},
                                                        {PROC_ADDRESS::CNE,"ProcCneAppMQ"},
                                                        {PROC_ADDRESS::IOMGR,"ProcioMgrAppMQ"},
                                                        {PROC_ADDRESS::NETWORK,"ProcNwkAppMQ"},
                                                        {PROC_ADDRESS::ISOMAPP,"ProcIsomAppMQ"},
                                                        {PROC_ADDRESS::EVENTLOGAPP,"ProcELAppMQ"},
                                                        {PROC_ADDRESS::FIRMWAREAPP,"ProcFWAppMQ"},
                                                        {PROC_ADDRESS::FIRE_DOMAIN_APP,"ProcFDAMQ"},
                                                        {PROC_ADDRESS::CCL_BROKER,"ProcCCLBroker"},
                                                        {PROC_ADDRESS::MOL_SENDER,"ProcMolSender"},
                                                        {PROC_ADDRESS::MOL_RECEIVER,"ProcMolReceiver"},
														{PROC_ADDRESS::EVENT_PROVIDERAPP,"ProcEPAppMQ"},
														{PROC_ADDRESS::LICENSEVALIDATOR,"ProcLiVaAppMQ"},
                                                        {PROC_ADDRESS::AUDITLOG_APP,"ProcAdtAppMq"},
                                                        {PROC_ADDRESS::ENGLOG_APP,"ProcEngLogAppMQ"},
                                                        {PROC_ADDRESS::ACTIVE_EVENTSAPP,"ProcActEvtsAppMQ"},
														{PROC_ADDRESS::CLSSMGR,"ProcClssMgrMQ"},
                                                        //{PROC_ADDRESS::ZONALINDICATOR,"ProcZNAppMQ"},
                                                        {PROC_ADDRESS::PANELLEARN_APP,"ProcPNLAppMQ"}
                                                      };
    #elif IS_FREE_RTOS_PLATFORM()
    std::map<PROC_ADDRESS,std::string> m_processMap = {
                                                        {PROC_ADDRESS::MODULE_APP,"ProcModuleApp"},
                                                        {PROC_ADDRESS::CCL_BROKER,"ProcCCLBroker"}
                                                      };
    #else
    #error "Unknown platform type!!!"
    #endif
};



} //end of platform
#endif //PLATFORM_MESSAGE_TRANSPORTER_H
