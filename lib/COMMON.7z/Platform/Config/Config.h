#ifndef PLATFORM_CONFIG_INCLUDE_H
#define PLATFORM_CONFIG_INCLUDE_H

#ifdef HMI_BUILD
namespace PlatformNative = PlatformLinux;
#else
namespace PlatformNative = PLATFORMTYPE; 
#endif

#endif// PLATFORM_CONFIG_INCLUDE_H
