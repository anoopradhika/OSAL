/******************************************************************************//**
* @file PlatformType.h
* @brief Platform identifying methods 
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFOPRM_PLATFORM_TYPE_H
#define PLATFOPRM_PLATFORM_TYPE_H

// Helper to determine the currently selected platform
#define CAT_HELPER(lhs, rhs)            lhs##rhs
#define CAT(lhs, rhs)                   CAT_HELPER(lhs, rhs)

#define TEST_PREFIX_PlatformLinux       0
#define TEST_PREFIX_PlatformFreeRTOS    1

#define IS_LINUX_PLATFORM()             (CAT(TEST_PREFIX_, PLATFORMTYPE) == CAT(TEST_PREFIX_, PlatformLinux))
#define IS_FREE_RTOS_PLATFORM()         (CAT(TEST_PREFIX_, PLATFORMTYPE) == CAT(TEST_PREFIX_, PlatformFreeRTOS))

#endif //PLATFOPRM_PLATFORM_TYPE_H
