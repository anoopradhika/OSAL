/**********************************************************************************
* @file     CCLMessageBroker.h
* @brief    Collect message from subscriber and send to Wire
*           Get message from  wire and broadcast to all subscriber
*
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#ifndef CCL_MESSAGE_BROKER_INCLUDE_H
#define CCL_MESSAGE_BROKER_INCLUDE_H

#include "Component/Component.h"
#include "Mol/DeviceUniqueID.h"
#include "CommunicationLibrary.h"
#include "CommonDefsInCCL.h"
#include "Mol/Events/Event.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/FunctionDisable.h"
#include "Mol/Events/FunctionEnable.h"
#include "Mol/Events/DelayStartedEvent.h"
#include "Mol/Events/WarningEvent.h"
#include "Mol/Commands/SetAlarmSignal.h"
#include "Mol/Commands/Command.h"
#include <iostream>
#include "LibraryErrorCodes.h"


namespace Platform
{

/** @brief This class is used by CommonModuleCommunicator Application.
           It is used to Register the ipAddress and ModuleID mapping to ATU map.
           Register to CCL library for initiating network communication with other modules
           and Start a thread which receives the messages from CCL.
           It broadcasts the same message to other applications through FDA.
           This class also provides interface for the log Dump.
*/

class CCLMessageBroker: public Platform::Component
{
public:

/**
     * @brief       Constructor is used to populate the private members
     * @param[in]   ipv6Address IPV6 Address of the Main CPU
     * @param[in]   sourceID the ModuleID of the Main CPU
     * @param[in]   appName calling Application name like "CMCApp"
     * @param[in]   selfPort the UNICAST listening port number of the Calling Application(8000).
     * @param[in]   peerPort the UNICAST listening port number of the other Module Application(8000).
     * @param[in]   multicastPort the Mulitcast port number at which modules are listening.
     * @param[in]   type type of communication
     * @param[in]   dealyedCCLRegisteration Status of Registration with CCL
     * @param[in]   storage ATUStorage Address translation from DNM and IP Address map's storage location
     * @return CCLMessageBroker object is constructed
*/

    CCLMessageBroker(const std::string& ipv6Address, const uint64_t sourceID, const std::string& appName, const uint16_t selfPort, const uint16_t peerPort,
            const uint16_t multicastPort, const CommunicationType type, bool dealyedCCLRegisteration = false, const ATUStorage storage = ATUStorage::INTERNAL_BUFFER) :
        m_appName{appName},
        m_ipv6Address{ipv6Address},
        m_selfPort{selfPort},
        m_peerPort{peerPort},
        m_multicastPort{multicastPort},
        m_commType{type},
        m_delayedCCLRegisteration{dealyedCCLRegisteration},
        m_atuStorage{storage},
        m_sourceID{sourceID}
    {

    }

    virtual ~CCLMessageBroker() = default;

    /**
    * @brief This function does the class Registration to CCL library services,
             it helps to subscribe to multicast group for the message notification
             and also updates its own info into ATU map (ipaddress and Module ID).
      @param[in] Void
      @return Void
    */

    virtual void Prepare() override
    {
        if(!m_delayedCCLRegisteration)
        {

            if(!RegisterToCCL())
            {
                m_delayedCCLRegisteration = true;
            }
        }
#if !IS_FREE_RTOS_PLATFORM()
        m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &CCLMessageBroker::RecieveSubsystemInitialisationEvent);
#endif
        Platform::Component::Prepare();
    }
    /**
      @brief This function will start a session thread called CCLMonitor which
             runs in an infinite loop, Also the notifier class is updated with
             the send function pointer to enable sending of notification or
             the messages to other modules.
      @param[in] Void
      @return Void
    */
    virtual void Start() override
    {
        m_communicator.m_messageTransporter.m_brokerNotifier.Connect(this, &CCLMessageBroker::Send);

        Platform::Notifier workerData;
        workerData.Connect(this, &CCLMessageBroker::CCLMonitor);
        m_thread = Platform::Thread<>{workerData, "CCLMonitor", PlatformNative::Thread::DEFAULT_STACK, TASK_PRIORITY_CCL_MONITOR};
        Platform::Component::Start();
    }

    /**
      @brief Will detach thread from process and stops it.
             It also Stops the component.
      @param[in] Void
      @return Void
    */
    virtual void Stop() override
    {
        m_thread.Detach();
        Platform::Component::Stop();
    }

    /**
      @brief Helps in graceful shutdown of the component
      @param[in] Void
      @return Void
    */
    virtual void Shutdown() override
    {
#if !IS_FREE_RTOS_PLATFORM()
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &CCLMessageBroker::RecieveSubsystemInitialisationEvent);
        m_communicator.m_event.Unsubscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
#endif
        Platform::Component::Shutdown();
    }

protected:
/** @brief Buffer size that holds the circular buffers containing the transmitted
    and recieved messages. These Buffers are used to reduce the packet loss
    and duplicate packet detection.
*/

#if IS_FREE_RTOS_PLATFORM()
    /// Priority of CCL Monitor thread
    static constexpr int            TASK_PRIORITY_CCL_MONITOR = 6;
#if SDRAM_PRESENT == 2
    // We can afford a bigger buffer on modules using SDRAM
    static constexpr uint16_t       m_cclBufferSize = 32768;
#else
    static constexpr uint16_t       m_cclBufferSize = 3008;
#endif
#else
    /// Priority of CCL Monitor thread
    static constexpr int            TASK_PRIORITY_CCL_MONITOR = 4;
    static constexpr uint16_t       m_cclBufferSize = 16384;
#endif
/// Timeout for wait on the message Queue to recieve data
    static constexpr uint16_t       m_receiveTimedWait = 500;
/// CCLMonitor thread sleep timer, used when there is a failure in reading message queue
    static constexpr uint16_t       m_monitorSleepTime = 100;
/// Instance of Communication library for sending and receiving messages over network
    CommunicationLibrary            &m_commLibraryObj = CommunicationLibrary::GetInstance();
/// Stores the Source Application name
    const std::string               m_appName;
/// Stores the IPv6 address passed by source application
    const std::string               m_ipv6Address;

private:
/// Listening port of Main CPU for unicast message
    uint16_t                        m_selfPort = 0;
/// Listening port of Modules or destination port for Unicast
    uint16_t                        m_peerPort = 0;
/// Multicast port number
    uint16_t                        m_multicastPort = 0;
/// Type of communication like interprocess, intermodule etc
    CommunicationType               m_commType;
/// SessionId of the communication library
    int32_t                         m_SessionID = ERROR_VALUE;
/** @brief Buffer used to hold the transmitted and recieved packets, which are used
    for retranmission and duplicate packet detection.
*/
    uint8_t                         m_cclbuffer[m_cclBufferSize];
/// Handler for call back functions
    NotificationHandler             m_processCallbacks;
/// Thread handler
    Platform::Thread<>              m_thread;
/// Currently just used for infinite looping if Registration to CCL fails
    bool                            m_terminated = false;
/** @brief Used to register for CCLMonitor session in case if the registration fails during
    Component prepare, CCL Registation is executed in a loop untill it is success.
*/
    bool                            m_delayedCCLRegisteration = false;
/// Used to Store Main CPU/Source Application details like port, address etc
    SelfCommunicationAddress        m_selfCommDetails;
/// Storage type for ATU table, currently internal buffer
    ATUStorage                      m_atuStorage = ATUStorage::NOT_DEFINED;
/// Used to Recieve Application data from Recieve Queue posted by CCL
    ApplicationDataFormat           m_recvData{};
/// Used to send Application data to transmit Queue, used by CCL

    ApplicationDataFormat           m_sendData{};
/// Module ID of the device running the Source Application of the Component
    uint64_t                        m_sourceID = 0;
#if !IS_FREE_RTOS_PLATFORM()
    bool                            mReceivedSubSystemFaultClear = false;
    //bool                            mSendSubSystemFault = false;
    Dol::Translator<Mol::Event::FaultEvent, Mol::Message<Mol::Event::EVENT_CATEGORY>> m_eventTranslator;
    /**
     * @brief RecieveSubsystemInitialisationEvent
     * @param[in]   event base event object type to be casted asMol::Event::FaultClearedEvent
     * @param[in]  senderID not used
     */
    void RecieveSubsystemInitialisationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
    {
        auto FaultClearedEvent = std::static_pointer_cast<Mol::Event::FaultClearedEvent>(event);
        if(FaultClearedEvent != nullptr)
        {
            auto type = FaultClearedEvent->GetSource().GetObjectType();

            if(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS == FaultClearedEvent->GetEventCode()&& type == Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE)
            {
                /*
                while(!mSendSubSystemFault) 
                {
                    DEBUGPRINT(DEBUG_INFO,"CCLMessageBroker::RecieveSubsystemInitialisationEvent:Waiting to send Sub System Initialization Fault");
                    Platform::this_thread::Sleep(500);    
                }
                m_communicator.m_event.Send(event, PROC_ADDRESS::EVENT_PROVIDERAPP);
                m_communicator.m_event.Send(event, PROC_ADDRESS::EVENTLOGAPP);
                m_communicator.m_event.Send(event, PROC_ADDRESS::ACTIVE_EVENTSAPP);
                m_communicator.m_event.Send(event, PROC_ADDRESS::NETWORK);
                m_communicator.m_event.Send(event, PROC_ADDRESS::MOL_RECEIVER);
                */
                DEBUGPRINT(DEBUG_INFO,"CCLMessageBroker::RecieveSubsystemInitialisationEvent:Received FaultClearedEvent  senderID[{0}] ",senderID);
                mReceivedSubSystemFaultClear = true;
            }
        }
    }
    /**
     * @brief SendSubSystemInitializationFatult: Send SUBSYSTEM_INITIALIZATION_IN_PROGRESS fault for Main CPU
     */

    void SendSubSystemInitializationFatult()
    {
        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:SendSubSystemInitializationFatult:Start");
        auto event = std::make_shared<Mol::Event::FaultEvent>(Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS);
        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        Mol::DataType::ObjectReference objref(m_sourceID, Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE);
        event->SetSource(objref);

        m_communicator.m_event.Send(event, PROC_ADDRESS::EVENT_PROVIDERAPP);
        m_communicator.m_event.Send(event, PROC_ADDRESS::EVENTLOGAPP);
        m_communicator.m_event.Send(event, PROC_ADDRESS::ACTIVE_EVENTSAPP);
        m_communicator.m_event.Send(event, PROC_ADDRESS::NETWORK);
        m_communicator.m_event.Send(event, PROC_ADDRESS::MOL_RECEIVER);

        //mSendSubSystemFault = true;
        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:SendSubSystemInitializationFatult:End2");
    }
    /**
     * @brief Send fault and fault cleared initialization fault
     */
    bool SendInitializedFault(std::string data, auto faultEvent, auto faultEventTranslator)
    {
        try
        {
            faultEvent = faultEventTranslator.StringToDomainObjectMessage(data);
            if((nullptr != faultEvent) && (faultEvent->GetEventCode() == Mol::Event::FAULT_EVENT_CODE::SUBSYSTEM_INITIALIZATION_IN_PROGRESS))
            {
                faultEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION,std::string("CMC"));
                try
                {
                    //package = faultEventTranslator.DomainObjectMessageToString(faultEvent);
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:Start**************");
                    m_communicator.m_event.Send(faultEvent, PROC_ADDRESS::NETWORK);
                    m_communicator.m_event.Send(faultEvent, PROC_ADDRESS::EVENT_PROVIDERAPP);
                    m_communicator.m_event.Send(faultEvent, PROC_ADDRESS::EVENTLOGAPP);
                    m_communicator.m_event.Send(faultEvent, PROC_ADDRESS::ACTIVE_EVENTSAPP);
                    m_communicator.m_event.Send(faultEvent, PROC_ADDRESS::BROADCAST);
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:End**************");
                    return true;
                }
                catch(...)
                {
                    DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:IsInitializationFault: problem in faultEventTranslator.DomainObjectMessageToString");
                    return false;
                }
            }
            else
            {
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault: Not a SUBSYSTEM_INITIALIZATION_IN_PROGRESS event");
                return false;
            }
        }
        catch(...)
        {
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:IsInitializationFault:Invalid fault event");
            return false;
        }
    }
	
	
	    /**
     * @brief Send SendFREActivate
     */
    bool SendFREActivate(std::string data, auto activateEvent, auto activateEventTranslator)
    {
        try
        {
            activateEvent = activateEventTranslator.StringToDomainObjectMessage(data);
			if(nullptr != activateEvent)
			{
				return false;
			}
			
            if(activateEvent->GetSource().GetObjectType() == Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT)	
            {
                activateEvent->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION,std::string("CMC"));
                try
                {
                    //package = activateEventTranslator.DomainObjectMessageToString(activateEvent);
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:Start**************");
                    m_communicator.m_event.Send(activateEvent, PROC_ADDRESS::NETWORK);
                    m_communicator.m_event.Send(activateEvent, PROC_ADDRESS::EVENT_PROVIDERAPP);
                    m_communicator.m_event.Send(activateEvent, PROC_ADDRESS::EVENTLOGAPP);
                    m_communicator.m_event.Send(activateEvent, PROC_ADDRESS::ACTIVE_EVENTSAPP);
                    m_communicator.m_event.Send(activateEvent, PROC_ADDRESS::BROADCAST);
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:End**************");
                    return true;
                }
                catch(...)
                {
                    DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:IsInitializationFault: problem in activateEventTranslator.DomainObjectMessageToString");
                    return false;
                }
            }
            else
            {
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault: Not a SUBSYSTEM_INITIALIZATION_IN_PROGRESS event");
                return false;
            }
        }
        catch(...)
        {
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:IsInitializationFault:Invalid fault event");
            return false;
        }
    }
    /**
     * @brief IsIntendedMessage: Check if current message is SUBSYSTEM_INITIALIZATION_IN_PROGRESS fault 
     * @param[in] package is a message in string form
     */

    bool IsIntendedMessage(std::string package)
    {
        Dol::Translator<Platform::Message,Platform::Message> translator;
        std::shared_ptr<Platform::Message> message;
        try
        {
             message = translator.StringToDomainObjectMessage(package);    
        }
        catch(...)
        {
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:IsInitializationFault:Invalide package");
            return false;
        }
        if (message == nullptr)
        {
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:Invalide package");
            return false;        
        }
        if(message->m_messageType == Platform::Message::MessageType::EVENT)
        {
            using EventCategory = Mol::Message<Mol::Event::EVENT_CATEGORY>;
            Dol::Translator<EventCategory, EventCategory>   eventTranslator;
            try
            {
                std::shared_ptr <EventCategory> event = eventTranslator.StringToDomainObjectMessage(message->m_Data);
                if(event->GetObjectType() == Mol::Event::EVENT_CATEGORY::TROUBLE)
                {
                    std::shared_ptr <Mol::Event::FaultEvent> faultEvent;
                    Dol::Translator <Mol::Event::FaultEvent, EventCategory> faultEventTranslator;
                    return SendInitializedFault(message->m_Data, faultEvent,faultEventTranslator);
                }
                else if(event->GetObjectType() == Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)
                {
                    std::shared_ptr <Mol::Event::FaultClearedEvent> faultEvent;
                    Dol::Translator <Mol::Event::FaultClearedEvent, EventCategory> faultEventTranslator;
                    return SendInitializedFault(message->m_Data, faultEvent,faultEventTranslator);
                }
                else if(event->GetObjectType() == Mol::Event::EVENT_CATEGORY::ACTIVATION)
                {
                    std::shared_ptr <Mol::Event::ActivationEvent> activateEvent;
                    Dol::Translator <Mol::Event::ActivationEvent, EventCategory> activateEventTranslator;
					return SendFREActivate(message->m_Data, activateEvent,activateEventTranslator);
                }
                else
                {
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:Not a fault event");
                    return false;
                }
            }
            catch(...)
            {
                DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:IsInitializationFault:Invalide Event");
                return false;
            }
        }
        else
        {
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:IsInitializationFault:Not a Event message");
            return false;
        }
    }
#endif
    /**
      @brief Will run indefinitely as a thread to receive messages from the
             Modules and broadcast the same to FDA.
      @param[in] Void
      @return Void
    */
    void CCLMonitor()
    {

//#if !IS_FREE_RTOS_PLATFORM()
//       SendSubSystemInitializationFatult();
//#endif


        if(m_delayedCCLRegisteration)
        {
            while(!m_terminated)
            {
                if(RegisterToCCL())
                {
                    break;
                }
                DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:CCLMonitor: Failed to register.");
                Platform::this_thread::Sleep(m_monitorSleepTime);
            }
        }

        while (!m_terminated)
        {
            m_recvData = {};
            //@TODO change m_CommLibraryObj.ReceiveData() to work with string so we don't have to wrap character buffer here?
            //Or at least create a function overload that takes string as output parameter.
            int returnCode = m_commLibraryObj.ReceiveData(m_SessionID, (uint8_t* )&m_recvData, sizeof(ApplicationDataFormat), m_receiveTimedWait);
            if (returnCode > 0)
            {
                std::string package((char *)(m_recvData.data), m_recvData.dataLength);
#if !IS_FREE_RTOS_PLATFORM()
                if(mReceivedSubSystemFaultClear)
                {
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:CCLMonitor: Received Fault Clear Message");
                    m_communicator.m_messageTransporter.Send(package, PROC_ADDRESS::BROADCAST);
                }
                else
                {
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:CCLMonitor: Did not receive Fault Clear Message");
                    if(!IsIntendedMessage(package))
                    {
                        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:CCLMonitor: Not an Initialization message");
                        m_communicator.m_messageTransporter.Send(package, PROC_ADDRESS::BROADCAST);
                    }
                    else
                    {
                        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:CCLMonitor::Initialization message");
                    }
                }
#else
                m_communicator.m_messageTransporter.Send(package, PROC_ADDRESS::BROADCAST);
#endif
            }
            else if ((returnCode == ERROR_GENERAL_FAILURE) || (returnCode == QUEUE_ERROR_RECEIVE_FAILED))
            {
                // Moderate retries for connection failure
                Platform::this_thread::Sleep(m_monitorSleepTime);
            }
            else
            {
                // Do nothing
            }
        }
    }


    /**
      @brief Updates the Address Translation Unit map by adding an entry of
             IPAddress and Module ID combination or deletes an entry from the map.
             This mapping is used for communication between modules and Main CPU.
      @param[in] Void
      @return Void
    */
    bool UpdateATU(std::shared_ptr<Platform::Message> message)
    {
        bool atuUpdated = false;
        Dol::Translator<Mol::Monitoring::AtuUpdate, Mol::Message<Mol::Monitoring::MONITORING_CATEGORY>> translator;
        auto monitoringMsg = translator.StringToDomainObjectMessage(message->m_Data);
        auto parameters = monitoringMsg->GetParameters();
        if(monitoringMsg->GetObjectType() == Mol::Monitoring::MONITORING_CATEGORY::ATU_UPDATE)
        {
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:RegisterCCL:ATU_UPDATE message Received");
            auto updateAtuCode = monitoringMsg->GetMonitoringCode();
            if(updateAtuCode == Mol::Monitoring::ATU_UPDATE_TYPE::ADD)
            {
                if(parameters.size() < 2)
                {
                    DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:ATU_UPDATE:ADD invalid parameter size[%d]", parameters.size());
                }
                else
                {
                    auto ipAddr = monitoringMsg->GetParameters().at(0).GetValue<std::string>();
                    auto moduleID = monitoringMsg->GetParameters().at(1).GetValue<uint16_t>();
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send:ATU_UPDATE Add IP :IP[%s] ID[%x]", ipAddr.c_str(), moduleID);
                    m_commLibraryObj.UpdateATUInfo(ipAddr, moduleID);
                    atuUpdated = true;
                }
            }
            else if(updateAtuCode == Mol::Monitoring::ATU_UPDATE_TYPE::DELETE)
            {
                if(parameters.size() < 1)
                {
                    DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:ATU_UPDATE:DELETE invalid parameter size[%d]", parameters.size());
                }
                else
                {
                    auto ipAddr = monitoringMsg->GetParameters().at(0).GetValue<std::string>();
                    DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:ATU_UPDATE DELETE IP :[%s]", ipAddr.c_str());
                    m_commLibraryObj.DeleteATUInfo(ipAddr);
                    atuUpdated = true;
                }
            }
            else
            {
                DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:ATU_UPDATE invalid option");
            }
        }
        return atuUpdated;
    }

    /**
      @brief This function registers services with CCL.
             Provides an interface to CCL for log dump.
             It subscribes the CCL/Communication Library to multicast notifier group
             and also adds self address to ATU using UpdateATU().
      @param[in] Void
      @return Void
    */
    bool RegisterToCCL()
    {
        m_selfCommDetails.selfPortNumber = m_selfPort;
        m_selfCommDetails.applicationName = m_appName.c_str();
        m_ipv6Address.copy((char*)m_selfCommDetails.selfIPAddr,m_ipv6Address.length());
        m_processCallbacks.callbackFunctions.NotifyEvents = &WrapperEventNotification;
        m_processCallbacks.callbackFunctions.NotifySend = static_cast< void (*) (const void* const, LibraryReturnCode)> (nullptr);
        m_processCallbacks.callerObj = this;

        //Register with CCL
        m_SessionID = m_commLibraryObj.RegisterForServices(m_commType, m_cclbuffer, sizeof(m_cclbuffer), &m_selfCommDetails, &m_processCallbacks, m_atuStorage);
        if (ERROR_VALUE == m_SessionID)
        {
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker:RegisterCCL:Services register request returned error");
            return false;
        }

        if(m_multicastPort)
        {
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:RegisterCCL:Services register request success");
            m_commLibraryObj.SubscribeToMulticastGroup(m_SessionID, MulticastGroupType::MODULEREGISTRATION_GRP);
        }

        //Add self ATU details for unicast

        Mol::DeviceUniqueID sourceID(m_sourceID);
        auto moduleID = sourceID.GetModuleID();
        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:RegisterCCL:Adding self ATU details:IP[%s] ID[%d]", m_ipv6Address.c_str(), moduleID);
        m_commLibraryObj.UpdateATUInfo(m_ipv6Address, moduleID);
        return true;
    }

    /**
      @brief This function is used to get the correct Service Type based on Message Type
      @param[in] type Message Type for which service Type needs to be found
      @return ServiceType correcponding to Message Type
    */
    ServiceType GetServiceType(const Platform::Message::MessageType type)
    {
        static int DOL_Count =0, MOL_MONITORING_Count =0, MOL_COMMAND_Count=0, MOL_EVENT_Count=0, MOL_REQUEST_Count=0, MOL_RESPONSE_Count=0;
        auto serviceType = ServiceType::END_OF_LIST;
        switch(type)
        {
            case Platform::Message::MessageType::DOL:
                serviceType = ServiceType::DOL;
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: DOL_Count count [%d]", DOL_Count++);
                break;
            case Platform::Message::MessageType::MONITOR:
                serviceType = ServiceType::MOL_MONITORING;
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: MOL_MONITORING_Count count [%d]", MOL_MONITORING_Count++);
                break;
            case Platform::Message::MessageType::COMMAND:
                serviceType = ServiceType::MOL_COMMAND;
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: MOL_COMMAND_Count count [%d]", MOL_COMMAND_Count++);
                break;
            case Platform::Message::MessageType::EVENT:
                serviceType = ServiceType::MOL_EVENT;
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: MOL_EVENT_Count count [%d]", MOL_EVENT_Count++);
                break;
            case Platform::Message::MessageType::REQUEST:
                serviceType = ServiceType::MOL_REQUEST;
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: MOL_REQUEST_Count count [%d]", MOL_REQUEST_Count++);
                break;
            case Platform::Message::MessageType::RESPONSE:
                serviceType = ServiceType::MOL_RESPONSE;
                DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: MOL_RESPONSE_Count count [%d]", MOL_RESPONSE_Count++);
                break;
            default:
                break;
        }
       return serviceType;
    }

    /**
      @brief This function gets the source and destination IDs, prepares the send
             data in the required format and also adds the sources address and
             then transmits the data over Message Queue. This Message Queue is read
             by the Send thread in Communication Library and sent across Network
      @param[in] message message to be sent across network to other modules
      @return Void
    */
    void Send(std::shared_ptr<Platform::Message> message)
    {
        Mol::DeviceUniqueID sourceID(message->m_SourceUniqueID); // Added for debugging
        Mol::DeviceUniqueID destinationID(message->m_DestinationUniqueID);

        if(message->m_messageType == Platform::Message::MessageType::MONITOR)
        {
            if(UpdateATU(message))
            {
                // Application internal ATU update message. Used internally by CCL to update the ATU table
                return;
            }
        }

        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send:Source domain :[%x] node[%x] module:[%x]", sourceID.GetDomainID(),sourceID.GetNodeID(), sourceID.GetModuleID());
        DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send:Dest domain :[%x] node[%x] module:[%x]", destinationID.GetDomainID(),destinationID.GetNodeID(), destinationID.GetModuleID());

        m_sendData.messageType = GetServiceType(message->m_messageType);
        m_sendData.sourceAddress = sourceID.GetModuleID();

        // Module Multi-cast message
        if(destinationID.GetModuleID() == Mol::DeviceUniqueID::MODULE_MULTICAST_ID)
        {
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: multicast message");
            m_sendData.commAddr.domainID = 0;
            m_sendData.commAddr.nodeID = 0;
            m_sendData.commAddr.moduleID = 0;
            m_sendData.commAddr.peerPortNumber = m_multicastPort;

			//Maincpu will not send events through this path..
			//All the events are blocked to avoid unnecessary network on the wire
			if(message->m_messageType == Platform::Message::MessageType::EVENT)
			{
				DEBUGPRINT(DEBUG_ERROR,"Event blocked *****");
				return;
			}

        }
        else
        {
            // unicast message
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: unicast message");
            m_sendData.commAddr.domainID = destinationID.GetDomainID();
            m_sendData.commAddr.nodeID = destinationID.GetNodeID();
            m_sendData.commAddr.moduleID = destinationID.GetModuleID();
            m_sendData.commAddr.peerPortNumber = m_peerPort;
        }

        Dol::Translator<Platform::Message, Platform::Message> messageTranslator;
        std::string messageSend =  messageTranslator.DomainObjectMessageToString(message);
        if((messageSend.length() <= sizeof(m_sendData.data)) && (messageSend.length() != 0))
        {
            memcpy(m_sendData.data, messageSend.c_str(), messageSend.length());
            m_sendData.dataLength = messageSend.length();

            auto ret= m_commLibraryObj.SendData(m_SessionID, (const uint8_t*) &m_sendData, sizeof(m_sendData));
            DEBUGPRINT(DEBUG_INFO, "CCLMessageBroker:Send: SendData ret [%d]", ret);
        }
        else
        {
            uint32_t size = messageSend.length();
#ifndef CCL_OSSELECT_NXP_K66_FREE_RTOS
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker: Message size is invalid %x",size);
#else
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker: Message size is invalid %lx",size);
#endif
        }
        m_sendData = {}; // reset for next receive
    }

    /*
     * @brief       Callback registered with CCL for receiving error codes. WrapperEventNotification will be
     *              executed from CCL thread context.
     * @param[in]   ptrToObject - dispatcher class object
     * @param[in]   code - error code from CCL library
     * @return Void
     */
    static void WrapperEventNotification (const void* ptrToObject, const LibraryReturnCode code)
    {
        switch(code)
        {

        case LibraryReturnCode::commFault:
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker::WrapperEventNotification(): commFault.");
            break;

        case LibraryReturnCode::queueReceiveError:
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker::WrapperEventNotification(): queueReceiveError.");
            break;

        case LibraryReturnCode::queueSendError:
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker::WrapperEventNotification(): queueSendError.");
            break;

        case LibraryReturnCode::duplicateDiscard:
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker::WrapperEventNotification(): duplicateDiscard.");
            break;

        case LibraryReturnCode::memoryError:
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker::WrapperEventNotification(): memoryError.");
            break;

        default:
            DEBUGPRINT(DEBUG_ERROR, "CCLMessageBroker::WrapperEventNotification(): Unhandled error code:%x.", (uint8_t)code);
            break;
        }
    }

};
}
#endif //CCL_MESSAGE_BROKER_INCLUDE_H
