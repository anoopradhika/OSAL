/*
* @file    Notifier.hpp
* @date    01.12.2017
* @brief   Notifier class used for callback notification.
* Special thanks to Rudolph, Klaus <Klaus.Rudolph@Honeywell.com>
* for design support
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, re-engineered, distributed or
* disclosed to others without the written consent of Honeywell.
 */
#ifndef PLATFORM_NOTIFIER_INCLUDE_H
#define PLATFORM_NOTIFIER_INCLUDE_H

#include <functional>
#include <iostream>
#include <memory>
 
/**
Notifier class used for notify 
- class method
- Normal C function
- Lambda function
*/
namespace Platform
{
    
class Notifier
{
public:
    Notifier():m_signal(nullptr) {};
    
    ~Notifier() = default;
    Notifier(const Notifier&) = default;
    
    /**
      Connect class method
      @param object: owner of the method
      @param Member: Method to be called
      @param Argument: argument for the method
    */
    template<typename ClassType, typename Member>
    void Connect(ClassType* object, Member member)
    {
        auto functor = [object, member](){ (object->*member)(); };
        Connect(functor);
    }

    /**
      Connect class method
      @param object: owner of the method
      @param Member: Method to be called
      @param Argument: argument for the method
    */
    template<typename ClassType, typename Member, typename Argument>
    void Connect(ClassType* object, Member member,Argument argument)
    {
        auto functor = [object, member,argument](){ (object->*member)(argument); };
        Connect(functor);
    }

    /**
      Connect class method
      @param object: owner of the method
      @param Member: Method to be called
      @param Argument: argument as shared_ptr
    */
    template<typename ClassType, typename Member, typename Argument>
    void Connect(ClassType* object, Member member,std::shared_ptr<Argument> argument)
    {
        auto functor = [object, member,argument](){ (object->*member)(argument); };
        Connect(functor);
    }

    /**
      Connect static function
      @param Member: Method to be called
      @param Argument: argument for the method
    */
    template<typename Method, typename Argument>
    void Connect(Method method,Argument argument)
    {
        auto functor = [ method,argument](){ (*method)(argument); };
        Connect(functor);
    }

    /**
      Connect static function
      @param slot: Lambda function to be called
    */    
    template<typename Functor>
    void Connect(Functor &&slot)
    {
        if( m_signal )
        {
            std::cout << "Function is not empty! Please disconnect and connect again.\n";
        }
        else
        {
            m_signal =  std::forward<Functor>(slot);
        }
    }

    /**
        Disconnect the notification callback.
    */
    void Disconnect()
    {
        m_signal =  nullptr;
    }
    
    /**
        Execute operator for call notification call.
    */
    void operator()() const
    {
        if( m_signal )  
        {
            m_signal();
        }
        else
        {
            std::cout << "Function is empty. Nothing to do.\n";
        }
    }
    
    Notifier& operator=(const Notifier& notifier)
    {
        if (this != &notifier)
        {
            m_signal = notifier.m_signal;
        }

        return *this;
    }

private:
    std::function<void()>  m_signal;
};

} // end of platform

#endif //PLATFORM_NOTIFIER_INCLUDE_H
