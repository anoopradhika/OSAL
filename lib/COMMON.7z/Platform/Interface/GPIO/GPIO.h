/*******************************************************************************
* @file GPIO .h
* @brief General Class to access gpio pins
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_GPIO_H
#define PLATFORM_GPIO_H

#include <fstream>
#include <streambuf>

#include "Interface/GPIO/GPIOpins.h"
#include "Interface/GPIO/GPIOConfiguration.h"

namespace Platform
{

/**
* @brief Singleton class to configure GPIO pins
* Also set and get it status
*
*/
class GPIO
{
public:

    GPIO(GPIO const&) = delete;             // Copy construct
    GPIO(GPIO&&) = delete;                  // Move construct
    GPIO& operator=(GPIO const&) = delete;  // Copy assign
    GPIO& operator=(GPIO &&) = delete;      // Move assign

    ~GPIO() = default;

    /**
    * @brief Get GPIO instance
    *
    */
    static GPIO& Getinstance()
    {
        static GPIO gpio;
        return gpio;
    }

    /**
    * @brief Set GPIO pin mode, levels
    * @param pin GPIO pin number from GPIO_PIN
    * @return  true on success full operation, else false
    */
    bool Prepare(GPIO_PIN pin)
    {
        for(auto GPIOConfiguration :GPIOConfigurations)
        {
            if(pin == GPIOConfiguration.m_pin)
            {
                if(nullptr == GPIOConfiguration.m_mode)
                {
                    return false;
                }
                std::string m_gpioDirection{GPIO_PATH + std::to_string(static_cast<uint8_t>(pin)) + GPIO_DIRECTION};
                FileWrite(m_gpioDirection,std::string{GPIOConfiguration.m_mode});
                return true;
            }

        }
        return false;
    }

    /**
    * @brief Register for Monitoring GPIO pin
    * @param pin GPIO pin number from GPIO_PIN
    * @param notifier callback function on GPIO value change
    * @param intervalMs monitor intervals in MS
    * @return  true on success full operation, else false
    */
    bool Monitor(GPIO_PIN pin, Platform::Notifier notifier, uint32_t intervalMs = 1000)
    {
        bool retValue = false;
        GlobalDataType::FileNotification fileNotifier;

        std::string path{GPIO_PATH +  std::to_string(static_cast<uint8_t>(pin)) + GPIO_VALUE};
        retValue = fileNotifier.Registration(path,notifier,intervalMs);

        return retValue;
    }
    /**
    * @brief check GPIO pin in input mode
    * @param pin GPIO pin number from GPIO_PIN
    * @return  true if pin is in input mode, else false
    */
    bool IsInputMode(GPIO_PIN pin)
    {
        std::string m_gpioDirection{GPIO_PATH +  std::to_string(static_cast<uint8_t>(pin)) + GPIO_VALUE};
        auto data = FileRead(m_gpioDirection);
        if(0 == data.compare("in"))
        {
            return true;
        }
        return false;
    }

    /**
    * @brief check GPIO pin in out mode
    * @param pin GPIO pin number from GPIO_PIN
    * @return  true if pin is in out mode, else false
    */
    bool IsOutputMode(GPIO_PIN pin)
    {
        std::string m_gpioDirection{GPIO_PATH +  std::to_string(static_cast<uint8_t>(pin)) + GPIO_VALUE};
        auto data =  FileRead(m_gpioDirection);
        if(0 == data.compare("out"))
        {
            return true;
        }
        return false;
    }

    /**
    * @brief pull up gpio pin
    * @param pin GPIO pin number from GPIO_PIN
    * @return  true on success full operation, else false
    */
    bool PullUp(GPIO_PIN pin)
    {
        std::string gpioValue{GPIO_PATH +  std::to_string(static_cast<uint8_t>(pin)) + GPIO_VALUE};
        return FileWrite(gpioValue,std::string{"1"});
    }

    /**
    * @brief pull down gpio pin
    * @param pin GPIO pin number from GPIO_PIN
    * @return  true on success full operation, else false
    */
    bool PullDown(GPIO_PIN pin)
    {
        std::string gpioValue{GPIO_PATH +  std::to_string(static_cast<uint8_t>(pin)) + GPIO_VALUE};
        return FileWrite(gpioValue,std::string{"0"});
    }
    /**
    * @brief check whether GPIO pin in is pulled up
    * @param pin GPIO pin number from GPIO_PIN
    * @return  true if pin is pulled up, else false
    */
    bool IsPulledUp(GPIO_PIN pin)
    {
        std::string m_gpioValue{GPIO_PATH +  std::to_string(static_cast<uint8_t>(pin)) + GPIO_VALUE};
        auto data = FileRead(m_gpioValue);
        if(0 == data.compare(0, 1, "1"))
        {
            return true;
        }
        return false;

    }

private:

    char const* GPIO_PATH = "/sys/class/gpio/gpio";
    char const* GPIO_VALUE = "/value";
    char const* GPIO_DIRECTION = "/direction";

    GPIO() = default;

    /**
    * @brief GPIO file write operation
    * @param filename GPIO file path
    * @param action to do on GPIO file
    * @return return true on successful operation, else false
    */
    bool FileWrite(const std::string& filename, const std::string& action)
    {
        std::ofstream fileHandle (filename, std::ofstream::out);

        if(!fileHandle)
        {
            return false;
        }
        fileHandle<< action;

        fileHandle.close();
        return true;
    }
    /**
    * @brief GPIO file read operation
    * @param filename GPIO file path
    * @return return file read data
    */
    std::string FileRead(const std::string& filename)
    {
        std::ifstream fileHandle (filename, std::ofstream::in);

        if(!fileHandle)
        {
            return std::string{};
        }
        std::string data;
        data.reserve(fileHandle.tellg());
        fileHandle.seekg(0,std::ios::end);
        fileHandle.seekg(0,std::ios::beg);
        data.assign( (std::istreambuf_iterator<char>(fileHandle)),
                      (std::istreambuf_iterator<char>())
                  );
            fileHandle.close();
        return data;
    }

};

}
#endif //PLATFORM_GPIO_H
