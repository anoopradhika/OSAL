/*******************************************************************************
* @file GPIOConfiguration.h
* @brief GPIO pin mapping is maintained here
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_GPIO_CONFIGURATION_H
#define PLATFORM_GPIO_CONFIGURATION_H

#include<vector>

namespace Platform
{

    struct GPIOConfiguration
    {
        GPIOConfiguration( GPIO_PIN pin
                         , const char* edge
                         , const char*  mode
                        )
                        : m_pin{pin}
                        , m_edge{edge}
                        , m_mode{mode}
        {

        }
        GPIOConfiguration() = default;
        ~ GPIOConfiguration() = default;
        const GPIO_PIN m_pin;
        const char* m_edge;
        const char* m_mode;
    };

	extern std::vector<GPIOConfiguration> GPIOConfigurations;
}

#endif // PLATFORM_GPIO_CONFIGURATION_H
