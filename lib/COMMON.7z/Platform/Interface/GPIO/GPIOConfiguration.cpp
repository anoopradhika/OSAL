/*******************************************************************************
* @file GPIOConfiguration.cpp
* @brief GPIO pin mapping is maintained here
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#include "GPIOpins.h"
#include "GPIOConfiguration.h"

namespace Platform
{

std::vector<GPIOConfiguration> GPIOConfigurations
                            {  GPIOConfiguration{GPIO_PIN::BUZZER_LINE, nullptr, "out"}
                            ,  GPIOConfiguration{GPIO_PIN::FAULT_RELAY_LINE, nullptr, "out"}
                            ,  GPIOConfiguration{GPIO_PIN::FIRE_RELAY_LINE, nullptr, "out"}
                            ,  GPIOConfiguration{GPIO_PIN::FIRE_FALLBACK_LINE, nullptr, "in"}
                            ,  GPIOConfiguration{GPIO_PIN::DOOR_CONTACT_LINE, nullptr, "in"}
                            };

}
