/*******************************************************************************
* @file GPIOpins.h
* @brief GPIO pin mapping is maintained here
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_GPIO_PINS_H
#define PLATFORM_GPIO_PINS_H

#include <cstdint>

namespace Platform
{
    enum class GPIO_PIN : uint16_t
    {
        FAULT_RELAY_LINE = 101,
        FIRE_RELAY_LINE = 205,
        BUZZER_LINE = 507,
        FIRE_FALLBACK_LINE = 192,
        DOOR_CONTACT_LINE = 175,
    };
}

#endif // PLATFORM_GPIO_PINS_H
