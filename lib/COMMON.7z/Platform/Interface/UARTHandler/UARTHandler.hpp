/*****************************************************************//**
 *
 * @file    UARTHandler.h
 * @brief   UART Handler class for serial communication
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_UART_HANDLER_INCLUDE_H
#define PLATFORM_UART_HANDLER_INCLUDE_H


#include "UARTHandler/UARTHandler.h"
#include "CommonDef.h"

namespace Platform
{

    /**
     * Class used for implementing the UART I/O functionality.
     */
    class UARTHandler
    {

    public:

        /**
         * @brief      constructor, used for constructing a valid `UARTIOHandler` object.
         * @param[in]  port: A `std::string` object that represents the location of the UART-mapped tty* file.
         * @param[in]  config: Serial config details
         * @remark     If the UART-mapped tty*-like file can't be opened, `std::ios_base::failure` will be thrown.
         */
        UARTHandler(std::shared_ptr<Dol::Entities::SerialPort> config, const std::string& port) :
            m_nativeUARTHandler{config,port}
        {

        }

        /**
         * @brief    Destructor, will perform all the necessary cleanup.
         */
        ~UARTHandler() = default;

        /**
         * @brief     Method used for sending data out over a communication channel.
         *
         * @param[in] A pointer to a constant C-like array of bytes where the data is stored.
         * @param[in] A `int` value that represents the size of `data` C-like array.
         * @return Same as the standard UNIX `write()` function (check `man 3 write` for details).
         */
        int Write(const uint8_t *data, int size)
        {
            return  m_nativeUARTHandler.Write(data, size);;
        }

        /**
         * @brief     Method used for sending one byte over a communication channel.
         *
         * @param[in] A `uint8_t` value which represent the data which should be sent.
         * @return    1 if the byte was successfully sent, 0 otherwise.
         */
        int Write(uint8_t byte)
        {
            return m_nativeUARTHandler.Write(byte);
        }

        /**
         * @brief     Method used for sending data out over a communication channel.
         *
         * @param[in] data: A reference to a const `std::vector<uint8_t>` object that represents the vector of values.
         * @return    Same as the standard UNIX `write()` function (check `man 3 write` for details).
         */
        int Write(const std::vector<uint8_t> &data)
        {
            return m_nativeUARTHandler.Write(data);
        }

        /**
         * @brief      Method used for receiving data over a communication channel.
         *
         * @param[out] data: A const pointer to a `uint8_t` object (C-like array of `uint8_t`s) where the
         *             received data will be stored.
         * @param[in]  size: A `int` value which represents the number of maximum bytes to be read.
         * @return     Same as the standard UNIX `read()` function (check `man 3 read` for details).
         */
        int Read(uint8_t *const data, int size)
        {
            return m_nativeUARTHandler.Read( data, size);
        }

        /**
         * @brief    Getter, will get the location of the tty*-like UART-mapped file.
         * @return   A `std::string` value that represents the file's location and name.
         */
        std::string GetPort() const
        {
            return m_nativeUARTHandler.GetPort();
        }

        /**
         * @brief    Discards data written to the object referred to by fd but not transmitted,
         *           or data received but not read, depending on the value of queue_selector.
         */
        void DiscardBufferedData() const
        {
            m_nativeUARTHandler.DiscardBufferedData();
        }

        /**
         * @brief    Status of communication ready for read/write
         * @return   A `bool` value that represents if the Handler is ready for read/write operation.
         */
        bool IsOpen() const
        {
            return m_nativeUARTHandler.IsOpen();
        }

        /**
         * @brief    Method used to waits until all output written to the object referred
         *           to by fd has been transmitted.
         */
        void Flush()
        {
            m_nativeUARTHandler.Flush();
        }

        /**
         * @brief    Apply set terminos settings.
         */
        void ApplySettings()
        {
            m_nativeUARTHandler.ApplySettings();
        }

    private:
        PlatformNative::UARTHandler m_nativeUARTHandler;
    };

} //end of PlatformLinux

#endif //PLATFORM_UART_HANDLER_INCLUDE_H
