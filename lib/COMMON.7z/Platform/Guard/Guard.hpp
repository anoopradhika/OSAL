/*****************************************************************//**
 *
 * @file    Guard.hpp
 * @brief   Guard class is an utility for lock and unlock mutex
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_GUARD_H
#define PLATFORM_GUARD_H

#include "Mutex/Mutex.hpp"

namespace Platform
{
class Guard
{
public:
    Guard( const Guard& ) = delete;

    Guard & operator=(const Guard&) = delete;

    /**
        Obtain mutex lock
        @param mutex: mutex to protect critical region  
    */
    explicit Guard(Platform::Mutex<>& mutex):m_mutex(mutex)
    {
        m_mutex.Lock();
    }

    /**
        Release mutex lock
    */
    ~Guard()
    {
        m_mutex.Unlock();
    }

private:
     /** mutex used by Guard.*/
    Platform::Mutex<>& m_mutex;
};
}// end of Platform
#endif //PLATFORM_GUARD_H