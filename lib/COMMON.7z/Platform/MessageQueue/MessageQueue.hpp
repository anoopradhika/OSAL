/*****************************************************************//**
 *
 * @file    MessageQueue.hpp
 * @brief   MessageQueue abstraction class
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_MESSAGEQUEUE_INCLUDE_H
#define PLATFORM_MESSAGEQUEUE_INCLUDE_H

#include"MessageQueue/MessageQueue.h"
#include"GlobalDataType/MessageQueue.h"
#include"Config/Config.h"
#include<functional>

namespace Platform
{

template<typename NativeMessageQueue = PlatformNative::MessageQueue>
class MessageQueue: public GlobalDataType::MessageQueue
{
public:
    /** Default constructor */
    MessageQueue() = default;

    /**
        Create Queue with given name and  BlockType
        @param queueName : name used for queue
        @param BlockType : BOLCK or NON_BLOCK mode
    */
    MessageQueue(const std::string& queueName, BlockType type = GlobalDataType::MessageQueue::BlockType::NON_BLOCK):
                                            m_nativeMessageQueue(queueName,type)
    {

    }

    /** Default destructor */
    ~MessageQueue() = default;

    /**
         Sends the given data into the queue
         @param[in]   data              : original data part to be sent
         @param[in]   waitTime          : optional wait time in case of timedsend, Valid if queue created in Block mode
         @return status code true on success, else false
    */
    auto Send(const std::string& data, const uint32_t waitTime = 0, const bool toFront = false)
    {
        return m_nativeMessageQueue.Send(data,waitTime,toFront);
    }

    /**
         Receives the given data from the queue
         @param[in]   waitTime          : optional wait time in case of timedreceive,Valid if queue created in Block mode
         @return receive data
    */
    auto Receive(const uint32_t waitTime = 0)
    {
        return m_nativeMessageQueue.Receive(waitTime);
    }

    /**
        copy other valid MessageQueue.
        Method generate assert if assigned MessageQueue has
        a valid OS Queue handle
    */
    MessageQueue& operator = (const MessageQueue& otherMessageQueue)
    {
        m_nativeMessageQueue = otherMessageQueue.m_nativeMessageQueue;
        return *this;
    }

    void Registration(std::function<void(const std::string&)> notification)
    {
        m_nativeMessageQueue.Registration(notification);
    }
private:
    NativeMessageQueue m_nativeMessageQueue;


};

} //platform
#endif //PLATFORM_MESSAGEQUEUE_INCLUDE_H
