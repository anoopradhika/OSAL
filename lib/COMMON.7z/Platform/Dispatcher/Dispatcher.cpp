/**
* @file   Dispatcher.cpp
* @Author Anoop Chandran (anoop.chandran@honeywell.com)
* @brief  Dispatcher class for message distribution.
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
 */
 
#include "Dispatcher.h"
#include <sstream>

namespace Platform
{

void Dispatcher::Prepare()
{
    m_notifiers.emplace(Message::MessageType::DOL,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
    m_notifiers.emplace(Message::MessageType::EVENT,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
    m_notifiers.emplace(Message::MessageType::COMMAND,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
    m_notifiers.emplace(Message::MessageType::REQUEST,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
    m_notifiers.emplace(Message::MessageType::RESPONSE,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
    m_notifiers.emplace(Message::MessageType::MONITOR,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
    m_notifiers.emplace(Message::MessageType::SOFTWARE_CENTER,Gallant::Signal1<std::shared_ptr<Platform::Message> >{});
}


void Dispatcher::Distributer(const std::string& receivedMessage)
{
//    Dol::Translator<Platform::Message,Platform::Message> messageTranslator;
    std::shared_ptr<Platform::Message> message =  messageTranslator.StringToDomainObjectMessage(receivedMessage);

    if(m_notifiers.end() != m_notifiers.find(message->m_messageType))
    {
        m_notifiers[message->m_messageType](message);   
    }
}


void Dispatcher::BrokerDistributer(const std::string& receivedMessage)
{
    //Dol::Translator<Platform::Message,Platform::Message> messageTranslator;
    std::shared_ptr<Platform::Message> message =  messageTranslator.StringToDomainObjectMessage(receivedMessage);
    m_brokerNotifier(message);   

}

}//end of Platform
