/**
* @file   Dispatcher.h
* @Author Anoop Chandran (anoop.chandran@honeywell.com)
* @brief  Dispatcher class for message distribution.
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
 */
 
#ifndef DISPATCHER_INCLUDE_H
#define DISPATCHER_INCLUDE_H
#include "map"
#include "cassert"
#include "Signals/Delegate.h"
#include "Signals/Signal.h"

#include "Message/Message.h"
#include "DOL/Helper/Translator.h"
namespace Platform
{

/**
    Dispatcher class is used as a base for MessagePort class.
    MessagePort uses Dispatcher for Messages distribution.
    @ingroup Platform
*/
class Dispatcher
{
    public:
        /** A constructor. Does nothing */
        Dispatcher() = default;

        /** Assignment operation with class Dispatcher is restricted */
        void operator=(Dispatcher const&)  = delete;

        /** A destructor. Does nothing */
        virtual ~Dispatcher() = default;        

        /** Does nothing. TODO: needed for extension in future */
        void Prepare();

        /** 
            Message distribution method. Add new type of message here
            for distribution
        */
        void Distributer(const std::string& message);
        /** 
            Message distribution method. Add new type of message here
            for distribution
        */
        void BrokerDistributer(const std::string& message);

        /** Signals to connect dispatched message */
        std::map<Platform::Message::MessageType,Gallant::Signal1<std::shared_ptr<Platform::Message> > > m_notifiers;
        Gallant::Signal1<std::shared_ptr<Platform::Message> > m_brokerNotifier;
        Dol::Translator<Platform::Message,Platform::Message> messageTranslator;
};
}
#endif //DISPATCHER_INCLUDE_H
