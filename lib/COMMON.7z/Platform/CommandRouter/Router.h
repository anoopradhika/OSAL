/*****************************************************************//**
 *
 * @file    Router.h
 * @brief   route mol commands
 *
 * @copyright Copyright 2020 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_COMMAND_ROUTER_H
#define PLATFORM_COMMAND_ROUTER_H

// framework
#include "Mol/Commands/Command.h"
#include "Mol/Commands/CommandTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"

#include <chrono>
#include <ctime>

namespace Platform {

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class CommandDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i ) { 
             // Intentionally unimplemented...
         }
};

template<typename CommunicatorType>
struct CommandForwader {
    CommandForwader(std::set<uint64_t>& ids, CommunicatorType& communicator,uint64_t sourceId):
                m_ids{ids}
               ,m_communicator{communicator}
               ,m_sourceId{sourceId}
    {}
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message)
    {
        auto destinationReference  = message->GetCommandTarget();
        destinationReference.PrepareDeviceUniqueID();
        if(destinationReference.GetDNM() == 0)
        {
            // ignore multicast commands
            DEBUGPRINT(DEBUG_INFO, "Command ROUTER skipping same muticast destinationPanelID {}", destinationReference.GetObjectId());
            return;
        }

        auto destinationPanelID = Mol::DeviceUniqueID{destinationReference.GetObjectId()}.GetPanelId64Bit();
        auto sourcePanelID = Mol::DeviceUniqueID{m_sourceId}.GetPanelId64Bit();
        if( destinationPanelID == sourcePanelID)
        {
            DEBUGPRINT(DEBUG_INFO, "Command ROUTER skipping same sourcePanelID {} and destinationPanelID {}",sourcePanelID, destinationPanelID);
            return;
        }
        for(auto id : m_ids)
        {
            m_communicator.Send(message, PROC_ADDRESS::CMCAPP, id);
        }
        m_communicator.Send(message, PROC_ADDRESS::MOL_RECEIVER, sourcePanelID);
    }
    std::set<uint64_t>& m_ids;
    CommunicatorType& m_communicator;
    uint64_t m_sourceId;
};

using CommandType = Mol::Command::COMMAND_CATEGORY;
using CommandCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,CommandType,Mol::Message<CommandType>>;


auto ForwardCommand = [](auto event, std::set<uint64_t>& ids,CommandCommunicator& communicator, uint64_t sourceId)
{
    using EventCaster = Platform::CastAndCall< CommandDowncastAdapter,  Mol::Message<CommandType>, CommandObjectTypes >;
    EventCaster::Do<Mol::Event::EventDefault>(event,CommandForwader<CommandCommunicator>{ids,communicator,sourceId});
};

} // end namespace

#endif //PLTFORM_COMMAND_ROUTER_H
