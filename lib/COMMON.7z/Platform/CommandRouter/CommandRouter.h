/**********************************************************************************
* @file CommandRouter .h
* @brief Router commands
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_COMMAND_ROUTER_H
#define PLATFORM_MOL_COMMAND_ROUTER_H

#define MAX_EVENTS_QUEUE_SIZE (uint64_t)2000
#define MAX_TIMEOUT 10000

#include "Component/Component.h"
#include "CommandRouter/Router.h"
#include "CommandRouter/StateMachine.h"

#include "Mol/Commands/Command.h"
#include "Mol/Commands/Activate.h"
#include "Mol/Requests/EventRouterService.h"
#include "Mol/Responses/EventRouterService.h"
#include <queue>
#include "boost/sml.hpp"
#include "Timer/Timer.hpp"

namespace Platform
{

/**
 * @brief    CommandRouter main responsibility is to
 *           Route commands message to Subscribers
*/
class CommandRouter: public Platform::Component
{
public:
    using CommandType = Mol::Command::COMMAND_CATEGORY;

    explicit CommandRouter(uint64_t panelId):
    m_panelId{panelId}
    ,m_StateMachine(*this)
    ,m_updaterStateMachine{m_StateMachine}
    {
    }

    void Prepare() override
    {
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: Prepare component");
        Platform::Component::Prepare();
        MolCommandSubscribe<Mol::Command::Activate, CommandType>(CommandType::ACTIVATE);
        MolCommandSubscribe<Mol::Command::Deactivate, CommandType>(CommandType::DEACTIVATE);
        MolCommandSubscribe<Mol::Command::SetAlarmSignal, CommandType>(CommandType::SET_ALARM_SIGNAL);
        MolCommandSubscribe<Mol::Command::Disable, CommandType>(CommandType::DISABLE);
        MolCommandSubscribe<Mol::Command::Enable, CommandType>(CommandType::ENABLE);
        MolCommandSubscribe<Mol::Command::ReSynchronization, CommandType>(CommandType::RESYNC);

        m_communicator.m_request.Subscribe<Mol::Request::EventRouterService>(Mol::Request::REQUEST_CATEGORY::EVENT_ROUTER_SERVICE);
        m_communicator.m_request.getService(Mol::Request::REQUEST_CATEGORY::EVENT_ROUTER_SERVICE)->Connect(this, &CommandRouter::EventRouterServiceRequest);

        Platform::Notifier notifier;
        Platform::Notifier notifierSending;
        notifier.Connect(this,&CommandRouter::SubscriberTimeout);
        m_timer = Platform::Timer<>(MAX_TIMEOUT,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);

        notifierSending.Connect(this,&CommandRouter::SendBufferedEvents);
        m_unBufferingTimer = Platform::Timer<>(1,GlobalDataType::Timer::AlarmType::PERIODIC,notifierSending);

    }


    ~CommandRouter() = default;

    void AddFirstSubscriberStartWaiting(uint64_t senderID)
    {
        m_subscriberDSnums.emplace(senderID);
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: EVENT_ROUTER_SERVICE_CODE::ADD id[{:#x}]", senderID);
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: ForwardCommand() first subscriber is there lets wait 3s for the others");
        m_timer.Start();
        EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::ADDED, senderID);
    }

    void SendBufferedEvents()
    {
        if (!m_commandsQueue.empty())
        {
            auto event = m_commandsQueue.front();
            ForwardCommand(event, m_subscriberDSnums, m_communicator.m_command,m_panelId);
            m_commandsQueue.pop();
            DEBUGPRINT(DEBUG_INFO, "CommandRouter: SendBufferedEvents() reading from queue size [{}] elements ", m_commandsQueue.size());
        }
    }

    void DoRouting(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
    {
        ForwardCommand(command, m_subscriberDSnums, m_communicator.m_command,m_panelId);
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: DoRouting()");
    }

    void BufferCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
    {
        m_commandsQueue.push(command);
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: BufferCommand(), queuing[{}] elements ", m_commandsQueue.size());
    }

    bool isMaxBuffring()
    {
        return ((uint64_t)m_commandsQueue.size() >= MAX_EVENTS_QUEUE_SIZE);
    }

    bool isEmptyQueue()
    {
        return (m_commandsQueue.empty());
    }

    void StartSendingTimer()
    {
        m_unBufferingTimer.Start();
    }

    void CancelTimeoutTimer()
    {
        m_timer.Stop();
    }

    void SubscriberTimeout()
    {
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: SubscriberTimeout()");
        m_timer.Stop();
        m_updaterStateMachine.process_event(CommandBufferingTimeout());
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "CommandRouter is now in state[{}]", state.c_str());});

    }

    void UpdateSubscriber(std::shared_ptr<Mol::Request::EventRouterService> request, uint64_t senderID)
    {
        if(request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD)
        {
            m_subscriberDSnums.emplace(senderID);
            DEBUGPRINT(DEBUG_INFO, "CommandRouter: UpdateSubscriber(), adding id[{0:#x}], number of subs[{1:#x}]", senderID, m_subscriberDSnums.size());
            EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::ADDED, senderID);
        }
        else if (request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::REMOVE)
        {
            auto it = m_subscriberDSnums.find(senderID);
            if (it != m_subscriberDSnums.end())
            {
                m_subscriberDSnums.erase(it);
                EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::REMOVED, senderID);
            }
            else
            {
                EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED, senderID);
            }
        }
        else
        {
             DEBUGPRINT(DEBUG_INFO, "CommandRouter : UpdateSubscriber,DoNothing");
        }
    }

    void SendInvalideRequest(uint64_t senderID)
    {
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED id {}",senderID);
        EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED,senderID);
    }

protected:

    template<typename command, typename commandType>
    void MolCommandSubscribe(commandType commandTypeId)
    {
        m_communicator.m_command.Subscribe<command>(commandTypeId);
        m_communicator.m_command.getService(commandTypeId)->Connect(this,&CommandRouter::ReceiveCommand);
    }

    void EventRouterServiceRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, const uint64_t senderID)
    {
        auto eventRouterServiceRequest = std::static_pointer_cast<Mol::Request::EventRouterService>(request);

        if( (Mol::DeviceUniqueID{m_panelId}.GetDomainID() != Mol::DeviceUniqueID{senderID}.GetDomainID() )
            ||
            (Mol::DeviceUniqueID{m_panelId}.GetNodeID() != Mol::DeviceUniqueID{senderID}.GetNodeID() )
          )
        {
            DEBUGPRINT(DEBUG_INFO, "CommandRouter: EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED id {}",senderID);
            EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED,senderID);
            return;
        }

        CommandRouterRequest routerRequest =
            { .request = eventRouterServiceRequest, .senderID = senderID };
        m_updaterStateMachine.process_event(routerRequest);
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "CommandRouter is now in state[{}]", state.c_str());
                });

    }

    void EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE code, uint64_t senderID)
    {
        auto message = std::make_shared<Mol::Response::EventRouterService>(code);
        m_communicator.m_response.Send(message, PROC_ADDRESS::CMCAPP, senderID);
        DEBUGPRINT(DEBUG_INFO, "CommandRouter: Send reponse to id {}",senderID);
    }

    void ReceiveCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, const uint64_t senderID)
    {
        m_updaterStateMachine.process_event(command);
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "CommandRouter is now in state[{}]", state.c_str());
                });
    }


    uint64_t m_panelId;
    std::set<uint64_t> m_subscriberDSnums;
    std::queue<std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>>> m_commandsQueue;
    StateMachine<CommandRouter> m_StateMachine;
    boost::sml::sm<StateMachine<CommandRouter>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;
    Platform::Timer<> m_timer;
    Platform::Timer<> m_unBufferingTimer;
};

}
#endif //PLATFORM_MOL_COMMAND_ROUTER_H
