/**********************************************************************************
 * @file StateMachine .h
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#ifndef PLATFORM_MOL_COMMAND_ROUTER_STATE_MACHINE_H
#define PLATFORM_MOL_COMMAND_ROUTER_STATE_MACHINE_H

#include "Mol/DataType/ObjectReference.h"
#include "Component/Component.h"
#include "GlobalDataType/Error.h"
#include "boost/sml.hpp"
#include <queue>
#include "CommandRouter/StateMachine.h"
#include "Mol/Requests/EventRouterService.h"
struct CommandBufferingTimeout {};

struct CommandRouterRequest {
    std::shared_ptr<Mol::Request::EventRouterService> request;
    const uint64_t senderID;
};
namespace Platform
{
/**
* Template state Machine for handling comand routing
@startuml

title AddSubscraber/RemoveSubscraber/BufferingEvents/Routing/SendInvalideRequest of Event Routing
[*] --> EventRouterStarted
state EventRouterStarted
state "MainCPU ready for\n routing events" as EventRouterStarted {
state start
state waiting
state routing
[*] -> start

start --> waiting :IsAddSubscriber(first subscriber is there, lets wait for the others)
start --> start :NeedBuffering(new event, no subscriber do buffering)
start --> routing :NeedRouting(new event, max buffering reached, stop timeout timer, switch to routing)
waiting --> waiting :NeedUpdateSubscriber(add/remove subscriber)
waiting --> waiting :IsInvalideRequest(send Invalid request response)
waiting --> waiting :NeedBuffering(new event, still in waiting so do buffering)
waiting --> routing :NeedRouting(max buffering reached, stop timeout timer, switch to routing)
waiting --> routing :CommandBufferingTimeout(switch to routing)
routing --> routing :NeedUpdateSubscriber(add/remove subscriber)
routing --> routing :IsInvalideRequest(send Invalid request response)
routing --> routing :NeedRouting(new event arrive, DoRouting)
routing --> routing :NeedBuffering(new event arrive, queue not empty)


routing: Timeout or max buffering reached do routing events to subscribers
routing: Add new subscriber
routing: Remove subscriber
routing: SendInvalideRequest
routing: DoRouting

waiting: Add the first subcraber
waiting: Wait for other subscribers
waiting: Add new subscriber
waiting: Remove subscriber
waiting: SendInvalideRequest
waiting: DoBufferCommand

start: MainCPU started
start: EventRouter ready to add new subscribers for events routing


}

@enduml
*/

template<typename Handler>
class StateMachine
{
public:
    StateMachine() = delete;

    StateMachine(StateMachine&& other) = delete;

   explicit StateMachine(Handler& handler):
    m_handler(handler)
    {
    }

    ~StateMachine() = default;
    StateMachine(const StateMachine & other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;

        const auto isAddSubscriber = [this] (CommandRouterRequest CommandRouterRequest)
        {
            return (CommandRouterRequest.request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD);
        };

        const auto isValidRequest = [this] (CommandRouterRequest CommandRouterRequest)
        {
            return (CommandRouterRequest.request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::REMOVE ||
                    CommandRouterRequest.request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD);
        };

        const auto isValidCommand = [this] (std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
        {
            return (nullptr != command);
        };

        const auto isMaxBuffring = [this] ()
        {
            return isMaxBuffringCall();
        };

        const auto isEmptyQueue = [this] ()
        {
            return isEmptyQueueCall();
        };


        const auto AddFirstSubStartWaiting = [this] (CommandRouterRequest CommandRouterRequest)
        {
            AddFirstSubscriberStartWaiting(CommandRouterRequest.senderID);
        };

        const auto DoBufferCommand = [this] (std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
        {
            BufferCommand(command);
        };

        const auto UpdateSubscriber = [this] (CommandRouterRequest CommandRouterRequest)
        {
            CallUpdateSubscriber(CommandRouterRequest.request, CommandRouterRequest.senderID);
        };

        const auto DoRouting = [this] (std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
        {
            DoRoutingCall(command);
        };

        const auto DoStartSendingTimer = [this] ()
        {
            StartSendingTimer();
        };

        const auto CancelTimoutStartSendingTimer = [this] (std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
        {
            CancelTimeoutTimer();
            BufferCommand(command); //need to buffer this last event
            StartSendingTimer();
        };

        const auto DoSendInvalideRequest = [this] (CommandRouterRequest CommandRouterRequest)
        {
            SendInvalideRequest(CommandRouterRequest.senderID);
        };

                // State machine transition table switching
        return boost::sml::make_transition_table(
                // first subscriber is there, lets wait for the others --> waiting
                *"start"_s + event<CommandRouterRequest> [isAddSubscriber] / AddFirstSubStartWaiting = "waiting"_s
                //at startup events are coming no subscriber yet, stay in start state and buffering --> start
                ,"start"_s + event<std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>>> [!isMaxBuffring && isValidCommand] / DoBufferCommand = "start"_s
                //at startup events are coming no subscriber yet, if we exceed buffering size  --> routing
                ,"start"_s + event<std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>>> [isMaxBuffring] / CancelTimoutStartSendingTimer = "routing"_s
                //while waiting if new subscriber is add/removed, stay in --> waiting
                ,"waiting"_s + event<CommandRouterRequest> [isValidRequest] / UpdateSubscriber = "waiting"_s
                ,"waiting"_s + event<CommandRouterRequest> [!isValidRequest] / DoSendInvalideRequest = "waiting"_s
                //while waiting if new events are coming, stay in waiting state and buffering --> waiting
                ,"waiting"_s + event<std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>>> [!isMaxBuffring && isValidCommand] / DoBufferCommand = "waiting"_s
                ,"waiting"_s + event<std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>>> [isMaxBuffring] / CancelTimoutStartSendingTimer = "routing"_s
                //while waiting if timeout come --> routing
                ,"waiting"_s + event<CommandBufferingTimeout> / DoStartSendingTimer = "routing"_s //unbuffring



                //while in routing state if if new subscriber is add, keep --> routing
                ,"routing"_s + event<CommandRouterRequest> [isValidRequest] / UpdateSubscriber = "routing"_s
                ,"routing"_s + event<CommandRouterRequest> [!isValidRequest] / DoSendInvalideRequest = "routing"_s
                ,"routing"_s + event<std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>>>  [isEmptyQueue && isValidCommand] / DoRouting = "routing"_s
                ,"routing"_s + event<std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>>>  [!isEmptyQueue && isValidCommand] / DoBufferCommand = "routing"_s

                );
    }

protected:

    void AddFirstSubscriberStartWaiting(uint64_t senderID)
    {
        m_handler.AddFirstSubscriberStartWaiting(senderID);
    }

    void BufferCommand(std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>> event)
    {
        m_handler.BufferCommand(event);
    }

    void CallUpdateSubscriber(std::shared_ptr<Mol::Request::EventRouterService> request, uint64_t senderID)
    {
        m_handler.UpdateSubscriber(request, senderID);
    }

    void SendInvalideRequest(uint64_t senderID)
    {
        m_handler.SendInvalideRequest(senderID);
    }

    void DoRoutingCall(std::shared_ptr< Mol::Message<Mol::Command::COMMAND_CATEGORY>> command)
    {
        m_handler.DoRouting(command);
    }

    void StartSendingTimer()
    {
        m_handler.StartSendingTimer();
    }

    void CancelTimeoutTimer()
    {
        m_handler.CancelTimeoutTimer();
    }

    bool isMaxBuffringCall()
    {
        return m_handler.isMaxBuffring();
    }

    bool isEmptyQueueCall()
    {
        return m_handler.isEmptyQueue();
    }
    Handler& m_handler;
};

}
#endif //PLATFORM_MOL_COMMAND_ROUTER_STATE_MACHINE_H
