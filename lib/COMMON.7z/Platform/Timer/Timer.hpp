/*
* @file    Notifier.hpp
* @date    01.12.2017
* @brief   Timer can be used as  both SINGLE_SHOT and PERIODIC timer. It
* provides notification on timer expiry.
* @copyright Copyright [2017] by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, re-engineered, distributed or
* disclosed to others without the written consent of Honeywell.
 */
#include"Timer/Timer.h"
#include"Config/Config.h"

#ifndef PLATFORM_TIMER_INCLUDE_H
#define PLATFORM_TIMER_INCLUDE_H

namespace Platform
{

/**
    platform::Timer is abstract interface to all type of OS
    specific time
    - It supports Linux Timer
    - It supports FreeRTOS Timer
*/
template<typename nativeTimerType = PlatformNative::Timer>
class Timer
{
public:
    /**
      default constructor
    */
    Timer() = default;

    virtual ~Timer() = default;

    /**
      constructor to set alarm type and time
      @param mS  Notification period
      @param alarmType
    */
    Timer(const uint32_t mS, GlobalDataType::Timer::AlarmType alarmType, Platform::Notifier& notifier) :
            m_nativeTimer(mS, alarmType,notifier)
    {
    }

    Timer& operator=(const Timer& timer) = delete;
    Timer(const Timer& other) = delete;

    /**
      move operator is used for timer copy operation. Note: This will
      move the timer to the lhs.
      @param timer: Source timer
    */
    Timer& operator=(Timer&& timer) noexcept
    {
       m_nativeTimer =  std::move(timer.m_nativeTimer);
       return *this;
    }

    /**
      @brief Starts the timer, if stopped. Restarts the timer, if running.
      @Note Also creates the timer.
    */
    void Start()
    {
        m_nativeTimer.Start();
    }

    /**
      @brief Stops the timer.
    */
    void Stop()
    {
        m_nativeTimer.Stop();
    }

    /**
      @brief Stops and delete the timer.
    */
    void Shutdown()
    {
        m_nativeTimer.Shutdown();
    }

    /**
      @brief Current running state of the timer.
      @return return true if timer is running, else false
    */
    bool Running() const
    {
        return m_nativeTimer.Running();
    }
    /**
      @brief Current running state of the timer.
      @return return true if timer is stopped, else false
    */
    bool IsStopped() const
    {
        return m_nativeTimer.IsStopped();
    }

    /**
      @brief Start timer from previous state
    */
    void Resume()
    {
        m_nativeTimer.Resume();
    }

    /**
      @brief Returns the number of milliseconds elapsed since the last timer expiry.
      @return time in milliseconds.
    */
    uint32_t Elapsed() const
    {
        return m_nativeTimer.Elapsed();
    }

private:
    nativeTimerType m_nativeTimer;
};

} //platform
#endif //PLATFORM_TIMER_INCLUDE_H
