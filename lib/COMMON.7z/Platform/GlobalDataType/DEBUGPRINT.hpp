	/*****************************************************************//**
 *
 * @file    DEBUGPRINT.hpp
 * @brief   Shared DEBUGPRINT class for both linux and FreeRTOS
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef GLOBAL_DATATYPE_DEBUGPRINT_INCLUDE_H
#define GLOBAL_DATATYPE_DEBUGPRINT_INCLUDE_H

#include <stdint.h>
#include <string>
#include "PlatformType/PlatformType.h"

#if IS_LINUX_PLATFORM()
#include <syslog.h>
#endif

//if enum class use here, the enum value can only access with
//DebugLevel::DEBUG_ALL. this cause rework in all files using DEBUG_XXX.
enum  DebugLevel
{
    DEBUG_EMERG,
    DEBUG_ALERT,
    DEBUG_FATAL,
    DEBUG_ERROR,
    DEBUG_WARNING,
    DEBUG_NOTICE,
    DEBUG_INFO,
    DEBUG_ALL,
};



enum class OutStream
{
    STDOUT,
    LOGFILE,
};

namespace GlobalDataType
{

class DEBUGPRINT
{
public:

    /**
        A default constructor
    */
    DEBUGPRINT() = default;

    /**
        A default destructor
    */
    ~DEBUGPRINT() = default;

    static void SetDebugLevel(DebugLevel debugLevel);

    static void SetOutStream(OutStream outStream);
    static DebugLevel GetDebugLevel();

protected:
    static DebugLevel m_globalDebugLevel;

    static OutStream m_outstream;
};
} //end of Interface

#endif // GLOBAL_DATATYPE_DEBUGPRINT_INCLUDE_H
