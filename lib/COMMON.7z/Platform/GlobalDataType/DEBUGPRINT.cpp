/*****************************************************************//**
 *
 * @file    DEBUGPRINT.cpp
 * @brief   Shared DEBUGPRINT class for both linux and FreeRTOS
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include "GlobalDataType/DEBUGPRINT.hpp"

namespace GlobalDataType
{

DEBUGPRINT obj;
void DEBUGPRINT::SetDebugLevel(DebugLevel debugLevel)
{
#if IS_LINUX_PLATFORM()
    setlogmask(LOG_UPTO (debugLevel));
#endif
    //anyway we need this also in linux and rtos
    if(DEBUG_ALL >= debugLevel)
    {
        m_globalDebugLevel = debugLevel;
    }

}


void DEBUGPRINT::SetOutStream(OutStream outStream)
{
    if(OutStream::LOGFILE == m_outstream)
    {
        m_outstream = outStream;
    }
}

DebugLevel  DEBUGPRINT::GetDebugLevel()
{
    return DEBUGPRINT::m_globalDebugLevel;
}

DebugLevel DEBUGPRINT::m_globalDebugLevel = DEBUG_ERROR;

OutStream DEBUGPRINT::m_outstream = OutStream::LOGFILE;

} //end of GlobalDataType
