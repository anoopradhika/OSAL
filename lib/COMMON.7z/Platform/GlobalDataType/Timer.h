/*****************************************************************//**
 *
 * @file    Timer.h
 * @brief   Data type shared between OS Timer shall be added here
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef COMMON_PLATFORM_GLOBALDATATYPE_TIMER_H
#define COMMON_PLATFORM_GLOBALDATATYPE_TIMER_H

#include <stdint.h>

namespace GlobalDataType
{

class Timer
{
public:
    enum class AlarmType : uint8_t
    {
        SINGLE_SHOT,
        PERIODIC
    };
};

} //end of Interface

#endif // COMMON_PLATFORM_GLOBALDATATYPE_TIMER_H
