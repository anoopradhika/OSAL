/*****************************************************************//**
 *
 * @file FileNotification.h
 * @brief FileNotification monitor file modification. It provides notification
 * on file modfication
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef PLATFORM_FILE_NOTIFICATION_INCLUDE_H
#define PLATFORM_FILE_NOTIFICATION_INCLUDE_H

#include <memory>

#include "uv.h"
#include "Notifier/Notifier.hpp"

namespace GlobalDataType
{

class FileNotification
{
public:
    FileNotification()
    {
        uv_fs_poll_init(uv_default_loop(),m_fsEvent.get());
    }


    bool Registration(const std::string& path, Platform::Notifier& notifier, uint32_t intervalMs = 1000)
    {
        if(!mRegistered)
        {
            mPollIntervalMs = intervalMs;
            if(0 == mPollIntervalMs)
            {
                mPollIntervalMs = POLL_INTERVAL_MS;
            }
            m_notifier = notifier;
            m_fsEvent->data = this;
            uv_fs_poll_start(m_fsEvent.get()
                             , [](uv_fs_poll_t* handle, int status, const uv_stat_t* prev, const uv_stat_t* curr)
                               {
                                   static_cast<FileNotification*>(handle->data)->m_notifier();
                               }
                              , path.c_str()
                              , mPollIntervalMs
                          );
            mRegistered = true;
        }
        return mRegistered;
    }

    bool UnRegistration()
    {
        if(mRegistered)
        {
            uv_fs_poll_stop(m_fsEvent.get());
            mRegistered = false;
            return true;
        }

        return false;
    }

    ~FileNotification()
    {
        uv_fs_poll_stop(m_fsEvent.get());
    }


protected:
    Platform::Notifier m_notifier{};
    uint32_t mPollIntervalMs{0};
    static constexpr uint32_t POLL_INTERVAL_MS{1000};
    std::shared_ptr<  uv_fs_poll_t> m_fsEvent = std::make_shared<  uv_fs_poll_t>();
    bool mRegistered{false};
};

} // end of GlobalDataType

#endif //PLATFORM_FILE_NOTIFICATION_INCLUDE_H
