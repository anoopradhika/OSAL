/*****************************************************************//**
 *
 * @file    MessageQueue.h
 * @brief   Data type shared between OS messagequeues shall be added here
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef GLOBAL_DATATYPE_MESSAGEQUEUE_INCLUDE_H
#define GLOBAL_DATATYPE_MESSAGEQUEUE_INCLUDE_H

#include <stdint.h>
#include <string>

namespace GlobalDataType
{

class MessageQueue
{
public:
    /**
        A default constructor
    */
    MessageQueue() = default;

    /**
        A default destructor
    */
    ~MessageQueue() = default;

    /**
        block type used in message queue.
    */
    enum class BlockType :uint32_t
    {
      BLOCK, //If BLOCK is specified timed send and receive will not work
      NON_BLOCK
    };
};

} //end of Interface

#endif // GLOBAL_DATATYPE_MESSAGEQUEUE_INCLUDE_H

