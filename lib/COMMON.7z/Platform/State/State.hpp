
#ifndef PLATFORM_STATE_INCLUDE_H
#define PLATFORM_STATE_INCLUDE_H

#include <cassert>

namespace Platform
{

/**

@startuml

title State Transaction
State DEINIT
State INIT
State PREPARE
State START
State STOP
State SHUTDOWN

[*] -down-> DEINIT
DEINIT -right-> INIT
INIT -right-> PREPARE
PREPARE -down-> START
START -down-> STOP
STOP -left-> SHUTDOWN
SHUTDOWN -left->DEINIT
DEINIT -down->[*]

@enduml
*/
class State
{
public:
    State():m_state(DEINIT){};

    virtual ~State(){assert(m_state == DEINIT);};

    virtual void Init()
    {
        assert(m_state == DEINIT);
        m_state = INIT;
    }

    virtual void Prepare()
    {
        assert(m_state == INIT);
        m_state = PREPARE;
    }

    virtual void Start()
    {
        assert((m_state == PREPARE) || (m_state == STOP) );
        m_state = START;
    }

    virtual void Stop()
    {
        assert(m_state == START);
        m_state = STOP;
    }

    virtual void Shutdown()
    {
        assert(m_state == STOP);
        m_state = SHUTDOWN;
    }

    virtual void Uninit()
    {
        assert(m_state == SHUTDOWN);
        m_state = DEINIT;
    }

protected:
    enum StateType
    {
        INIT,
        PREPARE,
        START,
        STOP,
        SHUTDOWN,
        DEINIT
    };

    StateType m_state;
};

}//platform

#endif //PLATFORM_STATE_INCLUDE_H
