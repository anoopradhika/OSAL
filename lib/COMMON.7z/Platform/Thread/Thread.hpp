/*!
 * @file   Thread.hpp
 * @author E190637
 * @brief  Platform wrapper for native platform threading.
 *
 * Mainly based on the std::thread operations provided by C++11. When the object is deleted, 
 * or goes out context the execution thread is immediately terminated.
 *
 * Create thread, move thread, and then detach
 * @code{.cpp}
 *
 *     // Create execution point.
 *     platform::Notifier notifier;
 *     notifier.Connect(&TestThread, 1000);
 *
 *     platform::Thread task;
 *
 *     // Create thread and assign to task
 *     task = platform::Thread<> { notifier, "Thread Name" };
 *
 *     // Detach thread from task.
 *     task.detach();
 *
 * @endcode
 * 
 */

#ifndef PLATFORM_THREAD_INCLUDE_H
#define PLATFORM_THREAD_INCLUDE_H

#include"Thread/Thread.h"
#include"Config/Config.h"

namespace Platform
{

/*!
 * @brief Wrapper class for platform independent threading
 */
template<typename NativeThreadType = PlatformNative::Thread>
class Thread
{
public:
    /*!
 	 * @brief A default constructor
     */
    Thread() = default;

    /*!
     * @brief Constructor create the thread
     * @param worker  takes the thread and it argument.
     * @param name name of thread (OS specific, optional)
     * @param stack_size size of stack in bytes (OS specific, optional)
     * @param priority initial thread priority(OS specific, optional)
     */
    Thread(Notifier &worker, std::string name="", size_t stack_size=NativeThreadType::DEFAULT_STACK, int priority=NativeThreadType::DEFAULT_PRIORITY):
                m_nativeThread(worker, name, stack_size, priority)
    {

    }

    /*!
     * @brief Constant copy constructor not allowed.
     */
    Thread(Thread const& thread) = delete;

    /*!
     * @brief Constant assignment disallowed
     */
    Thread& operator = (Thread const&& thread) = delete;

    /*!
     * @brief Moves other execution thread to this object. Method generate 
     * assert if the host thread is joinable
     */
    Thread& operator=( Thread&& other )
    {
        m_nativeThread = std::move( other.m_nativeThread );
        return *this;
    }

    /*!
     * @brief default destructor
     */
    virtual ~Thread() = default;

    /*!
     * @brief Checks if the thread object identifies an active thread of execution. Specifically, 
     *        returns true if get_id() != std::thread::id(). So a default constructed thread is 
     *        not joinable.
     *        Note: a default constructed thread is not joinable
     */
    auto Joinable() const  -> decltype(std::declval<NativeThreadType>().Joinable())
    {
        return m_nativeThread.Joinable();
    }

    /*!
     * @brief Returns a value of std::thread::id identifying the thread associated with *this.
     */
    auto GetId() const
    {
        return m_nativeThread.GetId();
    }

    /*!
     * @brief Blocks the current thread until the thread identified by *this finishes its execution.
     */
    void Join()
    {
        m_nativeThread.Join();
    }
    
    /*!
     * @brief Separates the thread of execution from the thread object, allowing execution to continue 
     *        independently. Any allocated resources will be freed once the thread exits.
     */
    void Detach()
    {
        m_nativeThread.Detach();
    }

private:
    NativeThreadType m_nativeThread;
};

namespace this_thread
{
    /**
      Reschedule the execution of threads, allowing other threads to run.
    */
    inline void Yield()
    {
        namespace NativeThisThreadType = PlatformNative::this_thread;
        NativeThisThreadType::Yield();
    }
    /*!
     * @brief
     */
    inline void Sleep(uint32_t timeMs)
    {
        namespace NativeThisThreadType = PlatformNative::this_thread;
        NativeThisThreadType::Sleep(timeMs);
    }
} //end of this_thread
} //platform
#endif //PLATFORM_THREAD_INCLUDE_H
