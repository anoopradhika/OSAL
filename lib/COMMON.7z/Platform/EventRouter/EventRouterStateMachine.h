/**********************************************************************************
 * @file EventRouterStateMachine .h
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#ifndef PLATFORM_MOL_EVENT_ROUTER_STATE_MACHINE_H
#define PLATFORM_MOL_EVENT_ROUTER_STATE_MACHINE_H

#include "Mol/DataType/ObjectReference.h"
#include "Component/Component.h"
#include "GlobalDataType/Error.h"
#include "boost/sml.hpp"
#include <queue>
#include "EventRouter/EventRouterStateHandler.h"
#include "Mol/Requests/EventRouterService.h"
struct BufferingTimeout {};

struct RouterRequest {
    std::shared_ptr<Mol::Request::EventRouterService> request;
    const uint64_t senderID;
};
namespace Platform
{
/**
* Template state Machine for handling EventRouter
@startuml

title AddSubscraber/RemoveSubscraber/BufferingEvents/Routing/SendInvalideRequest of Event Routing
[*] --> EventRouterStarted
state EventRouterStarted
state "MainCPU ready for\n routing events" as EventRouterStarted {
state start
state waiting
state routing
[*] -> start

start --> waiting :IsAddSubscriber(first subscriber is there, lets wait for the others)
start --> start :NeedBuffering(new event, no subscriber do buffering)
start --> routing :NeedRouting(new event, max buffering reached, stop timeout timer, switch to routing)
waiting --> waiting :NeedUpdateSubscriber(add/remove subscriber)
waiting --> waiting :IsInvalideRequest(send Invalid request response)
waiting --> waiting :NeedBuffering(new event, still in waiting so do buffering)
waiting --> routing :NeedRouting(max buffering reached, stop timeout timer, switch to routing)
waiting --> routing :BufferingTimeout(switch to routing)
routing --> routing :NeedUpdateSubscriber(add/remove subscriber)
routing --> routing :IsInvalideRequest(send Invalid request response)
routing --> routing :NeedRouting(new event arrive, DoRouting)
routing --> routing :NeedBuffering(new event arrive, queue not empty)


routing: Timeout or max buffering reached do routing events to subscribers
routing: Add new subscriber
routing: Remove subscriber
routing: SendInvalideRequest
routing: DoRouting

waiting: Add the first subcraber
waiting: Wait for other subscribers
waiting: Add new subscriber
waiting: Remove subscriber
waiting: SendInvalideRequest
waiting: DoBufferEvent

start: MainCPU started
start: EventRouter ready to add new subscribers for events routing


}

@enduml
*/

template<typename Handler>
class EventRouterStateMachine
{
public:
    EventRouterStateMachine() = delete;

    EventRouterStateMachine(EventRouterStateMachine&& other) = delete;

    explicit EventRouterStateMachine(Handler& handler):
    m_handler(handler)
    {
    }

    ~EventRouterStateMachine() = default;
    EventRouterStateMachine(const EventRouterStateMachine & other) :
        m_handler{other.m_handler}
    {
    }

    /**
     * @brief Overloaded Operator() for state machine. Please refer boost::sml for more info
     */
    auto operator()()
    {
    	using boost::sml::operator""_s;
    	using boost::sml::v1_1_2::event;
    	using boost::sml::operator&&;
    	using boost::sml::operator!;

        const auto isAddSubscriber = [this] (RouterRequest routerRequest)
        {
            return (routerRequest.request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD);
        };

        const auto isValidRequest = [this] (RouterRequest routerRequest)
        {
            return (routerRequest.request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::REMOVE ||
                    routerRequest.request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD);
        };

        const auto isValidEvent = [this] (std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
        {
            return (nullptr != event);
        };

        const auto isMaxBuffring = [this] ()
        {
            return isMaxBuffringCall();
        };

        const auto isEmptyQueue = [this] ()
        {
            return isEmptyQueueCall();
        };


        const auto AddFirstSubStartWaiting = [this] (RouterRequest routerRequest)
        {
            AddFirstSubscriberStartWaiting(routerRequest.senderID);
        };

        const auto DoBufferEvent = [this] (std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
        {
            BufferEvent(event);
        };

        const auto UpdateSubscriber = [this] (RouterRequest routerRequest)
        {
            CallUpdateSubscriber(routerRequest.request, routerRequest.senderID);
        };

        const auto DoRouting = [this] (std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
        {
            DoRoutingCall(event);
        };

        const auto DoStartSendingTimer = [this] ()
        {
            StartSendingTimer();
        };

        const auto CancelTimoutStartSendingTimer = [this] (std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
        {
            CancelTimeoutTimer();
            BufferEvent(event); //need to buffer this last event
            StartSendingTimer();
        };

        const auto DoSendInvalideRequest = [this] (RouterRequest routerRequest)
        {
            SendInvalideRequest(routerRequest.senderID);
        };

                // State machine transition table switching
        return boost::sml::make_transition_table(
                // first subscriber is there, lets wait for the others --> waiting
                *"start"_s + event<RouterRequest> [isAddSubscriber] / AddFirstSubStartWaiting = "waiting"_s
                //at startup events are coming no subscriber yet, stay in start state and buffering --> start
                ,"start"_s + event<std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>>> [!isMaxBuffring && isValidEvent] / DoBufferEvent = "start"_s
                //at startup events are coming no subscriber yet, if we exceed buffering size  --> routing
                ,"start"_s + event<std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>>> [isMaxBuffring] / CancelTimoutStartSendingTimer = "routing"_s
                //while waiting if new subscriber is add/removed, stay in --> waiting
                ,"waiting"_s + event<RouterRequest> [isValidRequest] / UpdateSubscriber = "waiting"_s
                ,"waiting"_s + event<RouterRequest> [!isValidRequest] / DoSendInvalideRequest = "waiting"_s
                //while waiting if new events are coming, stay in waiting state and buffering --> waiting
                ,"waiting"_s + event<std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>>> [!isMaxBuffring && isValidEvent] / DoBufferEvent = "waiting"_s
                ,"waiting"_s + event<std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>>> [isMaxBuffring] / CancelTimoutStartSendingTimer = "routing"_s
                //while waiting if timeout come --> routing
                ,"waiting"_s + event<BufferingTimeout> / DoStartSendingTimer = "routing"_s //unbuffring



                //while in routing state if if new subscriber is add, keep --> routing
                ,"routing"_s + event<RouterRequest> [isValidRequest] / UpdateSubscriber = "routing"_s
                ,"routing"_s + event<RouterRequest> [!isValidRequest] / DoSendInvalideRequest = "routing"_s
                ,"routing"_s + event<std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>>>  [isEmptyQueue && isValidEvent] / DoRouting = "routing"_s
                ,"routing"_s + event<std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>>>  [!isEmptyQueue && isValidEvent] / DoBufferEvent = "routing"_s

                );
    }

protected:

    void AddFirstSubscriberStartWaiting(uint64_t senderID)
    {
        m_handler.AddFirstSubscriberStartWaiting(senderID);
    }

    void BufferEvent(std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
    {
        m_handler.BufferEvent(event);
    }

    void CallUpdateSubscriber(std::shared_ptr<Mol::Request::EventRouterService> request, uint64_t senderID)
    {
        m_handler.UpdateSubscriber(request, senderID);
    }

    void SendInvalideRequest(uint64_t senderID)
    {
        m_handler.SendInvalideRequest(senderID);
    }

    void DoRoutingCall(std::shared_ptr< Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
    {
        m_handler.DoRouting(event);
    }

    void StartSendingTimer()
    {
        m_handler.StartSendingTimer();
    }

    void CancelTimeoutTimer()
    {
        m_handler.CancelTimeoutTimer();
    }

    bool isMaxBuffringCall()
    {
        return m_handler.isMaxBuffring();
    }

    bool isEmptyQueueCall()
    {
        return m_handler.isEmptyQueue();
    }

    Handler& m_handler;
};

}
#endif //PLATFORM_MOL_EVENT_ROUTER_STATE_MACHINE_H
