/**********************************************************************************
* @file EventRouterStateHandler .h
* @brief Router all event
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_EVENT_ROUTER_STATE_HANDLER_H
#define PLATFORM_MOL_EVENT_ROUTER_STATE_HANDLER_H

#define MAX_EVENTS_QUEUE_SIZE (uint64_t)2000
#define MAX_TIMEOUT 10000

#include "Component/Component.h"
#include "EventRouter/Router.h"
#include "EventRouter/EventRouterStateMachine.h"

#include "Mol/Events/Event.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/AccessEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/AlarmSignalEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/InputChangeEvent.h"
#include "Mol/Events/MaintenanceEvent.h"
#include "Mol/Events/Reset.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/WarningEvent.h"
#include "Mol/Requests/EventRouterService.h"
#include "Mol/Responses/EventRouterService.h"
#include <queue>
#include "boost/sml.hpp"
#include "Timer/Timer.hpp"

namespace Platform
{

/**
 * @brief    EventRouterStateHandler main responsibility is to
 *           Route all event message to Subscribers
*/
class EventRouterStateHandler: public Platform::Component
{
public:
    using EventType = Mol::Event::EVENT_CATEGORY;

    explicit EventRouterStateHandler(uint64_t panelId):
    m_panelId{panelId}
    ,m_eventRouterStateMachine(*this)
    ,m_updaterStateMachine{m_eventRouterStateMachine}
    {

    }

    void Prepare() override
    {
        Platform::Component::Prepare();
        MolEventSubscribe<Mol::Event::AccessEvent,EventType>(EventType::USER_ACCESS);
        MolEventSubscribe<Mol::Event::ActivationEvent,EventType>(EventType::ACTIVATION);
        MolEventSubscribe<Mol::Event::AlarmEvent,EventType>(EventType::ALARM);
        MolEventSubscribe<Mol::Event::DisablementEvent,EventType>(EventType::DISABLEMENT);
        MolEventSubscribe<Mol::Event::FunctionDisable,EventType>(EventType::FUNCTION_DISABLE);
        MolEventSubscribe<Mol::Event::FunctionEnable,EventType>(EventType::FUNCTION_ENABLE);
        MolEventSubscribe<Mol::Event::AlarmSignalEvent,EventType>(EventType::ALARM_SIGNAL);
        MolEventSubscribe<Mol::Event::FaultClearedEvent,EventType>(EventType::TROUBLE_CLEARED);
        MolEventSubscribe<Mol::Event::FaultEvent,EventType>(EventType::TROUBLE);
        //MolEventSubscribe<Mol::Event::InformationEvent,EventType>(EventType::INFORMATION);//filters added for information event ..refer ReciveInformationEvent() method
        MolEventSubscribe<Mol::Event::InputChangeEvent,EventType>(EventType::INPUT_CHANGE_IN_STATUS);
        MolEventSubscribe<Mol::Event::MaintenanceEvent,EventType>(EventType::MAINTENANCE);
        MolEventSubscribe<Mol::Event::Reset,EventType>(EventType::RESET);
        MolEventSubscribe<Mol::Event::TestOperationEvent,EventType>(EventType::TEST);
        MolEventSubscribe<Mol::Event::UserOperationEvent,EventType>(EventType::USER_OPERATION);
        MolEventSubscribe<Mol::Event::WarningEvent,EventType>(EventType::WARNING);
        MolEventSubscribe<Mol::Event::DelayStartedEvent,EventType>(EventType::DELAY_STARTED_EVENT);

        m_communicator.m_request.Subscribe<Mol::Request::EventRouterService>(Mol::Request::REQUEST_CATEGORY::EVENT_ROUTER_SERVICE);
        m_communicator.m_request.getService(Mol::Request::REQUEST_CATEGORY::EVENT_ROUTER_SERVICE)->Connect(this, &EventRouterStateHandler::EventRouterServiceRequest);
		m_communicator.m_event.Subscribe<Mol::Event::InformationEvent>(Mol::Event::EVENT_CATEGORY::INFORMATION);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::INFORMATION)->Connect(this, &EventRouterStateHandler::ReciveInformationEvent);

        Platform::Notifier notifier;
        Platform::Notifier notifierSending;
        notifier.Connect(this,&EventRouterStateHandler::SubscriberTimeout);
        m_timer = Platform::Timer<>(MAX_TIMEOUT,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);

        notifierSending.Connect(this,&EventRouterStateHandler::SendBufferedEvents);
        m_unBufferingTimer = Platform::Timer<>(1,GlobalDataType::Timer::AlarmType::PERIODIC,notifierSending);

    }


    ~EventRouterStateHandler() = default;

    void AddFirstSubscriberStartWaiting(uint64_t senderID)
    {
        m_subscriberDSnums.emplace(senderID);
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: EVENT_ROUTER_SERVICE_CODE::ADD id[{:#x}]", senderID);
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: ForwardEvent() first subscriber is there lets wait 3s for the others");
        m_timer.Start();
        EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::ADDED, senderID);
    }

    void SendBufferedEvents()
    {
        if (!m_eventsQueue.empty())
        {
            auto event = m_eventsQueue.front();
            ForwardEvent(event, m_subscriberDSnums, m_communicator.m_event);
            m_eventsQueue.pop();
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: SendBufferedEvents() reading from queue size [{}] elements ", m_eventsQueue.size());
            //DebugSentEvent(event);
        }
    }

    void DoRouting(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
    {
        ForwardEvent(event, m_subscriberDSnums, m_communicator.m_event);
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: DoRouting() ");
        //DebugSentEvent(event);
    }

    void BufferEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
    {
        m_eventsQueue.push(event);
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: BufferEvent(), queuing[{}] elements ", m_eventsQueue.size());
    }

    bool isMaxBuffring()
    {
        return ((uint64_t)m_eventsQueue.size() >= MAX_EVENTS_QUEUE_SIZE);
    }

    bool isEmptyQueue()
    {
        return (m_eventsQueue.empty());
    }

    void StartSendingTimer()
    {
        m_unBufferingTimer.Start();
    }

    void CancelTimeoutTimer()
    {
        m_timer.Stop();
    }

    void SubscriberTimeout()
    {
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: SubscriberTimeout()");
        m_timer.Stop();
        m_updaterStateMachine.process_event(BufferingTimeout());
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler is now in state[{}]", state.c_str());});

    }

    void UpdateSubscriber(std::shared_ptr<Mol::Request::EventRouterService> request, uint64_t senderID)
    {
        if(request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD)
        {
            m_subscriberDSnums.emplace(senderID);
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: UpdateSubscriber(), adding id[{0:#x}], number of subs[{1:#x}]", senderID, m_subscriberDSnums.size());
            EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::ADDED, senderID);
        }
        else if (request->GetRequestCode() == Mol::Request::EVENT_ROUTER_SERVICE_CODE::REMOVE)
        {
            auto it = m_subscriberDSnums.find(senderID);
            if (it != m_subscriberDSnums.end())
            {
                m_subscriberDSnums.erase(it);
                EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::REMOVED, senderID);
            }
            else
            {
                EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED, senderID);
            }
        }
        else
        {
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: UpdateSubscriber(),DoNothing");
        }
    }

    void SendInvalideRequest(uint64_t senderID)
    {
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED id {}",senderID);
        EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED,senderID);
    }
protected:

    template<typename event, typename eventType>
    void MolEventSubscribe(eventType eventTypeId)
    {
        m_communicator.m_event.Subscribe<event>(eventTypeId);
        m_communicator.m_event.getService(eventTypeId)->Connect(this, &EventRouterStateHandler::ReceiveEvent);
    }

    void EventRouterServiceRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, const uint64_t senderID)
    {
        auto eventRouterServiceRequest = std::static_pointer_cast<Mol::Request::EventRouterService>(request);

        if( (Mol::DeviceUniqueID{m_panelId}.GetDomainID() != Mol::DeviceUniqueID{senderID}.GetDomainID() )
            ||
            (Mol::DeviceUniqueID{m_panelId}.GetNodeID() != Mol::DeviceUniqueID{senderID}.GetNodeID() )
          )
        {
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED id {}",senderID);
            EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE::NOT_SUPPORTED,senderID);
            return;
        }

        RouterRequest routerRequest =
            { .request = eventRouterServiceRequest, .senderID = senderID };
        m_updaterStateMachine.process_event(routerRequest);
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler is now in state[{}]", state.c_str());
                });

    }

    void EventRouterServiceReponse(Mol::Response::EVENT_ROUTER_SERVICE_CODE code, uint64_t senderID)
    {
        auto message = std::make_shared<Mol::Response::EventRouterService>(code);
        m_communicator.m_response.Send(message, PROC_ADDRESS::CMCAPP, senderID);
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: Send reponse to id {}",senderID);
    }


    /**
     * @brief  InformationEvent notification for site
     * @param event - event received
     * @param senderID - Unique id of the sender
     */
    void ReciveInformationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
    {
        if(event == nullptr)
        {
            DEBUGPRINT(DEBUG_ERROR,"FDA::InformationEvent:Received invalid event");
            return;
        }
        auto informationEvent = std::static_pointer_cast<Mol::Event::InformationEvent>(event);
		auto eventCode = informationEvent->GetEventCode();

        //USB connected and fw update events are local to panel, no need to send via network
		if( (eventCode == Mol::Event::INFORMATION_EVENT_CODE::USB_CONNECTED) ||
		    (eventCode == Mol::Event::INFORMATION_EVENT_CODE::USB_DISCONNECTED) ||
			(eventCode == Mol::Event::INFORMATION_EVENT_CODE::FIRMWARE_UPDATE_STATUS) ||
			(eventCode == Mol::Event::INFORMATION_EVENT_CODE::USB_MOUNT_FAILURE) ||
			(eventCode == Mol::Event::INFORMATION_EVENT_CODE::USB_MOUNT_SUCCESS) ||
			(eventCode == Mol::Event::INFORMATION_EVENT_CODE::INVALID_USB_CONNECTED) ||
			(eventCode == Mol::Event::INFORMATION_EVENT_CODE::MOUNT_USB) ||
			(eventCode == Mol::Event::INFORMATION_EVENT_CODE::UNMOUNT_USB) ||
            (eventCode == Mol::Event::INFORMATION_EVENT_CODE::CONFIG_UPDATE_STATUS) ||
            (eventCode == Mol::Event::INFORMATION_EVENT_CODE::CONFIGURATION_DATA_UPDATING) ||
            (eventCode == Mol::Event::INFORMATION_EVENT_CODE::CONFIGURATION_DATA_UPDATED) ||
            (eventCode == Mol::Event::INFORMATION_EVENT_CODE::APPLY_CONFIGURATION_STATUS) ||
            (eventCode == Mol::Event::INFORMATION_EVENT_CODE::CONFIG_UPDATE_COMPLETE_REBOOT_PANEL) ||
            (eventCode == Mol::Event::INFORMATION_EVENT_CODE::CONFIGURATION_UPDATE_STATUS))
		{
			return;
		}

        ReceiveEvent(event,senderID);
    }
	
    void ReceiveEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
    {
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: ReceiveEvent()");
        m_updaterStateMachine.process_event(event);
        m_updaterStateMachine.visit_current_states([](auto state){
            DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler is now in state[{}]", state.c_str());
                });
    }

    void DebugSentEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event)
    {
        auto concreetEvent = std::static_pointer_cast<Mol::Event::AlarmSignalEvent>(event);
        DEBUGPRINT(DEBUG_INFO, "EventRouterStateHandler: DebugSentEvent() event source id[{}]",concreetEvent->GetSource().GetObjectId());
    }

    uint64_t m_panelId;
    std::set<uint64_t> m_subscriberDSnums;
    std::queue<std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>>> m_eventsQueue;
    EventRouterStateMachine<EventRouterStateHandler> m_eventRouterStateMachine;
    boost::sml::sm<EventRouterStateMachine<EventRouterStateHandler>, boost::sml::process_queue<std::queue>> m_updaterStateMachine;
    Platform::Timer<> m_timer;
    Platform::Timer<> m_unBufferingTimer;
};

}
#endif //PLATFORM_MOL_EVENT_ROUTER_STATE_HANDLER_H
