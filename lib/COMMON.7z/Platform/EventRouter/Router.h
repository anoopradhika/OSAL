/*****************************************************************//**
 *
 * @file    router.h
 * @brief   route mol events
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_ROUTER_H
#define PLATFORM_ROUTER_H
 
// framework
#include "Mol/Events/Event.h"
#include "Mol/Events/EventTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"

#include <chrono>
#include <ctime>

namespace Platform {

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class MolDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i ) {
            // Intentionally unimplemented...
          }
};

template<typename CommunicatorType>
struct MessageForwader {
    MessageForwader(std::set<uint64_t>& ids, CommunicatorType& communicator):
                m_ids{ids}
               ,m_communicator{communicator}
    {}
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message)
    {
        for(auto id : m_ids)
        {
            m_communicator.Send(message, PROC_ADDRESS::CMCAPP, id);
        }
    }
    std::set<uint64_t>& m_ids;
    CommunicatorType& m_communicator;
};

using EventType = Mol::Event::EVENT_CATEGORY;
using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;


auto ForwardEvent = [](auto event, std::set<uint64_t>& ids,EventCommunicator& communicator)
{
    using EventCaster = Platform::CastAndCall< MolDowncastAdapter,  Mol::Message<EventType>, EventObjectTypes >;
    EventCaster::Do<Mol::Event::EventDefault>(event,MessageForwader<EventCommunicator>{ids,communicator});
};

} // end namespace

#endif //PLTFORM_ROUTER_H
