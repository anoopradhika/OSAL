/*****************************************************************//**
 *
 * @file    Semaphore.hpp
 * @brief   Semaphore abstraction class
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef PLATFORM_SEMAPHORE_INCLUDE_H
#define PLATFORM_SEMAPHORE_INCLUDE_H

#include "Semaphore/Semaphore.h"
#include "Config/Config.h"

namespace Platform
{
/**
 * @brief Semaphore class
 *
 * Provides wrapper class for using Semaphore functionality.
 */
template<typename NativeSemaphoreType = PlatformNative::Semaphore>
class Semaphore
{
public:
    /** Default constructor */
    Semaphore() = default;

    /** Default destructor */
    virtual ~Semaphore() = default;

    /**
        Create counting semaphore
    */
    bool Create(maxCount, initialCount)
    {
        m_nativeSemaphore.Create(maxCount, initialCount);
    }

    /**
        Waits until the current thread got the semaphore
    */
    bool Lock(count)
    {
        m_nativeSemaphore.Lock(count);
    }

    /**
        Releases the lock on the Semaphore. Gives the semaphore
    */
    void Unlock()
    {
        m_nativeSemaphore.Unlock();
    }

    /**
        Releases the lock on the Semaphore.
    */
    void Shutdown()
    {
        m_nativeSemaphore.Shutdown();
    }
private:
    NativeSemaphoreType m_nativeSemaphore;
};

} // Platform

#endif /* PLATFORM_SEMAPHORE_INCLUDE_H */
