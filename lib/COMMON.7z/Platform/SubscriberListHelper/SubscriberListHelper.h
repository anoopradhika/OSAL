
/******************************************************************************//**
*
* @file    SubscriberListHelper.h
* @brief   Global Indicator status data types
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, re engineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_SUBSCRIBER_LIST_HELPER_H
#define PLATFORM_SUBSCRIBER_LIST_HELPER_H

#include "CommonDef.h"
#include "Mol/Helper/SubscriberList.h"

class SubscriberListHelper
{
public:

     PROC_ADDRESS GetAddress(const Mol::SubscriberList subscriber)
    {
        PROC_ADDRESS address = PROC_ADDRESS::UNINITIALIZED;

        switch(subscriber)
        {
        case Mol::SubscriberList::CMCAPP:
            address = PROC_ADDRESS::CMCAPP;
            break;
        case Mol::SubscriberList::IOMGR:
            address = PROC_ADDRESS::IOMGR;
            break;
        case Mol::SubscriberList::NETWORK:
            address = PROC_ADDRESS::NETWORK;
            break;
        case Mol::SubscriberList::FDA:
            address = PROC_ADDRESS::FIRE_DOMAIN_APP;
            break;
        case Mol::SubscriberList::EVENTLOG:
            address = PROC_ADDRESS::EVENTLOGAPP;
            break;
        case Mol::SubscriberList::EVENT_PROVIDER:
            address = PROC_ADDRESS::EVENT_PROVIDERAPP;
            break;
        case Mol::SubscriberList::LICENSEVALIDATOR:
            address = PROC_ADDRESS::LICENSEVALIDATOR;
            break;
       case Mol::SubscriberList::AUDITLOG_APP:
            address =PROC_ADDRESS::AUDITLOG_APP;
            break;
       case Mol::SubscriberList::ENGLOG_APP:
            address =PROC_ADDRESS::ENGLOG_APP;
            break;
       case Mol::SubscriberList::ACTIVE_EVENTSAPP:
            address =PROC_ADDRESS::ACTIVE_EVENTSAPP;
            break;
	   case Mol::SubscriberList::CLSSMGR:
            address = PROC_ADDRESS::CLSSMGR;
			break;
        default:
            break;
        }
        return address;
    }
};

#endif //PLATFORM_SUBSCRIBER_LIST_HELPER_H
