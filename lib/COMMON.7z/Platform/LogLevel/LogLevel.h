
/*****************************************************************//**
 *
 * @file    LogLevel.h
 * @brief   LogLevel class used for changing log level at runtime
 *
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#ifndef PLATFORM_LOG_LEVEL_INCLUDE_H
#define PLATFORM_LOG_LEVEL_INCLUDE_H


#include "Component/Component.h"
#include "Mol/Commands/SetDebugLevel.h"
#include "DebugPrint/DEBUGPRINT.hpp"

namespace Platform
{

/**
 * @brief  Changes application debug log level
*/
class LogLevel : public Platform::Component
{
public:

    LogLevel() = default;

    ~LogLevel() = default;

    void Prepare() final
    {
        m_communicator.m_command.Subscribe<Mol::Command::SetDebugLevel>(Mol::Command::COMMAND_CATEGORY::SET_DEBUG_LEVEL);
        m_communicator.m_command.getService(Mol::Command::COMMAND_CATEGORY::SET_DEBUG_LEVEL)->Connect(this, &LogLevel::DebugNotification);

        Platform::Component::Prepare();
    }

protected:

    /**
    * @brief SetDebugLevel command notification
    * @param command command
    * @param senderID command sender ID
    */
    void DebugNotification(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, const uint64_t senderID)
    {
        if(command == nullptr)
        {
            return;
        }

        auto setDebug = std::static_pointer_cast<Mol::Command::SetDebugLevel>(command);
        auto code = setDebug->GetCommandCode();

        auto logLevel = DebugLevel::DEBUG_ERROR;

        switch(code)
        {

        case Mol::Command::DEBUG_LEVEL_CODE::DEBUG_ALL :
            logLevel = DebugLevel::DEBUG_ALL;
            break;

        case Mol::Command::DEBUG_LEVEL_CODE::DEBUG_INFO :
            logLevel = DebugLevel::DEBUG_INFO;
            break;

        case Mol::Command::DEBUG_LEVEL_CODE::DEBUG_WARNING :
            logLevel = DebugLevel::DEBUG_WARNING;
            break;

        case Mol::Command::DEBUG_LEVEL_CODE::DEBUG_ERROR :
            logLevel = DebugLevel::DEBUG_ERROR;
            break;

        case Mol::Command::DEBUG_LEVEL_CODE::DEBUG_FATAL :
            logLevel = DebugLevel::DEBUG_FATAL;
            break;

        default :
            break;
        }
        DEBUGPRINT::SetDebugLevel(logLevel);
        DEBUGPRINT(logLevel, "LogLevel changed to [%d]", static_cast<int>(logLevel));
    }
};
}
#endif // PLATFORM_LOG_LEVEL_INCLUDE_H
