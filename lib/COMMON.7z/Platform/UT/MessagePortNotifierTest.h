#ifndef MESSAGE_PORT_NOTIFIER_TEST_INCLUDE_H
#define MESSAGE_PORT_NOTIFIER_TEST_INCLUDE_H
#include "gmock/gmock.h"
#include "MessagePort/MessagePort.h"
#include "Message/Message.h"

/**
    Test class to publish message
*/
class MessagePortPublisherTest: public:: testing::Test
{
    public:
        /** Publisher Test ID */
        static const Platform::MessagePortID publisherId;

        /** Test buffer size */
        static constexpr uint32_t DATA_SIZE_BYTE = 512;

        /** Test data ID */
        static const uint32_t DATA_ID;

        /** Data used for testing */
        static const std::string TEST_DATA;
        
        /** Get MessagePort */
        MessagePortPublisherTest();

        /** Default destructor */
        ~MessagePortPublisherTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();
        
        /** Prepare message Port to send */
        void PrepareToSendMessage();
        
        /** Prepare message port to receive */
        void PrepareToReceiveMessage();

        /** MessagePort for testing */
        Platform::MessagePort& m_MessagePort;

        /** Test message */
        Platform::TestMessage m_message;

        /** Connection point get on successful subscription */
        int32_t m_EndPoint;
};


/**
    Test class to subscribe message
*/
class MessagePortSubscriberTest: public:: testing::Test
{
    public:
        /** Publisher Test ID */
        static const Platform::MessagePortID publisherId;

         /** Test buffer size */
        static constexpr uint32_t DATA_SIZE_BYTE = 512;

        /** Test data ID */
        static const uint32_t DATA_ID;

        /** Data used for testing */
        static const std::string TEST_DATA;

        /** Get MessagePort */
        MessagePortSubscriberTest();

        /** Default destructor */
        ~MessagePortSubscriberTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();
        
        /** Prepare message Port communication */
        void PrepareMessagePort();
        
        /** Prepare message port to receive */
        void PrepareToReceiveMessage();

        /**
            Notification callback on message reception
            @param receivedMessage: Message provided  from MessagePort
        */
        void ReceiveMessage(Platform::Message* receivedMessage);

        /** MessagePort for testing */
        Platform::MessagePort& m_MessagePort;

        /** Connection point get on successful subscription */
        int32_t m_EndPoint;

        /** Expected Test message */
        Platform::TestMessage m_message;

        /** True on message received*/
        bool messageReceived;
};
#endif //MESSAGE_PORT_NOTIFIER_TEST_INCLUDE_H
