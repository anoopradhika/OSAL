#include "ActiveEventReqRep.h"

TEST_F(ActiveEventReqRep, Send)
{
        WaitForResult(50000000);
}
