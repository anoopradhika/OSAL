/******************************************************************************//**
* @file ModuleTest.h
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#include "Watchdog/Watchdog.h"
#include "Application/Application.h"
#include "PanelMonitor/PanelMonitor.h"
#include "ModuleMonitor/ModuleMonitor.h"
#include "CCLMessageBroker/CCLMessageBroker.h"

namespace
{
    uint64_t moduleSourceID = 0x0100020300000000;
}

class ModuleTest : Platform::Application
{

public:

    ModuleTest(const std::string& ipAddress, PROC_ADDRESS source, PROC_ADDRESS broker):
                                                                Application(source,moduleSourceID),
                                                                m_source(source),m_broker(broker)
    {
        auto module = std::make_shared<Dol::Entities::Module>(ipAddress, moduleSourceID);
        m_PanelMonitor =  std::make_shared<ModuleRegistration::PanelMonitor>(module,m_source,m_broker,5000);
        AddComponent(m_PanelMonitor);
        m_cclBroker =  std::make_shared<Platform::CCLMessageBroker>(ipAddress, moduleSourceID, "ModuleTest1",
                8000, 8000, 9000, CommunicationType::interModuleCommunication);
        AddComponent(m_cclBroker);
    }
    virtual ~ModuleTest() = default;

    virtual void Init() override
    {
        std::cout<<"ModuleTest:: Init\n";
        Platform::Application::Init();
    }
    virtual void Prepare() override
    {
        Platform::Application::Prepare();
        m_communicator.m_messageTransporter.NeedBrokerSupport(m_broker);
        m_communicator.m_messageTransporter.Connect(m_source);
        m_communicator.m_messageTransporter.Connect(m_broker);
    }
    virtual void Start() override
    {
       Platform::Application::Start();
    }
    virtual void Stop() override
    {
       Platform::Application::Stop();
    }
    virtual void Shutdown() override
    {
       Platform::Application::Shutdown();
    }
    virtual void Uninit() override
    {
       Platform::Application::Uninit();
    }

protected:
    std::shared_ptr<Platform::Watchdog> m_watchdog;
    std::shared_ptr<ModuleRegistration::PanelMonitor> m_PanelMonitor;
    std::shared_ptr<Platform::CCLMessageBroker> m_cclBroker;
    PROC_ADDRESS m_source;
    PROC_ADDRESS m_broker;
};
