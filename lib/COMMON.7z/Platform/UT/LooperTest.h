/******************************************************************************//**
* @file LooperTest.h
* @brief Test case for looper component.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_TEST_LOOPER_H
#define PLATFORM_TEST_LOOPER_H

#include "ACT/ACT.hpp"
#include "Watchdog/Watchdog.h"
#include "Timer/Timer.hpp"
#include"Component/Component.h"
#include "Mol/Monitoring/HeartBeat.h"

#include <chrono>
#include <ctime>

namespace platformTest
{

class TestComponent :public Platform::Component
{
public:
    TestComponent(PROC_ADDRESS brokerID)
    {
        m_brokerID = brokerID;
    }
    void Init() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this,&TestComponent::testNotification);
        m_timer = Platform::Timer<>{(uint64_t)1000,GlobalDataType::Timer::AlarmType::PERIODIC,notifier};
        Platform::Component::Init();
    }

    void Start() override
    {
        std::cout<<"TestComponent start"<<std::endl;
        m_communicator.m_monitoring.Subscribe<Mol::Monitoring::HeartBeat>(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT);
        m_communicator.m_monitoring.getService(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT)->Connect(this, &TestComponent::ReceiveHeartBeat);
        m_timer.Start();
        Platform::Component::Start();
    }
    void testNotification()
    {
        auto now = std::chrono::system_clock::now();
        auto duration = now.time_since_epoch();
        auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
        std::cout<<" is received millis ==> "<<millis<<std::endl;
        if(count>10)
        {
            std::cout<<"Stop timer"<<std::endl;
            m_timer.Stop();
        }
        auto heartBeat = std::make_shared<Mol::Monitoring::HeartBeat>(Mol::Monitoring::HEARTBEAT_CODE::MODULE);
        m_communicator.m_monitoring.Send(heartBeat, m_brokerID, 0);
        count++;
    }
    void ReceiveHeartBeat(std::shared_ptr<Mol::Message<Mol::Monitoring::MONITORING_CATEGORY>> message, uint64_t senderID)
    {
        std::cout<<"Heart beat received" <<std::endl;
    }
protected:
    Platform::Timer<> m_timer;
    uint32_t count = 0;
    PROC_ADDRESS m_brokerID;
};
/**
    MessagePortTest class to test MessagePort functionality
*/
class LooperTest: public platform::ACT
{
    public:

        /** Get MessagePort */
        LooperTest()
        {
            AddComponent(std::make_shared<Platform::Watchdog>(m_componentManager));
            AddComponent(std::make_shared<TestComponent>(m_address));
        }
        /** Default destructor */
        virtual ~LooperTest() = default;

        /** Add test Setup here */
        virtual void SetUp()
        {
            Init();
            Prepare();
        }

        /** Add test cleanup here */
        virtual void TearDown()
        {
            Stop();
            Shutdown();
            Uninit();
        }

        void Prepare() override
        {
            m_communicator.m_messageTransporter.Connect(m_address);
            platform::ACT::Prepare();
        }
};

} //end of platformTest

#endif //PLATFORM_TEST_LOOPER_H
