#include "ApplicationConfigurationTest.h"
namespace platformTest
{

/**
* Read configuation from JSON file and validate it.
*/
TEST_F(ApplicationConfigurationTest, PanelID)
{
    const uint32_t waitTimeMs = 3000;
    WaitForResult(waitTimeMs);
}

}
