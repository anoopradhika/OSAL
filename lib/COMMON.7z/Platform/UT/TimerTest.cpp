#include"TimerTest.h"
#include "CommonDef.h"
namespace platformTest{

int32_t debugLevel = DEBUG_INFO;

Timer::Timer()
{
    m_timer.Stop();
}



void Timer::SetUp()
{
    Platform::Notifier notifier;
    m_data =225;
    notifier.Connect(this,&platformTest::Timer::testNotification);
    m_timer = Platform::Timer<>((uint64_t)1000,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);
}


void Timer::TearDown()
{
  m_timer.Shutdown();
}


void Timer::testNotification()
{
    std::cout<<" is received"<<std::endl;
}

/**

*/
TEST_F(Timer, StartAndStop)
{
    m_timer.Start();
    sleep(10);
}

}