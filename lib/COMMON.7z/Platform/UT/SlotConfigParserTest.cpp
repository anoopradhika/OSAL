/******************************************************************************//**
* @file SlotConfigParserTest.cpp
* @brief Test case for Slot config Parser
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <iostream>
#include "gmock/gmock.h"
#include "SlotConfigParser/SlotConfigParser.h"
#include "gtest/gtest.h"
#include "DOL/Entities/Module.h"

/**
* @brief   SlotConfigParserTest class for testing Xml parsing
*/
class SlotConfigParserTest : public:: testing::Test
{
    public:
        std::map<uint64_t, std::shared_ptr<Dol::Entities::Module>> m_moduleConfigMap;
        const uint64_t m_sourceID  = 0;
        const char* m_systemConfigFileName   = "../../../UTSUPPORTFILES/systemconfig_ut.xml";
        const char* m_systemInvalidFileName1 = "../../../UTSUPPORTFILES/invalidconfig_ut1.xml";
        const char* m_systemInvalidFileName2 = "../../../UTSUPPORTFILES/invalidconfig_ut2.xml";
        const char* m_systemInvalidFileName3 = "../../../UTSUPPORTFILES/invalidconfig_ut3.xml";
        const char* m_systemInvalidFileName4 = "../../../UTSUPPORTFILES/invalidconfig_ut4.xml";
        const char* m_systemInvalidFileName5 = "../../../UTSUPPORTFILES/invalidconfig_ut5.xml";
        const char* m_systemCorruptFile      = "../../../UTSUPPORTFILES/corruptconfig_ut.xml";
        const char* m_systemDummyFileName    = "config.xml";
};

/**
* @brief   Read Invalid file test
*/
TEST_F(SlotConfigParserTest, ReadDummyFileTest)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemDummyFileName), SUCCESS);
}

/**
* @brief   Read Corrupt file test
*/
TEST_F(SlotConfigParserTest, ReadCorruptFileTest)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemCorruptFile), SUCCESS);
}


/**
* @brief   Read Invalid file test 1 with some tags missing
*/
TEST_F(SlotConfigParserTest, ReadInvalidFileTest1)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemInvalidFileName1), SUCCESS);
}

/**
* @brief   Read Invalid file test 2 with some tags missing
*/
TEST_F(SlotConfigParserTest, ReadInvalidFileTest2)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemInvalidFileName2), SUCCESS);
}

/**
* @brief   Read Invalid file test 3 with some tags missing
*/
TEST_F(SlotConfigParserTest, ReadInvalidFileTest3)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemInvalidFileName3), SUCCESS);
}

/**
* @brief   Read Invalid file test 4 with some tags missing
*/
TEST_F(SlotConfigParserTest, ReadInvalidFileTest4)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemInvalidFileName4), SUCCESS);
}

/**
* @brief   Read Invalid file test 5 with some tags missing
*/
TEST_F(SlotConfigParserTest, ReadInvalidFileTest5)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_NE(configParser.LoadFile(m_systemInvalidFileName5), SUCCESS);
}

/**
* @brief   Read Valid file test all tags available
*/
TEST_F(SlotConfigParserTest, ReadValidFileTest)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_EQ(configParser.LoadFile(m_systemConfigFileName), SUCCESS);
}

/**
* @brief   Read Valid file test and check the values of all the tags
*/
TEST_F(SlotConfigParserTest, VerifyValuesTest)
{
    SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
    EXPECT_EQ(configParser.LoadFile(m_systemConfigFileName), SUCCESS);

    std::map<uint64_t, Dol::Entities::Module::MODULE_TYPE> configMap = {
        {72058697844523008, Dol::Entities::Module::MODULE_TYPE::CHARGER},
        {72058702139490304, Dol::Entities::Module::MODULE_TYPE::NOTIFIER_EMEA_FIELDBUS_LOOP},
        {72058706434457600, Dol::Entities::Module::MODULE_TYPE::SERIAL_COMMS},
        {72058710729424896, Dol::Entities::Module::MODULE_TYPE::FAT_FBF},
        {72058715024392192, Dol::Entities::Module::MODULE_TYPE::IO},
        {72058719319359488, Dol::Entities::Module::MODULE_TYPE::MAINCPU},
        {72058723614326784, Dol::Entities::Module::MODULE_TYPE::FARE_FRE},
        {72058727909294080, Dol::Entities::Module::MODULE_TYPE::IDNET_NETWORK_GATEWAY},
    };

    // Verify the module values in the map
    for (auto itr = configMap.begin(); itr != configMap.end(); ++itr) {
        auto mapItr = m_moduleConfigMap.find(itr->first);
        if (mapItr != m_moduleConfigMap.end()) {
            EXPECT_EQ(mapItr->second->GetType() , itr->second);
        } else {
            // Error value not found
        }
    }
}
