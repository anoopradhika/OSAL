#include "WatchdogTest.h"
namespace platformTest
{

TEST_F(WatchdogTest, Watchdog)
{
    const uint32_t waitTimeMs = 5000;
    WaitForResult(waitTimeMs);
}

}
