/**
 * @file   DolCommunicatorTest.h
 * @Author Anoop Chandran (anoop.chandran@honeywell.com)
 * @brief  Test for Dol Communicator
 *
 */
 
#ifndef COMMUNICATOR_TEST_INCLUDE_H
#define COMMUNICATOR_TEST_INCLUDE_H

#include "gmock/gmock.h"

#include "ObjectModelCommunicator/ObjectModelCommunicator.h"
#include "DOL/Network/HeartBeat.h"
#include "DOL/Network/RegistrationConfirmation.h"
#include "DOL/Network/LogicalAddress.h"
#include "MessageTransporter/MessageTransporter.h"

class DolCommunicatorTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        DolCommunicatorTest();

        /** A default constructor */
        virtual ~DolCommunicatorTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare HeartBeat class with test data */
        void PrepareDolCommuncator();

        /**
            Unsubscribe HeartBeat
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        /**
            HeartBeat used for serialization and  deserialization.
            It is used as a DomainObject to send and receive in the test
        */
        std::shared_ptr<Dol::Network::HeartBeat> m_HeartBeat;
        Dol::Network::LogicalAddress networkAddress;
        std::shared_ptr<Dol::Network::RegistrationConfirmation> m_RegistrationConfirmation;
        std::shared_ptr<Dol::Network::LogicalAddress> rcNetworkAddress ;
        /**
            MessagePort for Communicator test
        */
        Platform::MessageTransporter& m_messageTransporter;

        /**
            Class under test
        */
        Platform::ObjectModelCommunicator<Platform::MessageTransporter,Dol::DOMAIN_OBJECT_TYPE,Dol::DomainObject>& m_Communicator;

        /** Test data */
        static const PROC_ADDRESS publisherId;
        static const PROC_ADDRESS Broker;
        void receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase,uint64_t destinationID = 0);
        void BrokerRegistrationConfirmation(std::shared_ptr<Dol::DomainObject> domainObjectBase, uint64_t destinationID = 0);
        void PublisherHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase,uint64_t destinationID = 0);
        
        bool messageReceived = false;
    private:
     uint32_t receivedCount;   
     uint32_t BrokerreceivedCount;   
};

class DolCommunicatorSubscribeTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        DolCommunicatorSubscribeTest();

        /** A default constructor */
        virtual ~DolCommunicatorSubscribeTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare HeartBeat class with test data */
        void PrepareDolCommuncator();

        /**
            Unsubscribe HeartBeat
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        /**
            HeartBeat used for serialization and  deserialization.
            It is used as a DomainObject to send and receive in the test
        */
        std::shared_ptr<Dol::Network::HeartBeat> m_HeartBeat;
        Dol::Network::LogicalAddress networkAddress;

        /**
            MessagePort for Communicator test
        */
        Platform::MessageTransporter& m_messageTransporter;

        /**
            Class under test
        */
        Platform::ObjectModelCommunicator<Platform::MessageTransporter,Dol::DOMAIN_OBJECT_TYPE,Dol::DomainObject>& m_Communicator;
        /** Test data */
        static const PROC_ADDRESS publisherId;
        void receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase, uint64_t destinationID = 0);
        
        bool messageReceived = false;
    private:
 uint32_t receivedCount;   
};

#endif //COMMUNICATOR_TEST_INCLUDE_H