
/*****************************************************************//**
 *
 * @file    DEBUGPRINTTest.cpp
 * @brief   DEBUGPRINT test class to test DEBUGPRINT
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#include "DebugPrint/DEBUGPRINT.hpp"
#include "gmock/gmock.h"
#include <sstream>

TEST(DEBUGPRINTTest, format)
{
    using DEBUGPRINT = Platform::DEBUGPRINT;
    EXPECT_EQ("42", DEBUGPRINT::format("{0}", 42));
    EXPECT_EQ("before 42", DEBUGPRINT::format("before {0}", 42));
    EXPECT_EQ("abracadabra", DEBUGPRINT::format("{0}{1}{0}", "abra", "cad"));
    EXPECT_EQ("42 after", DEBUGPRINT::format("{0} after", 42));
    EXPECT_EQ("before 42 after", DEBUGPRINT::format("before {0} after", 42));
    EXPECT_EQ("answer = 42", DEBUGPRINT::format("{0} = {1}", "answer", 42));
    EXPECT_EQ("42 is the answer", DEBUGPRINT::format("{1} is the {0}", "answer", 42));
    EXPECT_EQ("42 is the answer", DEBUGPRINT::format("{1} is the {0}", "answer", 42));
    EXPECT_EQ("std::string", DEBUGPRINT::format(std::string{"std::string"}));
    EXPECT_NE("std::string", DEBUGPRINT::format("%s", "std::string"));
}

TEST(DEBUGPRINTTest, stdoutWithNormalPrint)
{
    using DEBUGPRINT = Platform::DEBUGPRINT;

    DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
    DEBUGPRINT::SetOutStream(OutStream::STDOUT);
    uint64_t testValue = 0x1010101010101010;
    DEBUGPRINT(DEBUG_ALL,"%d", testValue);
    DEBUGPRINT(DEBUG_ALL,"%s","blabla");
}


TEST(DEBUGPRINTTest, stdoutWithCPPFormat)
{
    std::stringstream outBuffer;
    auto old =  std::cout.rdbuf(outBuffer.rdbuf());
    using DEBUGPRINT = Platform::DEBUGPRINT;
    char charArray[11]{};
    char charArray1[] = "HelloWorld";
    std::string stringVal = "HelloWorld";
    strcpy(charArray,"hhhhhhlk");
    DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
    DEBUGPRINT::SetOutStream(OutStream::STDOUT);
    uint64_t testValue = 0x1010101010101010;
    DEBUGPRINT(DEBUG_ALL,"{}", testValue);
    std::cout.rdbuf(old);
    std::string text = outBuffer.str();
    EXPECT_NE(text.find(DEBUGPRINT::format("{0}", testValue)), std::string::npos);
    DEBUGPRINT(DEBUG_ALL,"value [{0}]", charArray);
    DEBUGPRINT(DEBUG_ALL,"value [{0}]", charArray1);
    DEBUGPRINT(DEBUG_ALL,"value [{0}]", stringVal);
}



TEST(DEBUGPRINTTest, withoutFormat)
{
    std::stringstream outBuffer;
    auto old = std::cout.rdbuf(outBuffer.rdbuf());
    using DEBUGPRINT = Platform::DEBUGPRINT;

    DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
    DEBUGPRINT::SetOutStream(OutStream::STDOUT);
    DEBUGPRINT(DEBUG_ALL,"blabla");
    std::cout.rdbuf(old);
    std::string text = outBuffer.str();
    EXPECT_EQ(text.find(DEBUGPRINT::format("blabla")), std::string::npos);
}
