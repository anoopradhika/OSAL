/**
 * @file   CCLMessageBrokerTest.h
 * @brief  Test for CCLMessageBroker
 *
 */
 
#ifndef CCL_MESSAGE_BROKER_TEST_INCLUDE_H
#define CCL_MESSAGE_BROKER_TEST_INCLUDE_H

#include "gmock/gmock.h"
#include "CommonDef.h"
#include "Application/Application.h"
#include "CCLMessageBroker/CCLMessageBroker.h"

int debugLevel      =       CURRENT_DEBUG_LEVEL;


namespace CCLMessageBrokerUT
{

namespace
{
static const uint16_t CMC_SELF_PORT = 8001;
static const uint16_t CMC_PEER_PORT = 8000;
static const uint16_t MAINLOOP_SELF_PORT = 8000;
static const uint16_t MAINLOOP_PEER_PORT = 8001;
}

class CCLMessageBrokerTest : public Platform::Application
{
public:
	CCLMessageBrokerTest(PROC_ADDRESS procAddress) : Application(procAddress)
	{
		m_addr = procAddress;
		std::cout<<"CCLMessageBrokerTest cons\n";
		if(m_addr == PROC_ADDRESS::CMCAPP)
		{
			m_msgBroker =  std::make_shared<Platform::CCLMessageBroker>("cmc.out", CMC_SELF_PORT, CMC_PEER_PORT, 0, CommunicationType::interModuleCommunication);
			std::cout <<"Adding CMCAPP m_msgBroker";
			AddComponent(m_msgBroker);
		}
		else if (m_addr == PROC_ADDRESS::MAINLOOP)
		{
			m_msgBroker =  std::make_shared<Platform::CCLMessageBroker>("mainloop.out", MAINLOOP_SELF_PORT, MAINLOOP_PEER_PORT, 0, CommunicationType::interModuleCommunication);
			std::cout <<"Adding mainoop m_msgBroker";
			AddComponent(m_msgBroker);
		}
	}

	virtual void Init()
	{
		std::cout<<"CCLMessageBrokerTest Init\n";
		Platform::Application::Init();
	}

	virtual void Prepare()
	{
		std::cout<<"CCLMessageBrokerTest Prepare\n";
	    Platform::Application::Prepare();
	    m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MAINLOOP);
	    m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CMCAPP);
	}

	virtual void Start()
	{
		std::cout<<"CCLMessageBrokerTest Start\n";
	    Platform::Application::Start();
	}

	virtual void Stop()
	{
		std::cout<<"CCLMessageBrokerTest Stop\n";
	    Platform::Application::Stop();
	}

	virtual void Shutdown()
	{
		std::cout<<"CCLMessageBrokerTest Shutdown\n";
	    Platform::Application::Shutdown();
	}

	virtual void Uninit()
	{
		std::cout<<"CCLMessageBrokerTest Uninit\n";
	    Platform::Application::Uninit();
	}
    std::shared_ptr<Platform::CCLMessageBroker> m_msgBroker = nullptr;
    PROC_ADDRESS m_addr;
};


class MessageBrokerTest : public ::testing::Test
{

protected:
	void SetUp()
	{

	}
	void TearDown()
	{

	}
};


/**
 * @brief	Test
 */
TEST_F(MessageBrokerTest, MainloopApp)
{
	std::cout<<"MessageBrokerTest MainloopApp test\n";
    CCLMessageBrokerTest m_obj{PROC_ADDRESS::MAINLOOP};
    m_obj.Init();
    m_obj.Prepare();
    m_obj.Start();
    m_obj.Stop();
    m_obj.Shutdown();
    m_obj.Uninit();
}

TEST_F(MessageBrokerTest, CMCApp)
{
	std::cout<<"MessageBrokerTest CMCApp test\n";
    CCLMessageBrokerTest m_obj{PROC_ADDRESS::CMCAPP};
    m_obj.Init();
    m_obj.Prepare();
    m_obj.Start();
    m_obj.Stop();
    m_obj.Shutdown();
    m_obj.Uninit();
}
}

#endif //CCL_MESSAGE_BROKER_TEST_INCLUDE_H
