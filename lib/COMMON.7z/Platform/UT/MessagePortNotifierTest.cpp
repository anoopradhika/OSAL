#include"MessagePortNotifierTest.h"


const Platform::MessagePortID MessagePortPublisherTest::publisherId = Platform::MessagePortID::TEST_ID_ONE;

const std::string MessagePortPublisherTest::TEST_DATA = "Message Port Test Data from test one";

const std::string MessagePortSubscriberTest::TEST_DATA = "Message Port Test Data from test one";

const Platform::MessagePortID MessagePortSubscriberTest::publisherId = Platform::MessagePortID::TEST_ID_TWO;

MessagePortPublisherTest::MessagePortPublisherTest():m_MessagePort(Platform::MessagePort::getMessagePort())
{
    
}
void MessagePortPublisherTest::PrepareToSendMessage()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_message.m_messageType = Platform::Message::TEST_ID;
    m_message.m_size = TEST_DATA.length();
    memset(m_message.m_data,0,sizeof(m_message.m_data));
    TEST_DATA.copy((char*)m_message.m_data,TEST_DATA.length(),0);
}


void MessagePortPublisherTest::PrepareToReceiveMessage()
{
    m_EndPoint = m_MessagePort.Connect(publisherId);
}


void MessagePortPublisherTest::SetUp()
{
    PrepareToSendMessage();
    PrepareToReceiveMessage();
}


void MessagePortPublisherTest::TearDown()
{
    m_MessagePort.Disconnect(publisherId,m_EndPoint);
    m_MessagePort.Shutdown();
}

/**
    Testcase to publish message
*/
TEST_F(MessagePortPublisherTest, PublishMessage)
{
    m_MessagePort.Send(m_message,sizeof(Platform::TestMessage));
    sleep(2);
}


MessagePortSubscriberTest::MessagePortSubscriberTest():m_MessagePort(Platform::MessagePort::getMessagePort())
{
    
}

void MessagePortSubscriberTest::ReceiveMessage(Platform::Message* receivedMessage)
{
    
   EXPECT_EQ(m_message.m_size,((Platform::TestMessage*)receivedMessage)->m_size);
   EXPECT_STREQ(m_message.m_data,((Platform::TestMessage*)receivedMessage)->m_data);
   EXPECT_EQ(m_message.m_messageType,((Platform::TestMessage*)receivedMessage)->m_messageType);
   messageReceived = true;
}

void MessagePortSubscriberTest::PrepareMessagePort()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_MessagePort.notifier.Connect(this, &MessagePortSubscriberTest::ReceiveMessage);
    m_MessagePort.Start();
}


void MessagePortSubscriberTest::PrepareToReceiveMessage()
{
    m_EndPoint = m_MessagePort.Connect(MessagePortPublisherTest::publisherId);
    m_message.m_messageType = Platform::Message::TEST_ID;
    m_message.m_size = TEST_DATA.length();
    memset(m_message.m_data,0,sizeof(m_message.m_data));
    TEST_DATA.copy((char*)m_message.m_data,TEST_DATA.length(),0);
}


void MessagePortSubscriberTest::SetUp()
{
    messageReceived = false;
    PrepareMessagePort();
    PrepareToReceiveMessage();
}


void MessagePortSubscriberTest::TearDown()
{
    m_MessagePort.Disconnect(MessagePortPublisherTest::publisherId,m_EndPoint);
    m_MessagePort.Stop();
    m_MessagePort.Shutdown();
}

/**
    Testcase to receive message based on message notification.
    Message is send from test MessagePortPublisherTest.PublishMessage
*/
TEST_F(MessagePortSubscriberTest, SubscriberMessage)
{
    while(false == messageReceived)
    {
        sleep(2);
    }
}
