/******************************************************************************//**
* @file RemoteSubscriberChannelUT.h
* @brief Test case verify RemoteSubscriberChannel Class.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_TEST_REMOTE_SUBSCRIBER_H
#define PLATFORM_TEST_REMOTE_SUBSCRIBER_H

#include "EventProvider/RemoteSubscriberChannel.h"
#include "GlobalDataType/Error.h"

class RemoteSubscriberChannelUT : public Platform::RemoteSubscriberChannel
{
public:
    RemoteSubscriberChannelUT(Mol::DataType::ObjectReference& channelID, std::shared_ptr<Platform::Communicator> communicator):
        RemoteSubscriberChannel(channelID, communicator)
    {

    }
    ~RemoteSubscriberChannelUT() = default;

    void ServiceRequestNullRequst()
    {
        ServiceRequest(nullptr);
    }

    void ServiceRequestInvalidchannelID(const Mol::DataType::ObjectReference& channelID)
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST);
        req->SetSourceTarget(channelID);
        ServiceRequest(req);
    }

    void ServiceRequestValidchannelID(const Mol::DataType::ObjectReference& channelID)
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST);
        req->SetSourceTarget(channelID);
        ServiceRequest(req);
    }

    bool ServiceRequestStartCommTest(const Mol::DataType::ObjectReference& channelID)
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::START_COMMUNICATION);
        req->SetSourceTarget(channelID);
        ServiceRequest(req);
        return (!m_requestInProgress &&
                !m_newEventAvailebel &&
                m_eventsQueue.empty() &&
                m_currentCommunicationStep == COMMUNICATION_STEP::ACTIVE_EVENT_LIST);
    }

    void ServiceRequestGetEventAndCommNotStartedTest(const Mol::DataType::ObjectReference& channelID )
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT);
        req->SetSourceTarget(channelID);
        m_currentCommunicationStep = COMMUNICATION_STEP::START_COMMUNICATION;
        ServiceRequest(req);
    }

    void ServiceRequestGetEventActiveEvent(const Mol::DataType::ObjectReference& channelID )
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT);
        req->SetSourceTarget(channelID);
        m_currentCommunicationStep = COMMUNICATION_STEP::ACTIVE_EVENT_LIST;
        ServiceRequest(req);
    }

    void ActiveEventGetEventTestNullMessage()
    {
        ActiveEventGetEventValidateParameters(nullptr);
    }

    void ActiveEventGetEventTestNotValideRequest()
    {
        auto resp = std::make_shared<Mol::Response::ActiveEventResponse>(Mol::ActiveEventQueryType::END_OF_LIST, Mol::Response::ActiveEventQueryStatus::END_OF_LIST);
        ActiveEventGetEventValidateParameters(resp);
    }

    void ActiveEventGetEventTestNotValideTarget(const Mol::DataType::ObjectReference& channelID )
    {
        auto resp = std::make_shared<Mol::Response::ActiveEventResponse>(Mol::ActiveEventQueryType::GET_ALL_EVENT, Mol::Response::ActiveEventQueryStatus::END_OF_LIST);
        resp->SetResponseTarget(channelID);
        ActiveEventGetEventValidateParameters(resp);
    }

    bool ActiveEventGetEventTestValdResponse(const Mol::DataType::ObjectReference& channelID)
    {
        Dol::Translator<Mol::Event::AlarmEvent, Mol::Event::AlarmEvent> eventTranslator1;
        auto resp = std::make_shared<Mol::Response::ActiveEventResponse>(Mol::ActiveEventQueryType::GET_ALL_EVENT, Mol::Response::ActiveEventQueryStatus::RESPONSE_SUCCESS);
        resp->SetResponseTarget(channelID);
        auto event = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::FIRST_ALARM);
        resp->SetData(eventTranslator1.DomainObjectMessageToString(event));
        ActiveEventGetEvent(resp,0);
        auto message = m_eventsQueue.front();
        Dol::Translator<Mol::Message<Mol::Event::EVENT_CATEGORY>,Mol::Message<Mol::Event::EVENT_CATEGORY>> eventTranslator2;
        auto resultEvent = eventTranslator2.StringToDomainObjectMessage(message.get()?*message.get():"");
        return (resultEvent != nullptr);
    }

    bool ActiveEventGetEventTestNotSuccessResponse(const Mol::DataType::ObjectReference& channelID )
    {
        auto resp = std::make_shared<Mol::Response::ActiveEventResponse>(Mol::ActiveEventQueryType::GET_ALL_EVENT, Mol::Response::ActiveEventQueryStatus::END_OF_LIST);
        resp->SetResponseTarget(channelID);
        ActiveEventGetEvent(resp,0);
        return (m_currentCommunicationStep == RemoteSubscriberChannel::COMMUNICATION_STEP::BUFFERED_EVENTS);
    }


    void PrintResponseTestEmptylMessage()
    {
        PrintResponse("");
    }

    void PrintResponseTestNotValidlMessage()
    {
        using InvaldIvent = Mol::Event::Event<Mol::Event::EVENT_CATEGORY::NONE>;
        auto event = std::make_shared<InvaldIvent>();
        Dol::Translator<InvaldIvent, InvaldIvent> eventTranslator;
        PrintResponse(eventTranslator.DomainObjectMessageToString(event));
    }

    void PrintResponseTestValidlMessage()
    {
        /*test EventUnpacker class also here for all possible Events types*/
        Dol::Translator<Mol::Event::AlarmEvent, Mol::Event::AlarmEvent> eventTranslator;
        auto event = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::FIRST_ALARM);
        PrintResponse(eventTranslator.DomainObjectMessageToString(event));

        Dol::Translator<Mol::Event::AccessEvent, Mol::Event::AccessEvent> eventTranslator1;
        auto event1 = std::make_shared<Mol::Event::AccessEvent>();
        PrintResponse(eventTranslator1.DomainObjectMessageToString(event1));

        Dol::Translator<Mol::Event::ActivationEvent, Mol::Event::ActivationEvent> eventTranslator2;
        auto event2 = std::make_shared<Mol::Event::ActivationEvent>();
        PrintResponse(eventTranslator2.DomainObjectMessageToString(event2));

        Dol::Translator<Mol::Event::AlarmSignalEvent, Mol::Event::AlarmSignalEvent> eventTranslator3;
        auto event3 = std::make_shared<Mol::Event::AlarmSignalEvent>();
        PrintResponse(eventTranslator3.DomainObjectMessageToString(event3));

        Dol::Translator<Mol::Event::DisablementEvent, Mol::Event::DisablementEvent> eventTranslator4;
        auto event4 = std::make_shared<Mol::Event::DisablementEvent>();
        PrintResponse(eventTranslator4.DomainObjectMessageToString(event4));

        Dol::Translator<Mol::Event::FaultClearedEvent, Mol::Event::FaultClearedEvent> eventTranslator5;
        auto event5 = std::make_shared<Mol::Event::FaultClearedEvent>();
        PrintResponse(eventTranslator5.DomainObjectMessageToString(event5));

        Dol::Translator<Mol::Event::FaultEvent, Mol::Event::FaultEvent> eventTranslator6;
        auto event6 = std::make_shared<Mol::Event::FaultEvent>();
        PrintResponse(eventTranslator6.DomainObjectMessageToString(event6));

        Dol::Translator<Mol::Event::InformationEvent, Mol::Event::InformationEvent> eventTranslator7;
        auto event7 = std::make_shared<Mol::Event::InformationEvent>();
        PrintResponse(eventTranslator7.DomainObjectMessageToString(event7));

        Dol::Translator<Mol::Event::InputChangeEvent, Mol::Event::InputChangeEvent> eventTranslator8;
        auto event8 = std::make_shared<Mol::Event::InputChangeEvent>();
        PrintResponse(eventTranslator8.DomainObjectMessageToString(event8));

        Dol::Translator<Mol::Event::MaintenanceEvent, Mol::Event::MaintenanceEvent> eventTranslator9;
        auto event9 = std::make_shared<Mol::Event::MaintenanceEvent>();
        PrintResponse(eventTranslator9.DomainObjectMessageToString(event9));

        Dol::Translator<Mol::Event::Reset, Mol::Event::Reset> eventTranslator10;
        auto event10 = std::make_shared<Mol::Event::Reset>();
        PrintResponse(eventTranslator10.DomainObjectMessageToString(event10));

        Dol::Translator<Mol::Event::TestOperationEvent, Mol::Event::TestOperationEvent> eventTranslator11;
        auto event11 = std::make_shared<Mol::Event::TestOperationEvent>();
        PrintResponse(eventTranslator11.DomainObjectMessageToString(event11));

        Dol::Translator<Mol::Event::UserOperationEvent, Mol::Event::UserOperationEvent> eventTranslator12;
        auto event12 = std::make_shared<Mol::Event::UserOperationEvent>();
        PrintResponse(eventTranslator12.DomainObjectMessageToString(event12));

        Dol::Translator<Mol::Event::WarningEvent, Mol::Event::WarningEvent> eventTranslator13;
        auto event13 = std::make_shared<Mol::Event::WarningEvent>();
        PrintResponse(eventTranslator13.DomainObjectMessageToString(event13));
    }

    bool ClearParametersTestValdate()
    {
        ClearParameters();
        return (m_eventsQueue.empty() &&
                !m_newEventAvailebel &&
                m_currentCommunicationStep == COMMUNICATION_STEP::START_COMMUNICATION);
    }

    bool CreateActiveEventLogGetAllEventRequestRequestTestValidate(const Mol::DataType::ObjectReference& channelID)
    {
        CreateActiveEventLogGetAllEventRequest();
        return (m_activeEventListRequest->GetQueryType() ==  Mol::ActiveEventQueryType::GET_ALL_EVENT &&
                m_activeEventListRequest->GetEventFilter().m_application == Mol::Event::EVENT_APPLICATION::END_OF_LIST &&
                m_activeEventListRequest->GetEventFilter().m_category == Mol::Event::EVENT_CATEGORY::END_OF_LIST &&
                m_activeEventListRequest->GetReceiveLimit() ==  0 &&
                m_activeEventListRequest->GetEndCount() ==  0 &&
                m_activeEventListRequest->GetSourceTarget() ==  channelID);
    }

    bool BufferNewEventTest1()
    {
        auto event = std::make_shared<std::string>("test only");
        m_currentCommunicationStep = COMMUNICATION_STEP::START_COMMUNICATION;
        BufferNewEvent(event, 0);
        return !m_newEventAvailebel;
    }

    bool BufferNewEventTest2()
    {
        auto event = std::make_shared<std::string>("test only");
        m_currentCommunicationStep = COMMUNICATION_STEP::BUFFERED_EVENTS;
        m_requestCode = Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST;
        BufferNewEvent(event, 0);
        return !m_newEventAvailebel;
    }

    bool BufferNewEventTest3()
    {
        auto event = std::make_shared<std::string>("test only");
        m_currentCommunicationStep = COMMUNICATION_STEP::BUFFERED_EVENTS;
        m_requestCode = Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT;
        BufferNewEvent(event, 0);
        return m_newEventAvailebel;
    }
    bool BufferNewEventTest4()
    {
        m_currentCommunicationStep = COMMUNICATION_STEP::BUFFERED_EVENTS;
        m_requestCode = Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT;
        BufferNewEvent(nullptr, 0);
        return m_newEventAvailebel;
    }
    bool BufferEventTest1()
    {
        ClearParameters();
        BufferEvent(nullptr);
        return m_eventsQueue.empty();
    }
    bool BufferEventTest2()
    {
        auto event = std::make_shared<std::string>("test only");
        BufferEvent(event);
        return !m_eventsQueue.empty();
    }
    bool BufferEventTest3()
    {
        auto event = std::make_shared<std::string>("test only");
        for (unsigned int var = 0; var <= MAX_EVENTS_QUEUE_SIZE + 1; ++var) {
            BufferEvent(event);
        }
        return (!(m_eventsQueue.size() > MAX_EVENTS_QUEUE_SIZE));
    }
    bool UpdateEventsTimerTest1()
    {
        m_requestInProgress = true;
        m_newEventAvailebel = true;
        UpdateEventsTimer();
        return m_newEventAvailebel;
    }
    bool UpdateEventsTimerTest2()
    {
        m_requestInProgress = true;
        m_newEventAvailebel = false;
        UpdateEventsTimer();
        return !m_newEventAvailebel;
    }
    bool UpdateEventsTimerTest3()
    {
        m_requestInProgress = false;
        m_newEventAvailebel = false;
        UpdateEventsTimer();
        return !m_newEventAvailebel;
    }
    bool UpdateEventsTimerTest4()
    {
        m_requestInProgress = false;
        m_newEventAvailebel = true;
        UpdateEventsTimer();
        return !m_newEventAvailebel;
    }
    bool SendBufferedEventsTest1()
    {
        auto event = std::make_shared<std::string>("test only");
        ClearParameters();
        m_eventsQueue.push(event);
        SendBufferedEvents();
        return m_eventsQueue.empty();
    }
    bool SendBufferedEventsTest2()
    {
        ClearParameters();
        SendBufferedEvents();
        return m_eventsQueue.empty();
    }
};
#endif //PLATFORM_TEST_REMOTE_SUBSCRIBER_H
