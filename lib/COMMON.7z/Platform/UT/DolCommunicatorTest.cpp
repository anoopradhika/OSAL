
/******************************************************************************//**
* @file DolCommunicatorTest.cpp
* @brief Test for Dol Communicator
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "DolCommunicatorTest.h"

int32_t debugLevel = DEBUG_INFO;

const PROC_ADDRESS DolCommunicatorTest::publisherId = PROC_ADDRESS::MAINLOOP;
const PROC_ADDRESS DolCommunicatorTest::Broker = PROC_ADDRESS::CMCAPP;
const PROC_ADDRESS DolCommunicatorSubscribeTest::publisherId = PROC_ADDRESS::CMCAPP;

DolCommunicatorTest::DolCommunicatorTest():m_messageTransporter(Platform::MessageTransporter::GetMessageTransporter()), m_Communicator(Platform::ObjectModelCommunicator<Platform::MessageTransporter,Dol::DOMAIN_OBJECT_TYPE,Dol::DomainObject>::GetObjectModelCommunicator(m_messageTransporter,Platform::Message::MessageType::DOL))
{}


void DolCommunicatorTest::SetUp()
{
    PrepareDolCommuncator();
    m_HeartBeat = std::make_shared<Dol::Network::HeartBeat>();
    networkAddress.setDomainId(22);
    networkAddress.setModuleId(100);
    networkAddress.setNodeId(50);
    m_HeartBeat->SetNetworkAddress(networkAddress);
    rcNetworkAddress = std::make_shared<Dol::Network::LogicalAddress>();
    rcNetworkAddress->setDomainId(11);
    rcNetworkAddress->setModuleId(200);
    rcNetworkAddress->setNodeId(70);
    m_RegistrationConfirmation = std::make_shared<Dol::Network::RegistrationConfirmation>();
    m_RegistrationConfirmation->SetNetworkAddress(rcNetworkAddress);
}

void DolCommunicatorTest::PrepareDolCommuncator()
{
    m_messageTransporter.Prepare(publisherId);
    m_messageTransporter.Connect(DolCommunicatorSubscribeTest::publisherId);
    m_messageTransporter.Connect(publisherId);
    m_Communicator.Prepare(0);
}


void DolCommunicatorTest::TearDownDolCommuncator()
{
    m_Communicator.Unsubscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT,publisherId);
    m_Communicator.Shutdown();
    //m_MessagePort.Disconnect(Platform::MessagePortID::TEST_ID_ONE,endPoint);
    m_messageTransporter.Stop();
    m_messageTransporter.Shutdown();
}



void DolCommunicatorTest::TearDown()
{
    TearDownDolCommuncator();
}


void DolCommunicatorTest::receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase, uint64_t destinationID)
{
    
    std::shared_ptr<Dol::Network::HeartBeat> heartBeatReceived = std::static_pointer_cast<Dol::Network::HeartBeat>(domainObjectBase);
    
    EXPECT_EQ(networkAddress.getDomainId(), heartBeatReceived->GetNetworkAddress().getDomainId());
    EXPECT_EQ(networkAddress.getModuleId(), heartBeatReceived->GetNetworkAddress().getModuleId());
    EXPECT_EQ(networkAddress.getNodeId(), heartBeatReceived->GetNetworkAddress().getNodeId());
    std::cout<<"heartBeatReceived->GetNetworkAddress().getDomainId() = "<<heartBeatReceived->GetNetworkAddress().getDomainId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getModuleId() = "<<heartBeatReceived->GetNetworkAddress().getModuleId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getNodeId() = "<<heartBeatReceived->GetNetworkAddress().getNodeId()<<"\n";
    std::cout<<"receiveHeartBeat"<< ++receivedCount<<"\n";
    messageReceived = true;
}


void DolCommunicatorTest::BrokerRegistrationConfirmation(std::shared_ptr<Dol::DomainObject> domainObjectBase,uint64_t destinationID)
{
    
    std::shared_ptr<Dol::Network::RegistrationConfirmation> registrationConfirmation = std::static_pointer_cast<Dol::Network::RegistrationConfirmation>(domainObjectBase);
    
    EXPECT_EQ(rcNetworkAddress->getDomainId(), registrationConfirmation->GetNetworkAddress()->getDomainId());
    EXPECT_EQ(rcNetworkAddress->getModuleId(), registrationConfirmation->GetNetworkAddress()->getModuleId());
    EXPECT_EQ(rcNetworkAddress->getNodeId(), registrationConfirmation->GetNetworkAddress()->getNodeId());
    std::cout<<"heartBeatReceived->GetNetworkAddress().getDomainId() = "<<registrationConfirmation->GetNetworkAddress()->getDomainId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getModuleId() = "<<registrationConfirmation->GetNetworkAddress()->getModuleId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getNodeId() = "<<registrationConfirmation->GetNetworkAddress()->getNodeId()<<"\n";
    std::cout<<"RegistrationConfirmation"<< ++receivedCount<<"\n";
    m_Communicator.Send(m_HeartBeat,Broker);

    messageReceived = true;
}


void DolCommunicatorTest::PublisherHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase, uint64_t destinationID)
{
    
    std::shared_ptr<Dol::Network::HeartBeat> heartBeatReceived = std::static_pointer_cast<Dol::Network::HeartBeat>(domainObjectBase);
    
    EXPECT_EQ(networkAddress.getDomainId(), heartBeatReceived->GetNetworkAddress().getDomainId());
    EXPECT_EQ(networkAddress.getModuleId(), heartBeatReceived->GetNetworkAddress().getModuleId());
    EXPECT_EQ(networkAddress.getNodeId(), heartBeatReceived->GetNetworkAddress().getNodeId());
    std::cout<<"heartBeatReceived->GetNetworkAddress().getDomainId() = "<<heartBeatReceived->GetNetworkAddress().getDomainId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getModuleId() = "<<heartBeatReceived->GetNetworkAddress().getModuleId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getNodeId() = "<<heartBeatReceived->GetNetworkAddress().getNodeId()<<"\n";
    std::cout<<"PublisherHeartBeat"<< ++BrokerreceivedCount<<"\n";
    m_Communicator.Send(m_RegistrationConfirmation,publisherId);
    messageReceived = true;
}


DolCommunicatorSubscribeTest::DolCommunicatorSubscribeTest():m_messageTransporter(Platform::MessageTransporter::GetMessageTransporter()), m_Communicator(Platform::ObjectModelCommunicator<Platform::MessageTransporter,Dol::DOMAIN_OBJECT_TYPE,Dol::DomainObject>::GetObjectModelCommunicator(m_messageTransporter,Platform::Message::MessageType::DOL))
{}


void DolCommunicatorSubscribeTest::SetUp()
{
    PrepareDolCommuncator();
    m_HeartBeat = std::make_shared<Dol::Network::HeartBeat>();
    networkAddress.setDomainId(22);
    networkAddress.setModuleId(100);
    networkAddress.setNodeId(50);
    m_HeartBeat->SetNetworkAddress(networkAddress);
}

void DolCommunicatorSubscribeTest::PrepareDolCommuncator()
{
    m_messageTransporter.Prepare(publisherId);
    m_Communicator.Prepare(0);
}


void DolCommunicatorSubscribeTest::TearDownDolCommuncator()
{
    m_Communicator.Unsubscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT,DolCommunicatorTest::publisherId);
    m_Communicator.Shutdown();
    //m_MessagePort.Disconnect(Platform::MessagePortID::TEST_ID_ONE,endPoint);
    m_messageTransporter.Stop();
    m_messageTransporter.Shutdown();
}



void DolCommunicatorSubscribeTest::TearDown()
{
    TearDownDolCommuncator();
}


void DolCommunicatorSubscribeTest::receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase,uint64_t destinationID)
{
    std::shared_ptr<Dol::Network::HeartBeat> heartBeatReceived = std::static_pointer_cast<Dol::Network::HeartBeat>(domainObjectBase);
    
    EXPECT_EQ(networkAddress.getDomainId(), heartBeatReceived->GetNetworkAddress().getDomainId());
    EXPECT_EQ(networkAddress.getModuleId(), heartBeatReceived->GetNetworkAddress().getModuleId());
    EXPECT_EQ(networkAddress.getNodeId(), heartBeatReceived->GetNetworkAddress().getNodeId());
    std::cout<<"heartBeatReceived->GetNetworkAddress().getDomainId() = "<<heartBeatReceived->GetNetworkAddress().getDomainId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getModuleId() = "<<heartBeatReceived->GetNetworkAddress().getModuleId()<<"\n";
    std::cout<<"heartBeatReceived->GetNetworkAddress().getNodeId() = "<<heartBeatReceived->GetNetworkAddress().getNodeId()<<"\n";
    std::cout<<"receiveHeartBeat"<< ++receivedCount<<"\n";
    messageReceived = true;
}



TEST_F(DolCommunicatorTest, HeartBeatSerialization)
{
    m_Communicator.Send(m_HeartBeat,publisherId);
    sleep(1);
    std::shared_ptr<Dol::Network::HeartBeat> ReceivedHeartBeat = m_Communicator.Receive<Dol::Network::HeartBeat>();
   m_Communicator.Receive<Dol::Network::HeartBeat>();

  std::cout<<ReceivedHeartBeat->GetNetworkAddress().getDomainId()<<std::endl;
  std::cout<<ReceivedHeartBeat->GetNetworkAddress().getModuleId()<<std::endl;
  std::cout<<ReceivedHeartBeat->GetNetworkAddress().getNodeId()<<std::endl;
  
  EXPECT_EQ(ReceivedHeartBeat->GetNetworkAddress().getDomainId(),networkAddress.getDomainId());
  EXPECT_EQ(ReceivedHeartBeat->GetNetworkAddress().getModuleId(),networkAddress.getModuleId());
  EXPECT_EQ(ReceivedHeartBeat->GetNetworkAddress().getNodeId(),networkAddress.getNodeId());
}

TEST_F(DolCommunicatorTest, HeartBeatSendSubscribe)
{
    m_Communicator.Subscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT)->Connect(this, &DolCommunicatorTest::receiveHeartBeat);
    m_messageTransporter.Connect(publisherId);
    m_messageTransporter.Start();
    while(messageReceived != true)
    {
        m_Communicator.Send(m_HeartBeat,publisherId);
        sleep(1);
    }
    m_messageTransporter.Stop();
}


TEST_F(DolCommunicatorTest, HeartBeatSend)
{
    m_Communicator.Subscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT)->Connect(this, &DolCommunicatorTest::receiveHeartBeat);
    m_messageTransporter.Start();
    while(true)
    {
        m_Communicator.Send(m_HeartBeat,DolCommunicatorSubscribeTest::publisherId);
        sleep(1);
    }
}

TEST_F(DolCommunicatorTest, HeartBeatAndRegistrationConfirmation)
{
    m_Communicator.Subscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT)->Connect(this, &DolCommunicatorTest::PublisherHeartBeat);
    m_Communicator.Subscribe<Dol::Network::RegistrationConfirmation>(Dol::DOMAIN_OBJECT_TYPE::REGISTRATION_CONFIRMATION);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::REGISTRATION_CONFIRMATION)->Connect(this, &DolCommunicatorTest::BrokerRegistrationConfirmation);
    m_messageTransporter.NeedBrokerSupport(Broker);
    m_messageTransporter.Connect(Broker);
    m_messageTransporter.Start();
    m_Communicator.Send(m_HeartBeat,Broker);
    while(true)
    {
        sleep(1);
    }
}



TEST_F(DolCommunicatorSubscribeTest, HeartBeatSubscribe)
{
    m_Communicator.Subscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT)->Connect(this, &DolCommunicatorSubscribeTest::receiveHeartBeat);
    m_messageTransporter.Start();
    while(true)
    {
        sleep(1);
    }
    m_messageTransporter.Stop();
}