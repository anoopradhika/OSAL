/******************************************************************************//**
* @file PanelTest.h
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#include "Watchdog/Watchdog.h"
#include "Application/Application.h"
#include "PanelMonitor/PanelMonitor.h"
#include "ModuleMonitor/ModuleMonitor.h"
#include "CCLMessageBroker/CCLMessageBroker.h"

namespace
{
    uint64_t m_sourceIDPanel = 0x0100020100000000;
}

class PanelTest : Platform::Application
{


public:
    PanelTest(const std::string& ipAddress, PROC_ADDRESS applicationId, PROC_ADDRESS broker ) :
            Application{applicationId, m_sourceIDPanel},
            m_applicationId{applicationId},
            m_broker{broker}
    {
        Mol::DeviceUniqueID sourceID(m_sourceIDPanel);
        m_ModuleMonitor =  std::make_shared<ModuleRegistration::ModuleMonitor>(ipAddress, m_sourceIDPanel, m_applicationId, m_broker, 5000);
        AddComponent(m_ModuleMonitor);
        m_cclBroker =  std::make_shared<Platform::CCLMessageBroker>(ipAddress, m_sourceIDPanel, "MainLoop", 8000, 8000, 9000, CommunicationType::interModuleCommunication);
        AddComponent(m_cclBroker);
    }

    virtual ~PanelTest() = default;

    void Init() override
    {
       Platform::Application::Init();
    }

    virtual void Prepare() override
    {
       Platform::Application::Prepare();
       m_communicator.m_messageTransporter.NeedBrokerSupport(m_broker);
       m_communicator.m_messageTransporter.Connect(m_applicationId);
       m_communicator.m_messageTransporter.Connect(m_broker);
    }

    virtual void Start() override
    {
       Platform::Application::Start();
    }

    virtual void Stop() override
    {
       Platform::Application::Stop();
    }

    virtual void Shutdown() override
    {
       Platform::Application::Shutdown();
    }

    virtual void Uninit() override
    {
       Platform::Application::Uninit();
    }

protected:

    std::shared_ptr<Platform::Watchdog> m_watchdog;
    std::shared_ptr<ModuleRegistration::ModuleMonitor> m_ModuleMonitor;
    std::shared_ptr<Platform::CCLMessageBroker> m_cclBroker;
    PROC_ADDRESS m_applicationId;
    PROC_ADDRESS m_broker;
};
