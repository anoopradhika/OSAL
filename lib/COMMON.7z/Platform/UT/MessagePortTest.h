#ifndef MESSAGE_PORT_TEST_INCLUDE_H
#define MESSAGE_PORT_TEST_INCLUDE_H
#include "gmock/gmock.h"
#include "MessagePort/MessagePort.h"

/**
    MessagePortTest class to test MessagePort functionality
*/
class MessagePortTest: public:: testing::Test
{
    public:
        /** Publisher Test ID */
        static const Platform::MessagePortID publisherId;

        /** Test buffer size */
        static constexpr uint32_t DATA_SIZE_BYTE = 512;

        /** Test data ID */
        static const uint32_t DATA_ID;
        
        /** Data used for testing */
        static const std::string TEST_DATA;
        
        /** Test message type */
        typedef struct 
        {
          uint32_t Id;
          int8_t Data[DATA_SIZE_BYTE];
        }MessageType;

        /** Get MessagePort */
        MessagePortTest();

        /** Default destructor */
        ~MessagePortTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();
        
        /** Prepare message Port to send */
        void PrepareToSendMessage();
        
        /** Prepare message port to receive */
        void PrepareToReceiveMessage();

        /** MessagePort for testing */
        Platform::MessagePort& m_MessagePort;

        /** Test message */
        MessageType m_message;

        /** Connection point get on successful subscription */
        int32_t m_EndPoint;
};


#endif //MESSAGE_PORT_TEST_INCLUDE_H
