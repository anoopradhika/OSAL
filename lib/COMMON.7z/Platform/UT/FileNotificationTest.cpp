#include "FileNotificationTest.h"
namespace platformTest
{

TEST_F(FileNotificationTest, Notification)
{
    StartTimer();
    WaitForResult(mNoFIleNotifcationMs);
    EXPECT_EQ(validate(),false);
    WaitForResult(mTestExitMs);
    EXPECT_EQ(validate(),true);
}

}
