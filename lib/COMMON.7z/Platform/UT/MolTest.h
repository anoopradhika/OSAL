/******************************************************************************//**
* @file MolTest.h
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#include "Baseapp.h"

#include "gmock/gmock.h"

#include "ObjectModelCommunicator/ObjectModelCommunicator.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Commands/SoftwareCenterCommands.h"
#include "Mol/Requests/SoftwareCenterRequests.h"
#include "Mol/Responses/SoftwareCenterResponses.h"
#include "MessageTransporter/MessageTransporter.h"

class MolSenderTest:public:: testing::Test
{

public:
    /** Get Communicator */
    MolSenderTest() = default;

    /** A default constructor */
    virtual ~MolSenderTest() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();

    /** Prepare communicators to send and subscribe Model objects */
    void PrepareCommuncator();

    /**
        Unsubscribe Model objects
        shutdown Communicator and MessageTransporter
    */
    void TearDownCommuncator();

    std::shared_ptr<Mol::Command::StartServer>  m_startServer;
    std::shared_ptr<Mol::Request::SoftwareVersion>  m_softwareVersionRequest;

    using EventType = Mol::Event::EVENT_CATEGORY;
    using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;
    
    using CommandType = Mol::Command::COMMAND_CATEGORY;
    using CommandCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,CommandType,Mol::Message<CommandType>>;
    
    using RequestType = Mol::Request::REQUEST_CATEGORY;
    using RequestCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,RequestType,Mol::Message<RequestType>>;

    using ResponseType = Mol::Response::RESPONSE_CATEGORY;    
    using ResponseCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,ResponseType,Mol::Message<ResponseType>>;

    //virtual void OnShutDown(const int sig_num)=0; //Method will be called when systemd is about to shutdown
    Platform::MessageTransporter& m_messageTransporter = Platform::MessageTransporter::GetMessageTransporter();
    EventCommunicator& m_eventCommunicator = EventCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::EVENT);
    CommandCommunicator& m_commandCommunicator = CommandCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::COMMAND);
    RequestCommunicator& m_requestCommunicator = RequestCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::REQUEST);
    ResponseCommunicator& m_responseCommunicator = ResponseCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::RESPONSE);
    static const PROC_ADDRESS publisherId;
    
    /**
        Notification for Software version response
    */
    void receiveSoftwareVersionResponse(std::shared_ptr<Mol::Message<ResponseType>> response, uint64_t DestinationID);
    
    /**
        Notification for Alarm event
    */
    void receiveAlarmEvent(std::shared_ptr<Mol::Message<EventType>> event,uint64_t DestinationID);
    bool SoftwareVersionResponseReceived = false;
    bool AlarmEventReceived = false;
private:
    
};

class MolSubscriberTest: public:: testing::Test
{

public:
    /** Get Communicator */
    MolSubscriberTest() = default;

    /** A default constructor */
    virtual ~MolSubscriberTest() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();

    /** Prepare communicators to send and subscribe Model objects */
    void PrepareCommuncator();

    /**
        Unsubscribe Modle objects
        shutdown Communicator and MessagePort
    */
    void TearDownCommuncator();

    
    std::shared_ptr<Mol::Event::AlarmEvent>  m_alarmEvent;
    std::shared_ptr<Mol::Response::SoftwareVersion>  m_softwareVersionResponse;

    using EventType = Mol::Event::EVENT_CATEGORY;
    using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;
    
    using CommandType = Mol::Command::COMMAND_CATEGORY;
    using CommandCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,CommandType,Mol::Message<CommandType>>;
    
    using RequestType = Mol::Request::REQUEST_CATEGORY;
    using RequestCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,RequestType,Mol::Message<RequestType>>;

    using ResponseType = Mol::Response::RESPONSE_CATEGORY;    
    using ResponseCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,ResponseType,Mol::Message<ResponseType>>;

    //virtual void OnShutDown(const int sig_num)=0; //Method will be called when systemd is about to shutdown
    Platform::MessageTransporter& m_messageTransporter = Platform::MessageTransporter::GetMessageTransporter();
    EventCommunicator& m_eventCommunicator = EventCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::EVENT);
    CommandCommunicator& m_commandCommunicator = CommandCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::COMMAND);
    RequestCommunicator& m_requestCommunicator = RequestCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::REQUEST);
    ResponseCommunicator& m_responseCommunicator = ResponseCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::RESPONSE);
                                                
    /**
        Notification for server command
    */
    void receiveStartServerCommand(std::shared_ptr<Mol::Message<CommandType>> command, uint64_t DestinationID);
    
    /**
        Notification for software version request
    */
    void receiveSoftwareVersionRequest(std::shared_ptr<Mol::Message<RequestType>> request,uint64_t DestinationID);
    static const PROC_ADDRESS publisherId;
    bool StartServerCommandReceived = false;
    bool SoftwareVersionRequestReceived = false;
private:
    
};