/******************************************************************************//**
* @file WatchDogtest.h
* @brief Test case for WatchDog component.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFPRM_TEST_WATCHDOG_H
#define PLATFPRM_TEST_WATCHDOG_H

#include "ACT/ACT.hpp"
#include "Watchdog/Watchdog.h"
#include "Timer/Timer.hpp"

namespace platformTest
{

/**
    MessagePortTest class to test MessagePort functionality
    @todo Add Test for system test(both positive and negative case)
*/
class WatchdogTest: public platform::ACT
{
    public:

        /** Get MessagePort */
        WatchdogTest()
        {
            AddComponent(std::make_shared<Platform::Watchdog>(m_componentManager));
        }
        /** Default destructor */
        virtual ~WatchdogTest() = default;

        /** Add test Setup here */
        virtual void SetUp()
        {
            Init();
            Prepare();
        }

        /** Add test cleanup here */
        virtual void TearDown()
        {
            Stop();
            Shutdown();
            Uninit();
        }

};

} //end of platformTest

#endif //PLATFPRM_TEST_WATCHDOG_H
