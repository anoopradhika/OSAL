/******************************************************************************//**
* @file MolTest.h
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#include "gtest/gtest.h"
#include "PanelTest.h"
int debugLevel = CURRENT_DEBUG_LEVEL;
namespace
{
//static const std::string PanelIPAddress = "fe80::a00:27ff:fe9d:3884"; //LinuxVM
//static const std::string PanelIPAddress = "fe80::21e:1eff:fe00:314"; //Panel 
//static const std::string PanelIPAddress = "fe80::d366:dcf0:8ec0:e6bc";
static const std::string PanelIPAddress = "fd00:1:2:3:21e:1eff:fe00:314"; //linuxPC
}

class ModuleMonitorTest:public:: testing::Test
{

public:
    /** Get Communicator */
    ModuleMonitorTest() :panel(PanelIPAddress,PROC_ADDRESS::MAINLOOP,PROC_ADDRESS::CMCAPP)
    {}

    /** A default constructor */
    virtual ~ModuleMonitorTest() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();
    PanelTest panel;
private:
    
};
