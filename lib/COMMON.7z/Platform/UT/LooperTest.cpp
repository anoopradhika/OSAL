#include "LooperTest.h"
namespace platformTest
{

TEST_F(LooperTest, Looper)
{
    WaitForResult(5000);
}

}
