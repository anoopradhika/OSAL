/******************************************************************************//**
 * @file    Thread.cpp
 * @brief   Unit test cases for functions implemented in Platform::Thread class
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/


#include "Thread.h"
#include"Notifier/Notifier.hpp"
#include <chrono>
#include <stdexcept>


namespace platformTest{
    
void Thread::worker(uint32_t data)
{
    for (int i = 0; i < 5; ++i) {
        std::cout << "Thread 1 executing\n";
        ++data;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}
 
void Thread::SetUp()
{}


void Thread::TearDown()
{}
    
TEST_F(Thread, ThreadJoin)
{

    const uint32_t m_data =225;
    Platform::Notifier workerData;
    workerData.Connect(this,&platformTest::Thread::worker,m_data);
    m_Thread = Platform::Thread<>{workerData};
    m_Thread.Join();

}


}