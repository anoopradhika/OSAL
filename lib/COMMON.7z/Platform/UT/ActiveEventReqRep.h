
#ifndef PLATFORM_ACTIVE_EVENT_REQUEST_RESPONSE_TEST_H
#define PLATFORM_ACTIVE_EVENT_REQUEST_RESPONSE_TEST_H

#include "Application/Application.h"
#include "Mol/Events/AlarmEvent.h"
#include "ACT/ACT.hpp"
#include "CommonDef.h"
#include "Mol/Requests/ActiveEventRequest.h"
#include "Mol/Responses/ActiveEventResponse.h"


class ActiveEventReqRep: public platform::ACT
{
public:
    using EventType = Mol::Event::EVENT_CATEGORY;
    ActiveEventReqRep():platform::ACT(m_address,sourceID)
    {
        DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
        DEBUGPRINT::SetOutStream(OutStream::STDOUT);
    }
    virtual ~ActiveEventReqRep() = default;

    virtual void SetUp()
    {

        Init();
        Prepare();
        m_communicator.m_event.Subscribe<Mol::Event::AlarmEvent>(EventType::ALARM);
        m_communicator.m_event.getService(EventType::ALARM)->Connect(this, &ActiveEventReqRep::ReceiveFireEvent);
    }

    virtual void TearDown()
    {
        Stop();
        Shutdown();
        Uninit();
    }

    virtual void Prepare() override
    {
       m_communicator.m_messageTransporter.Connect(m_sendAddress);
       m_communicator.m_messageTransporter.Connect(m_address);

       m_communicator.m_response.Subscribe<Mol::Response::ActiveEventResponse>(Mol::Response::RESPONSE_CATEGORY::ACTIVE_EVENT_RESPONSE);
       m_communicator.m_response.getService(Mol::Response::RESPONSE_CATEGORY::ACTIVE_EVENT_RESPONSE)->Connect(this, &ActiveEventReqRep::EventResponseReceived);

       m_communicator.m_event.Subscribe<Mol::Event::AlarmEvent>(Mol::Event::EVENT_CATEGORY::ALARM);
       m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::ALARM)->Connect(this, &ActiveEventReqRep::ReceiveFireEvent);
       platform::ACT::Prepare();
    }

    void EventResponseReceived(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> message, uint64_t senderId)
    {
        m_timer.Stop();

        auto response = std::static_pointer_cast<Mol::Response::ActiveEventResponse>(message);
        PrintResponse(response);
        auto objectReference  = response->GetResponseTarget();
        endcount = response->GetEndCount();
        DEBUGPRINT(DEBUG_INFO, "CNE: ReceiveFireEvent id {} code {} endcount {}",objectReference.GetObjectId(),(uint32_t)response->GetResponseCode(),endcount);
        if(response->GetStatus() == Mol::Response::ActiveEventQueryStatus::RESPONSE_SUCCESS)
        {
            if(response->GetCurrentCount() <= response->GetTotalCount())
            {
                auto reponseMsg = response->GetData();
                if(reponseMsg.size() != 0)
                {
                    std::shared_ptr<Platform::Message> Message(new Platform::Message(Platform::Message::MessageType::EVENT,reponseMsg,response->GetDataLength()));
                    Message->m_SourceUniqueID = sourceID;
                    Message->m_DestinationUniqueID = 0;
                    Dol::Translator<Platform::Message,Platform::Message> messageTranslator;
                    std::string packedData = messageTranslator.DomainObjectMessageToString(Message);
                    m_communicator.m_messageTransporter.Send(packedData,m_address);
                }
            }

            {
                if((endcount - response->GetCurrentCount()) == 0)
                {
                    currentCount = 0;
                    RequestFIre(endcount);
                }
            }
        }
        else if(response->GetStatus() == Mol::Response::ActiveEventQueryStatus::REQUESTED_DATA_LAST_ENTRY)
        {
            Terminate();
        }
    }
    void ReceiveFireEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
    {
        auto message = std::static_pointer_cast<Mol::Event::AlarmEvent>(event);
        DEBUGPRINT(DEBUG_INFO,"Alram event EventType {0} code {1} source id {2:#x}"
                                    , (uint32_t)message->GetEventCategory()
                                    , (uint32_t)message->GetEventCode()
                                    , message->GetSource().GetObjectId()
                                );
        //Terminate();
    }
    virtual void Start() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this,&ActiveEventReqRep::SentEventRTRequest);
        m_timer = Platform::Timer<>(1000,GlobalDataType::Timer::AlarmType::PERIODIC,notifier);
        m_timer.Start();
        platform::ACT::Start();
    }


    virtual void Shutdown() override
    {
        m_timer.Stop();
        m_timer.Shutdown();
       platform::ACT::Shutdown();
       m_communicator.m_messageTransporter.Disconnect(m_sendAddress);
    }

    void SentEventRTRequest()
    {
        RequestFIre(endcount);
        //Platform::this_thread::Sleep(10);
    }

    void RequestFIre(uint32_t count)
    {
        auto filter = Mol::CompleteEventCode{Mol::Event::EVENT_APPLICATION::END_OF_LIST, Mol::Event::EVENT_CATEGORY::END_OF_LIST, 0};
        filter.Print();
        auto message = std::make_shared<Mol::Request::ActiveEventRequest>(Mol::ActiveEventQueryType::GET_EVENT,filter);
        auto source = Mol::DataType::ObjectReference{sourceID,Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE};
        message->SetSourceTarget(source);
        message->SetEndCount(count);
        message->SetReceiveLimit(offsetIndex);
        m_communicator.m_request.Send(message,PROC_ADDRESS::FIRE_DOMAIN_APP,0);
        DEBUGPRINT(DEBUG_INFO, "REquest :: count {} offsetIndex {}"
                            , count
                            , offsetIndex);
    }

protected:

    void PrintResponse(std::shared_ptr<Mol::Response::ActiveEventResponse> response)
    {
        DEBUGPRINT(DEBUG_INFO, "............................................");
        DEBUGPRINT(DEBUG_INFO, " EndCount {0} current count {2} Total count {3} status {1} "
                        , (uint32_t)response->GetEndCount()
                        , (uint32_t)response->GetStatus()
                        , (uint32_t)response->GetCurrentCount()
                        , (uint32_t)response->GetTotalCount());
        DEBUGPRINT(DEBUG_INFO, "............................................");
    }

    static constexpr PROC_ADDRESS m_sendAddress =  PROC_ADDRESS::FIRE_DOMAIN_APP;
    static constexpr  PROC_ADDRESS m_address = PROC_ADDRESS::CMCAPP;
    static constexpr  uint64_t sourceID = 0x0100010200000000;
    std::vector<Platform::Notifier> m_sendEvents{};
    int32_t endcount = 0;
    int32_t currentCount = 0;
    const int32_t offsetIndex  = 2;
    /** MessagePort for testing */
    Platform::Timer<> m_timer;

};

#endif //PLATFORM_ACTIVE_EVENT_REQUEST_RESPONSE_TEST_H
