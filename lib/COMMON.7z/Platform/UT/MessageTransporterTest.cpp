/******************************************************************************//**
* @file MessageTransporterTest.cpp
* @brief Test case for model object communication with MessageTransporter.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "MessageTransporterTest.h"


const PROC_ADDRESS MessageTransporterTest::publisherId = PROC_ADDRESS::MAINLOOP;
const PROC_ADDRESS MessageTransporterSubTest::publisherId = PROC_ADDRESS::CMCAPP;


MessageTransporterTest::MessageTransporterTest():m_messageTransporter(Platform::MessageTransporter::GetMessageTransporter()),
                         m_dolCommunicator(DOLCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Platform::Message::MessageType::DOL)),
                         m_eventCommunicator(EventCommunicator::GetObjectModelCommunicator
                                            ( m_messageTransporter,Platform::Message::MessageType::EVENT))
{
    
}
void MessageTransporterTest::SetUp()
{
    PrepareCommuncator();
    m_HeartBeat = std::make_shared<Dol::Network::HeartBeat>();
    networkAddress.setDomainId(22);
    networkAddress.setModuleId(100);
    networkAddress.setNodeId(50);
    m_HeartBeat->SetNetworkAddress(networkAddress);
    m_alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
}

void MessageTransporterTest::PrepareCommuncator()
{
    m_messageTransporter.Prepare(publisherId);
    m_messageTransporter.Connect(MessageTransporterSubTest::publisherId);
    m_dolCommunicator.Prepare(0);
    m_eventCommunicator.Prepare(0);
}


void MessageTransporterTest::TearDownCommuncator()
{
    m_dolCommunicator.Unsubscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT,publisherId);
    m_dolCommunicator.Shutdown();
    m_eventCommunicator.Shutdown();
    m_messageTransporter.Stop();
    m_messageTransporter.Shutdown();

}



void MessageTransporterTest::TearDown()
{
    TearDownCommuncator();
}


void MessageTransporterSubTest::DolSubscription(std::shared_ptr<Platform::Message> message)
{
    std::cout<<"Dol message type is "<<(uint32_t)message->m_messageType<<std::endl;
    DolMessageReceived = true;
}

void MessageTransporterSubTest::MolSubscription(std::shared_ptr<Platform::Message> message)
{
    std::cout<<"MOl message type is "<<(uint32_t)message->m_messageType<<std::endl;
    MolMessageReceived = true;
}



void MessageTransporterSubTest::SetUp()
{
    m_messageTransporter.Prepare(publisherId);
   // m_messageTransporter.Connect(MessageTransporterSubTest::publisherId );
}


void MessageTransporterSubTest::TearDown()
{
    m_messageTransporter.Stop();
    m_messageTransporter.Shutdown();
}

TEST_F(MessageTransporterTest, SendDolAndEvent)
{
    m_dolCommunicator.Send(m_HeartBeat,MessageTransporterSubTest::publisherId );
    m_eventCommunicator.Send(m_alarmEvent,MessageTransporterSubTest::publisherId );
    sleep(1);
    m_messageTransporter.Stop();
}

TEST_F(MessageTransporterSubTest, Receive)
{
    m_messageTransporter.m_notifiers[Platform::Message::MessageType::DOL].Connect(this,&MessageTransporterSubTest::DolSubscription);
    m_messageTransporter.m_notifiers[Platform::Message::MessageType::EVENT].Connect(this,&MessageTransporterSubTest::MolSubscription);
    m_messageTransporter.Start();
    while((DolMessageReceived != true) && (MolMessageReceived != true) )
    {
        std::cout<<"DolMessageReceived "<<DolMessageReceived<<std::endl;
        std::cout<<"MolMessageReceived "<<MolMessageReceived<<std::endl;
        sleep(1);
    }
    m_messageTransporter.Stop();
}