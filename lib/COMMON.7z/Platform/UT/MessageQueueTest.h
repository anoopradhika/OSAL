#ifndef PLATFPRM_TEST_MESSAGE_QUEUE_INCLUDE_H
#define PLATFPRM_TEST_MESSAGE_QUEUE_INCLUDE_H

#include "gmock/gmock.h"
#include "MessageQueue/MessageQueue.hpp"

namespace platformTest{

/**
    MessageQueueBLockType class to test MessageQueue functionality
*/
class MessageQueueBLockType: public:: testing::Test
{
public:

    /** Get MessageQueue */
    MessageQueueBLockType();

    /** Default destructor */
    virtual ~MessageQueueBLockType() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();

    /** MessageQueue for testing */
    Platform::MessageQueue<> m_blockQueue;

private:
    static const std::string m_queueName;
    
        
};

/**
    MessageQueueNonBlockType class to test MessageQueue functionality
*/
class MessageQueueNonBlockType: public:: testing::Test
{
public:

    /** Get MessageQueue */
    MessageQueueNonBlockType();

    /** Default destructor */
    virtual ~MessageQueueNonBlockType() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();

    /** MessageQueue for testing */
    Platform::MessageQueue<> m_nonBlockQueue;
private:
    static const std::string m_queueName;
        
};

} //end of platformTest
#endif //PLATFPRM_TEST_MESSAGE_QUEUE_INCLUDE_H
