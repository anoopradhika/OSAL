/******************************************************************************//**
* @file FileNotificationTest.h
* @brief Test case verify file notification.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_TEST_FILE_NOTIFICATION_H
#define PLATFORM_TEST_FILE_NOTIFICATION_H

#include "ACT/ACT.hpp"
#include "GlobalDataType/FileNotification/FileNotification.h"
#include "Timer/Timer.hpp"

#include <iostream>
#include <fstream>

namespace platformTest
{

/**
    MessagePortTest class to test MessagePort functionality
*/
class FileNotificationTest: public platform::ACT
{
    public:

        /** Get MessagePort */
        FileNotificationTest()
        {
        }
        /** Default destructor */
        virtual ~FileNotificationTest()
        {
            m_timer.Stop();
        }

        /** Add test Setup here */
        virtual void SetUp()
        {
            Init();
            Prepare();
            PrepareTimer();
            Platform::Notifier notify;
            notify.Connect(this,&FileNotificationTest::LocalNotification);
            mFileNotification.Registration(mFileName,notify,mNotificationIntervalMs);
        }
        void LocalNotification()
        {
            mNotificationReceived = true;
        }
        /** Add test cleanup here */
        virtual void TearDown()
        {
            Stop();
            Shutdown();
            Uninit();
            m_timer.Shutdown();
        }
        void PrepareTimer()
        {
            Platform::Notifier notifier;
            notifier.Connect(this,&FileNotificationTest::write);
            m_timer = Platform::Timer<>(mFileWriteIntervalMs,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);
        }
        void write()
        {
            std::ofstream mMyfile;
            mMyfile.open(mFileName);
            mMyfile << "Writing this to a file................\n";
            mMyfile.close();
        }
        bool validate()
        {
            return mNotificationReceived;
        }
        void StartTimer()
        {
            m_timer.Start();
        }
        static const uint64_t mNotificationIntervalMs = 10;
        static const uint64_t mFileWriteIntervalMs = 100;
        static const uint64_t mNoFIleNotifcationMs = mFileWriteIntervalMs -mNotificationIntervalMs;
        static const uint64_t mTestExitMs = mFileWriteIntervalMs + mNotificationIntervalMs;
    private:
        std::string mFileName = "example.txt";
        GlobalDataType::FileNotification mFileNotification;
        bool mNotificationReceived = false;
        Platform::Timer<> m_timer;
};

} //end of platformTest

#endif //PLATFORM_TEST_FILE_NOTIFICATION_H
