#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "DolCommunicatorNotificationTest.h"
#include <chrono>

const uint32_t DolCommunicatorPublisherTest::SensitivityProfileId  = 0x4321;

const Platform::MessagePortID DolCommunicatorPublisherTest::publisherId = Platform::MessagePortID::TEST_ID_ONE;


const uint32_t DolCommunicatorsubscriberTest::SensitivityProfileId  = 0x4321;

const Platform::MessagePortID DolCommunicatorsubscriberTest::publisherId = Platform::MessagePortID::TEST_ID_TWO;


DolCommunicatorPublisherTest::DolCommunicatorPublisherTest():m_Communicator(Platform::DolCommunicator::getDolCommunicator()),m_MessagePort(Platform::MessagePort::getMessagePort())
{}


void DolCommunicatorPublisherTest::SetUp()
{
    PrepareDolCommuncator();
    prepareFireDetectionDevice();
    prepareFireIncident();
}

void DolCommunicatorPublisherTest::PrepareDolCommuncator()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    
    std::cout<<"Here1\n";
    m_Communicator.Prepare();
    endPoint = m_Communicator.Subscribe<Dol::FireIncident>(Dol::DOMAIN_OBJECT_TYPE::FIRE_INCIDENT,publisherId);
}


void DolCommunicatorPublisherTest::TearDownDolCommuncator()
{
    m_Communicator.Unsubscribe<Dol::FireIncident>(Dol::DOMAIN_OBJECT_TYPE::FIRE_INCIDENT,publisherId,endPoint);
    m_Communicator.Shutdown();
    m_MessagePort.Stop();
    m_MessagePort.Shutdown();
}


void DolCommunicatorPublisherTest::prepareFireDetectionDevice()
{

    sensitivityProfile = std::make_shared<Dol::SensitivityProfile>();
    sensorValues = std::make_shared<Dol::SensorValues>();
    sensorCondition = std::make_shared<Dol::SensorCondition>();
    modelNumber = std::make_shared<Dol::ModelNumber>();
    serialNumber = std::make_shared<Dol::SerialNumber>();

    sensitivityProfile->setSensitivityProfileId(SensitivityProfileId);
    serialNumber->setSerialNumber("123ABC");

    fireDetectionDevice = std::make_shared<Dol::FireDetectionDevice>(serialNumber);
    fireDetectionDevice->setDetectionType(Dol::DetectionZone::DETECTION_TYPE::DT_AUTOMATIC_SENSORS);
    fireDetectionDevice->setDetectionZoneId(42);
    fireDetectionDevice->setDeviceType(Dol::FireDetectionDevice::DEVICE_TYPE::H_RATE_OF_RISE);
    fireDetectionDevice->setSensitivityProfile(sensitivityProfile);
    fireDetectionDevice->setSensitivityProfile(sensitivityProfile);

    fireEventType = std::make_shared<Dol::FireEventType>(Dol::FireEventType::FIRE_EVENT_TYPE::FIRE_SIGNAL);
}

void DolCommunicatorPublisherTest::prepareFireIncident()
{
    fireIncident = std::make_shared<Dol::FireIncident>(fireDetectionDevice,fireEventType);
    fireIncident->setSiteId(0x11);
    fireIncident->setBuildingId(0x22);
    fireIncident->setManagedAreaId(0x33);
    fireIncident->setEventOriginType(Dol::ActiveLifeSafetyEvent::EVENT_ORIGIN_TYPE::PANEL);

    fireIncident->setDateTime(datetime);
    fireIncident->setLabel("label");
    fireIncident->setEntryId(0x44);  
}


Dol::DateTime& DolCommunicatorPublisherTest::getSerializedDataTime()
{
    return datetime;
}


void DolCommunicatorPublisherTest::TearDown()
{
    TearDownDolCommuncator();
}


DolCommunicatorsubscriberTest::DolCommunicatorsubscriberTest():m_Communicator(Platform::DolCommunicator::getDolCommunicator()),m_MessagePort(Platform::MessagePort::getMessagePort())
{}


void DolCommunicatorsubscriberTest::SetUp()
{
    PrepareDolCommuncator();
    prepareFireDetectionDevice();
    prepareFireIncident();
    domainObjectReceived = false;
}


void DolCommunicatorsubscriberTest::receiveDomainObject(std::shared_ptr<Dol::DomainObject> domainObjectBase)
{
    
    std::shared_ptr<Dol::FireIncident> fireIncidentReceived = std::static_pointer_cast<Dol::FireIncident>(domainObjectBase);
    EXPECT_EQ(fireIncident->getSiteId(), fireIncidentReceived->getSiteId());
    EXPECT_EQ(fireIncident->getBuildingId(), fireIncidentReceived->getBuildingId());
    EXPECT_EQ(fireIncident->getManagedAreaId(), fireIncidentReceived->getManagedAreaId());
    EXPECT_EQ(fireIncident->getEventOriginType(), fireIncidentReceived->getEventOriginType());

    EXPECT_EQ(fireIncident->getFireDetectionDevice()->getSerialNumber()->getSerialNumber(), fireIncidentReceived->getFireDetectionDevice()->getSerialNumber()->getSerialNumber());

    EXPECT_EQ(fireIncident->getFireDetectionDevice()->getSensitivityProfile()->getSensitivityProfileId(), fireIncidentReceived->getFireDetectionDevice()->getSensitivityProfile()->getSensitivityProfileId());
    domainObjectReceived = true;
}



bool DolCommunicatorsubscriberTest::isDomainObjectReceived()
{
    return domainObjectReceived;
}

void DolCommunicatorsubscriberTest::PrepareDolCommuncator()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    std::cout<<"Here2\n";
    m_Communicator.Prepare();
    endPoint = m_Communicator.Subscribe<Dol::FireIncident>(Dol::DOMAIN_OBJECT_TYPE::FIRE_INCIDENT,DolCommunicatorPublisherTest::publisherId);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::FIRE_INCIDENT)->Connect(this, &DolCommunicatorsubscriberTest::receiveDomainObject);
    m_MessagePort.Start();

}


void DolCommunicatorsubscriberTest::TearDownDolCommuncator()
{
    m_Communicator.Shutdown();
    m_Communicator.Unsubscribe<Dol::FireIncident>(Dol::DOMAIN_OBJECT_TYPE::FIRE_INCIDENT,publisherId,endPoint);
    m_MessagePort.Stop();
    m_MessagePort.Shutdown();
}


void DolCommunicatorsubscriberTest::prepareFireDetectionDevice()
{

    sensitivityProfile = std::make_shared<Dol::SensitivityProfile>();
    sensorValues = std::make_shared<Dol::SensorValues>();
    sensorCondition = std::make_shared<Dol::SensorCondition>();
    modelNumber = std::make_shared<Dol::ModelNumber>();
    serialNumber = std::make_shared<Dol::SerialNumber>();

    sensitivityProfile->setSensitivityProfileId(SensitivityProfileId);
    serialNumber->setSerialNumber("123ABC");

    fireDetectionDevice = std::make_shared<Dol::FireDetectionDevice>(serialNumber);
    fireDetectionDevice->setDetectionType(Dol::DetectionZone::DETECTION_TYPE::DT_AUTOMATIC_SENSORS);
    fireDetectionDevice->setDetectionZoneId(42);
    fireDetectionDevice->setDeviceType(Dol::FireDetectionDevice::DEVICE_TYPE::H_RATE_OF_RISE);
    fireDetectionDevice->setSensitivityProfile(sensitivityProfile);
    fireDetectionDevice->setSensitivityProfile(sensitivityProfile);

    fireEventType = std::make_shared<Dol::FireEventType>(Dol::FireEventType::FIRE_EVENT_TYPE::FIRE_SIGNAL);
}

void DolCommunicatorsubscriberTest::prepareFireIncident()
{
    fireIncident = std::make_shared<Dol::FireIncident>(fireDetectionDevice,fireEventType);
    fireIncident->setSiteId(0x11);
    fireIncident->setBuildingId(0x22);
    fireIncident->setManagedAreaId(0x33);
    fireIncident->setEventOriginType(Dol::ActiveLifeSafetyEvent::EVENT_ORIGIN_TYPE::PANEL);

    fireIncident->setDateTime(datetime);
    fireIncident->setLabel("label");
    fireIncident->setEntryId(0x44);  
}


Dol::DateTime& DolCommunicatorsubscriberTest::getSerializedDataTime()
{
    return datetime;
}


void DolCommunicatorsubscriberTest::TearDown()
{
    TearDownDolCommuncator();
}


TEST_F(DolCommunicatorPublisherTest, sendFireIncident)
{
    m_Communicator.Send<Dol::FireIncident>(fireIncident);
}

TEST_F(DolCommunicatorsubscriberTest, receiveFireIncidentNotification)
{
    while(false == isDomainObjectReceived())
    {
        auto start = std::chrono::high_resolution_clock::now();
        std::cout<< "isDomainObjectReceived = "<<isDomainObjectReceived()<<"\n";
        sleep(1);
        auto elapsed = std::chrono::high_resolution_clock::now() - start;
        std::cout << "waited for "
        << std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count()
        << " microseconds\n";
    }
}
