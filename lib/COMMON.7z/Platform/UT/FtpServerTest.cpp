#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <signal.h>
#include "CommonDef.h"
#include "gmock/gmock.h"
#include "FtpServer/FtpServer.hpp"
#include "Mol/Commands/SoftwareCenterCommands.h"

namespace platformTest
{
static platform::FtpServer server(2121);

extern "C" void sighandler(int signal, siginfo_t *info, void *ptr){

    DEBUGPRINT(DEBUG_INFO,"Dispara sigaction");
    server.Stop();
    exit(-1);
}


void exit_handler(){
    DEBUGPRINT(DEBUG_INFO,"exit_handler called");
    server.Stop();
}

TEST(FtpServer, StartFtpServer)
{

    struct sigaction action;

    action.sa_sigaction = sighandler;
    action.sa_flags = SA_SIGINFO;
    sigaction(SIGINT, &action , NULL);

    atexit(exit_handler);

    //@todo need real fix here
    server.Run(Mol::Command::FTP_START_MODE::DEFAULT);

}
}
