#ifndef PLATFPRM_TEST_TIMER_INCLUDE_H
#define PLATFPRM_TEST_TIMER_INCLUDE_H
#include "gmock/gmock.h"
#include "Timer/Timer.hpp"

namespace platformTest{

/**
    MessagePortTest class to test MessagePort functionality
*/
class Timer: public:: testing::Test
{
    public:

        /** Get MessagePort */
        Timer();

        /** Default destructor */
        ~Timer() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** MessagePort for testing */
        Platform::Timer<> m_timer;
        
        void testNotification();
        
        int m_data;

};

}
#endif //PLATFPRM_TEST_TIMER_INCLUDE_H
