#ifndef COMMUNICATOR_TEST_INCLUDE_H
#define COMMUNICATOR_TEST_INCLUDE_H

#include "gmock/gmock.h"

#include "DolCommunicator/DolCommunicator.h"
#include "dol/FireIncident.h"
#include "dol/FaultIncident.h"
#include "dol/FireDetectionDevice.h"
#include "MessagePort/MessagePort.h"


class DolCommunicatorPublisherTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        DolCommunicatorPublisherTest();

        /** A default constructor */
        virtual ~DolCommunicatorPublisherTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare FireDetectionDevice class with test data */
        void prepareFireDetectionDevice();

        /** Prepare FireIncident class with test data */
        void prepareFireIncident();

        /**
            Prepare MessagePort
            Subscribe FIRE_INCIDENT with publisherId
        */
        void PrepareDolCommuncator();

        /**
            Unsubscribe FIRE_INCIDENT
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        /**
            Used for test validation
        */
        Dol::DateTime& getSerializedDataTime();

        /**
            fireIncident used for serialization and  deserialization.
            It is used as a DomainObject to send and receive in the test
        */
        std::shared_ptr<Dol::FireIncident> fireIncident;

        /**
            Class under test
        */
        Platform::DolCommunicator& m_Communicator;

        /**
            MessagePort for Communicator test
        */
        Platform::MessagePort& m_MessagePort;

        /** Test data */
        static const uint32_t SensitivityProfileId; 

        /** Test data */
        static const Platform::MessagePortID publisherId;

    private:
        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::FireDetectionDevice> fireDetectionDevice;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::FireEventType> fireEventType;  

        /** Test data required for FireIncident*/
        Dol::DateTime datetime;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SensitivityProfile> sensitivityProfile;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SensorValues> sensorValues;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SensorCondition> sensorCondition;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::ModelNumber> modelNumber;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SerialNumber> serialNumber;

        /** endPoint ID on subscription */
        int32_t endPoint;
};


class DolCommunicatorsubscriberTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        DolCommunicatorsubscriberTest();

        /** A default constructor */
        virtual ~DolCommunicatorsubscriberTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare FireDetectionDevice class with test data */
        void prepareFireDetectionDevice();
        
        /** Prepare FireIncident class with test data */
        void prepareFireIncident();

        /**
            Prepare MessagePort
            Subscribe FIRE_INCIDENT with publisherId
        */
        void PrepareDolCommuncator();

        /**
            Unsubscribe FIRE_INCIDENT
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        /**
            Check whether a DomainObject is received and 
            verified. It is used for terminate a test 
            @return True on DomainObject received. 
        */
        bool isDomainObjectReceived();

        /**
            Used for test validation
        */
        Dol::DateTime& getSerializedDataTime();

        /**
            fireIncident used for serialization and  deserialization.
            It is used as a DomainObject to send and receive in the test
        */
        std::shared_ptr<Dol::FireIncident> fireIncident;

        /**
            Class under test
        */
        Platform::DolCommunicator& m_Communicator;

        /**
            MessagePort for Communicator test
        */
        Platform::MessagePort& m_MessagePort;

        /** Test data */
        static const uint32_t SensitivityProfileId; 

        /** Test data */        
        static const Platform::MessagePortID publisherId;

    private:
        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::FireDetectionDevice> fireDetectionDevice;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::FireEventType> fireEventType;  

        /** Test data required for FireIncident*/
        Dol::DateTime datetime;
        
        /** True on reception of DomainObject */
        bool domainObjectReceived;

        /**
            Service connected to receive DomainObject
            @param domainObjectBase: DomainObject shared pointer
        */
        void receiveDomainObject(std::shared_ptr<Dol::DomainObject> domainObjectBase);

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SensitivityProfile> sensitivityProfile;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SensorValues> sensorValues;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SensorCondition> sensorCondition;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::ModelNumber> modelNumber;

        /** Test data required for FireIncident*/
        std::shared_ptr<Dol::SerialNumber> serialNumber;

        /** endPoint ID on subscription */
        int32_t endPoint;
};

#endif //COMMUNICATOR_TEST_INCLUDE_H
