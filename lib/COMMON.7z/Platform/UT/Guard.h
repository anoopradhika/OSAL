/*****************************************************************//**
 *
 * @file    Guard.hpp
 * @brief   Guard test class to verify Platform::Guard
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
 
#ifndef PLATFPRM_TEST_GUARD_INCLUDE_H
#define PLATFPRM_TEST_GUARD_INCLUDE_H
#include "gmock/gmock.h"
#include "Guard/Guard.hpp"
#include "Mutex/Mutex.hpp"

#include <map>

namespace platformTest{

/**
    Guard test class to test Platform::Guard functionality
*/
class Guard: public:: testing::Test
{
    public:

        /** Default constructor  */
        Guard() = default;

        /** Default destructor */
        ~Guard() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Does nothing */
        virtual void TearDown();

        /** worker thread test Guard. @todo static shall be removed after thread implementation. 
        */
        static void worker(const std::string &workerName);

        /** m_pages is protected by Guard. @todo static shall be removed after thread implementation. */
        static std::map<std::string, std::string> m_pages;

        /** mutex used by Guard. @todo static shall be removed after thread implementation. */
        static Platform::Mutex<> mutex;
};

}// end of platformTest
#endif //PLATFPRM_TEST_GUARD_INCLUDE_H
