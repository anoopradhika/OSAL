/******************************************************************************//**
* @file MolTest.cpp
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "ModuleRegistrationPanelTest.h"
#include <sys/resource.h>

void ModuleMonitorTest::SetUp()
{
    struct rlimit rlim;
    rlim.rlim_cur = RLIM_INFINITY;
    rlim.rlim_max = RLIM_INFINITY;

    if (setrlimit(RLIMIT_MSGQUEUE, &rlim) == -1) {
    perror("setrlimit");
    }
    panel.Init();
    panel.Prepare();

}


void ModuleMonitorTest::TearDown()
{
    panel.Stop();
    panel.Shutdown();
    panel.Uninit();
}


TEST_F(ModuleMonitorTest, panel)
{
    
   panel.Start();

}
