/******************************************************************************//**
* @file MolTest.cpp
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "ModuleRegistrationModuleTest.h"


void PanelMonitorTest::SetUp()
{
    module.Init();
    module.Prepare();
}

void PanelMonitorTest::TearDown()
{
    module.Stop();
    module.Shutdown();
    module.Uninit();
}


TEST_F(PanelMonitorTest, module)
{
    module.Start();
}
