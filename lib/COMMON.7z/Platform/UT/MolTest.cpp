/******************************************************************************//**
* @file MolTest.cpp
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "MolTest.h"


const PROC_ADDRESS MolSenderTest::publisherId = PROC_ADDRESS::MAINLOOP;
const PROC_ADDRESS MolSubscriberTest::publisherId = PROC_ADDRESS::CMCAPP;


void MolSenderTest::SetUp()
{
    PrepareCommuncator();
    m_startServer = std::make_shared<Mol::Command::StartServer>(Mol::Command::SERVER_TYPE_CODE::FTP);
    m_softwareVersionRequest = std::make_shared<Mol::Request::SoftwareVersion>();
}

void MolSenderTest::PrepareCommuncator()
{
    m_messageTransporter.Prepare(publisherId);
    m_messageTransporter.Connect(MolSubscriberTest::publisherId);
    m_eventCommunicator.Prepare(0);
    m_commandCommunicator.Prepare(0);
    m_requestCommunicator.Prepare(0);
    m_responseCommunicator.Prepare(0);
}


void MolSenderTest::TearDownCommuncator()
{
    m_eventCommunicator.Shutdown();
    m_commandCommunicator.Shutdown();
    m_requestCommunicator.Shutdown();
    m_responseCommunicator.Shutdown();
    m_messageTransporter.Stop();
    m_messageTransporter.Shutdown();

}

void MolSenderTest::receiveAlarmEvent(std::shared_ptr<Mol::Message<EventType>> event, uint64_t DestinationID)
{
    
    std::shared_ptr<Mol::Event::AlarmEvent> alarmEvent = std::static_pointer_cast<Mol::Event::AlarmEvent>(event);
    
    EXPECT_EQ(Mol::Event::EVENT_CATEGORY::ALARM, alarmEvent->GetObjectType());
    std::cout<<"alarmEvent->GetObjectType()= "<<(uint32_t)alarmEvent->GetObjectType()<<std::endl;
    std::cout<<"AlarmEven"<<"\n";
    m_requestCommunicator.Send(m_softwareVersionRequest,MolSubscriberTest::publisherId );
    AlarmEventReceived = true;

}

void MolSenderTest::receiveSoftwareVersionResponse(std::shared_ptr<Mol::Message<ResponseType>> response,uint64_t DestinationID )
{
    
    std::shared_ptr<Mol::Response::SoftwareVersion> softwareVersionResponse = std::static_pointer_cast<Mol::Response::SoftwareVersion>(response);
    
    EXPECT_EQ(Mol::Response::RESPONSE_CATEGORY::SOFTWARE_VERSION, softwareVersionResponse->GetObjectType());
    std::cout<<"softwareVersionResponse->GetObjectType() = "<<(uint32_t)softwareVersionResponse->GetObjectType()<<std::endl;
    std::cout<<"SoftwareVersion response"<<"\n";
    SoftwareVersionResponseReceived = true;
}

void MolSenderTest::TearDown()
{
    TearDownCommuncator();
}


void MolSubscriberTest::SetUp()
{
    PrepareCommuncator();
    m_alarmEvent = std::make_shared<Mol::Event::AlarmEvent>(Mol::Event::ALARM_EVENT_CODE::ALARM);
    m_softwareVersionResponse = std::make_shared<Mol::Response::SoftwareVersion>();

}

void MolSubscriberTest::PrepareCommuncator()
{
    m_messageTransporter.Prepare(publisherId);
    m_messageTransporter.Connect(MolSenderTest::publisherId);
    m_eventCommunicator.Prepare(0);
    m_commandCommunicator.Prepare(0);
    m_requestCommunicator.Prepare(0);
    m_responseCommunicator.Prepare(0);
}


void MolSubscriberTest::TearDownCommuncator()
{
    m_eventCommunicator.Shutdown();
    m_commandCommunicator.Shutdown();
    m_requestCommunicator.Shutdown();
    m_responseCommunicator.Shutdown();
    m_messageTransporter.Stop();
    m_messageTransporter.Shutdown();

}
void MolSubscriberTest::receiveStartServerCommand(std::shared_ptr<Mol::Message<CommandType>> command,uint64_t DestinationID)
{
    
    std::shared_ptr<Mol::Command::StartServer> startServerCommand = std::static_pointer_cast<Mol::Command::StartServer>(command);
    
    EXPECT_EQ(Mol::Command::COMMAND_CATEGORY::START_SERVER, startServerCommand->GetObjectType());
    std::cout<<"startServerCommand->GetObjectType() = "<<(uint32_t)startServerCommand->GetObjectType()<<std::endl;;
    std::cout<<"receiveStartServerCommand"<<"\n";
    m_eventCommunicator.Send(m_alarmEvent,MolSenderTest::publisherId );
    StartServerCommandReceived = true;
}

void MolSubscriberTest::receiveSoftwareVersionRequest(std::shared_ptr<Mol::Message<RequestType>> request,uint64_t DestinationID)
{
    
    std::shared_ptr<Mol::Request::SoftwareVersion> softwareVersionRequest = std::static_pointer_cast<Mol::Request::SoftwareVersion>(request);
    
    EXPECT_EQ(Mol::Request::REQUEST_CATEGORY::SOFTWARE_VERSION, softwareVersionRequest->GetObjectType());
    std::cout<<"softwareVersionRequest->GetObjectType() = "<<(uint32_t)softwareVersionRequest->GetObjectType()<<"\n";
    std::cout<<"SoftwareVersion request"<<"\n";
    m_responseCommunicator.Send(m_softwareVersionResponse,MolSenderTest::publisherId );
    SoftwareVersionRequestReceived = true;
}



void MolSubscriberTest::TearDown()
{
    TearDownCommuncator();
}


TEST_F(MolSenderTest, Send)
{
    m_eventCommunicator.Subscribe<Mol::Event::AlarmEvent>(Mol::Event::EVENT_CATEGORY::ALARM);
    m_eventCommunicator.getService(Mol::Event::EVENT_CATEGORY::ALARM)->Connect(this, &MolSenderTest::receiveAlarmEvent);

    m_responseCommunicator.Subscribe<Mol::Response::SoftwareVersion>(Mol::Response::RESPONSE_CATEGORY::SOFTWARE_VERSION);
    m_responseCommunicator.getService(Mol::Response::RESPONSE_CATEGORY::SOFTWARE_VERSION)->Connect(this, &MolSenderTest::receiveSoftwareVersionResponse);
    
    m_commandCommunicator.Send(m_startServer,MolSubscriberTest::publisherId );
    m_messageTransporter.Start();
    while((SoftwareVersionResponseReceived == false) || (AlarmEventReceived == false) )
    {
        std::cout<<"SoftwareVersionResponseReceived "<<SoftwareVersionResponseReceived<<std::endl;
        std::cout<<"AlarmEventReceived "<<AlarmEventReceived<<std::endl;
        sleep(1);
    }
    m_messageTransporter.Stop();
}

TEST_F(MolSubscriberTest, Receive)
{
    m_commandCommunicator.Subscribe<Mol::Command::StartServer>(Mol::Command::COMMAND_CATEGORY::START_SERVER);
    m_commandCommunicator.getService(Mol::Command::COMMAND_CATEGORY::START_SERVER)->Connect(this, &MolSubscriberTest::receiveStartServerCommand);
    
    m_requestCommunicator.Subscribe<Mol::Request::SoftwareVersion>(Mol::Request::REQUEST_CATEGORY::SOFTWARE_VERSION);
    m_requestCommunicator.getService(Mol::Request::REQUEST_CATEGORY::SOFTWARE_VERSION)->Connect(this, &MolSubscriberTest::receiveSoftwareVersionRequest);

    m_messageTransporter.Start();
    
    while((StartServerCommandReceived == false) || (SoftwareVersionRequestReceived == false) )
    {
        std::cout<<"StartServerCommandReceived "<<StartServerCommandReceived<<std::endl;
        std::cout<<"SoftwareVersionRequestReceived "<<SoftwareVersionRequestReceived<<std::endl;
        sleep(1);
    }
    m_messageTransporter.Stop();
}