
/*****************************************************************//**
 *
 * @file    DEBUGPRINTTest.cpp
 * @brief   DEBUGPRINT test class to test DEBUGPRINT
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#include "DebugPrint/DEBUGPRINT.hpp"
#include "MolFactory/CommandGenerator.h"
#include "gmock/gmock.h"
#include <sstream>
#include "Mol/Commands/SetAlarmSignal.h"
#include "Mol/Commands/Silence.h"
#include "Mol/Commands/ApplyConfiguration.h"
#include "Communicator/Communicator.hpp"



TEST(CommandFactory, SetAlarmSignal)
{
    auto command = Platform::CommandFactory::Create(Mol::Command::COMMAND_CATEGORY::SET_ALARM_SIGNAL,2,Mol::DataType::ObjectReference(1,Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT));
    Platform::SendCommand(command,PROC_ADDRESS::CMCAPP,0);
}



TEST(CommandFactory, Silence)
{
    auto command = Platform::CommandFactory::Create(Mol::Command::COMMAND_CATEGORY::SILENCE,Mol::DataType::ObjectReference(3,Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT));
    Platform::SendCommand(command,PROC_ADDRESS::CMCAPP,0);
}

TEST(CommandFactory, ApplyConfiguration)
{
    auto command = Platform::CommandFactory::Create(Mol::Command::COMMAND_CATEGORY::APPLY_CONFIGURATION,Mol::Command::APPLY_CONFIGURATION_CODE::ALL_CONFIGURATION,Mol::DataType::ObjectReference(3,Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT));
    Platform::SendCommand(command,PROC_ADDRESS::CMCAPP,0);
}

//
// TEST(DEBUGPRINTTest, withoutFormat)
// {
//     std::stringstream outBuffer;
//     auto old = std::cout.rdbuf(outBuffer.rdbuf());
//     using DEBUGPRINT = Platform::DEBUGPRINT;
//
//     DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
//     DEBUGPRINT::SetOutStream(OutStream::STDOUT);
//     DEBUGPRINT(DEBUG_ALL,"blabla");
//     std::cout.rdbuf(old);
//     std::string text = outBuffer.str();
//     EXPECT_NE(text.find(DEBUGPRINT::format("blabla")), std::string::npos);
// }
