#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include "Guard.h"

namespace platformTest
{

std::map<std::string, std::string> Guard::m_pages;
Platform::Mutex<> Guard::mutex;

void Guard::worker(const std::string &workerName)
{
    // simulate a long page fetch
    std::this_thread::sleep_for(std::chrono::seconds(2));
    std::string result = "Test content";

    Platform::Guard guard(mutex);
    m_pages[workerName] = result;
}

void Guard::SetUp()
{
    std::thread thread1(worker, "worker1");
    std::thread thread2(worker, "worker2");
    thread1.join();
    thread2.join();
}

void Guard::TearDown()
{
    
}

/**
Lock and unlock mutex with guard 
*/
TEST_F(Guard, LockAndUnlock)
{

    for (const auto &pair : m_pages) {
        std::cout << pair.first << " => " << pair.second << '\n';
    }
}
}
