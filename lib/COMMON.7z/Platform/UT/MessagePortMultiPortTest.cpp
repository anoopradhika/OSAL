#include"MessagePortMultiPortTest.h"


const Platform::MessagePortID CommunicatorSenderTest::publisherId = Platform::MessagePortID::TEST_ID_ONE;

const uint32_t CommunicatorSenderTest::DATA_ID = 2;

const std::string CommunicatorSenderTest::TEST_DATA = "Message Port Test Data from test one";

const Platform::MessagePortID CommunicatorReceiverTest::publisherId = Platform::MessagePortID::TEST_ID_TWO;

const uint32_t CommunicatorReceiverTest::DATA_ID = 3;

const std::string CommunicatorReceiverTest::TEST_DATA = "Message Port Test Data from test two";

CommunicatorSenderTest::CommunicatorSenderTest():m_MessagePort(Platform::MessagePort::getMessagePort())
{
    
}
void CommunicatorSenderTest::PrepareToSendMessage()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_message.Id = DATA_ID;
    TEST_DATA.copy((char*)m_message.Data,TEST_DATA.length(),0);
}


void CommunicatorSenderTest::PrepareToReceiveMessage()
{
    m_EndPoint = m_MessagePort.Connect(publisherId);
}


void CommunicatorSenderTest::SetUp()
{
    PrepareToSendMessage();
    PrepareToReceiveMessage();
}


void CommunicatorSenderTest::TearDown()
{
    m_MessagePort.Disconnect(publisherId,m_EndPoint);
    m_MessagePort.Shutdown();
}

/**
    Test case to send message from this process
*/
TEST_F(CommunicatorSenderTest, SendAndReceive)
{
    uint32_t count = 0;
    while(true)
    {
        usleep(10);
        m_MessagePort.Send(m_message,sizeof(MessageType));
        ++count;
        std::cout <<"send data "<< m_message.Data<<"\n";
        std::cout << count<<"\n";
        sleep(2);
    }
}


CommunicatorReceiverTest::CommunicatorReceiverTest():m_MessagePort(Platform::MessagePort::getMessagePort())
{
    
}
void CommunicatorReceiverTest::PrepareToSendMessage()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_message.Id = DATA_ID;
    TEST_DATA.copy((char*)m_message.Data,TEST_DATA.length(),0);
}


void CommunicatorReceiverTest::PrepareToReceiveMessage()
{
    m_EndPoint = m_MessagePort.Connect(CommunicatorSenderTest::publisherId);
    m_EndPointSelf = m_MessagePort.Connect(publisherId);
}


void CommunicatorReceiverTest::SetUp()
{
    PrepareToSendMessage();
    PrepareToReceiveMessage();
}


void CommunicatorReceiverTest::TearDown()
{
    m_MessagePort.Disconnect(CommunicatorSenderTest::publisherId,m_EndPoint);
    m_MessagePort.Disconnect(publisherId,m_EndPointSelf);
    m_MessagePort.Shutdown();
}

/**
    Test case to send message from other process
*/
TEST_F(CommunicatorReceiverTest, SendAndReceive)
{
    while(true)
    {

        MessageType messageReceived;
        const int32_t receivedBytes = m_MessagePort.Receive(messageReceived,sizeof(MessageType),Platform::MessagePort::WAIT);
        std::cout << "receivedBytes = "<<receivedBytes<<"\n";
        std::cout << "received data = "<<messageReceived.Data<<"\n";
        std::cout << "received Id = "<<messageReceived.Id<<"\n";
        
        sleep(2);
        m_MessagePort.Send(m_message,sizeof(MessageType));
        usleep(10);
    }
}