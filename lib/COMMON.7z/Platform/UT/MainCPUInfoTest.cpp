#include "gmock/gmock.h"
#include "EventProviderTest.h"
#include "MainCPUInfoTest.h"

TEST(MainCPUInfoUT, TestSetDefaultInfo)
{

    uint64_t sourceID = 0x1000100110100000;
    const std::string ipv6Address ="2001:0db8:85a3:0000:0000:8a2e:0370:7334";
    MainCPUInfoTest testobject{sourceID, ipv6Address};
    EXPECT_TRUE(testobject.TestSetDefaultInfo(sourceID, ipv6Address));
}

TEST(MainCPUInfoUT, TestStartfunction)
{

    uint64_t sourceID = 0x1000100110100000;
    const std::string ipv6Address ="2001:0db8:85a3:0000:0000:8a2e:0370:7334";
    MainCPUInfoTest testobject{sourceID, ipv6Address};
    EXPECT_TRUE(testobject.TestStartfunction());
}

TEST(MainCPUInfoUT, TestComponentLifecycle)
{

    uint64_t sourceID = 0x1000100110100000;
    const std::string ipv6Address ="2001:0db8:85a3:0000:0000:8a2e:0370:7334";
    MainCPUInfoTest testobject{sourceID, ipv6Address};
    EXPECT_TRUE(testobject.TestComponentLifecycle());
}
