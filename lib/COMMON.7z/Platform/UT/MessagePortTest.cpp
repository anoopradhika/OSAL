#include"MessagePortTest.h"


const Platform::MessagePortID MessagePortTest::publisherId = Platform::MessagePortID::TEST_ID_ONE;

const uint32_t MessagePortTest::DATA_ID = 1;

const std::string MessagePortTest::TEST_DATA = "Message Port Test Data";


MessagePortTest::MessagePortTest():m_MessagePort(Platform::MessagePort::getMessagePort())
{
    
}
void MessagePortTest::PrepareToSendMessage()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_message.Id = DATA_ID;
    TEST_DATA.copy((char*)m_message.Data,TEST_DATA.length(),0);
}


void MessagePortTest::PrepareToReceiveMessage()
{
    m_EndPoint = m_MessagePort.Connect(publisherId);
}


void MessagePortTest::SetUp()
{
    PrepareToSendMessage();
    PrepareToReceiveMessage();
}


void MessagePortTest::TearDown()
{
    m_MessagePort.Disconnect(publisherId,m_EndPoint);
    m_MessagePort.Shutdown();
}

/**
    Testcase to test message send and receive method
*/
TEST_F(MessagePortTest, SendAndReceive)
{
    usleep(10);
    m_MessagePort.Send(m_message,sizeof(MessageType));
    usleep(10);
    MessageType messageReceived;
    m_MessagePort.Receive(messageReceived,sizeof(MessageType));
    EXPECT_EQ(m_message.Id,messageReceived.Id);
}