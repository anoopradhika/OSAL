/******************************************************************************//**
* @file MolTest.h
* @brief Test case for model object communication.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/


#include "gtest/gtest.h"

#include "ModuleTest.h"


namespace
{
std::string ModuleIPAddress = "fd00:1:2:3:3b26:6a3a:d54c:4c2f";
}

class PanelMonitorTest: public:: testing::Test
{

public:
    /** Get Communicator */
    PanelMonitorTest() :module(ModuleIPAddress,PROC_ADDRESS::CNE,PROC_ADDRESS::NETWORK)
    {}

    /** A default constructor */
    virtual ~PanelMonitorTest() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();
    ModuleTest module;
private:
    
};
