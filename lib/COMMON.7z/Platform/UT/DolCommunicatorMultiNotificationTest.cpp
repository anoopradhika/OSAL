#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cereal/types/memory.hpp>
#include <cereal/archives/binary.hpp>
#include <sstream>
#include "DolCommunicatorMultiNotificationTest.h"
#include <chrono>

const Platform::MessagePortID RegistrationConfirmationPublisherTest::publisherId = Platform::MessagePortID::TEST_ID_ONE;


const Platform::MessagePortID HeartBeatPublisherTest::publisherId = Platform::MessagePortID::TEST_ID_TWO;

const Platform::MessagePortID RegistrationConfirmationHeartBeatsubscriberTest::publisherId = Platform::MessagePortID::TEST_ID_THREE;

const uint32_t RegistrationConfirmationHeartBeatsubscriberTest::MAX_RECEIVED_COUNT = 2;

RegistrationConfirmationPublisherTest::RegistrationConfirmationPublisherTest():m_MessagePort(Platform::MessagePort::getMessagePort()), m_Communicator(Platform::DolCommunicator<Platform::MessagePort>::getDolCommunicator(m_MessagePort))
{}


void RegistrationConfirmationPublisherTest::SetUp()
{
    PrepareDolCommuncator();
    prepareRegistrationConfirmation();
}

void RegistrationConfirmationPublisherTest::PrepareDolCommuncator()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_Communicator.Prepare();
}


void RegistrationConfirmationPublisherTest::TearDownDolCommuncator()
{
    m_Communicator.Shutdown();
    m_MessagePort.Stop();
    m_MessagePort.Shutdown();
}


void RegistrationConfirmationPublisherTest::prepareLogicalAddress()
{
    logicalAddress = std::make_shared<Dol::Network::LogicalAddress>();
    logicalAddress->setDomainId((uint16_t)40);
    logicalAddress->setModuleId((uint16_t)50);
    logicalAddress->setNodeId((uint16_t)60);
}


void RegistrationConfirmationPublisherTest::prepareRegistrationConfirmation()
{
    prepareLogicalAddress();
    registrationConfirmation = std::make_shared<Dol::Network::RegistrationConfirmation>();
    registrationConfirmation->SetNetworkAddress(logicalAddress);
}


void RegistrationConfirmationPublisherTest::TearDown()
{
    TearDownDolCommuncator();
}


HeartBeatPublisherTest::HeartBeatPublisherTest():m_MessagePort(Platform::MessagePort::getMessagePort()),m_Communicator(Platform::DolCommunicator<Platform::MessagePort>::getDolCommunicator(m_MessagePort))
{}


void HeartBeatPublisherTest::SetUp()
{
    PrepareDolCommuncator();
    prepareHeartBeat();
}


void HeartBeatPublisherTest::prepareLogicalAddress()
{
    logicalAddress.setDomainId(10);
    logicalAddress.setModuleId(20);
    logicalAddress.setNodeId(30);
}


void HeartBeatPublisherTest::prepareHeartBeat()
{
    prepareLogicalAddress();
    heartBeat = std::make_shared<Dol::Network::HeartBeat>();
    heartBeat->SetNetworkAddress(logicalAddress);
}


void HeartBeatPublisherTest::PrepareDolCommuncator()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_Communicator.Prepare();
}


void HeartBeatPublisherTest::TearDownDolCommuncator()
{
    m_Communicator.Shutdown();
    m_MessagePort.Stop();
    m_MessagePort.Shutdown();
}


void HeartBeatPublisherTest::TearDown()
{
    TearDownDolCommuncator();
}


RegistrationConfirmationHeartBeatsubscriberTest::RegistrationConfirmationHeartBeatsubscriberTest():m_MessagePort(Platform::MessagePort::getMessagePort()), m_Communicator(Platform::DolCommunicator<Platform::MessagePort>::getDolCommunicator(m_MessagePort))
{}


void RegistrationConfirmationHeartBeatsubscriberTest::SetUp()
{
    PrepareDolCommuncator();
    domainObjectReceived = 0;
}


void RegistrationConfirmationHeartBeatsubscriberTest::receiveRegistrationConfirmation(std::shared_ptr<Dol::DomainObject> domainObjectBase)
{
    
    std::shared_ptr<Dol::Network::RegistrationConfirmation> registrationConfirmationReceived = std::static_pointer_cast<Dol::Network::RegistrationConfirmation>(domainObjectBase);
    EXPECT_EQ(40, registrationConfirmationReceived->GetNetworkAddress()->getDomainId());
    EXPECT_EQ(50, registrationConfirmationReceived->GetNetworkAddress()->getModuleId());
    EXPECT_EQ(60, registrationConfirmationReceived->GetNetworkAddress()->getNodeId());
    std::cout<<"registrationConfirmationReceived->GetNetworkAddress()->getDomainId() = "<<registrationConfirmationReceived->GetNetworkAddress()->getDomainId()<<"\n";
    std::cout<<"receiveRegistrationConfirmation"<<"\n";
    ++domainObjectReceived;
}


void RegistrationConfirmationHeartBeatsubscriberTest::receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase)
{
    
    std::shared_ptr<Dol::Network::HeartBeat> heartBeatReceived = std::static_pointer_cast<Dol::Network::HeartBeat>(domainObjectBase);
    
    EXPECT_EQ(10, heartBeatReceived->GetNetworkAddress().getDomainId());
    EXPECT_EQ(20, heartBeatReceived->GetNetworkAddress().getModuleId());
    EXPECT_EQ(30, heartBeatReceived->GetNetworkAddress().getNodeId());
    std::cout<<"heartBeatReceived->GetNetworkAddress().getDomainId() = "<<heartBeatReceived->GetNetworkAddress().getDomainId()<<"\n";
    std::cout<<"receiveHeartBeat"<<"\n";
    usleep(100000);
    ++domainObjectReceived;
}


bool RegistrationConfirmationHeartBeatsubscriberTest::isDomainObjectReceived()
{
    return (domainObjectReceived == MAX_RECEIVED_COUNT);
}


void RegistrationConfirmationHeartBeatsubscriberTest::PrepareDolCommuncator()
{
    m_MessagePort.Prepare(Platform::MessagePort::PUBLISH_SUBSCRIBE,publisherId);
    m_Communicator.Prepare();
    heartBeatEndPoint = m_Communicator.Subscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT,HeartBeatPublisherTest::publisherId);
    registrationConfirmationEndPoint = m_Communicator.Subscribe<Dol::Network::RegistrationConfirmation>(Dol::DOMAIN_OBJECT_TYPE::REGISTRATION_CONFIRMATION,RegistrationConfirmationPublisherTest::publisherId);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::REGISTRATION_CONFIRMATION)->Connect(this, &RegistrationConfirmationHeartBeatsubscriberTest::receiveRegistrationConfirmation);
    m_Communicator.getService(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT)->Connect(this, &RegistrationConfirmationHeartBeatsubscriberTest::receiveHeartBeat);
    m_MessagePort.Start();
}


void RegistrationConfirmationHeartBeatsubscriberTest::TearDownDolCommuncator()
{
    m_Communicator.Shutdown();
    m_Communicator.Unsubscribe<Dol::Network::RegistrationConfirmation>(Dol::DOMAIN_OBJECT_TYPE::REGISTRATION_CONFIRMATION,publisherId,registrationConfirmationEndPoint);
    
    m_Communicator.Unsubscribe<Dol::Network::HeartBeat>(Dol::DOMAIN_OBJECT_TYPE::HEARTBEAT,publisherId,heartBeatEndPoint);
    m_MessagePort.Stop();
    m_MessagePort.Shutdown();
}



void RegistrationConfirmationHeartBeatsubscriberTest::TearDown()
{
    TearDownDolCommuncator();
}


TEST_F(RegistrationConfirmationPublisherTest, sendRegistrationConfirmation)
{
    m_Communicator.Send<Dol::Network::RegistrationConfirmation>(registrationConfirmation);
}

TEST_F(HeartBeatPublisherTest, sendHeartBeat)
{
    heartBeat->IncrementTicksSinceStart();
    m_Communicator.Send<Dol::Network::HeartBeat>(heartBeat);
}


TEST_F(RegistrationConfirmationHeartBeatsubscriberTest, receiveRegistrationConfirmationAndHeartBeatNotification)
{
    while(false == isDomainObjectReceived())
    {
        auto start = std::chrono::high_resolution_clock::now();
        std::cout<< "isDomainObjectReceived valid= "<<isDomainObjectReceived()<<"\n";
        sleep(1);
        auto elapsed = std::chrono::high_resolution_clock::now() - start;
        std::cout << "waited for "
        << std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count()
        << " microseconds\n";
    }
}
