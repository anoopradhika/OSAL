#include "ActiveEventReqRepService.h"

TEST_F(ActiveEventReqRepService, Send)
{
        WaitForResult(50000000);
}
