/******************************************************************************//**
* @file MessageTransporterTest.h
* @brief Test case for model object communication with MessageTransporter.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef MESSAGE_TRANSPORTER_TEST_INCLUDE_H
#define MESSAGE_TRANSPORTER_TEST_INCLUDE_H

#include "gmock/gmock.h"

#include "ObjectModelCommunicator/ObjectModelCommunicator.h"
#include "DOL/Network/HeartBeat.h"
#include "DOL/Network/LogicalAddress.h"
#include "Mol/Events/AlarmEvent.h"
#include "MessageTransporter/MessageTransporter.h"

class MessageTransporterTest: public:: testing::Test
{

public:
    /** Get Communicator */
    MessageTransporterTest();

    /** A default constructor */
    virtual ~MessageTransporterTest() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();

    /** Prepare communicators to send and subscribe Model objectsa */
    void PrepareCommuncator();

    /**
        Unsubscribe Model objects
        shutdown Communicator and MessagePort
    */
    void TearDownCommuncator();

    /**
        HeartBeat used for serialization and  deserialization.
        It is used as a DomainObject to send and receive in the test
    */
    std::shared_ptr<Dol::Network::HeartBeat> m_HeartBeat;
    Dol::Network::LogicalAddress networkAddress;
    std::shared_ptr<Mol::Event::AlarmEvent>  m_alarmEvent;
    /**
        MessagePort for Communicator test
    */
    Platform::MessageTransporter& m_messageTransporter;

    /**
        Class under test
    */
    using DOLCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,Dol::DOMAIN_OBJECT_TYPE,Dol::DomainObject>;
    DOLCommunicator& m_dolCommunicator;
    using EventType = Mol::Event::EVENT_CATEGORY;
    using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;
    EventCommunicator& m_eventCommunicator;
    /** Test data */
    static const PROC_ADDRESS publisherId;
private:
    
};

class MessageTransporterSubTest: public:: testing::Test
{

public:
    /** Get Communicator */
    MessageTransporterSubTest() = default;

    /** A default constructor */
    virtual ~MessageTransporterSubTest() = default;

    /** Add test Setup here */
    virtual void SetUp();

    /** Add test cleanup here */
    virtual void TearDown();

    /**
        MessagePort for Communicator test
    */
    Platform::MessageTransporter& m_messageTransporter = Platform::MessageTransporter::GetMessageTransporter();

    /**
        Class under test
    */
    /** Test data */
    static const PROC_ADDRESS publisherId;
    void receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase);
    /**
        subscribe all DOl objects
    */
    void DolSubscription(std::shared_ptr<Platform::Message> message);
    
    /**
        subscribe all Even mol objects
    */
    void MolSubscription(std::shared_ptr<Platform::Message> message);
    
    bool DolMessageReceived = false;
    bool MolMessageReceived = false;
private:
    
};
#endif //MESSAGE_TRANSPORTER_TEST_INCLUDE_H