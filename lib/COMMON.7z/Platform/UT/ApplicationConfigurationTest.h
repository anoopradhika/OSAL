/******************************************************************************//**
* @file ApplicationConfigurationTest.h
* @brief Test case for WatchDog component.
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFPRM_APPLICATION_CONFIGURATION_TEST_H
#define PLATFPRM_APPLICATION_CONFIGURATION_TEST_H

#include "ACT/ACT.hpp"
#include "ApplicationConfiguration/ApplicationConfiguration.h"
#include "ConfigurationInjector/ConfigurationInjector.h"
#include <cereal/archives/json.hpp>
#include <fstream>      // std::ofstreamt

namespace platformTest
{

/**
    MessagePortTest class to test MessagePort functionality
    @todo Add Test for system test(both positive and negative case)
*/
class ApplicationConfigurationTest: public platform::ACT
{
    public:

        /** Get MessagePort */
        ApplicationConfigurationTest()
        {
            m_applicationConfiguration.SetPanelID(m_panelID);
            Platform::CMCConfiguration cmcConf{ m_applicationAddress
                                               , m_brokerAddress
                                               , m_unicastPort
                                               , m_moduleUnicastPort
                                               , m_multicastPort
                                               , m_networkInterface
                                               , m_cmcAppName
                                           };
            m_applicationConfiguration.SetCMCConfiguration(cmcConf);
            // cereal::JSONOutputArchive archive_out(os);
            // archive_out(CEREAL_NVP(m_applicationConfiguration));
        }
        /** Default destructor */
        virtual ~ApplicationConfigurationTest() = default;

        /** Add test Setup here */
        virtual void SetUp()
        {
            Init();
            Prepare();
        }
        // Use for future test
        void PrepareJsonFile()
        {
            std::string json_str = os.str();
            std::ofstream ofs (filename, std::ofstream::out);
            ofs<<json_str;
            std::cout<<"Wirte info \n"<< json_str << std::endl;
            ofs.close();
        }

        // Use for future test
        void DeserialzeTheConfigFile()
        {
            std::ifstream istrm(filename, std::ios::binary);
            istrm.seekg (0, istrm.end);
            int length = istrm.tellg();
            istrm.seekg (0, istrm.beg);
             char * buffer = new char [length];
            istrm.read (buffer,length);

            std::cout<<"Read file info \n" << buffer<< std::endl;

            std::stringstream is(buffer);
            std::shared_ptr<Platform::ApplicationConfiguration> readConfig;
            cereal::JSONInputArchive archive_in(is);
            archive_in(readConfig);
        }

        /** Add test cleanup here */
        virtual void TearDown()
        {
            Platform::ApplicationConfiguration readConfig;
            Platform::ConfigurationInjector::GetInjector(filename).Get(readConfig);
            std::cout<<"PanelID ="<<readConfig.GetPanelID()<<std::endl;
            EXPECT_EQ(m_panelID, readConfig.GetPanelID());
            auto cmcConf = readConfig.GetCMCConfiguration();
            EXPECT_EQ(m_applicationAddress, cmcConf.GetApplicationAddress());
            EXPECT_EQ(m_brokerAddress, cmcConf.GetBrokerAddress());
            EXPECT_EQ(m_unicastPort, cmcConf.GetUnicastPort());
            EXPECT_EQ(m_moduleUnicastPort, cmcConf.GetModuleUnicastPort());
            EXPECT_EQ(m_multicastPort, cmcConf.GetMulticastPort());
            EXPECT_STREQ(m_cmcAppName.c_str(), cmcConf.GetAppName().c_str());
            std::cout<<"GetApplicationAddress = "<<(uint32_t)cmcConf.GetApplicationAddress()<<std::endl;
            std::cout<<"GetBrokerAddress = "<<(uint32_t)cmcConf.GetBrokerAddress()<<std::endl;
            std::cout<<"GetUnicastPort = "<<(uint32_t)cmcConf.GetUnicastPort()<<std::endl;
            std::cout<<"GetModuleUnicastPort = "<<(uint32_t)cmcConf.GetModuleUnicastPort()<<std::endl;
            std::cout<<"GetAppName = "<<cmcConf.GetAppName()<<std::endl;
            std::cout<<"GetNetworkInterfae = "<<cmcConf.GetNetworkInterfae()<<std::endl;
            Stop();
            Shutdown();
            Uninit();
        }
private:
    Platform::ApplicationConfiguration m_applicationConfiguration;
    std::stringstream os;
    std::string filename{"./test.json"};
    const uint64_t m_panelID = 213;
    PROC_ADDRESS m_applicationAddress = PROC_ADDRESS::CMCAPP;
    PROC_ADDRESS m_brokerAddress = PROC_ADDRESS::CCL_BROKER;
    uint16_t m_unicastPort = 8000;
    uint16_t m_moduleUnicastPort = 8000;
    uint16_t m_multicastPort = 9000;
    std::string m_cmcAppName = "CMCAPP";
    std::string m_networkInterface = "eth0";
};

} //end of platformTest

#endif //PLATFPRM_APPLICATION_CONFIGURATION_TEST_H
