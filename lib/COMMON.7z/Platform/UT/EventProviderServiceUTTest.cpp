#include "gmock/gmock.h"
#include "EventProviderTest.h"
#include "RemoteSubscriberChannelUT.h"

TEST(EventProviderServiceUT, PrepareTestValidate)
{

    EventProviderTest testobject{0x1000100110100000};
    EXPECT_TRUE(testobject.PrepareTestValidate());
}

TEST(EventProviderServiceUT, requestWithValidFirstSubscriber)
{

    EventProviderTest testobject{0x1000100110100000};
    EXPECT_TRUE(testobject.requestWithValidFirstSubscriber());
}

TEST(EventProviderServiceUT, requestWithValidSecondSubscriber)
{

    EventProviderTest testobject{0x1000100110100000};
    EXPECT_TRUE(testobject.requestWithValidSecondSubscriber());
}

TEST(EventProviderServiceUT, constructInvalidParameterTest)
{
    EXPECT_THROW({
        try
        {
            //this Shall Throw
            EventProviderTest testobject{0x00};
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::INVALID_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}


TEST(EventProviderServiceUT, constructValidParameterTest)
{
    EXPECT_NO_THROW(EventProviderTest{0x1000100110100000});
}

TEST(EventProviderServiceUT, requestExternalPanalIDTest)
{
    EXPECT_THROW({
        try
        {
            EventProviderTest testobject{0x1000100110100000};
            //this Shall Throw
            testobject.requestExternalPanalIDTest(0x2000200110100000);
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::INVALID_DEVICE_ID,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderServiceUT, requestWithNullRequestObjectTest)
{
    EXPECT_THROW({
        try
        {
            EventProviderTest testobject{0x1000100110100000};
            testobject.requestWithNullRequestObjectTest();
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::NULL_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, constructNullCommunicatorParameterTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    std::shared_ptr<Platform::Communicator> communicator{};
    EXPECT_THROW({
        try
        {
            RemoteSubscriberChannelUT testobject(channelID, communicator);
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::NULL_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, constructInvalidChannelIDParameterTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100010100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    std::shared_ptr<Platform::Communicator> communicator{};
    EXPECT_THROW({
        try
        {
            RemoteSubscriberChannelUT testobject(channelID, communicator);
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::INVALID_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestInvalidRequstTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.ServiceRequestNullRequst();
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::NULL_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestInvalidchannelIDTest)
{
    Mol::DataType::ObjectReference channelID1 = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    Mol::DataType::ObjectReference channelID2 = { 0x2000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID1, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.ServiceRequestInvalidchannelID(channelID2);
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::INVALID_DEVICE_ID,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestValidchannelIDTest)
{
    try
    {
        Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
        RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
        //it may throw
        testobject.ServiceRequestValidchannelID(channelID);
    }
    catch (Platform::ERROR& error)
    {
        //but not these to exceptions below
        EXPECT_NE(Platform::ERROR::INVALID_DEVICE_ID,error);
        EXPECT_NE(Platform::ERROR::INVALID_PARAMETER,error);
    }
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestStartCommTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            EXPECT_TRUE(testobject.ServiceRequestStartCommTest(channelID));
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::SEND_ERROR,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestGetEventAndCommNotStartedTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW(testobject.ServiceRequestGetEventAndCommNotStartedTest(channelID));
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestGetEventActiveEvent)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.ServiceRequestGetEventActiveEvent(channelID);
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::SEND_ERROR,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ServiceRequestGetEventFromEventLog)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.ActiveEventGetEventTestNullMessage();
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::NULL_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ActiveEventGetFirstEventTestNotValideRequest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.ActiveEventGetEventTestNotValideRequest();
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::INVALID_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ActiveEventGetFirstEventTestNotValideTarget)
{
    Mol::DataType::ObjectReference channelID1 = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    Mol::DataType::ObjectReference channelID2 = { 0x2000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID1, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.ActiveEventGetEventTestNotValideTarget(channelID2);
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::INVALID_DEVICE_ID,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, ActiveEventGetEventTestNotValideTarget)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW(testobject.ActiveEventGetEventTestNotValideTarget(channelID));
}

TEST(EventProviderRemoteSubscriberChannelUT, ActiveEventGetEventTestNotSuccessResponse)
{
    try
    {
        Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
        RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
        EXPECT_TRUE(testobject.ActiveEventGetEventTestNotSuccessResponse(channelID));
    }
    catch (Platform::ERROR& error)
    {
        EXPECT_NE(Platform::ERROR::NULL_PARAMETER,error);
        EXPECT_NE(Platform::ERROR::INVALID_PARAMETER,error);
        EXPECT_NE(Platform::ERROR::INVALID_DEVICE_ID,error);
    }
}

TEST(EventProviderRemoteSubscriberChannelUT, ActiveEventGetEventTestValdResponse)
{
    try
    {
        Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
        RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
        EXPECT_TRUE(testobject.ActiveEventGetEventTestValdResponse(channelID));
    }
    catch (Platform::ERROR& error)
    {
        EXPECT_NE(Platform::ERROR::NULL_PARAMETER,error);
        EXPECT_NE(Platform::ERROR::INVALID_PARAMETER,error);
        EXPECT_NE(Platform::ERROR::INVALID_DEVICE_ID,error);
    }
}

TEST(EventProviderRemoteSubscriberChannelUT, ClearParametersTestValdate)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.ClearParametersTestValdate());});
}

TEST(EventProviderRemoteSubscriberChannelUT, PrintResponseTestEmptylMessage)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.PrintResponseTestEmptylMessage();
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::NULL_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, PrintResponseTestNotValidlMessage)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_THROW({
        try
        {
            testobject.PrintResponseTestNotValidlMessage();
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::NULL_PARAMETER,error);
            throw;
        }
    }, Platform::ERROR );
}

TEST(EventProviderRemoteSubscriberChannelUT, PrintResponseTestValidlMessage)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW(testobject.PrintResponseTestValidlMessage(););
}

TEST(EventProviderRemoteSubscriberChannelUT, BufferNewEventTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferNewEventTest1());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferNewEventTest2());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferNewEventTest3());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferNewEventTest4());});
}

TEST(EventProviderRemoteSubscriberChannelUT, BufferEventTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferEventTest1());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferEventTest2());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.BufferEventTest3());});
}

TEST(EventProviderRemoteSubscriberChannelUT, UpdateEventsTimerTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.UpdateEventsTimerTest1());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.UpdateEventsTimerTest2());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.UpdateEventsTimerTest3());});
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.UpdateEventsTimerTest4());});
}

TEST(EventProviderRemoteSubscriberChannelUT, SendBufferedEventsTest)
{
    Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    RemoteSubscriberChannelUT testobject(channelID, std::make_shared< Platform::Communicator>(Platform::Communicator{}));
    EXPECT_NO_THROW({EXPECT_TRUE(testobject.SendBufferedEventsTest1());});
    EXPECT_THROW({
        try
        {
            EXPECT_TRUE(testobject.SendBufferedEventsTest2());
        }
        catch(Platform::ERROR& error)
        {
            // with this particular value
            EXPECT_EQ(Platform::ERROR::SEND_ERROR,error);
            throw;
        }
    }, Platform::ERROR );
}
