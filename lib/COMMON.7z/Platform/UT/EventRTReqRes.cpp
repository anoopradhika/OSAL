#include "EventRTReqRes.h"

TEST_F(ERTSenderApplication, Send)
{
        WaitForResult(50000000);
}
