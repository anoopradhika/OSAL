#include "Application/Application.h"
#include "Mol/Events/AlarmEvent.h"
#include "ACT/ACT.hpp"
#include "CommonDef.h"
#include "Mol/Requests/EventRouterService.h"
#include "Mol/Responses/EventRouterService.h"

class ERTSenderApplication: public platform::ACT
{
public:
    ERTSenderApplication():platform::ACT(m_address,sourceID)
    {
    }
    virtual ~ERTSenderApplication() = default;

    virtual void SetUp()
    {

        Init();
        Prepare();
    }

    virtual void TearDown()
    {
        Stop();
        Shutdown();
        Uninit();
    }

    virtual void Prepare() override
    {
       m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENTLOGAPP);

       m_communicator.m_response.Subscribe<Mol::Response::EventRouterService>(Mol::Response::RESPONSE_CATEGORY::EVENT_ROUTER_SERVICE);
       m_communicator.m_response.getService(Mol::Response::RESPONSE_CATEGORY::EVENT_ROUTER_SERVICE)->Connect(this, &ERTSenderApplication::EventResponseReceived);

       platform::ACT::Prepare();
    }

    void EventResponseReceived(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> message, uint64_t senderId)
    {
        std::cout << "SendEvent.h: EventResponseReceived\n";
        Terminate();
    }

    virtual void Start() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this,&ERTSenderApplication::SentEventRTRequest);
        m_timer = Platform::Timer<>(1000,GlobalDataType::Timer::AlarmType::PERIODIC,notifier);
        m_timer.Start();
        std::cout << "SendEvent.h: Conect tot timer\n";
        platform::ACT::Start();
    }


    virtual void Shutdown() override
    {
        m_timer.Stop();
        m_timer.Shutdown();
       platform::ACT::Shutdown();
       m_communicator.m_messageTransporter.Disconnect(PROC_ADDRESS::EVENTLOGAPP);
    }

    void SentEventRTRequest()
    {
        std::cout << "SendEvent.h: SendEventRTRequest\n";
        auto message = std::make_shared<Mol::Request::EventRouterService>(Mol::Request::EVENT_ROUTER_SERVICE_CODE::ADD);
        auto source = Mol::DataType::ObjectReference{sourceID,Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE};
        message->SetSourceTarget(source);
        m_communicator.m_request.Send(message,PROC_ADDRESS::EVENTLOGAPP,0);
        //Platform::this_thread::Sleep(10);
    }

protected:
    static constexpr PROC_ADDRESS m_sendAddress =  PROC_ADDRESS::EVENTLOGAPP;
    static constexpr  PROC_ADDRESS m_address = PROC_ADDRESS::CMCAPP;
    static constexpr  uint64_t sourceID = 0x0100010200000000;
    std::vector<Platform::Notifier> m_sendEvents{};
    /** MessagePort for testing */
    Platform::Timer<> m_timer;

};
