#include "gtest/gtest.h"
#include "boost/sml.hpp"
#include <iostream>
#include <memory>
#include <string>
#include <vector>

// State machine events
struct timeout{};
struct SendFileEvent{};
struct FileTransferSuccess{};
struct FileTransferFailure{};
struct StopServerEvent{};
struct InvalidParameters{};
struct StartServerEvent
{
uint64_t m_targetId;
std::shared_ptr<int> msg;
std::string m_ipAddr;
std::string m_username;
std::string m_passwd;
std::int32_t numberOfFiles;
std::vector<std::string> vectorString;
};
namespace sml = boost::sml;
struct FileTransferCommand{};
struct ServerStatus{};
//struct InvalidParameters{};
/**

@brief FileTransferStateMachine class
State Machine for File Transfer client
*/
struct FileTransferStateMachine
{
public:

    FileTransferStateMachine()
    {
        std::cout<<"===FileTransferStateMachine"<<std::endl;
    }
    ~FileTransferStateMachine()
    {
        std::cout<<"~FileTransferStateMachine"<<std::endl;
    }
    FileTransferStateMachine(FileTransferStateMachine&& other)
    {
        std::cout<< "I am being moved FileTransferStateMachine&& other"<<std::endl;
    }
    
    FileTransferStateMachine(const FileTransferStateMachine&other)
    {
        std::cout<< "I am being moved FileTransferStateMachine&other"<<std::endl;
    }
/**

@brief Overloaded Operator() for state machine. Please refer boost::sml for more info
*/
auto operator()() 
{
using namespace boost::sml;
// Command to module to start server
auto SendStartServer = [this](const StartServerEvent& message)
{
    m_ipAddr = message.m_ipAddr;

    m_files = message.vectorString;
    m_username = message.m_username;
    m_passwd = message.m_passwd;
    m_targetId = message.m_targetId;
    for(auto n : m_files)
    {
        std::cout<<n<<std::endl;
    }
    std::cout<<"m_username "<<m_username<<std::endl;
    std::cout<<"m_passwd "<<m_passwd<<std::endl;
    std::cout<<"m_targetId "<<m_targetId<<std::endl;
    std::cout<<"m_ipAddr "<<m_ipAddr<<std::endl;

};

// Send Server start failure
const auto SendFailure = [this] ()
{

};


// Send file send success
const auto SendSuccess = [this] ()
{
};

// Send stop server command to module
const auto SendStopServer = [this] ()
{

};

// Transfer File
const auto SendFile = [this]()
{

};


/*
@startuml
title File Transfer Client State machine
StartServer : SendStartServer
StartServer : CheckParameters
FileTransfer : Send File
FileTransfer : SendTransferStatus
ServerStarted : Start transfer
StopServer : SendStopServerCommand

[*] right> Disconnected
Disconnected down> StartServer : FileTransferCommand
StartServer down> FileTransfer : SendFileEvent/SendFile
FileTransfer right> StopServer : FileTransferSuccess
FileTransfer right> StopServer : FileTransferFailure
StopServer --> Disconnected : StopServerEvent
Disconnected --> X : timeout
@enduml
*/

return make_transition_table(
*"Disconnected"_s + event<StartServerEvent> / SendStartServer = "StartServer"_s
,"StartServer"_s + event<SendFileEvent> / SendFile = "FileTransfer"_s
,"FileTransfer"_s + event<FileTransferSuccess> / SendSuccess = "StopServer"_s
,"FileTransfer"_s + event<FileTransferFailure> / SendFailure = "StopServer"_s
,"StopServer"_s + event<StopServerEvent> / SendStopServer = "Disconnected"_s
,"Disconnected"_s + event<timeout> =  X
);
}

std::vector<std::string> m_files;
// Server ip address
std::string m_ipAddr = "";
std::string m_username = "anonymous";
std::string m_passwd = "";
uint64_t m_targetId = 0;
};






TEST(BoostSMlTest, run)
{
//int xyz = 110;
FileTransferStateMachine fileTransferStateMachine{};
    sml::sm<FileTransferStateMachine> sm{fileTransferStateMachine};
    StartServerEvent testdata{}; // = std::make_shared<StartServerEvent>();
    auto testptr = std::make_shared<int>(5);
    testdata.msg = testptr;
    testdata.m_targetId = 10;
    testdata.m_ipAddr = "124::345";
    testdata.vectorString.emplace_back("2222");
    testdata.vectorString.emplace_back("33333333333");
    testdata.vectorString.emplace_back("66666666666666");
    testdata.m_username = "2255";
    testdata.m_passwd = "nopasswd";
    sm.process_event(testdata);
    sm.process_event(SendFileEvent{});
    sm.process_event(FileTransferSuccess{});
    sm.process_event(StopServerEvent{});
    sm.process_event(timeout{});
   EXPECT_EQ(true, sm.is(sml::X));
}