/******************************************************************************//**
* @file MainCPUInfoTest.h
* @brief Test case verify EventProviderService Class.
*
* @copyright Copyright 2020 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_TEST_MAIN_CPU_INFO_H
#define PLATFORM_TEST_MAIN_CPU_INFO_H

#include "MainCPUinfo/MainCPUinfo.h"

class MainCPUInfoTest : public Platform::MainCPUinfo
{
public:
    MainCPUInfoTest(uint64_t sourceID, const std::string& ipv6Address):
        MainCPUinfo(sourceID,ipv6Address)
    {

    }
    ~MainCPUInfoTest() override = default;

    bool TestSetDefaultInfo(uint64_t sourceID, const std::string& ipv6Address)
    {
        Dol::Entities::SemanticVersion defaultVersion;
        defaultVersion.SetGitHash(GIT_VERSION);
        if(nullptr == m_mainCPUModule)
        {
            return false;
        }
        if(m_mainCPUModule->GetIpv6Address() != ipv6Address)
        {
            return false;
        }
        if(m_mainCPUModule->GetHardwareVersion() != MainCPUinfo::DEFAULT_32BIT_VALUE)
        {
            return false;
        }
        if(m_mainCPUModule->GetSerialNumber() != MainCPUinfo::DEFAULT_32BIT_VALUE)
        {
            return false;
        }
        if(m_mainCPUModule->GetID() != sourceID)
        {
            return false;
        }
        if(m_mainCPUModule->GetType() != Dol::Entities::Module::MODULE_TYPE::MAINCPU)
        {
            return false;
        }
        if(m_mainCPUModule->GetLabel().empty())
        {
            return false;
        }
        if(m_mainCPUModule->GetModuleStatus() != Dol::Entities::Module::Status::NORMAL_OPERATION)
        {
            return false;
        }
        if((nullptr == m_mainCPUModule->GetConfigurationVersion()) || (*m_mainCPUModule->GetConfigurationVersion() != defaultVersion))
        {
            return false;
        }
        if((nullptr == m_mainCPUModule->GetSoftwareVersion()) || (*m_mainCPUModule->GetSoftwareVersion() != defaultVersion))
        {
            return false;
        }
        return true;
    }

    bool TestStartfunction()
    {
        SendInformationEvent();
        return true;
    }

    bool TestComponentLifecycle()
    {
        Init();
        Prepare();
        Start();
        Stop();
        Shutdown();
        Uninit();
        return(true);
    }

};
#endif //PLATFORM_TEST_MAIN_CPU_INFO_H
