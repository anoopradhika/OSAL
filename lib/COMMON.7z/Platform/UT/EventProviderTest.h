/******************************************************************************//**
* @file EventProviderTest.h
* @brief Test case verify EventProviderService Class.
*
* @copyright Copyright 2019 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_TEST_EVENTPROVIDER_SERVICE_H
#define PLATFORM_TEST_EVENTPROVIDER_SERVICE_H

#include "EventProvider/EventProviderService.h"
#include "Mol/Commands/Deactivate.h"
#include "GlobalDataType/Error.h"

class EventProviderTest : public Platform::EventProviderService
{
public:
    EventProviderTest(uint64_t id):
        EventProviderService(id)
    {

    }
    ~EventProviderTest() override = default;

    void requestExternalPanalIDTest(uint64_t id)
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST);
        EventProviderServiceRequest(req, id);
    }

    void requestWithNullRequestObjectTest()
    {
        EventProviderServiceRequest(nullptr, 0x1000100110100000);
    }

    bool requestWithValidFirstSubscriber()
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST);
        Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
        req->SetSourceTarget(channelID);
        EventProviderServiceRequest(req, 0x1000100110100000);
        return (!m_commsSubscriber.empty());
    }

    bool requestWithValidSecondSubscriber()
    {
        auto req = std::make_shared<Mol::Request::EventProviderService>(Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST);
        Mol::DataType::ObjectReference channelID = { 0x1000100110100000, Dol::DOMAIN_OBJECT_TYPE::INVALID };
        req->SetSourceTarget(channelID);
        EventProviderServiceRequest(req, 0x1000100110100000);
        EventProviderServiceRequest(req, 0x1000100110100000);
        return (!m_commsSubscriber.empty());
    }

    bool PrepareTestValidate()
    {
        bool val = false;
        Init();
        Prepare();
        val = m_communicator.m_request.getService(Mol::Request::REQUEST_CATEGORY::EVENT_PROVIDER_SERVICE_REQUEST) && m_communicator.m_request.getService(Mol::Request::REQUEST_CATEGORY::EVENT_PROVIDER_SERVICE_REQUEST);
        Start();
        Stop();
        Shutdown();
        Uninit();
        return(val);
    }
    private:

};
#endif //PLATFORM_TEST_EVENTPROVIDER_SERVICE_H
