#ifndef COMMUNICATOR_TEST_INCLUDE_H
#define COMMUNICATOR_TEST_INCLUDE_H

#include "gmock/gmock.h"

#include "DolCommunicator/DolCommunicator.h"
#include "dol/network/HeartBeat.h"
#include "dol/network/RegistrationConfirmation.h"
#include "dol/network/LogicalAddress.h"
#include "MessagePort/MessagePort.h"


class RegistrationConfirmationPublisherTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        RegistrationConfirmationPublisherTest();

        /** A default constructor */
        virtual ~RegistrationConfirmationPublisherTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare RegistrationConfirmation class with test data */
        void prepareRegistrationConfirmation();

        /** Prepare LogicalAddress class with dummy test data */
        void prepareLogicalAddress();

        /**
            Prepare MessagePort
            Subscribe FIRE_INCIDENT with publisherId
        */
        void PrepareDolCommuncator();

        /**
            Unsubscribe FIRE_INCIDENT
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        std::shared_ptr<Dol::Network::RegistrationConfirmation> registrationConfirmation;

       /**
            MessagePort for Communicator test
        */
        Platform::MessagePort& m_MessagePort; 

        /**
            Class under test
        */
        Platform::DolCommunicator<Platform::MessagePort>& m_Communicator;

 
        /** Test data */
        static const Platform::MessagePortID publisherId;

    private:
        /** endPoint ID on subscription */
        int32_t endPoint;

        /**
            Logical address  used here is
            a dummy test data
        */
        std::shared_ptr<Dol::Network::LogicalAddress> logicalAddress;
};

class HeartBeatPublisherTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        HeartBeatPublisherTest();

        /** A default constructor */
        virtual ~HeartBeatPublisherTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare HeartBeat class with test data */
        void prepareHeartBeat();

        /** Prepare LogicalAddress class with dummy test data */
        void prepareLogicalAddress();

        /**
            Prepare MessagePort
            Subscribe FIRE_INCIDENT with publisherId
        */
        void PrepareDolCommuncator();

        /**
            Unsubscribe FIRE_INCIDENT
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        /**
            Class under test
        */
        std::shared_ptr<Dol::Network::HeartBeat> heartBeat;

        /**
            MessagePort for Communicator test
        */
        Platform::MessagePort& m_MessagePort;

        Platform::DolCommunicator<Platform::MessagePort>& m_Communicator;

        /** Test data */
        static const Platform::MessagePortID publisherId;

    private:
        /** endPoint ID on subscription */
        int32_t endPoint;

        /**
            Logical address  used here is
            a dummy test data
        */
        Dol::Network::LogicalAddress logicalAddress;
};

class RegistrationConfirmationHeartBeatsubscriberTest: public:: testing::Test
{
  
    public:
        /** Get Communicator */
        RegistrationConfirmationHeartBeatsubscriberTest();

        /** A default constructor */
        virtual ~RegistrationConfirmationHeartBeatsubscriberTest() = default;

        /** Add test Setup here */
        virtual void SetUp();

        /** Add test cleanup here */
        virtual void TearDown();

        /** Prepare FireDetectionDevice class with test data */
        void prepareFireDetectionDevice();
        
        /** Prepare FireIncident class with test data */
        void prepareFireIncident();

        /**
            Prepare MessagePort
            Subscribe FIRE_INCIDENT with publisherId
        */
        void PrepareDolCommuncator();

        /**
            Unsubscribe FIRE_INCIDENT
            shutdown Communicator and MessagePort
        */
        void TearDownDolCommuncator();

        /**
            Check whether a DomainObject is received and 
            verified. It is used for terminate a test 
            @return True on DomainObject received. 
        */
        bool isDomainObjectReceived();

        std::shared_ptr<Dol::Network::HeartBeat> heartBeat;
        std::shared_ptr<Dol::Network::RegistrationConfirmation> registrationConfirmation;

        /**
            MessagePort for Communicator test
        */
        Platform::MessagePort& m_MessagePort;

        /**
            Class under test
        */
        Platform::DolCommunicator<Platform::MessagePort>& m_Communicator;

        /** Test data */
        static const uint32_t SensitivityProfileId; 

        /** Test data */        
        static const Platform::MessagePortID publisherId;
        
        static const uint32_t MAX_RECEIVED_COUNT;

    private:

        
        /** True on reception of DomainObject */
        uint32_t domainObjectReceived;

        /**
            Service connected to receive DomainObject
            @param domainObjectBase: DomainObject shared pointer
        */
        void receiveRegistrationConfirmation(std::shared_ptr<Dol::DomainObject> domainObjectBase);

        /**
            Service connected to receive DomainObject
            @param domainObjectBase: DomainObject shared pointer
        */
        void receiveHeartBeat(std::shared_ptr<Dol::DomainObject> domainObjectBase);


        /** endPoint ID on subscription */
        int32_t heartBeatEndPoint;
        int32_t registrationConfirmationEndPoint;
};

#endif //COMMUNICATOR_TEST_INCLUDE_H
