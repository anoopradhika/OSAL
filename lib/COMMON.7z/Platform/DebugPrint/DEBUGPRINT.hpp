
/*****************************************************************//**
 *
 * @file    DEBUGPRINT.hpp
 * @brief   DEBUGPRINT class used of print formatting.
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#ifndef PLATFORM_DEBUGPRINT_INCLUDE_H
#define PLATFORM_DEBUGPRINT_INCLUDE_H

#include "DEBUGPRINT/DEBUGPRINT.h"
#include "Config/Config.h"

namespace Platform
{
/**
    @brief  Class to print debug log
            it is also use for string formating.
*/
class DEBUGPRINT
{
public:
    /**
        @brief Constructor print format along with argument
        @param debugLevel level set is checked against default level
                if set level is less than default level, it is discarded
        @param format format of argument to be printed
        @param args argument to print
    */
    template <typename... Args>
    DEBUGPRINT(DebugLevel debugLevel, std::string format, const Args & ... args):
    m_debugPrint(debugLevel,format,args...)
    {
    }

    /**
        @brief Constructor print strings
        @param debugLevel level set is checked against defalt level
                if set level is less tha defalt level, it is discarded
        @param argument strint to print
    */
    DEBUGPRINT(DebugLevel debugLevel, std::string argument):
    m_debugPrint(debugLevel,"%s",argument.c_str())
    {
    }

    DEBUGPRINT(DEBUGPRINT& other) = delete;

    DEBUGPRINT(DEBUGPRINT&& other) = delete;

    ~DEBUGPRINT() = default;

    /**
        @brief format arguments to specified format
        @param format: format information for arguments
        @param args: arguments
        @return formatted string
    */
    template <typename... Args>
    static std::string format(const std::string& format, const Args & ... args)
    {
        return PlatformNative::DEBUGPRINT::format(format,args...);
    }

    /**
        @brief Set the debugLevel only once
        @param debugLevel: Default debug level
    */
    static void SetDebugLevel(DebugLevel debugLevel)
    {
       PlatformNative::DEBUGPRINT::SetDebugLevel(debugLevel);
    }

    /**
        @brief Set the OutStream only once
        @param outStream: Default outStream
    */
    static void SetOutStream(OutStream outStream)
    {
       PlatformNative::DEBUGPRINT::SetOutStream(outStream);
    }

    /**
        @brief Get the debugLevel
    */
    static DebugLevel GetDebugLevel()
    {
       return PlatformNative::DEBUGPRINT::GetDebugLevel();
    }

private:
    PlatformNative::DEBUGPRINT m_debugPrint;
};

}
#endif //PLATFORM_DEBUGPRINT_INCLUDE_H
