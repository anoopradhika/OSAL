/*****************************************************************//**
 *
 * @file ShutdownMonitor.h
 * @brief ShutdownMonitor to monitor and trigger shutdown activity.
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_SHUTDOWN_MONITOR_INCLUDE_H
#define PLATFORM_SHUTDOWN_MONITOR_INCLUDE_H

#include"Component/Component.h"
#include"Looper/Looper.hpp"
#include <execinfo.h>
#include <csignal>
#include "Signals/Delegate.h"
#include "Signals/Signal.h"
#include <stdint.h>
namespace Platform
{
/**
 *  @brief ShutdownMonitor wait from termination signal from systemd
 */

class ShutdownMonitor: public Platform::Component
{
public:
   explicit ShutdownMonitor(std::shared_ptr<Platform::Looper> looper): m_looper(looper)
    {
        //Signal to catch SIGTERM - shutdown signal from systemd
        SignalShutDown.Connect(this,&ShutdownMonitor::TriggerTermination);
        signal(SIGTERM,ShutDownSignalHandler);
        AttachSegmentFaultHandler();
    }
    virtual ~ShutdownMonitor() = default;
    virtual void Start() override;
    void AttachSegmentFaultHandler( void );
    static Gallant::Signal0<void> SignalShutDown;
    static const std::string  m_SigfaultLogFile;
	
	static const uint32_t ARRAY_SIZE = 50;
	
protected:
    static void CriticalErrorHandler(int sig_num, siginfo_t * info, void * ucontextParam);
    static void ShutDownSignalHandler(int sig_num);
    void TriggerTermination();
    std::shared_ptr<Platform::Looper> m_looper;
};

} //end of Platfrom

#endif //PLATFORM_SHUTDOWN_MONITOR_INCLUDE_H
