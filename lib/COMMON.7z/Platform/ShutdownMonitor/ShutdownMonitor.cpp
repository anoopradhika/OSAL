/*****************************************************************//**
 *
 * @file ShutdownMonitor.h
 * @brief ShutdownMonitor to monitor and trigger shutdown activity.
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include"Watchdog/Watchdog.h"
#include"ShutdownMonitor/ShutdownMonitor.h"
#include "Utility.h"
#include <unistd.h>

namespace Platform
{
 Gallant::Signal0<void> ShutdownMonitor::SignalShutDown;
const std::string  ShutdownMonitor::m_SigfaultLogFile{"/userdata/segfault.txt"};
void ShutdownMonitor::Start()
{

    Platform::Component::Start();
}


void ShutdownMonitor::ShutDownSignalHandler(int sig_num)
{
    SignalShutDown();
}


void ShutdownMonitor::TriggerTermination()
{
    m_looper->Terminate();
}

void ShutdownMonitor::AttachSegmentFaultHandler( void )
{
    struct sigaction sigact;

    static const int all_signals[] = {
            SIGXFSZ, //File size limit exceeded (4.2BSD);
            SIGXCPU, //CPU time limit exceeded (4.2BSD);
            SIGSYS, //Bad system call (SVr4);
            SIGBUS, //Bus error (bad memory access)
            SIGTERM // Termination signal
            //SIGABRT, //Abort signal from abort(3)
            //SIGFPE, //Floating-point exception
            //SIGILL, //Illegal Instruction
            //SIGSEGV, //Invalid memory reference
    };

    sigact.sa_sigaction = CriticalErrorHandler;
    sigact.sa_flags = (uint32_t)SA_RESTART | (uint32_t)SA_SIGINFO;
    DEBUGPRINT(DEBUG_INFO,"ShutdownMonitor:PSU: AttachSegmentFaultHandler");
    for(unsigned int i = 0; i < sizeof(all_signals)/sizeof(int); i++)
    {
        if ((sigaction(all_signals[i], &sigact, (struct sigaction *)nullptr) != 0) )
        {
            DEBUGPRINT(DEBUG_ERROR,"ShutdownMonitor::error setting signal handler for[{0}:{1}]",strsignal(all_signals[i]),all_signals[i]);
            exit(EXIT_FAILURE);
        }
        DEBUGPRINT(DEBUG_INFO,"ShutdownMonitor::setting signal handler for[{0}:{1}]",strsignal(all_signals[i]),all_signals[i]);
    }
}

void ShutdownMonitor::CriticalErrorHandler(int sig_num, siginfo_t * info, void * ucontextParam)
{
		void *             caller_address;
		ucontext_t* uc = (ucontext_t *)ucontextParam;

#if defined( __i386) || defined (__i386__) || defined(__ia64) || defined(__ia64__)
			/* Get the address at the time the signal was raised from the EIP (x86) */
			caller_address = (void *) uc->uc_mcontext.gregs[REG_EIP];
#elif defined(__x86_64__) || defined(__x86_64__)
			/* Get the address at the time the signal was raised from the RIP (x64) */
			caller_address = (void *) uc->uc_mcontext.gregs[REG_RIP];
#else
			/* Get the address at the time the signal was raised from the ARM () */
			caller_address = (void *) uc->uc_mcontext.arm_pc;
#endif

    	void* array[ARRAY_SIZE];
    	std::stringstream logbuff;
    	logbuff<<"\n=============================================================================================================================\n";
    	logbuff<<"Segmentation Fault : signal "<<sig_num<<"("<<strsignal(sig_num)<<")"<<", address is "<<info->si_addr<<" from "<<(void *)caller_address<<"\n";
    	logbuff<<"Find more details in "<<m_SigfaultLogFile.c_str();
    	logbuff<<"\n=============================================================================================================================\n";
		int size = backtrace(array, ARRAY_SIZE);
		/* overwrite sigaction with caller's address */
		array[1] = caller_address;
		if (Utility::IsSymlinkOrHardlink(m_SigfaultLogFile))
		{
			DEBUGPRINT(DEBUG_ERROR, "ShutdownMonitor::CriticalErrorHandler: [{0}] is a Symlink or Hardlink", m_SigfaultLogFile);

			return;
		}
		int fileDescriptor = open( m_SigfaultLogFile.c_str(), O_CREAT | O_APPEND | O_RDWR, S_IRUSR | S_IWUSR  | S_IRGRP  | S_IWGRP );  /* Replaced octal value '0660' to decimal value '432' i.e 400 | 200 | 40 |20 | 4| 2 */

		if( fileDescriptor >= 0 )
		{
			logbuff<<"\n"<<Utility::CurrentDateTime().c_str()<<":Starting New Fault Log\n";
			if (-1 == write(fileDescriptor, logbuff.str().c_str(),logbuff.str().size()))
			{
				DEBUGPRINT(DEBUG_ERROR, "Failed to write in %s", m_SigfaultLogFile.c_str());
			}
			backtrace_symbols_fd( array, size, fileDescriptor);
			close( fileDescriptor );
		}


    if(  SIGSYS == sig_num
      || SIGBUS == sig_num
      || SIGABRT == sig_num
	  ||SIGILL == sig_num
      || SIGSEGV == sig_num
      || SIGTERM == sig_num)
      {
        exit(EXIT_FAILURE);
      }
    else
    {
        /* code */
    }
}

} // end of Platform
