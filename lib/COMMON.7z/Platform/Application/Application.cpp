/*****************************************************************//**
 *
 * @file Application.cpp
 * @brief All SW Application shall be derived from Application class
 *
 * @copyright Copyright 2017 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#include "Application.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "Guard/Guard.hpp"

#include "Mol/Commands/CommandCategory.h"
#include "Mol/Events/EventCategory.h"
#include "Mol/Requests/RequestCategory.h"
#include "Mol/Responses/ReponseCategory.h"
#include "DOL/DomainObject/DomainObject.h"

namespace Platform
{


Application::Application(const PROC_ADDRESS address, uint64_t SourceID): m_address(address),m_sourceID(SourceID)
{
    m_looper =  std::make_shared<Platform::Looper>(address);
    AddComponent(m_looper);
}


void Application::Init()
{
    DEBUGPRINT(DEBUG_ERROR,"Mol_Dol_Version: CM_%d_EV_%d_RE_%d_RS_%d_DO_%d"
            , static_cast<uint32_t>(Mol::Command::COMMAND_CATEGORY::END_OF_LIST)
            , static_cast<uint32_t>( Mol::Event::EVENT_CATEGORY::END_OF_LIST)
            , static_cast<uint32_t>(Mol::Request::REQUEST_CATEGORY::END_OF_LIST)
            , static_cast<uint32_t>(Mol::Response::RESPONSE_CATEGORY::END_OF_LIST)
            , static_cast<uint32_t>(Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST)
            );
    Platform::State::Init();
    m_componentManager.InitAllComponents();
}


void Application::Prepare()
{
    m_communicator.m_messageTransporter.Prepare(m_address);
    m_communicator.m_dol.Prepare(m_sourceID, m_address);
    m_communicator.m_event.Prepare(m_sourceID,m_address);
    m_communicator.m_command.Prepare(m_sourceID,m_address);
    m_communicator.m_request.Prepare(m_sourceID,m_address);
    m_communicator.m_response.Prepare(m_sourceID,m_address);
    m_communicator.m_monitoring.Prepare(m_sourceID,m_address);
    Platform::State::Prepare();

    m_componentManager.PrepareAllComponents();
}


void Application::Start()
{
    m_communicator.m_messageTransporter.Start();
    m_componentManager.StartAllComponents();

    Platform::State::Start();
    m_looper->WaitForTermination();
}

void Application::Stop()
{
    m_communicator.m_messageTransporter.Stop();
    Platform::State::Stop();
    m_componentManager.StopAllComponents();
}

void Application::Shutdown()
{
    m_communicator.m_dol.Shutdown();
    m_communicator.m_event.Shutdown();
    m_communicator.m_command.Shutdown();
    m_communicator.m_request.Shutdown();
    m_communicator.m_response.Shutdown();
    m_communicator.m_monitoring.Shutdown();
    m_communicator.m_messageTransporter.Shutdown();

    Platform::State::Shutdown();
    m_componentManager.ShutdownAllComponents();
}

void Application::Uninit()
{
    Platform::State::Uninit();
    m_componentManager.UninitAllComponents();
}

void Application::AddComponent(std::shared_ptr<Platform::Component> component)
{
    assert(m_state == DEINIT);
    m_componentManager.AddComponent(component);
}

} //end of Platform
