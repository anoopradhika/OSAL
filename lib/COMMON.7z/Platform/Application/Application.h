/*****************************************************************//**
 *
 * @file Application.h
 * @brief All SW Application shall be derived from Application class
 *
 * @copyright Copyright 2017 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_APPLICATION_INCLUDE_H
#define PLATFORM_APPLICATION_INCLUDE_H

#include "CommonDef.h"
#include "Looper/Looper.hpp"
#include "State/State.hpp"
#include "ComponentManager/ComponentManager.h"

namespace Platform
{

/** @class Application
 *  @brief Application is the interface for applications. This class
 *         composes the functionalities to internal IPC and also provides
 *         heartbeat mechanism to all applications
 */


class Application:public Platform::State
{
public:
    Application(const PROC_ADDRESS address, uint64_t SourceID);

    virtual ~Application() = default;

    virtual void Init() override;

    virtual void Prepare() override;

    virtual void Start() override;

    virtual void Stop() override;

    virtual void Shutdown() override;

    virtual void Uninit() override;

    void AddComponent(std::shared_ptr<Platform::Component> component);

    void SetSourceID(uint64_t sourceID)
    {
        if (m_sourceID == 0) // Only allowed to be changed once
        {
            m_sourceID = sourceID;
        }
    }

    uint64_t GetSourceID()
    {
        return m_sourceID;
    }

protected:
    std::shared_ptr<Platform::Looper> m_looper;
    //virtual void OnShutDown(const int sig_num)=0; //Method will be called when systemd is about to shutdown
    Platform::Communicator m_communicator;
    PROC_ADDRESS m_address;
    ComponentManager m_componentManager;
private:
    uint64_t m_sourceID;
};
} //end of Platform
#endif // PLATFORM_APPLICATION_INCLUDE_H
