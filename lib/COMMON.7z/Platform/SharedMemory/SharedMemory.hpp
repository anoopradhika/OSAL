/*****************************************************************//**
 *
 * @file    SharedMemory.hpp
 * @brief   Shared Memory class
 *
 * @todo    Explore boost library for Shared Memory
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_SHARED_MEMORY_INCLUDE_H
#define PLATFORM_SHARED_MEMORY_INCLUDE_H


#include "SharedMemory/SharedMemory.h"

namespace Platform
{

    /**
     * Class used for implementing shared memory functionality.
     */
    class SharedMemory
    {

    public:

        /**
         * @brief   constructor function
         *
         * @param[in]   sharedMemoryName  Name given to Shared Memory
         * @param[in]   sharedMemorySize  size of shared memory
         */

        SharedMemory(const std::string& sharedMemoryName, uint16_t sharedMemorySize = static_cast<uint32_t> (DEFAULT_SEGMENT_SIZE)) :
            m_nativeSharedMemory(sharedMemoryName, sharedMemorySize)
        {

        }

        /**
         * @brief   Destructor function
         *
         */

        ~SharedMemory() = default;

        /**
         * @brief   creates and opens a new, or opens an existing, POSIX shared memory object.
         *
         * @return  true or false
         */

        bool Create()
        {
            return (m_nativeSharedMemory.Create());
        }

        /**
         * @brief   opens opens an existing, POSIX shared memory object.
         *
         * @return  true or false
         */

        bool Open()
        {
            return (m_nativeSharedMemory.Open());
        }

        /**
         * @brief   Writes to shared memory
         *
         * @param[in]  stringShmValue  copies string to shared memory
         * @return  number of bytes written
         */

        uint16_t WriteData(const std::string &stringShmValue)
        {
            return (m_nativeSharedMemory.WriteData(stringShmValue));
        }

        /**
         * @brief   Writes to shared memory
         *
         * @param[in]  ptrBuffer copies content of character buffer to shared memory
         * @param[in]   bufferSize size of character buffer
         * @return  number of bytes written
         */

        uint16_t WriteData(const char *ptrBuffer, const uint16_t bufferSize)
        {

            return (m_nativeSharedMemory.WriteData(ptrBuffer, bufferSize));
        }

        /**
         * @brief   Reads shared memory content to a character buffer
         *
         * @param[out]  ptrBuffer  copies shared memory content to a character buffer
         * @param[in]   bufferSize size of character buffer
         * @return  number of bytes read
         */

        uint16_t GetData(char *ptrBuffer, const uint16_t bufferSize)
        {
            return (m_nativeSharedMemory.GetData(ptrBuffer, bufferSize));
        }

    private:
        static constexpr uint16_t DEFAULT_SEGMENT_SIZE = 8u;
        PlatformNative::SharedMemory m_nativeSharedMemory;
    };

} //end of Platform

#endif //PLATFORM_SHARED_MEMORY_INCLUDE_H
