/*****************************************************************//**
 *
 * @file    SlotConfigParser.h
 * @brief   Header file for Slot configuration parsing
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef SLOT_CONFIG_PARSER_H
#define SLOT_CONFIG_PARSER_H

#include <string>
#include <map>

#include "tinyxml/tinyxml.h"
#include "DOL/Entities/Module.h"
#include "CommonDef.h"
#include "Utility.h"
#include "Mol/DeviceUniqueID.h"
#include "Helper/StringToModule.h"

/**
 * @brief       SlotConfigParser class
 *              XML parser class for reading and storing the slot configuration information.
 */
class SlotConfigParser
{

public:

    SlotConfigParser(std::map<uint64_t, std::shared_ptr<Dol::Entities::Module>>&   moduleMap, uint64_t panelID) :
        m_moduleMap(moduleMap),
        m_panelID{panelID}
    {
    }

    ~SlotConfigParser() = default;

    /**
     * @brief       Loads the configuration XML file.
     *
     * @param[in]   file    absolute path of xml file
     * @return      0 on success, error code on failure
     */
    int LoadFile(const std::string& filePath)
    {
        int returnCode = ERROR_VALUE;

        std::shared_ptr<TiXmlDocument> xmlHandle{new (std::nothrow) TiXmlDocument(filePath.c_str())};
        if(xmlHandle == nullptr)
        {
            DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::LoadFile() memory allocation error");
        }
        else
        {
            // Check for Symlink or Hardlink
            if (Utility::IsSymlinkOrHardlink(filePath))
            {
                DEBUGPRINT(DEBUG_ERROR, "SlotConfigParser::LoadFile: [{0}] is a Symlink or Hardlink", filePath);
                return ERROR_VALUE;
            }
            if (!xmlHandle->LoadFile())
            {
                DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::LoadFile():Failed to load: [{0}]", filePath);
            }
            else
            {
                m_pParent = xmlHandle;
                returnCode = ConfigParser();
            }
        }
        return returnCode;
    }



private:

    std::shared_ptr<TiXmlNode> m_pParent = nullptr;

    std::map<uint64_t, std::shared_ptr<Dol::Entities::Module>>& m_moduleMap;

    uint64_t m_panelID = 0u;

    /**
     * @brief       Function to parse XML file
     *
     * @return      0 on success, -1 on failure
     */
    int ConfigParser()
    {
        int returnCode = ERROR_VALUE;

        TiXmlElement* const pElementConfig = m_pParent->FirstChildElement(cConfiguration);
        if (pElementConfig)
        {
            returnCode = ParseSiteInfo(pElementConfig);
            if(returnCode != SUCCESS)
            {
                DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::ConfigParser() [{}] not found", cConfiguration);
            }
            else
            {
                DEBUGPRINT(DEBUG_INFO,"SlotConfigParser::ConfigParser() success");
            }
        }
        return returnCode;
    }

        /**
         * @brief       Parse site xml tag
         *
         * @return      0 on success, -1 on failure
         */
        int ParseSiteInfo(TiXmlElement* pElementConfig)
        {
            int returnCode = ERROR_VALUE;
            TiXmlElement* const pElementSite = pElementConfig->FirstChildElement(cSite);
            if (pElementSite != nullptr)
            {
                returnCode = ParseNetworkInfo(pElementSite);
                if(returnCode != SUCCESS)
                {
                    DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::ParseSiteInfo() Failed");
                }
                else
                {
                    DEBUGPRINT(DEBUG_INFO,"SlotConfigParser::ParseSiteInfo() success");
                }
            }
            return returnCode;
        }

        /**
         * @brief       Parse network xml tag
         *
         * @return      0 on success, -1 on failure
         */
        int ParseNetworkInfo(TiXmlElement* pElementSite)
        {
            int returnCode = ERROR_VALUE;
            TiXmlElement* const pElementNetwork = pElementSite->FirstChildElement(cNetwork);
            if (pElementSite)
            {
                returnCode = ParsePanelConfig(pElementNetwork);
                if(returnCode != SUCCESS)
                {
                    DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::ParseNetworkInfo() Failed");
                }
                else
                {
                    DEBUGPRINT(DEBUG_INFO,"SlotConfigParser::ParseNetworkInfo() Success");
                }
            }
            return returnCode;
        }

    /**
     * @brief       Parse panel config xml tag
     *
     * @return      0 on success, -1 on failure
     */
    int ParsePanelConfig(TiXmlElement* pElementNetwork)
    {
        int returnCode = ERROR_VALUE;
        TiXmlElement* const pElementPanelConfig =
                pElementNetwork->FirstChildElement(cPanelConfig);
        if(pElementPanelConfig)
        {
            returnCode = ParseModules(pElementPanelConfig);
            if(returnCode != SUCCESS)
            {
                DEBUGPRINT(DEBUG_ERROR, "SlotConfigParser::ParsePanelConfig() Failed");
            }
            else
            {
                DEBUGPRINT(DEBUG_INFO,"SlotConfigParser::ParsePanelConfig() Success");
            }
        }
        return returnCode;
    }


    /**
     * @brief       Parse Modules xml tag
     *
     * @return      0 on success, -1 on failure
     */
    int ParseModules(TiXmlElement* pElementPanelConfig)
    {
        int returnCode = ERROR_VALUE;
        TiXmlElement* const pElementPanelModules =  pElementPanelConfig->FirstChildElement(cModules);
        if(pElementPanelModules)
        {
            returnCode = ParseSlotInfo(pElementPanelModules);
            if(returnCode != SUCCESS)
            {
                DEBUGPRINT(DEBUG_ERROR, "SlotConfigParser::ParseModules() Failed");
            }
            else
            {
                DEBUGPRINT(DEBUG_INFO, "SlotConfigParser::ParseModules() Success");
            }
        }
        return returnCode;
    }

    /**
     * @brief       Parse module id and type
     *
     * @return      0 on success, -1 on failure
     */
    int ParseSlotInfo(TiXmlElement* pElementPanelModules)
    {
        int returnCode = ERROR_VALUE;
        uint64_t uniqueID = 0;

        if (pElementPanelModules != nullptr)
        {
            TiXmlElement* pElementSubModules = pElementPanelModules->FirstChildElement(cSubmodules);
            if (pElementSubModules == nullptr)
            {
                DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::ParseSlotInfo() [{}] not found", cSubmodules);
                return ERROR_VALUE;
            }

            while (pElementSubModules)
            {
                Dol::Entities::Module::MODULE_TYPE type;
                auto moduleIDAttribute = pElementSubModules->Attribute(cID);
                std::istringstream iss(moduleIDAttribute);
                iss >> uniqueID;

                TiXmlElement* pElementType = pElementSubModules->FirstChildElement(cModuleType);
                if (pElementType == nullptr)
                {
                    DEBUGPRINT(DEBUG_ERROR,"SlotConfigParser::ParseSlotInfo() [{}] not found",cModuleType);
                    return ERROR_VALUE;
                }

                type = platform::stodt(pElementType->GetText());

                DEBUGPRINT(DEBUG_INFO,"SlotConfigParser::ParseSlotInfo() slotID [{0:#x}] type [{1}]",uniqueID, static_cast<int>(type));
                auto module_ptr = std::make_shared<Dol::Entities::Module>(uniqueID);
                module_ptr->SetType(type);
                m_moduleMap.emplace(std::make_pair(uniqueID, module_ptr));
                returnCode = SUCCESS;
                pElementSubModules = pElementSubModules->NextSiblingElement();
            }
       }
        return returnCode;
    }

    // XML tag elements
    const char* cConfiguration                  =       "configuration";
    const char* cSite                           =       "site";
    const char* cNetwork                        =       "network";
    const char* cPanelConfig                    =       "panel_config";
    const char* cModules                        =       "modules";
    const char* cSubmodules                     =       "sub_module";
    const char* cID                             =       "id";
    const char* cModuleType                     =       "type";
};

#endif /* SLOT_CONFIG_PARSER_H */
