/**
 * @file   Message.h
 * @Author Anoop Chandran (anoop.chandran@honeywell.com)
 * @brief  All type of messages in the system shall be added here.
 *
 */
 
#ifndef MESSAGE_INCLUDE_H
#define MESSAGE_INCLUDE_H

#include <cereal/cereal.hpp>
#include "CommonDef.h"

namespace Platform
{

/**
    MessagePortID are the Identification numbers for message port.
    New ID's shall be added before END_OF_LIST. 
*/
enum class MessagePortID: uint32_t
{
    COMMON_MODULE_COMMUNICATOR,
    TEST_ID_ONE,
    TEST_ID_TWO,
    TEST_ID_THREE,
    END_OF_LIST
};

/**
    Base message for all type of messages in the system.
*/
struct Message
{
    /**
        New type of message type Id shall be added here.
        Message distribution uses MessageType is used to identify
        the message. 
    */
    enum class MessageType: uint16_t
    {
        DOL = 1,
        EVENT,
        COMMAND,
        REQUEST,
        RESPONSE,
        MONITOR,
        SOFTWARE_CENTER,
        TEST_ID,
        END_OF_LIST
    };

    Message() = default;
    ~Message() = default;
    Message(MessageType messageType,std::string& Data,uint32_t Size ):
    m_messageType(messageType),m_Data(Data),m_Size(Size)
    {
    }
    
    /**
        Message distribution uses MessageType is used to identify
        the message.
    */
    MessageType m_messageType;
    std::string m_Data;
    uint32_t m_Size;
    uint64_t m_SourceUniqueID = 0;
    uint64_t m_DestinationUniqueID = 0;
    PROC_ADDRESS m_sender=PROC_ADDRESS::UNINITIALIZED;
    /**
      Allow cereal to access this class
    */
    friend class cereal::access;

        
    /**
      Member shall be added here for serialization 
    */            
    template<class Archive>
    void serialize(Archive & archive)
    {
        archive(const_cast<MessageType&> (m_messageType)
                , m_Size
                , m_SourceUniqueID
                , m_DestinationUniqueID
                , m_sender
                , m_Data);
    }
};

/**
    DomainObjectMessage is used for distributing Domain object among processes 
*/
struct DomainObjectMessage:Message
{
    static constexpr uint32_t MAX_SIZE = 512;   
    char m_data[DomainObjectMessage::MAX_SIZE];
};


/**
    Test message used for unit test
*/
struct TestMessage:Message
{
    static constexpr uint32_t MAX_SIZE = 512;   
    uint32_t m_size;
    char m_data[TestMessage::MAX_SIZE];
};
}
#endif //MESSAGE_INCLUDE_H
