/*******************************************************************************
* @file CommandSender .h
* @brief Send all type of MOL command
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_MOL_COMMAND_SENDER_H
#define PLATFORM_MOL_COMMAND_SENDER_H

#include "Component/Component.h"
#include "Mol/Commands/Command.h"

namespace Platform
{

/**
 * @brief    CommandSender send the assigned command
*/
template<typename ObjectType, typename CodeType>
class CommandSender: public Platform::Component
{
public:
    /**
    * @brief Constructor
    * @param deviceId device unique ID
    * @param client client to send command
    * @param code code associated with command
    */
    CommandSender(const uint64_t sourceId, Platform::Argumets& arguments)
        : m_sourceId{sourceId}
        , m_arguments{arguments}
    {
        if(!m_arguments.code.empty())
        {
            m_code = static_cast<CodeType>(std::stoi(m_arguments.code));
        }
    }

    void Start() override
    {
        if(std::is_same<CodeType, Mol::MESSAGE_DEFAULT_CODE>::value)
        {
            SendCommand(m_arguments.clientId);
        }
        else
        {
            SendCommand(m_arguments.clientId,m_code);
        }
        Platform::Component::Start();
    }

    virtual ~CommandSender() = default;

protected:
    const uint64_t m_sourceId  = 0;

    /**
        @brief Send a command
        @param client client to send message
        @tparam code code associated with command
    */
    void SendCommand(const PROC_ADDRESS client, const CodeType code)
    {
        auto command = std::make_shared<ObjectType>(code);
        SendCommand(client, command);
    }

    /**
        @brief Send a command
        @param client client to send message
    */
    void SendCommand(const PROC_ADDRESS client)
    {
        auto command = std::make_shared<ObjectType>();
        SendCommand(client, command);
    }

private:

      /// code associated with command
       CodeType m_code;

      Platform::Argumets m_arguments;
    
    /**
        @brief Send a command
        @param client    client to send message
        @param command   command to send
    */
    void SendCommand(const PROC_ADDRESS client, const std::shared_ptr<ObjectType> command)
    {
        auto target = Mol::DataType::ObjectReference{m_arguments.deviceId,stodt(m_arguments.ObjectType.c_str())};
        command->SetCommandTarget(target);
        m_communicator.m_command.Send(command, client, GetDestinationId(target));
    }

    uint64_t GetDestinationId(Mol::DataType::ObjectReference& reference)
    {
        reference.PrepareDeviceUniqueID();
        if(reference.GetDNM() != 0)
        {
            return reference.GetDNM64Bit();
        }
        else
        {
            auto multicastId = Mol::DeviceUniqueID{m_sourceId};
            return multicastId.GetModuleMultCastId();
        }
    }
};

}

#endif //PLATFORM_MOL_COMMAND_SENDER_H
