/*******************************************************************************
* @file ResponseHelper .h
* @brief Response supported datas are maintained here
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_TOOLS_RESPONSE_HELPER_H
#define PLATFORM_TOOLS_RESPONSE_HELPER_H

#include <map>
#include <set>
#include "Message/Message.h"
#include "Component/Component.h"
#include "ResponseSender/ResponseSender.h"
#include "Mol/Responses/Response.h"
#include "Mol/Responses/ObjectDataResponse.h"
#include "DOL/Entities/Zone/Zone.h"
#include "Mol/Responses/ChargerInfoResponse.h"
#include "Mol/Responses/NotifierDeviceStatusResponse.h"
#include "Mol/Responses/DeviceDiagnosticResponse.h"
#include "Mol/Responses/MultiObjectData.h"

namespace Platform
{

using ResponseType = Mol::Response::RESPONSE_CATEGORY;
/*
* @brief Map for response name to Mol::Response::RESPONSE_CATEGORY
*/
std::map<std::string,Mol::Response::RESPONSE_CATEGORY> ResponseNameToType
    { {"OBJECT_STATUS",ResponseType::OBJECT_STATUS}
    , {"CHARGER_INFO_RESPONSE",ResponseType::CHARGER_INFO_RESPONSE}
	, {"NOTIFIER_DEVICE_STATUS_RESPONSE",ResponseType::NOTIFIER_DEVICE_STATUS_RESPONSE}
    , {"DEVICE_DIAGNOSTIC_RESPONSE",ResponseType::DEVICE_DIAGNOSTIC_RESPONSE}
	, {"MULTI_OBJECT_DATA",ResponseType::MULTI_OBJECT_DATA}
        };

std::string rs_toString(ResponseType type)
{
    for(auto& response : ResponseNameToType)
    {
        if(response.second == type)
        {
            return response.first;
        }
    }
    return "unknown";
}
/**
* @brief Set of response need code
*/
std::set<Mol::Response::RESPONSE_CATEGORY> CodeNeededResponse
{
	ResponseType::CHARGER_INFO_RESPONSE
};

/**
* @brief map for Mol::Response::RESPONSE_CATEGORY to response component
*/
std::map<Mol::Response::RESPONSE_CATEGORY,std::function<std::shared_ptr<Platform::Component>( const uint64_t sourceId, Platform::Argumets& arguments)>> responseAction
{ 
	{ResponseType::OBJECT_STATUS, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
			    	{ return std::make_shared<ResponseSender<Mol::Response::ObjectDataResponse>>(sourceId, arguments);}},

	{ResponseType::CHARGER_INFO_RESPONSE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
    				{ return std::make_shared<ResponseSender<Mol::Response::ChargerInfoResponse,Mol::CHARGER_INFO_CODE>>(sourceId, arguments);}},
	{ResponseType::NOTIFIER_DEVICE_STATUS_RESPONSE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
    				{ return std::make_shared<ResponseSender<Mol::Response::NotifierDeviceStatusResponse>>(sourceId, arguments);}},
    {ResponseType::DEVICE_DIAGNOSTIC_RESPONSE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
    			    { return std::make_shared<ResponseSender<Mol::Response::DeviceDiagnosticResponse>>(sourceId, arguments);}},
	{ResponseType::MULTI_OBJECT_DATA, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
    				{ return std::make_shared<ResponseSender<Mol::Response::MultiObjectData>>(sourceId, arguments);}}
};

}

#endif //PLATFORM_TOOLS_HELPER_H

