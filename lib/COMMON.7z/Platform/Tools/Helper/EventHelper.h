/*******************************************************************************
* @file EventHelper .h
* @brief Data's rquired for event message preparation are maintained here
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_TOOLS_EVENT_HELPER_H
#define PLATFORM_TOOLS_EVENT_HELPER_H

#include <map>
#include <set>
#include "Message/Message.h"
#include "Component/Component.h"
#include "EventSender/EventSender.h"
#include "Mol/Events/Event.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/Reset.h"
#include "Mol/Events/MaintenanceEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/WarningEvent.h"
#include "Mol/Events/InputChangeEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/AlarmSignalEvent.h"
#include "Mol/Events/DelayStartedEvent.h"
#include "Mol/Events/FunctionDisable.h"
#include "Mol/Events/FunctionEnable.h"
#include "Mol/Events/AccessEvent.h"
#include "Mol/Events/SelfTestEvent.h"
#include "Mol/Events/SelfTestResultEvent.h"
#include "Mol/Events/SelfTestBeaconEvent.h"
#include "Mol/Events/UserRole.h"

namespace Platform
{

using EventType = Mol::Event::EVENT_CATEGORY;
/*
* @brief Map for Event name to Mol::Event::EVENT_CATEGORY
*/
std::map<std::string,EventType> EventNameToType
    { {"ALARM",EventType::ALARM}
    , {"DISABLEMENT",EventType::DISABLEMENT}
    , {"FAULT",EventType::TROUBLE}
    , {"FAULT_CLEARED",EventType::TROUBLE_CLEARED}
    , {"MAINTENANCE",EventType::MAINTENANCE}
    , {"WARNING",EventType::WARNING}
    , {"INPUT_CHANGE_IN_STATUS",EventType::INPUT_CHANGE_IN_STATUS}
    , {"ACTIVATION",EventType::ACTIVATION}
    , {"INFORMATION",EventType::INFORMATION}
    , {"USER_OPERATION",EventType::USER_OPERATION}
    , {"TEST",EventType::TEST}
    , {"TROUBLE_CLEARED",EventType::TROUBLE_CLEARED}
    , {"ALARM_SIGNAL",EventType::ALARM_SIGNAL}
    , {"RESET",EventType::RESET}
    , {"DELAY_STARTED_EVENT",EventType::DELAY_STARTED_EVENT}
    , {"FUNCTION_DISABLE",EventType::FUNCTION_DISABLE}
    , {"FUNCTION_ENABLE",EventType::FUNCTION_ENABLE}
    , {"USER_ACCESS",EventType::USER_ACCESS}
    , {"SELF_TEST",EventType::SELF_TEST}
    , {"SELF_TEST_RESULT",EventType::SELF_TEST_RESULT}
    , {"BEACONING",EventType::BEACONING}
    , {"USER_ROLE",EventType::USER_ROLE}
    };

    std::string ev_toString(EventType type)
    {
        for(auto& event : EventNameToType)
        {
            if(event.second == type)
            {
                return event.first;
            }
        }
        return "unknown";
    }
/**
* @brief Set of command need code
*/
std::set<EventType> CodeNeededEvent
    { EventType::USER_ACCESS
    , EventType::ACTIVATION
    , EventType::ALARM
    , EventType::DISABLEMENT
    , EventType::TROUBLE_CLEARED
    , EventType::TROUBLE
    , EventType::INFORMATION
    , EventType::INPUT_CHANGE_IN_STATUS
    , EventType::MAINTENANCE
    , EventType::TEST
    , EventType::USER_OPERATION
    , EventType::WARNING
    , EventType::DELAY_STARTED_EVENT
    , EventType::FUNCTION_DISABLE
    , EventType::FUNCTION_ENABLE
    , EventType::ALARM_SIGNAL
    , EventType::RESET
    , EventType::SELF_TEST
    , EventType::SELF_TEST_RESULT
    , EventType::BEACONING
    , EventType::USER_ROLE
    };

/**
* @brief map for Mol::Command::EVENT_CATEGORY to command component
*/
std::map<EventType,std::function<std::shared_ptr<Platform::Component>(uint64_t sourceId,Platform::Argumets& arguments)>> EventAction
    { {EventType::ALARM, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::AlarmEvent,Mol::Event::ALARM_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::DISABLEMENT, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::DisablementEvent,Mol::Event::DISABLEMENT_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::TROUBLE, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::FaultEvent,Mol::Event::FAULT_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::MAINTENANCE, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::MaintenanceEvent,Mol::Event::MAINTENANCE_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::WARNING, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::WarningEvent,Mol::Event::WARNING_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::INPUT_CHANGE_IN_STATUS, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::InputChangeEvent,Mol::Event::INPUT_CHANGE_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::ACTIVATION, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::ActivationEvent,Mol::Event::ACTIVATION_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::INFORMATION, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::InformationEvent,Mol::Event::INFORMATION_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::USER_OPERATION, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::UserOperationEvent,Mol::Event::USER_OPERATION_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::TEST, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::TestOperationEvent,Mol::Event::TEST_OPERATION_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::TROUBLE_CLEARED, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::FaultClearedEvent,Mol::Event::FAULT_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::ALARM_SIGNAL, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<EventSender<Mol::Event::AlarmSignalEvent,uint32_t>>(sourceId,arguments);}}

    , {EventType::RESET, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::Reset,Mol::Event::RESET_TYPE_CODE>>(sourceId,arguments);}}

    , {EventType::DELAY_STARTED_EVENT, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                                                    { return std::make_shared<EventSender<Mol::Event::DelayStartedEvent,uint16_t>>(sourceId,arguments);}}

    , {EventType::FUNCTION_DISABLE, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::FunctionDisable, Mol::FUNCTION_CODE>>(sourceId,arguments);}}

    , {EventType::FUNCTION_ENABLE, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::FunctionEnable, Mol::FUNCTION_CODE>>(sourceId,arguments);}}

    , {EventType::SELF_TEST, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::SelfTestEvent, Mol::SELFTEST_EVENT_CODE>>(sourceId,arguments);}}

    , {EventType::SELF_TEST_RESULT, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::SelfTestResultEvent, Mol::SELFTEST_RESULT_EVENTCODE>>(sourceId,arguments);}}
    
	, {EventType::BEACONING, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::SelfTestBeaconEvent, Mol::SELFTESTBEACON_EVENT_CODE>>(sourceId,arguments);}}
	
	, {EventType::USER_ROLE, [](uint64_t sourceId,Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<EventSender<Mol::Event::UserRole, Mol::Event::USER_ROLE_EVENT_CODE>>(sourceId,arguments);}}



    };

}
#endif //PLATFORM_TOOLS_EVENT_HELPER_H
