/*******************************************************************************
* @file Helper.cpp
* @brief Data needed for Dragon are maintained here
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#include "CommonDef.h"

#include <map>
#include <cstring>

#include "DOL/DomainObject/DomainObject.h"

namespace Platform
{
/**
* @brief map for Process name to PROC_ADDRESS
*/
std::map<std::string,PROC_ADDRESS>  processNameToId
    { {"CMCAPP",PROC_ADDRESS::CMCAPP}
    , {"CNE",PROC_ADDRESS::CNE}
    , {"IOMGR",PROC_ADDRESS::IOMGR}
    , {"NETWORK",PROC_ADDRESS::NETWORK}
    , {"ISOMAPP",PROC_ADDRESS::ISOMAPP}
    , {"EVENTLOGAPP",PROC_ADDRESS::EVENTLOGAPP}
    , {"EVENT_PROVIDERAPP",PROC_ADDRESS::EVENT_PROVIDERAPP}
    , {"FDA",PROC_ADDRESS::FIRE_DOMAIN_APP}
    , {"MAINLOOP",PROC_ADDRESS::MAINLOOP}
    , {"MOL_RECEIVER",PROC_ADDRESS::MOL_RECEIVER}
    , {"BROADCAST",PROC_ADDRESS::BROADCAST}
    , {"FIRMWAREAPP",PROC_ADDRESS::FIRMWAREAPP}
    , {"MODULE_APP",PROC_ADDRESS::MODULE_APP}
    , {"LICENSEVALIDATOR",PROC_ADDRESS::LICENSEVALIDATOR}
    , {"HMI",PROC_ADDRESS::HMI}
    , {"Dragon",PROC_ADDRESS::MOL_SENDER}
    , {"AUDITLOG_APP",PROC_ADDRESS::AUDITLOG_APP}
    , {"ENGLOG_APP",PROC_ADDRESS::ENGLOG_APP}
    , {"ACTIVE_EVENTSAPP",PROC_ADDRESS::ACTIVE_EVENTSAPP}
    //, {"ZONALINDICATOR",PROC_ADDRESS::ZONALINDICATOR}
    , {"PANELLEARN",PROC_ADDRESS::PANELLEARN_APP}
    , {"CLSSMGR",PROC_ADDRESS::CLSSMGR}
    };


    struct cmpStr
    {
        bool operator()(char const* lsh, char const* rsh) const
        {
            return std::strcmp(lsh,rsh)< 0;
        }
    };

    /**
    * @brief Support logical area and physical device
    *
    */
    std::map<const char*, Dol::DOMAIN_OBJECT_TYPE, cmpStr> stodtMap
        { {"ORGANIZATION", Dol::DOMAIN_OBJECT_TYPE::ORGANIZATION}
        , {"CONTACT", Dol::DOMAIN_OBJECT_TYPE::CONTACT}
        , {"SITE", Dol::DOMAIN_OBJECT_TYPE::SITE}
        , {"BUILDING", Dol::DOMAIN_OBJECT_TYPE::BUILDING}
        , {"MANAGED_AREA", Dol::DOMAIN_OBJECT_TYPE::MANAGED_AREA}
        , {"MULTI_DEPENDENCY_GROUP", Dol::DOMAIN_OBJECT_TYPE::MULTI_DEPENDENCY_GROUP}
        , {"ALARM", Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE}
        , {"ALARM_OUTPUT", Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT}
        , {"CONTROL_ZONE", Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE}
        , {"DETECTION", Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE}
        , {"GENERAL", Dol::DOMAIN_OBJECT_TYPE::GENERAL_ZONE}
        , {"CONTROL", Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE}
        , {"RELEASING_ZONE", Dol::DOMAIN_OBJECT_TYPE::RELEASING_ZONE}

        , {"LIFE_SAFETY_SYSTEM", Dol::DOMAIN_OBJECT_TYPE::LIFE_SAFETY_SYSTEM}
        , {"FIRE_PANEL", Dol::DOMAIN_OBJECT_TYPE::FIRE_PANEL}
        , {"FIELD_DEVICE", Dol::DOMAIN_OBJECT_TYPE::FIELD_DEVICE}
        , {"IO_CHANNEL", Dol::DOMAIN_OBJECT_TYPE::IO_CHANNEL}
        , {"FIRE_BRIGADE_CONTROL_PANEL", Dol::DOMAIN_OBJECT_TYPE::FIRE_BRIGADE_CONTROL_PANEL}
        , {"FIRE_ALARM_ROUTING_EQUIPMENT", Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_ROUTING_EQUIPMENT}		
		, {"TECHNICAL_ALARM_POINT", Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT}
        , {"FAULT_ROUTING_EQUIPMENT", Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT}

        , {"FIRE_SENSOR_INPUT", Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT}
        , {"CONTROL_OUTPUT_POINT", Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT}
        , {"TECH_ALARM", Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT}
        , {"CONTROL_INPUT_POINT", Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT}
        , {"RELEASING_POINT", Dol::DOMAIN_OBJECT_TYPE::RELEASING_POINT}
        , {"FIRE_ALARM_DEVICE_POINT", Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_DEVICE_POINT}
        , {"MANUAL_CALL_POINT", Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT}
        , {"FIRE_SENSOR", Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR}
        , {"MCP_INPUT", Dol::DOMAIN_OBJECT_TYPE::MCP_INPUT}
        , {"FAULT_INPUT", Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT}
        , {"ALARM_DEVICE", Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE}
        , {"SOUNDER", Dol::DOMAIN_OBJECT_TYPE::SOUNDER}
        , {"VISUAL_ELEMENT", Dol::DOMAIN_OBJECT_TYPE::VISUAL_ELEMENT}
        , {"ANALOG_INPUT_POINT", Dol::DOMAIN_OBJECT_TYPE::ANALOG_INPUT_POINT}
        , {"ANNUNCIATOR_PANEL_SWITCH_INPUT_POINT", Dol::DOMAIN_OBJECT_TYPE::ANNUNCIATOR_PANEL_SWITCH_INPUT_POINT}
        , {"ANNUNCIATIOR_PANEL_INDICATION_POINT", Dol::DOMAIN_OBJECT_TYPE::ANNUNCIATIOR_PANEL_INDICATION_POINT}
        , {"PAM_POINT", Dol::DOMAIN_OBJECT_TYPE::PAM_POINT}
        , {"KEY_SAFE", Dol::DOMAIN_OBJECT_TYPE::KEY_SAFE}
        , {"CONFIRMATION_INPUT", Dol::DOMAIN_OBJECT_TYPE::CONFIRMATION_INPUT}
        , {"AUX_DC_OUTPUT", Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT}
        , {"SERIAL_PORT", Dol::DOMAIN_OBJECT_TYPE::SERIAL_PORT}
        , {"CHARGER", Dol::DOMAIN_OBJECT_TYPE::CHARGER}
        , {"BATTERY", Dol::DOMAIN_OBJECT_TYPE::BATTERY}
        , {"EXTERNAL_PSU", Dol::DOMAIN_OBJECT_TYPE::EXTERNAL_PSU}
        , {"MODULE", Dol::DOMAIN_OBJECT_TYPE::MODULE}
        , {"IO_MODULE", Dol::DOMAIN_OBJECT_TYPE::IO_MODULE}
        , {"LOOP_MODULE", Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE}
        , {"CPU_MODULE", Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE}
        , {"SERIAL_COMM_MODULE", Dol::DOMAIN_OBJECT_TYPE::SERIAL_COMM_MODULE}
        , {"CHARGER_MODULE", Dol::DOMAIN_OBJECT_TYPE::CHARGER_MODULE}
        , {"NETWORK_MODULE", Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE}
        , {"FARE_FRE_MODULE", Dol::DOMAIN_OBJECT_TYPE::FARE_FRE_MODULE}
        , {"VOICE_PANEL", Dol::DOMAIN_OBJECT_TYPE::VOICE_PANEL}
        , {"CMSI_PANEL", Dol::DOMAIN_OBJECT_TYPE::CMSI_PANEL}
        , {"FIRE_PROTECTION_OUTPUT", Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT}
        , {"LOOP", Dol::DOMAIN_OBJECT_TYPE::LOOP}
		, {"COMMON_FAULT_OUTPUT", Dol::DOMAIN_OBJECT_TYPE::COMMON_FAULT_OUTPUT}
		, {"COMMON_FIRE_OUTPUT", Dol::DOMAIN_OBJECT_TYPE::COMMON_FIRE_OUTPUT}

        , {"AUX DC OUTPUT", Dol::DOMAIN_OBJECT_TYPE::AUX_DC_OUTPUT}
        , {"ALARM DEVICE", Dol::DOMAIN_OBJECT_TYPE::ALARM_DEVICE}
        , {"ALARM OUTPUT", Dol::DOMAIN_OBJECT_TYPE::ALARM_OUTPUT}
        , {"BATTERY_SET", Dol::DOMAIN_OBJECT_TYPE::BATTERY}
        , {"COMMON FAULT OUTPUT", Dol::DOMAIN_OBJECT_TYPE::COMMON_FAULT_OUTPUT}
        , {"COMMON FIRE OUTPUT", Dol::DOMAIN_OBJECT_TYPE::COMMON_FIRE_OUTPUT}
        , {"CONFIRMATION INPUT", Dol::DOMAIN_OBJECT_TYPE::CONFIRMATION_INPUT}
        , {"CONTROL INPUT", Dol::DOMAIN_OBJECT_TYPE::CONTROL_INPUT_POINT}
        , {"CONTROL OUTPUT", Dol::DOMAIN_OBJECT_TYPE::CONTROL_OUTPUT_POINT}
        , {"FAULT INPUT", Dol::DOMAIN_OBJECT_TYPE::FAULT_INPUT}
        , {"FAULT ROUTING OUTPUT", Dol::DOMAIN_OBJECT_TYPE::FAULT_ROUTING_EQUIPMENT}
        , {"FIELD DEVICE", Dol::DOMAIN_OBJECT_TYPE::FIELD_DEVICE}
        , {"FIRE PROTECTION OUTPUT", Dol::DOMAIN_OBJECT_TYPE::FIRE_PROTECTION_OUTPUT}
        , {"FIRE SENSOR", Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR}
        , {"FIRE SENSOR INPUT", Dol::DOMAIN_OBJECT_TYPE::FIRE_SENSOR_INPUT}
        , {"MANUAL CALL POINT", Dol::DOMAIN_OBJECT_TYPE::MANUAL_CALL_POINT}
        , {"MCP INPUT", Dol::DOMAIN_OBJECT_TYPE::MCP_INPUT}
        , {"TECHNICAL ALARM INPUT", Dol::DOMAIN_OBJECT_TYPE::TECHNICAL_ALARM_POINT}
        , {"FIRE ROUTING OUTPUT", Dol::DOMAIN_OBJECT_TYPE::FIRE_ALARM_ROUTING_EQUIPMENT}
		, {"ZONE", Dol::DOMAIN_OBJECT_TYPE::ZONE}
        , {"POINT", Dol::DOMAIN_OBJECT_TYPE::POINT}
        };

    Dol::DOMAIN_OBJECT_TYPE stodt(const char * name)
    {
        if(stodtMap.end() == stodtMap.find(name))
        {
            return Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST;
        }
        return stodtMap[name];
    }

    std::string Dol_toString(Dol::DOMAIN_OBJECT_TYPE type)
    {
        for(auto& dol : stodtMap)
        {
            if(dol.second == type)
            {
                return dol.first;
            }
        }
        return "Unknown";
    }

    std::string proceesNameToStr(PROC_ADDRESS address)
    {
        for(auto& procAddress : processNameToId)
        {
            if(procAddress.second == address)
            {
                return procAddress.first;
            }
        }
        return "Unknown";
    }
/**
* @brief Support logical area and physical device
*
*/
}
