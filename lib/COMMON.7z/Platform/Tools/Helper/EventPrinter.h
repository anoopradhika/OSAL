#ifndef PLTFORM_EVENT_PRINTER_H
#define PLTFORM_EVENT_PRINTER_H
/*****************************************************************//**
 *
 * @file    EventPrinter.h
 * @brief   Class to create Command objects and send
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

// framework
#include "Mol/Events/Event.h"
#include "Mol/Events/EventTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include "DOL/Entities/Module.h"
#include "Helper.h"
#include <chrono>
#include <ctime>

namespace Platform {

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class EventDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i )
        {  
          // Intentionally unimplemented...
        }
};
struct EventPrinter {
    EventPrinter(uint64_t id, PROC_ADDRESS address):
                m_id{id}
                ,m_address{address}
    {}
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message )
    {
        auto objectReference = message->GetSource();
        std::time_t messageTime = message->GetTimestamp();
        std::string timeInString = std::ctime(&messageTime);
        timeInString.erase(std::remove(timeInString.begin(), timeInString.end(), '\n'), timeInString.end());
        std::string label;
        auto labels = message->GetLabels();
        if(!labels.empty())
        {
            for (const Dol::Label& label_data : labels)
            {
                if(!label_data.GetLabel().empty())
                {
                    label.append(" Label["+ label_data.GetLabelTypeAsString() +"]:" + label_data.GetLabel());
                }
            }
        }

        std::string adpString = " ";
        std::string description;
        std::string notifierString;
        std::string sensorString;
        std::string loopString;
        auto parameters = message->GetParameters();
        for(const Mol::DataType::Parameter& parameter : parameters)
        {
            if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
            {
                adpString = " ADP:";
                description += parameter.GetValue<std::string>();
                description += " ";
            }
            else if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::NOTIFIER_TYPE_CODE)
            {
                auto value = parameter.GetValue<int32_t>();
                notifierString = " NOTIFIER_TYPE:" + std::to_string(value);
            }
            else if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::SENSING_ELEMENT_TYPE)
            {
                auto value = parameter.GetValue<uint32_t>();
                sensorString = " SENSING_TYPE:" + std::to_string(value);
            }
            else if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::LOOP_ID)
            {
                auto value = parameter.GetValue<uint8_t>();
                loopString = " LOOP_ID:" + std::to_string(value);
            }
            else
            {
                //DEBUGPRINT(DEBUG_INFO,"Parameter not decoded")
            }
        }
        adpString += description;
        std::string parentsString = "Parents:";
        auto parents = message->GetParents();
        if(!parents.empty())
        {
            for (const Mol::DataType::ObjectReference& parent : parents)
            {
                parentsString += "PType["+Dol_toString(parent.GetObjectType())+"] PID["+std::to_string(parent.GetObjectId())+"] ";
            }
        }
        else
        {
            parentsString += "None ";
        }
        auto printData = DEBUGPRINT::format("Event Time:{0} Type:{1} Code:{2} SType:{3} SID:{4:#x} REF[{5}] {6}PROCESS:{7}{8}{9}{10}{11}{12}senderID:{13:#x}",
                        timeInString
                      , ev_toString(message->GetObjectType())
                      , static_cast<uint32_t>(message->GetEventCode())
                      , Dol_toString(objectReference.GetObjectType())
                      , objectReference.GetObjectId()
                      , message->GetZonePointReference()
                      , parentsString
                      , proceesNameToStr(m_address)
                      , label
                      , notifierString
                      , sensorString
                      , loopString
                      , adpString
                      , m_id
                  );
        DEBUGPRINT(DEBUG_INFO,printData);
     }
    uint64_t m_id;
    PROC_ADDRESS m_address;
};

auto PrintEvent = [](auto event, uint64_t id, PROC_ADDRESS address)
{
    using EventCaster = Platform::CastAndCall< EventDowncastAdapter,  Mol::Message<EventType>, EventObjectTypes >;
    EventCaster::Do<Mol::Event::EventDefault>(event,EventPrinter{id,address});
};
void PrintInformationEventModuleDetails(auto information,uint64_t id, PROC_ADDRESS address)
{
    auto objectReference = information->GetSource();
    std::time_t messageTime = information->GetTimestamp();
    std::string timeInString = std::ctime(&messageTime);
    timeInString.erase(std::remove(timeInString.begin(), timeInString.end(), '\n'), timeInString.end());
    std::vector<Mol::DataType::Parameter> parameters = information->GetParameters();
    if (parameters.empty())
    {
        DEBUGPRINT(DEBUG_INFO,"Error in printing module details");
        return;
    }
    std::shared_ptr<Dol::Entities::Module> moduleObject = parameters.at(0).GetValue<std::shared_ptr<Dol::Entities::Module> >();
    if (moduleObject != nullptr)
    {
        auto printData = DEBUGPRINT::format("Event Time:{0} Type:{1} Code:{2} SType:{3} SID:{4:#x} SerialNum:{5} SWVersion:{6} HWVersion:{7} Slot:{8} PROCESS:{9} senderID {10:#x}",
            timeInString
            , ev_toString(information->GetObjectType())
            , static_cast<uint32_t>(information->GetEventCode())
            , Dol_toString(objectReference.GetObjectType())
            , objectReference.GetObjectId()
            , moduleObject->GetSerialNumber()
            , moduleObject->GetSoftwareVersion()->GetString()
            , moduleObject->GetHardwareVersion()
            , Mol::DeviceUniqueID{moduleObject->GetID()}.GetModuleID()
            , proceesNameToStr(address)
            ,id
        );
        DEBUGPRINT(DEBUG_INFO,printData);
    }
}
} // end namespace
#endif //PLTFORM_EVENT_PRINTER_H
