/*******************************************************************************
* @file RequestHelper .h
* @brief Request supported datas are maintained here
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_TOOLS_REQUEST_HELPER_H
#define PLATFORM_TOOLS_REQUEST_HELPER_H

#include <map>
#include <set>
#include "Message/Message.h"
#include "Component/Component.h"
#include "RequestSender/RequestSender.h"
#include "Mol/Requests/Request.h"
#include "Mol/Requests/ObjectData.h"
#include "Mol/Requests/ChargerInfoRequest.h"
#include "Mol/Requests/NotifierDeviceStatusRequest.h"
#include "Mol/Requests/DeviceDiagnosticRequest.h"
#include "Mol/Requests/MultiObjectQuery.h"

namespace Platform
{

using RequestType = Mol::Request::REQUEST_CATEGORY;
/*
* @brief Map for request name to Mol::Request::REQUEST_CATEGORY
*/
std::map<std::string,Mol::Request::REQUEST_CATEGORY> RequestNameToType
    { {"OBJECT_DATA",RequestType::OBJECT_DATA},
      {"CHARGER_INFO_REQUEST",RequestType::CHARGER_INFO_REQUEST},
	  {"NOTIFIER_DEVICE_STATUS_REQUEST",RequestType::NOTIFIER_DEVICE_STATUS_REQUEST},
      {"DEVICE_DIAGNOSTIC_DETAILS",RequestType::DEVICE_DIAGNOSTIC_DETAILS},
	  {"MULTI_OBJECT_QUERY",RequestType::MULTI_OBJECT_QUERY}
	};

std::string rq_toString(RequestType type)
{
    for(auto& request : RequestNameToType)
    {
        if(request.second == type)
        {
            return request.first;
        }
    }
    return "unknown";
}
/**
* @brief Set of request need code
*/
std::set<Mol::Request::REQUEST_CATEGORY> CodeNeededRequest
    { RequestType::OBJECT_DATA,
      RequestType::CHARGER_INFO_REQUEST,
	  RequestType::MULTI_OBJECT_QUERY
	};

/**
* @brief map for Mol::Request::REQUEST_CATEGORY to request component
*/
std::map<Mol::Request::REQUEST_CATEGORY,std::function<std::shared_ptr<Platform::Component>( const uint64_t sourceId, Platform::Argumets& arguments)>> requestAction
    { {RequestType::OBJECT_DATA, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
					      { return std::make_shared<RequestSender<Mol::Request::ObjectData,Mol::Request::OBJECT_DATA_REQUEST_CODE>>(sourceId, arguments);}},
      {RequestType::CHARGER_INFO_REQUEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                          { return std::make_shared<RequestSender<Mol::Request::ChargerInfoRequest,Mol::CHARGER_INFO_CODE>>(sourceId, arguments);}},
	  {RequestType::NOTIFIER_DEVICE_STATUS_REQUEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                          { return std::make_shared<RequestSender<Mol::Request::NotifierDeviceStatusRequest,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}},
      {RequestType::DEVICE_DIAGNOSTIC_DETAILS, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                          { return std::make_shared<RequestSender<Mol::Request::DeviceDiagnosticRequest,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}},
	  {RequestType::MULTI_OBJECT_QUERY, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                          { return std::make_shared<RequestSender<Mol::Request::MultiObjectQuery,Mol::Request::MULTI_OBJECT_QUERY_CODE>>(sourceId, arguments);}}
    };

}

#endif //PLATFORM_TOOLS_HELPER_H

