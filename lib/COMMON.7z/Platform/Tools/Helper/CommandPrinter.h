#ifndef COMMAND_PRINTER_H
#define COMMAND_PRINTER_H
/*****************************************************************//**
 *
 * @file    CommandPrinter.h
 * @brief   Class to create Command objects and send
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

// framework
#include "Mol/Commands/Command.h"
#include "Mol/Commands/CommandTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include <string>
#include <chrono>
#include <ctime>

namespace Platform {

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class CommandDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i )
        { 
          // Intentionally unimplemented...
         }
};
struct CommandPrinter {
    CommandPrinter(uint64_t id, PROC_ADDRESS address):
                m_id{id}
                ,m_address{address}
    {}
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message )
    {
        auto objectReference = message->GetCommandTarget();
        std::time_t messageTime = message->GetTimestamp();
        std::string timeInString = std::ctime(&messageTime);
        auto parameters = message->GetParameters();
        std::string discription;
        for(auto& parameter : parameters)
        {
            if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
            {
                discription += parameter.template GetValue<std::string>();
                discription += " ";
            }
        }
        timeInString.erase(std::remove(timeInString.begin(), timeInString.end(), '\n'), timeInString.end());
        auto printData = DEBUGPRINT::format("Command Time:{0} Type:{1} Code:{2} Source Type:{3} Source id:{4:#x} PROC_ADDRESS {5} ADP {6} senderID {7:#x}",
                        timeInString
                      , cm_toString(message->GetObjectType())
                      , (uint32_t) message->GetCommandCode()
                      , Dol_toString(objectReference.GetObjectType())
                      , objectReference.GetObjectId()
                      , proceesNameToStr(m_address)
                      ,discription
                      ,m_id
                  );
        DEBUGPRINT(DEBUG_INFO,printData);
     }
    uint64_t m_id;
    PROC_ADDRESS m_address;
};

auto PrintCommand = [](auto command, uint64_t id, PROC_ADDRESS address)
{
    using CommandCaster = Platform::CastAndCall< CommandDowncastAdapter,  Mol::Message<Mol::Command::COMMAND_CATEGORY>, CommandObjectTypes >;
    CommandCaster::Do<Mol::Command::CommandDefault>(command,CommandPrinter{id,address});
};
} // end namespace
#endif //COMMAND_PRINTER_H
