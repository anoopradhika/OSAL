/*******************************************************************************
* @file CommandHelper .h
* @brief Comand supported datas are maintained here
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_TOOLS_COMMAND_HELPER_H
#define PLATFORM_TOOLS_COMMAND_HELPER_H

#include <map>
#include <set>
#include "Message/Message.h"
#include "Component/Component.h"
#include "CommandSender/CommandSender.h"
#include "Mol/Commands/Command.h"
#include "Mol/Commands/Activate.h"
#include "Mol/Commands/Deactivate.h"
#include "Mol/Commands/ApplyConfiguration.h"
#include "Mol/Commands/CancelBuzzer.h"
#include "Mol/Commands/DelayOff.h"
#include "Mol/Commands/DelayOn.h"
#include "Mol/Commands/Disable.h"
#include "Mol/Commands/Enable.h"
#include "Mol/Commands/ExtendDelays.h"
#include "Mol/Commands/MeasureReferenceResistance.h"
#include "Mol/Commands/ModuleReboot.h"
#include "Mol/Commands/ModuleShutdown.h"
#include "Mol/Commands/OverrideDelays.h"
#include "Mol/Commands/Reset.h"
#include "Mol/Commands/ClearCounter.h"
#include "Mol/Commands/Resound.h"
#include "Mol/Commands/ServiceMode.h"
#include "Mol/Commands/Silence.h"
#include "Mol/Commands/EarthFaultMonitoring.h"
#include "Mol/Commands/SoftwareCenterCommands.h"
#include "Mol/Commands/SetAlarmSignal.h"
#include "Mol/Commands/SetDayNightMode.h"
#include "Mol/Commands/BatteryOperation.h"
#include "Mol/Commands/TestZoneStart.h"
#include "Mol/Commands/TestZoneStop.h"
#include "Mol/Commands/StartIndicatorTest.h"
#include "Mol/Commands/StopIndicatorTest.h"
#include "Mol/Commands/SetDebugLevel.h"
#include "Mol/Commands/FunctionDisable.h"
#include "Mol/Commands/FunctionEnable.h"
#include "Mol/Commands/EvacuationOn.h"
#include "Mol/Commands/EvacuationOff.h"
#include "Mol/Commands/FareTest.h"
#include "Mol/Commands/SetTimeDate.h"
#include "Mol/Commands/StartLoop.h"
#include "Mol/Commands/FindDevice.h"
#include "Mol/Commands/ReSynchronization.h"
#include "Mol/Commands/LoopAutoLearn.h"
#include "Mol/Commands/AuditLogTxfer.h"
#include "Mol/Commands/Synchronization.h"
#include "Mol/Commands/GenerateDefaultConfig.h"
#include "Mol/Commands/SelfTest.h"
#include "Mol/Commands/SelfTestAbort.h"
#include "Mol/Commands/SelfTestBeacon.h"
#include "Mol/Commands/SetSensitivityProfile.h"
#include "Mol/Commands/AuditMode.h"
#include "Mol/Commands/FireTest.h"
namespace Platform
{

using CommandType = Mol::Command::COMMAND_CATEGORY;
/*
* @brief Map for command name to Mol::Command::COMMAND_CATEGOR
*/
std::map<std::string,Mol::Command::COMMAND_CATEGORY> CommandNameToType
    { {"START_SERVER",CommandType::START_SERVER}
    , {"STOP_SERVER",CommandType::STOP_SERVER}
    , {"FILE_TRANSFER",CommandType::FILE_TRANSFER}
    , {"CHANGE_OPERATING_MODE",CommandType::CHANGE_OPERATING_MODE}
    , {"UPDATE_FIRMWARE",CommandType::UPDATE_FIRMWARE}
    , {"UPDATE_CONFIGURATION",CommandType::UPDATE_CONFIGURATION}
    , {"APPLY_FIRMWARE",CommandType::APPLY_FIRMWARE}
    , {"APPLY_CONFIGURATION",CommandType::APPLY_CONFIGURATION}
    , {"MODULE_REBOOT",CommandType::MODULE_REBOOT}
    , {"MODULE_SHUTDOWN",CommandType::MODULE_SHUTDOWN}
    , {"RESET",CommandType::RESET}
    , {"CLEAR_COUNTER",CommandType::CLEAR_COUNTER}
    , {"DELAY_ON",CommandType::DELAY_ON}
    , {"DELAY_OFF",CommandType::DELAY_OFF}
    , {"SET_ALARM_SIGNAL",CommandType::SET_ALARM_SIGNAL}
    , {"ENABLE",CommandType::ENABLE}
    , {"DISABLE",CommandType::DISABLE}
    , {"ACTIVATE",CommandType::ACTIVATE}
    , {"DEACTIVATE",CommandType::DEACTIVATE}
    , {"TEST_ZONE_START",CommandType::TEST_ZONE_START}
    , {"TEST_ZONE_STOP",CommandType::TEST_ZONE_STOP}
    , {"START_INDICATOR_TEST",CommandType::START_INDICATOR_TEST}
    , {"STOP_INDICATOR_TEST",CommandType::STOP_INDICATOR_TEST}
    , {"CONTROL_DEVICE",CommandType::CONTROL_DEVICE}
    , {"ALARM_OUTPUT",CommandType::ALARM_OUTPUT}
    , {"SERVICE_MODE",CommandType::SERVICE_MODE}
    , {"EXTEND_DELAYS",CommandType::EXTEND_DELAYS}
    , {"OVERRIDE_DELAYS",CommandType::OVERRIDE_DELAYS}
    , {"CANCEL_BUZZER",CommandType::CANCEL_BUZZER}
    , {"RESOUND",CommandType::RESOUND}
    , {"SILENCE",CommandType::SILENCE}
    , {"MEASURE_REFERENCE_RESISTANCE",CommandType::MEASURE_REFERENCE_RESISTANCE}
    , {"EARTH_FAULT_MONITORING",CommandType::EARTH_FAULT_MONITORING}
    , {"SET_DAY_NIGHT_MODE",CommandType::SET_DAY_NIGHT_MODE}
    , {"SET_DEBUG_LEVEL",CommandType::SET_DEBUG_LEVEL}
    , {"FUNCTION_ENABLE",CommandType::FUNCTION_ENABLE}
    , {"FUNCTION_DISABLE",CommandType::FUNCTION_DISABLE}
    , {"FARE_TEST",CommandType::FARE_TEST}
    , {"EVACUATION_ON",CommandType::EVACUATION_ON}
    , {"EVACUATION_OFF",CommandType::EVACUATION_OFF}
    , {"SET_TIME_DATE",CommandType::SET_TIME_DATE}
    , {"START_LOOP",CommandType::START_LOOP}
    , {"FIND_DEVICE",CommandType::FIND_DEVICE}
    , {"RESYNC",CommandType::RESYNC}
    , {"LOOP_AUTOLEARN",CommandType::LOOP_AUTOLEARN}
    , {"AUDIT_LOG_TXFER",CommandType::AUDIT_LOG_TXFER}
    , {"SYNC",CommandType::SYNC}
    , {"GENERATE_DEFAULT_CONFIG",CommandType::GENERATE_DEFAULT_CONFIG}
    , {"SELF_TEST",CommandType::SELF_TEST}
    , {"SELF_TEST_ABORT",CommandType::SELF_TEST_ABORT}
    , {"BEACON",CommandType::BEACON}
    , {"SET_SENSITIVITY_PROFILE",CommandType::SET_SENSITIVITY_PROFILE}
    , {"AUDIT_MODE",CommandType::AUDIT_MODE}
    , {"FIRE_TEST",CommandType::FIRE_TEST}
    , {"EVENTLOG_TXFER",CommandType::EVENTLOG_TXFER}
    };


std::string cm_toString(CommandType type)
{
    for(auto& command : CommandNameToType)
    {
        if(command.second == type)
        {
            return command.first;
        }
    }
    return "unknown";
}
/**
* @brief Set of command need code
*/
std::set<Mol::Command::COMMAND_CATEGORY> CodeNeededCommand
    { CommandType::APPLY_CONFIGURATION
    , CommandType::EARTH_FAULT_MONITORING
    , CommandType::START_SERVER
    , CommandType::STOP_SERVER
    , CommandType::FILE_TRANSFER
    , CommandType::UPDATE_FIRMWARE
    , CommandType::UPDATE_CONFIGURATION
    , CommandType::APPLY_FIRMWARE
    , CommandType::SET_ALARM_SIGNAL
    , CommandType::RESET
    , CommandType::CLEAR_COUNTER
    , CommandType::DISABLE
    , CommandType::ENABLE
    , CommandType::SET_DEBUG_LEVEL
    , CommandType::FUNCTION_DISABLE
    , CommandType::FUNCTION_ENABLE
    , CommandType::FARE_TEST
    , CommandType::SET_TIME_DATE
    , CommandType::SET_DAY_NIGHT_MODE
    , CommandType::START_LOOP
    , CommandType::FIND_DEVICE
    , CommandType::LOOP_AUTOLEARN
    , CommandType::AUDIT_LOG_TXFER
    , CommandType::SYNC
    , CommandType::SELF_TEST
    , CommandType::BEACON
    , CommandType::SET_SENSITIVITY_PROFILE
    , CommandType::AUDIT_MODE
    , CommandType::FIRE_TEST
    , CommandType::EVENTLOG_TXFER
    };

/**
* @brief map for Mol::Command::COMMAND_CATEGOR to command component
*/
std::map<Mol::Command::COMMAND_CATEGORY,std::function<std::shared_ptr<Platform::Component>( const uint64_t sourceId, Platform::Argumets& arguments)>> commandAction
    { {CommandType::ACTIVATE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::Activate,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::DEACTIVATE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::Deactivate,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::CANCEL_BUZZER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::CancelBuzzer,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::DELAY_OFF, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::DelayOff,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::DELAY_ON, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::DelayOn,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}


    , {CommandType::DISABLE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::Disable,Mol::Command::DISABLE_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::ENABLE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::Enable,Mol::Command::ENABLE_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::EXTEND_DELAYS, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::ExtendDelays,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::MEASURE_REFERENCE_RESISTANCE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::MeasureReferenceResistance,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::MODULE_REBOOT, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::ModuleReboot,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::MODULE_SHUTDOWN, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::ModuleShutdown,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::OVERRIDE_DELAYS, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::OverrideDelays,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::RESET, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        { return std::make_shared<CommandSender<Mol::Command::Reset,Mol::Command::RESET_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::CLEAR_COUNTER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        { return std::make_shared<CommandSender<Mol::Command::ClearCounter,Mol::Command::CLEAR_COUNTER_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::RESOUND, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::Resound,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::SERVICE_MODE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::ServiceMode,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::SILENCE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::Silence,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::APPLY_CONFIGURATION, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::ApplyConfiguration,Mol::Command::APPLY_CONFIGURATION_CODE>>(sourceId, arguments);}}

    , {CommandType::EARTH_FAULT_MONITORING, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::EarthFaultMonitoring,Mol::Command::EARTH_FAULT_MONITORING_CODE>>(sourceId, arguments);}}

    , {CommandType::START_SERVER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::StartServer,Mol::Command::SERVER_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::STOP_SERVER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::StopServer,Mol::Command::SERVER_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::FILE_TRANSFER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::FileTransfer,Mol::Command::FILE_TRANSFER_CODE>>(sourceId, arguments);}}

    , {CommandType::UPDATE_FIRMWARE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::UpdateFirmware,Mol::Command::UPDATE_FIRMWARE_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::UPDATE_CONFIGURATION, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::UpdateConfig,Mol::Command::UPDATE_CONFIG_TYPE_CODE>>(sourceId, arguments);}}

    , {CommandType::SET_ALARM_SIGNAL, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SetAlarmSignal,uint32_t>>(sourceId, arguments);}}

    , {CommandType::APPLY_FIRMWARE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::ApplyFirmware,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::BATTERY_OPERATION, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::BatteryOperation,Mol::Command::BATTERY_OPERATION_CODE>>(sourceId, arguments);}}

    , {CommandType::START_INDICATOR_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::StartIndicatorTest,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::STOP_INDICATOR_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            { return std::make_shared<CommandSender<Mol::Command::StopIndicatorTest,Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::SET_DEBUG_LEVEL, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SetDebugLevel, Mol::Command::DEBUG_LEVEL_CODE>>(sourceId, arguments);}}

    , {CommandType::FUNCTION_DISABLE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::FunctionDisable, Mol::FUNCTION_CODE>>(sourceId, arguments);}}

    , {CommandType::FUNCTION_ENABLE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::FunctionEnable, Mol::FUNCTION_CODE>>(sourceId, arguments);}}

    , {CommandType::FARE_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::FareTest, Mol::Command::FARE_TEST_CODE>>(sourceId, arguments);}}

    , {CommandType::EVACUATION_ON, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::EvacauationOn, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::EVACUATION_OFF, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::EvacauationOff, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}


    , {CommandType::TEST_ZONE_START, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::TestZoneStart, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}

    , {CommandType::TEST_ZONE_STOP, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::TestZoneStop, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::SET_TIME_DATE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SetTimeDate, uint32_t>>(sourceId, arguments);}}
    , {CommandType::SET_DAY_NIGHT_MODE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SetDayNightMode, Mol::Command::DAY_NIGHT_MODE>>(sourceId, arguments);}}
    , {CommandType::START_LOOP, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::StartLoop, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::FIND_DEVICE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::FindDevice, Mol::Command::FIND_DEVICE_CODE>>(sourceId, arguments);}}
    , {CommandType::RESYNC, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::ReSynchronization, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::LOOP_AUTOLEARN, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        { return std::make_shared<CommandSender<Mol::Command::LoopAutoLearn,Mol::Command::LOOP_AUTOLEARN_CODE>>(sourceId, arguments);}}
    , {CommandType::AUDIT_LOG_TXFER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        {return std::make_shared<CommandSender<Mol::Command::AuditLogTxfer, uint32_t>>(sourceId, arguments);}}
    , {CommandType::START_INDICATOR_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::StartIndicatorTest, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::STOP_INDICATOR_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::StopIndicatorTest, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::SYNC, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::Synchronization, Mol::Command::SYNC_TYPE_CODE>>(sourceId, arguments);}}
    , {CommandType::GENERATE_DEFAULT_CONFIG, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::GenerateDefaultConfig, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::SELF_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SelfTest, Mol::SELFTEST_CODE>>(sourceId, arguments);}}
    , {CommandType::SELF_TEST_ABORT, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SelfTestAbort, Mol::MESSAGE_DEFAULT_CODE>>(sourceId, arguments);}}
    , {CommandType::BEACON, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SelfTestBeacon, Mol::SELFTESTBEACON_CODE>>(sourceId, arguments);}}
    , {CommandType::SET_SENSITIVITY_PROFILE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                            {return std::make_shared<CommandSender<Mol::Command::SetSensitivityProfile, Mol::Command::SET_SENSITIVITY_PROFILE_CODE>>(sourceId, arguments);}}
    , {CommandType::AUDIT_MODE, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        { return std::make_shared<CommandSender<Mol::Command::AuditMode,Mol::Command::AUDIT_MODE_TYPE_CODE>>(sourceId, arguments);}}
    , {CommandType::FIRE_TEST, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        { return std::make_shared<CommandSender<Mol::Command::FireTest,Mol::Command::FIRE_TEST_CODE>>(sourceId, arguments);}}
    , {CommandType::EVENTLOG_TXFER, [](uint64_t sourceId,  Platform::Argumets& arguments)->std::shared_ptr<Platform::Component>
                        {return std::make_shared<CommandSender<Mol::Command::EventLogTxfer, uint32_t>>(sourceId, arguments);}}
    };

}

#endif //PLATFORM_TOOLS_HELPER_H
