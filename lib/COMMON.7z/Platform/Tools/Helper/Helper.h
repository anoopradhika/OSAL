/*******************************************************************************
* @file Helper .h
* @brief Data needed for Dragon are maintained here
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_TOOLS_HELPER_H
#define PLATFORM_TOOLS_HELPER_H

#include <map>
#include "CommonDef.h"
#include "DOL/DomainObject/DomainObject.h"
namespace Platform
{

/**
*@brief  argument used in command line argument parsing
*/
struct Argumets
{
    uint64_t deviceId{};
    std::string  timeperiod{0};
    std::string code{};
    PROC_ADDRESS clientId{};
    std::string  ObjectType{};
    std::string action;
    uint64_t parentId{};
    std::string  parentObjectType{};
	uint64_t targetId{};
    std::string  targetObjectType{};
    bool targetSetFlag{false};
};
struct cmpStr
{
    bool operator()(char const* lsh, char const* rsh) const
    {
        return std::strcmp(lsh,rsh)< 0;
    }
};
    extern std::map<std::string,PROC_ADDRESS>  processNameToId;
    extern std::map<const char*, Dol::DOMAIN_OBJECT_TYPE, cmpStr> stodtMap;
    Dol::DOMAIN_OBJECT_TYPE stodt(const char * name);

    std::string Dol_toString(Dol::DOMAIN_OBJECT_TYPE type);

    std::string proceesNameToStr(PROC_ADDRESS address);
/**
* @brief Support logical area and physical device
*
*/
}

#endif //PLATFORM_TOOLS_HELPER_H
