/*****************************************************************//**
 *
 * @file    RequestPrinter.h
 * @brief   Class to create Request objects and send
 *
 * @copyright Copyright 2021 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#ifndef RESPONSE_PRINTER_H
#define RESPONSE_PRINTER_H

// framework
#include "Mol/Responses/Response.h"
#include "Mol/Responses/ResponseTypeList.h"
#include "DesignPatterns/factory/factory.h"
#include "DesignPatterns/downcast/downcast.h"
#include "Communicator/Communicator.hpp"
#include "MolFactory/MolFactory.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include <string>
#include <chrono>
#include <ctime>

namespace Platform {

// Adapter to interface to a given user type
template <typename BASE, typename OBJ_TYPE>
class ResponseDowncastAdapter
{
    public:
        static auto StaticGetId() { return OBJ_TYPE::GetConcreteObjectType(); }
        static auto DynamicGetId( std::shared_ptr<BASE> base_ptr ) { return base_ptr->GetObjectType(); }
        static void Error( int i )
        { 
          // Intentionally unimplemented...
         }
};
struct ResponsePrinter {
    ResponsePrinter(uint64_t id, PROC_ADDRESS address):
                m_id{id}
                ,m_address{address}
    {
    }
    template < typename TYPE >
    void operator()( std::shared_ptr<TYPE> message )
    {
        auto objectReference = message->GetResponseTarget();
        std::time_t messageTime = message->GetTimestamp();
        std::string timeInString = std::ctime(&messageTime);
        auto parameters = message->GetParameters();
		auto source = message->GetSource();
		auto target = message->GetTarget();
        std::string discription;
        for(auto& parameter : parameters)
        {
            if( parameter.GetCatalog() == Mol::DataType::Parameter::CATALOG::DESCRIPTION)
            {
                discription += parameter.template GetValue<std::string>();
                discription += " ";
            }
        }
		timeInString.erase(std::remove(timeInString.begin(), timeInString.end(), '\n'), timeInString.end());
        auto printData = DEBUGPRINT::format("Response Time:{0} Type:{1} Code:{2} SourceTarget Type:{3} SourceTarget id:{4:#x} PROC_ADDRESS {5} ADP {6} senderID {7:#x} Source id:{8:#x} Source Type:{9} Target id:{10:#x} Target Type:{11}",
                        timeInString
                      , rs_toString(message->GetObjectType())
                      , (uint32_t) message->GetResponseCode()
                      , Dol_toString(objectReference.GetObjectType())
                      , objectReference.GetObjectId()
                      , proceesNameToStr(m_address)
                      ,discription
                      ,m_id
					  ,source.GetObjectId()
					  ,Dol_toString(source.GetObjectType())
					  ,target.GetObjectId()
					  ,Dol_toString(target.GetObjectType())
                  );        
		DEBUGPRINT(DEBUG_INFO,printData);
     }
    uint64_t m_id;
    PROC_ADDRESS m_address;
};

auto PrintResponse = [](auto response, uint64_t id, PROC_ADDRESS address)
{
    using ResponseCaster = Platform::CastAndCall< ResponseDowncastAdapter,  Mol::Message<Mol::Response::RESPONSE_CATEGORY>, ResponseObjectTypes >;
    ResponseCaster::Do<Mol::Response::ResponseDefault>(response,ResponsePrinter{id,address});
};
} // end namespace
#endif //RESPONSE_PRINTER_H
