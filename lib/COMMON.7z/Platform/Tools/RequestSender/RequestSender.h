/*******************************************************************************
* @file RequestSender .h
* @brief Send all type of MOL Requests
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_MOL_REQUEST_SENDER_H
#define PLATFORM_MOL_REQUEST_SENDER_H

#include "Component/Component.h"
#include "Mol/Requests/Request.h"

namespace Platform
{

/**
 * @brief    RequestSender send the assigned request
*/
template<typename ObjectType, typename CodeType>
class RequestSender: public Platform::Component
{
public:
    /**
    * @brief Constructor
    * @param deviceId device unique ID
    * @param client client to send request
    * @param code code associated with request
    */
    RequestSender(const uint64_t sourceId, Platform::Argumets& arguments)
        : m_sourceId{sourceId}
        , m_arguments{arguments}
    {
        if(!m_arguments.code.empty())
        {
            m_code = static_cast<CodeType>(std::stoi(m_arguments.code));
        }
    }

    void Start() override
    {
        if(std::is_same<CodeType, Mol::MESSAGE_DEFAULT_CODE>::value)
        {
            SendRequest(m_arguments.clientId);
        }
        else
        {
            SendRequest(m_arguments.clientId,m_code);
        }
        Platform::Component::Start();
    }

    virtual ~RequestSender() = default;

protected:
    const uint64_t m_sourceId  = 0;


    /**
        @brief Send a request
        @param client client to send message
        @tparam code code associated with request
    */
    void SendRequest(const PROC_ADDRESS client, const CodeType code)
    {
        auto request = std::make_shared<ObjectType>();
		request->SetRequestCode(code);
        SendRequest(client, request);
    }

    /**
        @brief Send a request
        @param client client to send message
    */
    void SendRequest(const PROC_ADDRESS client)
    {
        auto request = std::make_shared<ObjectType>();
        SendRequest(client, request);
    }

private:

       /// code associated with request
       CodeType m_code;
      
       Platform::Argumets m_arguments;
    /**
        @brief Send a request
        @param client    client to send message
        @param request   request to send
    */
    void SendRequest(const PROC_ADDRESS client, const std::shared_ptr<ObjectType> request)
    {
		auto sourceTarget = Mol::DataType::ObjectReference{m_arguments.deviceId,stodt(m_arguments.ObjectType.c_str())};
   		auto source = Mol::DataType::ObjectReference{m_arguments.parentId, stodt(m_arguments.parentObjectType.c_str())};
		auto target = Mol::DataType::ObjectReference{0, Dol::DOMAIN_OBJECT_TYPE::END_OF_LIST};	
		request->SetSourceTarget(sourceTarget);
		request->SetSource(source);
		if(m_arguments.targetSetFlag)
		{
        	target = Mol::DataType::ObjectReference{m_arguments.targetId,stodt(m_arguments.targetObjectType.c_str())};
			request->SetTarget(target);
			m_arguments.targetSetFlag = false;
		}
		else
		{
			target = sourceTarget;
			request->SetTarget(sourceTarget);
		}

		m_communicator.m_request.Send(request, client, GetDestinationId(target));        
	}

    uint64_t GetDestinationId(Mol::DataType::ObjectReference& reference)
    {
        reference.PrepareDeviceUniqueID();
        if(reference.GetDNM() != 0)
        {
            return reference.GetDNM64Bit();
        }
        else
        {
            auto multicastId = Mol::DeviceUniqueID{m_sourceId};
            return multicastId.GetModuleMultCastId();
        }
    }
};

}

#endif //PLATFORM_MOL_REQUEST_SENDER_H

