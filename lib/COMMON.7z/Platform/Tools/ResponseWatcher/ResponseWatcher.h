/**********************************************************************************
* @file ResponseWatcher .h
* @brief scan all type of Response
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_RESPONSE_WATCHER_H
#define PLATFORM_MOL_RESPONSE_WATCHER_H
#include "Helper/Helper.h"
#include "Helper/ResponsePrinter.h"
#include "Component/Component.h"
#include "Timer/Timer.hpp"
#include "Helper/ResponseHelper.h"
#include "Mol/Responses/ObjectDataResponse.h"
#include "Mol/Responses/ChargerInfoResponse.h"
#include "DOL/Entities/Zone/Zone.h"
#include "Mol/Responses/NotifierDeviceStatusResponse.h"
#include "Mol/Responses/DeviceDiagnosticResponse.h"
#include "Mol/Responses/MultiObjectData.h"

namespace Platform
{

/**
 * @brief    ResponseWatcher main responsibility is to
 *           scan the Response and print
*/
class ResponseWatcher: public Platform::Component
{
public:

    /**
    * @brief  Response validation and add associated response component
    * @param arguments arguments for response
    */
    explicit ResponseWatcher(Platform::Argumets& arguments)
    {
        MolResponseSubscribe<Mol::Response::ObjectDataResponse,RESPONSE_CATEGORY>(RESPONSE_CATEGORY::OBJECT_STATUS);
    	MolResponseSubscribe<Mol::Response::ChargerInfoResponse,RESPONSE_CATEGORY>(RESPONSE_CATEGORY::CHARGER_INFO_RESPONSE);
		MolResponseSubscribe<Mol::Response::NotifierDeviceStatusResponse,RESPONSE_CATEGORY>(RESPONSE_CATEGORY::NOTIFIER_DEVICE_STATUS_RESPONSE);
        MolResponseSubscribe<Mol::Response::DeviceDiagnosticResponse,RESPONSE_CATEGORY>(RESPONSE_CATEGORY::DEVICE_DIAGNOSTIC_RESPONSE);
		MolResponseSubscribe<Mol::Response::MultiObjectData,RESPONSE_CATEGORY>(RESPONSE_CATEGORY::MULTI_OBJECT_DATA);
	}

    ~ ResponseWatcher() = default;
private:
    using RESPONSE_CATEGORY = Mol::Response::RESPONSE_CATEGORY;
    template<typename response, typename responseType>
    void MolResponseSubscribe(responseType responseTypeId)
    {

        m_communicator.m_response.Subscribe<response>(responseTypeId);
        m_communicator.m_response.getServiceWithApplicationType(responseTypeId)->Connect(this, &ResponseWatcher::ReceiveResponse);
    }


    void ReceiveResponse(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> response, const uint64_t senderID, PROC_ADDRESS address)
    {
        PrintResponse(response,senderID,address);
    }
};

}
#endif //PLATFORM_MOL_RESPONSE_WATCHER_H

