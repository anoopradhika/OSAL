/*******************************************************************************
* @file EventSender .h
* @brief Send all types of MOL events
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
*******************************************************************************/

#ifndef PLATFORM_MOL_EVENT_SENDER_H
#define PLATFORM_MOL_EVENT_SENDER_H

#include "Component/Component.h"
#include "Mol/Events/Event.h"
#include "DOL/DomainObject/DomainObject.h"

namespace Platform
{

/**
 * @brief    EventSender send the assigned event
*/
template<typename ObjectType, typename CodeType>
class EventSender: public Platform::Component
{
public:
    /**
    * @brief Constructor convert code string to actual code
    * @param deviceId device unique ID
    * @param clientId clientId to send event
    * @param code code associated with event
    */
    EventSender(const uint64_t sourceId, Platform::Argumets& arguments)
        : m_sourceId{sourceId}
        , m_arguments{arguments}
    {
        if(!m_arguments.code.empty())
        {
            m_code = static_cast<CodeType>(std::stoi(m_arguments.code));
        }
        std::cout<<"-----------deviceId ------"<<m_arguments.deviceId<<std::endl;
        std::cout<<"-----------time------"<<m_arguments.timeperiod<<std::endl;
        std::cout<<"-----------code------"<<m_arguments.code<<std::endl;
        std::cout<<"-----------clientId------"<<(uint32_t)m_arguments.clientId<<std::endl;
        std::cout<<"-----------ObjectType------"<<m_arguments.ObjectType<<std::endl;
        std::cout<<"-----------action------"<<m_arguments.action<<std::endl;
        std::cout<<"-----------parentId------"<<m_arguments.parentId<<std::endl;
        std::cout<<"-----------parentObjectType------"<<m_arguments.parentObjectType<<std::endl;
    }

    void Start() override
    {
        if(std::is_same<CodeType, Mol::MESSAGE_DEFAULT_CODE>::value)
        {
            SendEvent(m_arguments.clientId);
        }
        else
        {
            SendEvent(m_arguments.clientId,m_code);
        }
        Platform::Component::Start();
    }

    virtual ~EventSender() = default;

protected:
    const uint64_t m_sourceId  = 0;

    /// code associated with command
    CodeType m_code;

    Platform::Argumets m_arguments;
    /**
        @brief Send a event
        @param clientId: clientId to which we send message
        @tparam code: code associated with event
    */
    void SendEvent(PROC_ADDRESS clientId,CodeType code)
    {
        std::cout<<"-----------deviceId ------"<<m_arguments.deviceId<<std::endl;
        std::cout<<"-----------time------"<<m_arguments.timeperiod<<std::endl;
        std::cout<<"-----------code------"<<m_arguments.code<<std::endl;
        std::cout<<"-----------clientId------"<<(uint32_t)m_arguments.clientId<<std::endl;
        std::cout<<"-----------ObjectType------"<<m_arguments.ObjectType<<std::endl;
        std::cout<<"-----------action------"<<m_arguments.action<<std::endl;
        std::cout<<"-----------parentId------"<<m_arguments.parentId<<std::endl;
        std::cout<<"-----------parentObjectType------"<<m_arguments.parentObjectType<<std::endl;
        auto event = std::make_shared<ObjectType>(code);
        Mol::DataType::ObjectReference source;
        Mol::Event::EVENT_APPLICATION applicationId = Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS;
       if(m_arguments.ObjectType.find("TECH_ALARM_ZONE") !=std::string::npos)
        {
             source = Mol::DataType::ObjectReference{m_arguments.deviceId, stodt("DETECTION")};
             applicationId = Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS;
             source.PrepareDeviceUniqueID();
            event->SetSource(source);
            event->SetEventApplication(applicationId);
        }
       else if(m_arguments.ObjectType.find("TECH_ALARM") !=std::string::npos)
        {
             source = Mol::DataType::ObjectReference{m_arguments.deviceId, stodt("FIRE_SENSOR_INPUT")};
             applicationId = Mol::Event::EVENT_APPLICATION::CRITICAL_PROCESS;
             source.PrepareDeviceUniqueID();
            event->SetSource(source);
            event->SetEventApplication(applicationId);
        }
        else
        {
            source = Mol::DataType::ObjectReference{m_arguments.deviceId, stodt(m_arguments.ObjectType.c_str())};
            applicationId = Mol::Event::EVENT_APPLICATION::FIRE;
            source.PrepareDeviceUniqueID();
            event->SetSource(source);
        }
        event->SetEventApplication(applicationId);
        if(event->GetEventCategory() == Mol::Event::EVENT_CATEGORY::ALARM)
        {
            event->AddLabel(Dol::Label("Detection zone (de_DE)", "de_DE", Dol::Label::LABEL_TYPE::POINT));
            event->AddLabel(Dol::Label("Detection zone (de_DE)", "de_DE", Dol::Label::LABEL_TYPE::POINT));
            if(m_arguments.parentObjectType.empty())
            {
                auto parent = Mol::DataType::ObjectReference{1401,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
                event->AddParent( parent);
            }
            else
            {
                auto parent = Mol::DataType::ObjectReference{m_arguments.parentId,stodt(m_arguments.parentObjectType.c_str())};
                event->AddParent( parent);
            }
        }
        else if(event->GetEventCategory() == Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL)
        {
            event->AddLabel(Dol::Label("Alarm zone (en_UK)", "en_UK", Dol::Label::LABEL_TYPE::POINT));
            if(m_arguments.parentObjectType.empty())
            {
                auto parent = Mol::DataType::ObjectReference{1115,Dol::DOMAIN_OBJECT_TYPE::ALARM_ZONE};
                event->AddParent( parent);
            }
            else
            {
                auto parent = Mol::DataType::ObjectReference{m_arguments.parentId,stodt(m_arguments.parentObjectType.c_str())};
                event->AddParent( parent);
            }
        }
        else if(event->GetEventCategory() == Mol::Event::EVENT_CATEGORY::ACTIVATION)
        {
            event->AddLabel(Dol::Label("Control zone (en_UK)", "en_UK", Dol::Label::LABEL_TYPE::POINT));
            if(m_arguments.parentObjectType.empty())
            {
                auto parent = Mol::DataType::ObjectReference{1404,Dol::DOMAIN_OBJECT_TYPE::CONTROL_ZONE};
                event->AddParent( parent);
            }
            else
            {
                auto parent = Mol::DataType::ObjectReference{m_arguments.parentId,stodt(m_arguments.parentObjectType.c_str())};
                event->AddParent( parent);
            }
        }
        else
        {
            event->AddLabel(Dol::Label("Detction zone (en_UK)", "en_UK", Dol::Label::LABEL_TYPE::POINT));
            if(m_arguments.parentObjectType.empty())
            {
                auto parent = Mol::DataType::ObjectReference{1405,Dol::DOMAIN_OBJECT_TYPE::DETECTION_ZONE};
                event->AddParent( parent);
            }
            else
            {
                auto parent = Mol::DataType::ObjectReference{m_arguments.parentId,stodt(m_arguments.parentObjectType.c_str())};
                event->AddParent( parent);
            }
        }
        std::string zoneRef = std::to_string(source.GetDeviceAddress());
        event->SetZonePointReference(zoneRef);
        m_communicator.m_event.Send(event, clientId, GetDestinationId(source));
    }

    /**
        @brief Send a command
        @param clientId: clientId to which we send message
    */
    void SendEvent(PROC_ADDRESS clientId)
    {
        auto event = std::make_shared<ObjectType>();
        auto source = Mol::DataType::ObjectReference{m_arguments.deviceId,stodt(m_arguments.ObjectType.c_str())};
        event->SetSource(source);
        m_communicator.m_event.Send(event, clientId, GetDestinationId(source));
    }

    uint64_t GetDestinationId(Mol::DataType::ObjectReference& reference)
    {
        reference.PrepareDeviceUniqueID();
        if(reference.GetDNM() != 0)
        {
            return reference.GetDNM64Bit();
        }
        else
        {
            auto multicastId = Mol::DeviceUniqueID{m_sourceId};
            return multicastId.GetModuleMultCastId();
        }
    }
};

}

#endif //PLATFORM_MOL_EVENT_SENDER_H
