/**********************************************************************************
* @file EventGenerator .h
* @brief Generate all type of event
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_EVENT_GENERATOR_H
#define PLATFORM_MOL_EVENT_GENERATOR_H
#include "Helper/Helper.h"
#include "Helper/EventHelper.h"
#include "Application/Application.h"
#include "EventSender/EventSender.h"
#include "Timer/Timer.hpp"

namespace Platform
{

/**
 * @brief    EventGenerator main responsibility is to
 *           trigger the comand specifi ccomponent to send the command
*/
class EventGenerator: public Platform::Application
{
public:

    /**
    * @brief  Command validation and add associated command component
    * @param arguments arguments for command
    */
    explicit EventGenerator(Platform::Argumets arguments)
    : Application{PROC_ADDRESS::MOL_SENDER, m_sourceID}
    {
        std::cout<<"-----------deviceId ------"<<arguments.deviceId<<std::endl;
        std::cout<<"-----------time------"<<arguments.timeperiod<<std::endl;
        std::cout<<"-----------code------"<<arguments.code<<std::endl;
        std::cout<<"-----------clientId------"<<(uint32_t)arguments.clientId<<std::endl;
        std::cout<<"-----------ObjectType------"<<arguments.ObjectType<<std::endl;
        std::cout<<"-----------action------"<<arguments.action<<std::endl;
        std::cout<<"-----------parentId------"<<arguments.parentId<<std::endl;
        std::cout<<"-----------parentObjectType------"<<arguments.parentObjectType<<std::endl;
        auto eventName = EventNameToType.find(arguments.action);
        if(eventName == EventNameToType.end() )
        {
            DEBUGPRINT(DEBUG_INFO,"Dragon does not support Event {}. Ask human for support",arguments.action);
            DEBUGPRINT(DEBUG_INFO,"EventNameToType size {} ",EventNameToType.size());
            exit(-1);
        }
        auto eventToExecute = EventAction.find(eventName->second);
        if(eventToExecute == EventAction.end() )
        {
            DEBUGPRINT(DEBUG_INFO,"Dragon does not support Event {} action. Ask human for support",arguments.action);
            exit(-1);
        }
        if(arguments.code.empty())
        {
            auto checkNeed = CodeNeededEvent.find(eventName->second);
            if(checkNeed != CodeNeededEvent.end())
            {
                DEBUGPRINT(DEBUG_INFO,"Event {} need code",arguments.action);
                exit(-1);
            }
        }
        else
        {
            auto checkNeed = CodeNeededEvent.find(eventName->second);
            if(checkNeed == CodeNeededEvent.end())
            {
                DEBUGPRINT(DEBUG_INFO,"Event {} does not need code",arguments.action);
                exit(-1);
            }
        }
        AddComponent(eventToExecute->second(m_sourceID, arguments));

        if(arguments.clientId == PROC_ADDRESS::BROADCAST)
        {
            // dont send event to CMCAPP
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MAINLOOP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CNE);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::IOMGR);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::NETWORK);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENTLOGAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::FIRE_DOMAIN_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MOL_RECEIVER);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENT_PROVIDERAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::LICENSEVALIDATOR);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::AUDITLOG_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::ENGLOG_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::ACTIVE_EVENTSAPP);
            // m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::ZONALINDICATOR);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::PANELLEARN_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CLSSMGR);
        }
        else
        {
            m_communicator.m_messageTransporter.Connect(arguments.clientId);
        }
    }

    /**
    * @brief Start a timer to terminate the application
    */
    void Start() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this, &EventGenerator::Terminate);
        m_timer = Platform::Timer<>(m_timeToTerminateMs, GlobalDataType::Timer::AlarmType::SINGLE_SHOT, notifier);
        m_timer.Start();
        Platform::Application::Start();
    }

    ~ EventGenerator() = default;
private:
    /*
    * @brief Terminate the application
    */
    void Terminate()
    {
        m_looper->Terminate();
    }

    /// Unique Id to satisfy ACFW
    static constexpr uint64_t m_sourceID = 0x0100010C00000000;

    /// Timer to terimate application
    Platform::Timer<> m_timer{};

    /// Time to terimate application
    static constexpr uint64_t m_timeToTerminateMs = 1;
};

}
#endif //PLATFORM_MOL_EVENT_GENERATOR_H
