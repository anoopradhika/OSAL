/**********************************************************************************
* @file CommandGenerator .h
* @brief Generate all type of command
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_COMMAND_GENERATOR_H
#define PLATFORM_MOL_COMMAND_GENERATOR_H

#include "Helper/Helper.h"
#include "Helper/CommandHelper.h"

#include "Application/Application.h"
#include "CommandSender/CommandSender.h"
#include "Mol/Commands/Activate.h"
#include "Mol/Commands/Deactivate.h"
#include "Mol/Commands/ApplyConfiguration.h"
#include "Timer/Timer.hpp"

namespace Platform
{

/**
 * @brief    CommandGenerator main responsibilitie is to
 *           trigger the comand specifc component to send the command
*/
class CommandGenerator: public Platform::Application
{
public:

    /**
    * @brief  Command validation and add associated command component
    * @param arguments arguments for command
    */
    explicit CommandGenerator(Platform::Argumets arguments)
    : Application{PROC_ADDRESS::MOL_SENDER, m_sourceID}
    {

        auto commandName = CommandNameToType.find(arguments.action);
        if(commandName == CommandNameToType.end() )
        {
            DEBUGPRINT(DEBUG_INFO,"Dragon does not supported Command {}. Ask human for support",arguments.action);
            ::exit(-1);
        }
        auto commanToExecute = commandAction.find(commandName->second);
        if(commanToExecute == commandAction.end() )
        {
            DEBUGPRINT(DEBUG_INFO,"Dragon does not supported Commands {} acttion. Ask human for support",arguments.action);
            ::exit(-1);
        }
        if(arguments.code.empty())
        {
            auto codeacheck = CodeNeededCommand.find(commandName->second);
            if(codeacheck != CodeNeededCommand.end())
            {
                DEBUGPRINT(DEBUG_INFO,"Command {} need code",arguments.action);
                ::exit(-1);
            }
        }
        else
        {
            auto codeacheck = CodeNeededCommand.find(commandName->second);
            if(codeacheck == CodeNeededCommand.end())
            {
                DEBUGPRINT(DEBUG_INFO,"Command {} does not need codee",arguments.action);
                ::exit(-1);
            }
        }
        AddComponent(commanToExecute->second(m_sourceID, arguments));
        if(arguments.clientId == PROC_ADDRESS::BROADCAST)
        {
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CMCAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MAINLOOP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CNE);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::IOMGR);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::NETWORK);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENTLOGAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::FIRE_DOMAIN_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MOL_RECEIVER);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENT_PROVIDERAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::LICENSEVALIDATOR);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::AUDITLOG_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::ENGLOG_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::ACTIVE_EVENTSAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CLSSMGR);
        }
        else
        {
            m_communicator.m_messageTransporter.Connect(arguments.clientId);
        }

    }

    /**
    * @brief Start a timer to terimate the application
    */
    void Start() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this,&CommandGenerator::Terminate);
        m_timer = Platform::Timer<>(m_timeToTerminateMs,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);
        m_timer.Start();
        Platform::Application::Start();
    }

    ~ CommandGenerator() = default;
private:
    /*
    * @brief Terminate the application
    */
    void Terminate() const
    {
        m_looper->Terminate();
    }

    /// Unique Id to satisfy ACFW
    static constexpr uint64_t m_sourceID = 0x0100010100000000;

    /// Timer to terimate application
    Platform::Timer<> m_timer{};

    /// Time to terimate application
    static constexpr uint64_t m_timeToTerminateMs = 1;
};

}
#endif //PLATFORM_MOL_COMMAND_GENERATOR_H
