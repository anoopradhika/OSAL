/**********************************************************************************
* @file MolWatcher .h
* @brief Generate all type of event
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_WATCHER_H
#define PLATFORM_MOL_WATCHER_H
#include "Helper/Helper.h"
#include "Helper/EventHelper.h"
#include "Helper/EventPrinter.h"
#include "Application/Application.h"
#include "EventWatcher/EventWatcher.h"
#include "CommandWatcher/CommandWatcher.h"
#include "RequestWatcher/RequestWatcher.h"
#include "ResponseWatcher/ResponseWatcher.h"
#include "Timer/Timer.hpp"

namespace Platform
{

/**
 * @brief    MolWatcher main responsibility is to
 *           trigger the comand specifi ccomponent to send the command
*/
class MolWatcher: public Platform::Application
{
public:
    /**
    * @brief  Command validation and add associated command component
    * @param arguments arguments for command
    */
    MolWatcher(std::string& componentType, Platform::Argumets& arguments)
    : Application{PROC_ADDRESS::MOL_RECEIVER, m_sourceID}
    {
        DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
        DEBUGPRINT::SetOutStream(OutStream::STDOUT);
        if(arguments.timeperiod.compare("DEFAULT"))
        {
            m_timeToTerminateMs = std::stoll(arguments.timeperiod);
        }
        if( (componentType.compare("COMMAND") == 0) || (componentType.compare("ALL") == 0) )
        {
            AddComponent(std::make_shared<CommandWatcher>(arguments));
        }

        if( (componentType.compare("EVENT") == 0 ) || (componentType.compare("ALL") == 0) )
        {
            AddComponent(std::make_shared<EventWatcher>(arguments));
        }
        if( (componentType.compare("REQUEST") == 0 ) || (componentType.compare("ALL") == 0) )
        {
            AddComponent(std::make_shared<RequestWatcher>(arguments));
        }
		if( (componentType.compare("RESPONSE") == 0 ) || (componentType.compare("ALL") == 0) )
        {
            AddComponent(std::make_shared<ResponseWatcher>(arguments));
        }
    }

    /**
    * @brief Start a timer to terminate the application
    */
    void Start() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this, &MolWatcher::Terminate);
        m_timer = Platform::Timer<>(m_timeToTerminateMs, GlobalDataType::Timer::AlarmType::SINGLE_SHOT, notifier);
        m_timer.Start();
        Platform::Application::Start();
    }

    ~ MolWatcher() = default;
private:

    /*
    * @brief Terminate the application
    */
    void Terminate()
    {
        m_looper->Terminate();
    }

    /// Unique Id to satisfy ACFW
    static constexpr uint64_t m_sourceID = 0x0100010100000000;

    /// Timer to terimate application
    Platform::Timer<> m_timer{};

    /// Time to terimate application
    uint64_t m_timeToTerminateMs = 1000*100;
};

}
#endif //PLATFORM_MOL_COMMAND_WATCHER_H
