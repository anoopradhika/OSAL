/**********************************************************************************
* @file RequestGenerator .h
* @brief Generate all type of Request
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_REQUEST_GENERATOR_H
#define PLATFORM_MOL_REQUEST_GENERATOR_H

#include "Helper/Helper.h"
#include "Helper/RequestHelper.h"
#include "Application/Application.h"
#include "Timer/Timer.hpp"
#include "RequestSender/RequestSender.h"
#include "Mol/Requests/ObjectData.h"
namespace Platform
{

/**
 * @brief    RequestGenerator main responsibilitie is to
 *           trigger the Request specifc component to send the request
*/
class RequestGenerator: public Platform::Application
{
public:

    /**
    * @brief  Request validation and add associated request component
    * @param arguments arguments for request
    */
    explicit RequestGenerator(Platform::Argumets arguments)
    : Application{PROC_ADDRESS::MOL_SENDER, m_sourceID}
    {

        auto requestName = RequestNameToType.find(arguments.action);
        if(requestName == RequestNameToType.end() )
        {
            DEBUGPRINT(DEBUG_INFO,"Dragon does not supported Request {}. Ask human for support",arguments.action);
            ::exit(-1);
        }
        auto requestToExecute = requestAction.find(requestName->second);
        if(requestToExecute == requestAction.end() )
        {
            DEBUGPRINT(DEBUG_INFO,"Dragon does not supported Request {} acttion. Ask human for support",arguments.action);
            ::exit(-1);
        }
        if(arguments.code.empty())
        {
            auto codeacheck = CodeNeededRequest.find(requestName->second);
            if(codeacheck != CodeNeededRequest.end())
            {
                DEBUGPRINT(DEBUG_INFO,"Request {} need code",arguments.action);
                ::exit(-1);
            }
        }
        else
        {
            auto codeacheck = CodeNeededRequest.find(requestName->second);
            if(codeacheck == CodeNeededRequest.end())
            {
                DEBUGPRINT(DEBUG_INFO,"Request {} does not need codee",arguments.action);
                ::exit(-1);
            }
        }
        AddComponent(requestToExecute->second(m_sourceID, arguments));
        if(arguments.clientId == PROC_ADDRESS::BROADCAST)
        {
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CMCAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MAINLOOP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::CNE);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::IOMGR);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::NETWORK);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENTLOGAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::FIRE_DOMAIN_APP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::MOL_RECEIVER);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::EVENT_PROVIDERAPP);
            m_communicator.m_messageTransporter.Connect(PROC_ADDRESS::LICENSEVALIDATOR);
        }
        else
        {
            m_communicator.m_messageTransporter.Connect(arguments.clientId);
        }

    }

    /**
    * @brief Start a timer to terimate the application
    */
    void Start() override
    {
        Platform::Notifier notifier;
        notifier.Connect(this,&RequestGenerator::Terminate);
        m_timer = Platform::Timer<>(m_timeToTerminateMs,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);
        m_timer.Start();
        Platform::Application::Start();
    }

    ~ RequestGenerator() = default;
private:
    /*
    * @brief Terminate the application
    */
    void Terminate() const
    {
        m_looper->Terminate();
    }

    /// Unique Id to satisfy ACFW
    static constexpr uint64_t m_sourceID = 0x0100010100000000;

    /// Timer to terimate application
    Platform::Timer<> m_timer{};

    /// Time to terimate application
    static constexpr uint64_t m_timeToTerminateMs = 1;
};

}
#endif //PLATFORM_MOL_REQUEST_GENERATOR_H

