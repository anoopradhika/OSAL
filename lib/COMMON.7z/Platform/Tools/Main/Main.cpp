
/*****************************************************************//**
 *
 * @file    Main.cpp
 * @brief   MOL sender application
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include <sys/resource.h>

#include "Dragon/CommandGenerator.h"
#include "Dragon/EventGenerator.h"
#include "Dragon/RequestGenerator.h"
#include "Dragon/ResponseGenerator.h"
#include "Dragon/MolWatcher.h"
#include "CommonDef.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include "Application/Application.h"
#include "Helper/Helper.h"
#include "Helper/CommandHelper.h"
#include "Helper/EventHelper.h"
#include "Helper/RequestHelper.h"
#include "Helper/ResponseHelper.h"
#include <string>
#include <vector>
#define MOL_MESSAGE_WITH_CODE								7
#define REQUEST_RESPONSE_WITH_SOURCEINFO					8
#define MOL_MESSAGE_WITH_CODE_PARENTINFO					9
#define REQUEST_RESPONSE_WITH_SOURCEINFO_TARGETINFO			10
#define REQUEST_RESPONSE_WITH_CODE_SOURCEINFO_TARGETINFO	11

void AddEndOfList(std::string space, std::string& data)
{
    data.append(space);
    data.append("END_OF_LIST");
    data.append("\n ");
}

/*
* usage
*/

void Usage(const std::string& process)
{
    {
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
        DEBUGPRINT(DEBUG_INFO,"{} <operation> <client ID> <uinqueID> <DOMAIN_OBJECT_TYPE> <event> <code optional>",process);
        std::string data{"COMMAND, EVENT , REQUEST , RESPONSE \n"};
        AddEndOfList("                               ",data);
        DEBUGPRINT(DEBUG_INFO,"Operations are {}",data);

        data.clear();
        for(auto& idmap :Platform::processNameToId)
        {
            data.append("                               ");
            data.append(idmap.first);
            data.append("\n ");
        }
        AddEndOfList("                               ",data);
        DEBUGPRINT(DEBUG_INFO,"client IDs are:  \n {} \n",data);
        data.clear();
        data.append("\n ");
        for(auto& idmap :Platform::stodtMap)
        {
            data.append("                               ");
            data.append(idmap.first);
            data.append("\n ");
        }
        AddEndOfList("                               ",data);
        DEBUGPRINT(DEBUG_INFO,"DOMAIN_OBJECT_TYPE are: {} ",data);
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
    }
    {
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
        DEBUGPRINT(DEBUG_INFO,"{} <operation> <options>",process);
        DEBUGPRINT(DEBUG_INFO,"Operations are COMMAND, EVENT, REQUEST ,RESPONSE");
        DEBUGPRINT(DEBUG_INFO,"options are: list ");
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
    }

}

void Usage(const std::string& process, const std::string& MOLType)
{
    if( MOLType.compare(std::string{"COMMAND"}) )
    {
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
        DEBUGPRINT(DEBUG_INFO,"{} COMMAND <client ID> <uinqueID> <DOMAIN_OBJECT_TYPE> <command> <code optional>",process);
        std::string clientIds{};
        clientIds.append("\"");
        for(auto& idmap :Platform::processNameToId)
        {
            clientIds.append(idmap.first);
            clientIds.append(" ");
        }
        clientIds.append("\"");
        DEBUGPRINT(DEBUG_INFO,"client IDs are {} ",clientIds);
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
    }
    else if( MOLType.compare(std::string{"EVENT"}) )
    {
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
        DEBUGPRINT(DEBUG_INFO,"{} EVENT <client ID> <uinqueID> <DOMAIN_OBJECT_TYPE> <event> <code optional>",process);
        std::string clientIds{};
        for(auto& idmap :Platform::processNameToId)
        {
            clientIds.append(idmap.first);
            clientIds.append(" ");
        }

        DEBUGPRINT(DEBUG_INFO,"client IDs are {} ",clientIds);
        DEBUGPRINT(DEBUG_INFO,"--------------------------------------------------------------------------------");
    }
    else
    {
        Usage(process);
    }
    exit(-1);
}

void Usage(const std::string& process, const std::string& MOLType, const std::string& options )
{
    if( (0 == MOLType.compare(std::string{"COMMAND"})) && (0 == options.compare(std::string{"list"})) )
    {
        std::string data;
        for(auto& name : Platform::CommandNameToType)
        {
            data.append("                         ");
            data.append(name.first);
            data.append("\n ");
        }
        AddEndOfList("                         ",data);
        DEBUGPRINT(DEBUG_INFO,"{} list :\n {} ",MOLType,data);
    }
    else if( (0 == MOLType.compare(std::string{"EVENT"})) && (0 == options.compare(std::string{"list"})) )
    {
        std::string data;
        for(auto& name : Platform::EventNameToType)
        {
            data.append("                         ");
            data.append(name.first);
            data.append("\n ");
        }
        AddEndOfList("                         ", data);
        DEBUGPRINT(DEBUG_INFO,"{} list :\n {} ",MOLType, data);
    }
    else
    {
        Usage(process,MOLType);
    }
    exit(-1);
}

/*
 *@brief Parse command line argument and prepare Platform::Argumets.
 *
 *@param[in]    argc argument count from command line
 *@param[in]    allArgs vector of argument expect process name
 *return Argumets Platform::Argumets
 */
Platform::Argumets PrepareArguments(int argc, const std::string& process, const std::vector<std::string>& allArgs)
{
    if(argc < 2)
    {
        Usage(process, std::string{});
    }
    if(argc == 2)
    {
        Usage(process, allArgs[0] );
    }
    if(argc == 3)
    {
        Usage(process, allArgs[0], allArgs[1]);
    }

    std::string argumentToExecute;
    for (const std::string& c : allArgs)
    {
        //std::cout << c <<" ";
        argumentToExecute.append(c);
        argumentToExecute.append(" ");

    }
    DEBUGPRINT(DEBUG_INFO,"{}",argumentToExecute);
    std::cout<<"argc "<<argc<<std::endl;
    Platform::Argumets  arguments;
    if( (argc <= 11) && (argc >= 6) )
    {
        arguments.clientId =  Platform::processNameToId[allArgs[1]];
        if ((allArgs[2].find("0x")!=std::string::npos) || (allArgs[2].find("0X")!=std::string::npos))
        {

            std::stringstream ss;
            ss << std::hex << allArgs[2].c_str();
            ss >> arguments.deviceId;
        }
        else
        {
            arguments.deviceId = static_cast<uint64_t>(std::stoll(allArgs[2].c_str()));
        }
        arguments.ObjectType = allArgs[3];
        arguments.action = allArgs[4];
		
		switch(argc)
		{
			case MOL_MESSAGE_WITH_CODE:
			{
				arguments.code = allArgs[5];
				break;
			}

			case REQUEST_RESPONSE_WITH_SOURCEINFO:
			{
				if(allArgs[0] == "REQUEST" || allArgs[0] == "RESPONSE")
				{
					if ((allArgs[6].find("0x")!=std::string::npos) || (allArgs[6].find("0X")!=std::string::npos))
					{
						std::stringstream ss;
						ss << std::hex << allArgs[6].c_str();
						ss >> arguments.parentId;
					}
					else
					{
						arguments.parentId = static_cast<uint64_t>(std::stoll(allArgs[6].c_str()));
					}
					arguments.parentObjectType  = allArgs[5];
				}
				break;
			}

			case MOL_MESSAGE_WITH_CODE_PARENTINFO://For Request and Response Mol messages, this condition is considered to insert source info
			{
				arguments.code = allArgs[5];
				if ((allArgs[7].find("0x")!=std::string::npos) || (allArgs[7].find("0X")!=std::string::npos))
				{
					std::stringstream ss;
					ss << std::hex << allArgs[7].c_str();
					ss >> arguments.parentId;
				}
				else
				{
					arguments.parentId = static_cast<uint64_t>(std::stoll(allArgs[7].c_str()));
				}
				arguments.parentObjectType  = allArgs[6];
				break;
			}

			case REQUEST_RESPONSE_WITH_SOURCEINFO_TARGETINFO:
			{
				if(allArgs[0] == "REQUEST" || allArgs[0] == "RESPONSE")
				{
					arguments.targetSetFlag = true;
					if ((allArgs[6].find("0x")!=std::string::npos) || (allArgs[6].find("0X")!=std::string::npos))
					{
						std::stringstream ss;
						ss << std::hex << allArgs[6].c_str();
						ss >> arguments.parentId;
					}
					else
					{
						arguments.parentId = static_cast<uint64_t>(std::stoll(allArgs[6].c_str()));
					}
					arguments.parentObjectType  = allArgs[5];

					if ((allArgs[8].find("0x")!=std::string::npos) || (allArgs[8].find("0X")!=std::string::npos))
					{
						std::stringstream ss;
						ss << std::hex << allArgs[8].c_str();
						ss >> arguments.targetId;
					}
					else
					{
						arguments.targetId = static_cast<uint64_t>(std::stoll(allArgs[8].c_str()));
					}
					arguments.targetObjectType  = allArgs[7];
				}
				break;
			}

			case REQUEST_RESPONSE_WITH_CODE_SOURCEINFO_TARGETINFO:
			{
				if(allArgs[0] == "REQUEST" || allArgs[0] == "RESPONSE")
				{
					arguments.targetSetFlag = true;
					arguments.code = allArgs[5];
					if ((allArgs[7].find("0x")!=std::string::npos) || (allArgs[7].find("0X")!=std::string::npos))
					{
						std::stringstream ss;
						ss << std::hex << allArgs[7].c_str();
						ss >> arguments.parentId;
					}
					else
					{
						arguments.parentId = static_cast<uint64_t>(std::stoll(allArgs[7].c_str()));
					}
					arguments.parentObjectType  = allArgs[6];

					if ((allArgs[9].find("0x")!=std::string::npos) || (allArgs[9].find("0X")!=std::string::npos))
					{
						std::stringstream ss;
						ss << std::hex << allArgs[9].c_str();
						ss >> arguments.targetId;
					}
					else
					{
						arguments.targetId = static_cast<uint64_t>(std::stoll(allArgs[9].c_str()));
					}
					arguments.targetObjectType  = allArgs[8];
				}
				break;
			}
      default : 
      {
           //Donothing. 
         break;
      }
		}
	}
    else if(argc == 5)
    {
        arguments.timeperiod = allArgs[3];
    }
    else
    {
        exit(-1);
    }
    return arguments;
}

/**
 * @brief   Dragon main function
 */
int main(int argc, char *argv[])
{
    DEBUGPRINT::SetDebugLevel(DEBUG_ALL);
    DEBUGPRINT::SetOutStream(OutStream::STDOUT);
    struct rlimit rlim;
    rlim.rlim_cur = RLIM_INFINITY;
    rlim.rlim_max = RLIM_INFINITY;
    DEBUGPRINT(DEBUG_INFO, "Dragon:Version 20190308");
    if (setrlimit(RLIMIT_MSGQUEUE, &rlim) == -1)
    {
        DEBUGPRINT(DEBUG_ERROR, "Dragon:MAIN setrlimit failed");
    }

    std::vector<std::string> allArgs;

    if (argc > 1)
    {
        allArgs.assign(argv + 1, argv + argc);
    }
    else
    {
        Usage(argv[0]);
        exit(-1);
    }

    std::string process{argv[0]};
    Platform::Argumets argumets = PrepareArguments(argc,process, allArgs);
    std::shared_ptr<Platform::Application> application;
    if(allArgs[0].compare("COMMAND") == 0)
    {
        application = std::make_shared<Platform::CommandGenerator>(argumets);
    }
    else if(allArgs[0].compare("EVENT") == 0)
    {
        std::cout<<"about to  EventGenerator"<<std::endl;
        application = std::make_shared<Platform::EventGenerator>(argumets);
    }
    else if (allArgs[0].compare("REQUEST") == 0)
    {
	    std::cout<<"about to  RequestGenerator"<<std::endl;
        application = std::make_shared<Platform::RequestGenerator>(argumets);
    }
    else if (allArgs[0].compare("RESPONSE") == 0)
    {
	    std::cout<<"about to  ResponseGenerator"<<std::endl;
        application = std::make_shared<Platform::ResponseGenerator>(argumets);
    }

    else if(allArgs[0].compare("SCAN") == 0)
    {
        application = std::make_shared<Platform::MolWatcher>(allArgs[1], argumets);
    }
    else
    {
        return -1;
    }
    application->Init();
    application->Prepare();
    application->Start();
    application->Stop();
    application->Shutdown();
    application->Uninit();

    return SUCCESS;
}
