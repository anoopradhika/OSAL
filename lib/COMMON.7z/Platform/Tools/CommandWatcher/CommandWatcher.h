/**********************************************************************************
* @file CommandWatcher .h
* @brief Generate all type of event
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_COMMAND_WATCHER_H
#define PLATFORM_MOL_COMMAND_WATCHER_H
#include "Helper/Helper.h"
#include "Helper/EventHelper.h"
#include "Helper/CommandPrinter.h"
#include "Component/Component.h"
#include "Mol/Commands/Activate.h"
#include "Mol/Commands/Deactivate.h"
#include "Mol/Commands/SoftwareCenterCommands.h"
#include "Mol/Commands/Silence.h"
#include "Mol/Commands/SetDayNightMode.h"
#include "Mol/Commands/SetAlarmSignal.h"
#include "Mol/Commands/ServiceMode.h"
#include "Mol/Commands/Resound.h"
#include "Mol/Commands/Reset.h"
#include "Mol/Commands/ClearCounter.h"
#include "Mol/Commands/OverrideDelays.h"
#include "Mol/Commands/ModuleShutdown.h"
#include "Mol/Commands/ModuleReboot.h"
#include "Mol/Commands/MeasureReferenceResistance.h"
#include "Mol/Commands/ExtendDelays.h"
#include "Mol/Commands/Enable.h"
#include "Mol/Commands/EarthFaultMonitoring.h"
#include "Mol/Commands/Disable.h"
#include "Mol/Commands/DelayOn.h"
#include "Mol/Commands/DelayOff.h"
#include "Mol/Commands/Deactivate.h"
#include "Mol/Commands/CommandTypeList.h"
#include "Mol/Commands/CancelBuzzer.h"
#include "Mol/Commands/ApplyConfiguration.h"
#include "Mol/Commands/SetDebugLevel.h"
#include "Mol/Commands/FunctionDisable.h"
#include "Mol/Commands/FunctionEnable.h"
#include "Mol/Commands/EvacuationOn.h"
#include "Mol/Commands/EvacuationOff.h"
#include "Mol/Commands/FareTest.h"
#include "Mol/Commands/FindDevice.h"
#include "Mol/Commands/ReSynchronization.h"
#include "Mol/Commands/LoopAutoLearn.h"
#include "Mol/Commands/Synchronization.h"
#include "Mol/Commands/GenerateDefaultConfig.h"
#include "Mol/Commands/SelfTest.h"
#include "Mol/Commands/SelfTestAbort.h"
#include "Mol/Commands/SelfTestBeacon.h"
#include "Mol/Commands/SetSensitivityProfile.h"
#include "Mol/Commands/AuditMode.h"
#include "Mol/Commands/FireTest.h"
#include "Timer/Timer.hpp"

namespace Platform
{

/**
 * @brief    CommandWatcher main responsibility is to
 *           trigger the comand specifi ccomponent to send the command
*/
class CommandWatcher: public Platform::Component
{
public:

    /**
    * @brief  Command validation and add associated command component
    * @param arguments arguments for command
    */
    explicit CommandWatcher(Platform::Argumets& arguments)
    {
        MolCommandSubscribe<Mol::Command::Activate,COMMAND_CATEGORY>(COMMAND_CATEGORY::ACTIVATE);
        MolCommandSubscribe<Mol::Command::Deactivate,COMMAND_CATEGORY>(COMMAND_CATEGORY::DEACTIVATE);
        MolCommandSubscribe<Mol::Command::SetAlarmSignal,COMMAND_CATEGORY>(COMMAND_CATEGORY::SET_ALARM_SIGNAL);
        MolCommandSubscribe<Mol::Command::StartServer,COMMAND_CATEGORY>(COMMAND_CATEGORY::START_SERVER);
        MolCommandSubscribe<Mol::Command::StopServer,COMMAND_CATEGORY>(COMMAND_CATEGORY::STOP_SERVER);
        MolCommandSubscribe<Mol::Command::FileTransfer,COMMAND_CATEGORY>(COMMAND_CATEGORY::FILE_TRANSFER);
        MolCommandSubscribe<Mol::Command::UpdateFirmware,COMMAND_CATEGORY>(COMMAND_CATEGORY::UPDATE_FIRMWARE);
        MolCommandSubscribe<Mol::Command::UpdateConfig,COMMAND_CATEGORY>(COMMAND_CATEGORY::UPDATE_CONFIGURATION);
        MolCommandSubscribe<Mol::Command::ApplyFirmware,COMMAND_CATEGORY>(COMMAND_CATEGORY::APPLY_FIRMWARE);
        MolCommandSubscribe<Mol::Command::ApplyConfiguration,COMMAND_CATEGORY>(COMMAND_CATEGORY::APPLY_CONFIGURATION);
        MolCommandSubscribe<Mol::Command::CancelBuzzer,COMMAND_CATEGORY>(COMMAND_CATEGORY::CANCEL_BUZZER);
        MolCommandSubscribe<Mol::Command::DelayOff,COMMAND_CATEGORY>(COMMAND_CATEGORY::DELAY_OFF);
        MolCommandSubscribe<Mol::Command::DelayOn,COMMAND_CATEGORY>(COMMAND_CATEGORY::DELAY_ON);
        MolCommandSubscribe<Mol::Command::Disable,COMMAND_CATEGORY>(COMMAND_CATEGORY::DISABLE);
        MolCommandSubscribe<Mol::Command::EarthFaultMonitoring,COMMAND_CATEGORY>(COMMAND_CATEGORY::EARTH_FAULT_MONITORING);
        MolCommandSubscribe<Mol::Command::Enable,COMMAND_CATEGORY>(COMMAND_CATEGORY::ENABLE);
        MolCommandSubscribe<Mol::Command::ExtendDelays,COMMAND_CATEGORY>(COMMAND_CATEGORY::EXTEND_DELAYS);
        MolCommandSubscribe<Mol::Command::MeasureReferenceResistance,COMMAND_CATEGORY>(COMMAND_CATEGORY::MEASURE_REFERENCE_RESISTANCE);
        MolCommandSubscribe<Mol::Command::ModuleReboot,COMMAND_CATEGORY>(COMMAND_CATEGORY::MODULE_REBOOT);
        MolCommandSubscribe<Mol::Command::ModuleShutdown,COMMAND_CATEGORY>(COMMAND_CATEGORY::MODULE_SHUTDOWN);
        MolCommandSubscribe<Mol::Command::OverrideDelays,COMMAND_CATEGORY>(COMMAND_CATEGORY::OVERRIDE_DELAYS);
        MolCommandSubscribe<Mol::Command::Reset,COMMAND_CATEGORY>(COMMAND_CATEGORY::RESET);
        MolCommandSubscribe<Mol::Command::ClearCounter,COMMAND_CATEGORY>(COMMAND_CATEGORY::CLEAR_COUNTER);
        MolCommandSubscribe<Mol::Command::Resound,COMMAND_CATEGORY>(COMMAND_CATEGORY::RESOUND);
        MolCommandSubscribe<Mol::Command::ServiceMode,COMMAND_CATEGORY>(COMMAND_CATEGORY::SERVICE_MODE);
        MolCommandSubscribe<Mol::Command::SetAlarmSignal,COMMAND_CATEGORY>(COMMAND_CATEGORY::SET_ALARM_SIGNAL);
        MolCommandSubscribe<Mol::Command::SetDayNightMode,COMMAND_CATEGORY>(COMMAND_CATEGORY::SET_DAY_NIGHT_MODE);
        MolCommandSubscribe<Mol::Command::Resound,COMMAND_CATEGORY>(COMMAND_CATEGORY::RESOUND);
        MolCommandSubscribe<Mol::Command::Silence,COMMAND_CATEGORY>(COMMAND_CATEGORY::SILENCE);
        MolCommandSubscribe<Mol::Command::SetDebugLevel,COMMAND_CATEGORY>(COMMAND_CATEGORY::SET_DEBUG_LEVEL);
        MolCommandSubscribe<Mol::Command::FunctionDisable,COMMAND_CATEGORY>(COMMAND_CATEGORY::FUNCTION_DISABLE);
        MolCommandSubscribe<Mol::Command::FunctionEnable,COMMAND_CATEGORY>(COMMAND_CATEGORY::FUNCTION_ENABLE);
        MolCommandSubscribe<Mol::Command::EvacauationOn,COMMAND_CATEGORY>(COMMAND_CATEGORY::EVACUATION_ON);
        MolCommandSubscribe<Mol::Command::EvacauationOff,COMMAND_CATEGORY>(COMMAND_CATEGORY::EVACUATION_OFF);
        MolCommandSubscribe<Mol::Command::FareTest,COMMAND_CATEGORY>(COMMAND_CATEGORY::FARE_TEST);
        MolCommandSubscribe<Mol::Command::TestZoneStart,COMMAND_CATEGORY>(COMMAND_CATEGORY::TEST_ZONE_START);
        MolCommandSubscribe<Mol::Command::TestZoneStop,COMMAND_CATEGORY>(COMMAND_CATEGORY::TEST_ZONE_STOP);
        MolCommandSubscribe<Mol::Command::SetTimeDate,COMMAND_CATEGORY>(COMMAND_CATEGORY::SET_TIME_DATE);
        MolCommandSubscribe<Mol::Command::StartLoop,COMMAND_CATEGORY>(COMMAND_CATEGORY::START_LOOP);
        MolCommandSubscribe<Mol::Command::FindDevice,COMMAND_CATEGORY>(COMMAND_CATEGORY::FIND_DEVICE);
        MolCommandSubscribe<Mol::Command::ReSynchronization,COMMAND_CATEGORY>(COMMAND_CATEGORY::RESYNC);
        MolCommandSubscribe<Mol::Command::LoopAutoLearn,COMMAND_CATEGORY>(COMMAND_CATEGORY::LOOP_AUTOLEARN);
        MolCommandSubscribe<Mol::Command::StartIndicatorTest,COMMAND_CATEGORY>(COMMAND_CATEGORY::START_INDICATOR_TEST);
        MolCommandSubscribe<Mol::Command::StopIndicatorTest,COMMAND_CATEGORY>(COMMAND_CATEGORY::STOP_INDICATOR_TEST);
        MolCommandSubscribe<Mol::Command::Synchronization,COMMAND_CATEGORY>(COMMAND_CATEGORY::SYNC);
        MolCommandSubscribe<Mol::Command::GenerateDefaultConfig,COMMAND_CATEGORY>(COMMAND_CATEGORY::GENERATE_DEFAULT_CONFIG);
        MolCommandSubscribe<Mol::Command::SelfTest,COMMAND_CATEGORY>(COMMAND_CATEGORY::SELF_TEST);
        MolCommandSubscribe<Mol::Command::SelfTestAbort,COMMAND_CATEGORY>(COMMAND_CATEGORY::SELF_TEST_ABORT);
        MolCommandSubscribe<Mol::Command::SelfTestBeacon,COMMAND_CATEGORY>(COMMAND_CATEGORY::BEACON);
        MolCommandSubscribe<Mol::Command::SetSensitivityProfile,COMMAND_CATEGORY>(COMMAND_CATEGORY::SET_SENSITIVITY_PROFILE);
        MolCommandSubscribe<Mol::Command::AuditMode,COMMAND_CATEGORY>(COMMAND_CATEGORY::AUDIT_MODE);
        MolCommandSubscribe<Mol::Command::FireTest,COMMAND_CATEGORY>(COMMAND_CATEGORY::FIRE_TEST);
    }

    ~ CommandWatcher() = default;
private:
    using COMMAND_CATEGORY = Mol::Command::COMMAND_CATEGORY;
    template<typename command, typename commandType>
    void MolCommandSubscribe(commandType commandTypeId)
    {

        m_communicator.m_command.Subscribe<command>(commandTypeId);
        m_communicator.m_command.getServiceWithApplicationType(commandTypeId)->Connect(this, &CommandWatcher::ReceiveCommand);
    }


    void ReceiveCommand(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, const uint64_t senderID, PROC_ADDRESS address)
    {
        std::cout<<"ReceiveCommand .........."<<std::endl;
        PrintCommand(command,senderID,address);
    }
};

}
#endif //PLATFORM_MOL_COMMAND_WATCHER_H
