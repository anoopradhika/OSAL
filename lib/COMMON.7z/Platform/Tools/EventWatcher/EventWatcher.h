/**********************************************************************************
* @file EventWatcher .h
* @brief Generate all type of event
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_EVENT_WATCHER_H
#define PLATFORM_MOL_EVENT_WATCHER_H
#include "Helper/Helper.h"
#include "Helper/EventHelper.h"
#include "Helper/EventPrinter.h"
#include "Component/Component.h"

#include "Mol/Events/Event.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/AccessEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/AlarmSignalEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/InputChangeEvent.h"
#include "Mol/Events/MaintenanceEvent.h"
#include "Mol/Events/Reset.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/WarningEvent.h"
#include "Mol/Events/SelfTestEvent.h"
#include "Mol/Events/SelfTestResultEvent.h"
#include "Mol/Events/SelfTestBeaconEvent.h"
#include "Mol/Events/UserRole.h"

namespace Platform
{

/**
 * @brief    EventWatcher main responsibility is to
 *           trigger the comand specifi ccomponent to send the command
*/
class EventWatcher: public Platform::Component
{
public:
    /**
    * @brief  Command validation and add associated command component
    * @param arguments arguments for command
    */
    explicit EventWatcher(Platform::Argumets& arguments)
    {
        MolCommandSubscribe<Mol::Event::AccessEvent,EventType>(EventType::USER_ACCESS);
        MolCommandSubscribe<Mol::Event::ActivationEvent,EventType>(EventType::ACTIVATION);
        MolCommandSubscribe<Mol::Event::AlarmEvent,EventType>(EventType::ALARM);
        MolCommandSubscribe<Mol::Event::DisablementEvent,EventType>(EventType::DISABLEMENT);
        MolCommandSubscribe<Mol::Event::AlarmSignalEvent,EventType>(EventType::ALARM_SIGNAL);
        MolCommandSubscribe<Mol::Event::FaultClearedEvent,EventType>(EventType::TROUBLE_CLEARED);
        MolCommandSubscribe<Mol::Event::FaultEvent,EventType>(EventType::TROUBLE);
        MolCommandSubscribe<Mol::Event::InputChangeEvent,EventType>(EventType::INPUT_CHANGE_IN_STATUS);
        MolCommandSubscribe<Mol::Event::MaintenanceEvent,EventType>(EventType::MAINTENANCE);
        MolCommandSubscribe<Mol::Event::Reset,EventType>(EventType::RESET);
        MolCommandSubscribe<Mol::Event::TestOperationEvent,EventType>(EventType::TEST);
        MolCommandSubscribe<Mol::Event::UserOperationEvent,EventType>(EventType::USER_OPERATION);
        MolCommandSubscribe<Mol::Event::WarningEvent,EventType>(EventType::WARNING);
        MolCommandSubscribe<Mol::Event::FunctionEnable,EventType>(EventType::FUNCTION_ENABLE);
        MolCommandSubscribe<Mol::Event::FunctionDisable,EventType>(EventType::FUNCTION_DISABLE);
        MolCommandSubscribe<Mol::Event::DelayStartedEvent,EventType>(EventType::DELAY_STARTED_EVENT);
        MolCommandSubscribe<Mol::Event::SelfTestEvent,EventType>(EventType::SELF_TEST);
        MolCommandSubscribe<Mol::Event::SelfTestResultEvent,EventType>(EventType::SELF_TEST_RESULT);
        MolCommandSubscribe<Mol::Event::SelfTestBeaconEvent,EventType>(EventType::BEACONING);
        MolCommandSubscribe<Mol::Event::UserRole,EventType>(EventType::USER_ROLE);
    	MolCommandSubscribeInformationEvent();
	}


    ~ EventWatcher() = default;
private:

    template<typename event, typename eventType>
    void MolCommandSubscribe(eventType eventTypeId)
    {
        m_communicator.m_event.Subscribe<event>(eventTypeId);
        m_communicator.m_event.getServiceWithApplicationType(eventTypeId)->Connect(this, &EventWatcher::ReceiveEvent);
    }


    void ReceiveEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID, PROC_ADDRESS address)
    {
        PrintEvent(event,senderID,address);
    }
	
	void MolCommandSubscribeInformationEvent()
    {
	m_communicator.m_event.Subscribe<Mol::Event::InformationEvent>(Mol::Event::EVENT_CATEGORY::INFORMATION);
        m_communicator.m_event.getServiceWithApplicationType(Mol::Event::EVENT_CATEGORY::INFORMATION)->Connect(this, &EventWatcher::ReceiveInformationEvent);
    }

    void ReceiveInformationEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID, PROC_ADDRESS address)
    {
		auto information = std::static_pointer_cast <Mol::Event::InformationEvent> (event);
		if(information->GetEventCode() == Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED)
		{
			PrintInformationEventModuleDetails(information,senderID,address);
		}
		else
		{
			PrintEvent(event,senderID,address);
		}
    }

};

}
#endif //PLATFORM_MOL_COMMAND_WATCHER_H
