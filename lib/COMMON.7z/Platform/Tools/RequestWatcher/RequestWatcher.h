/**********************************************************************************
* @file RequestWatcher .h
* @brief scan all type of Request
*
* @copyright Copyright 2021 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef PLATFORM_MOL_REQUEST_WATCHER_H
#define PLATFORM_MOL_REQUEST_WATCHER_H
#include "Helper/Helper.h"
#include "Helper/RequestPrinter.h"
#include "Component/Component.h"
#include "Timer/Timer.hpp"
#include "Helper/RequestHelper.h"
#include "Mol/Requests/ObjectData.h"
#include "Mol/Requests/NotifierDeviceStatusRequest.h"
#include "Mol/Requests/DeviceDiagnosticRequest.h"
#include "Mol/Requests/MultiObjectQuery.h"

namespace Platform
{

/**
 * @brief    RequestWatcher main responsibility is to
 *           scan the Request and print
*/
class RequestWatcher: public Platform::Component
{
public:

    /**
    * @brief  Request validation and add associated request component
    * @param arguments arguments for request
    */
    explicit RequestWatcher(Platform::Argumets& arguments)
    {
        MolRequestSubscribe<Mol::Request::ObjectData,REQUEST_CATEGORY>(REQUEST_CATEGORY::OBJECT_DATA);
    	MolRequestSubscribe<Mol::Request::ChargerInfoRequest,REQUEST_CATEGORY>(REQUEST_CATEGORY::CHARGER_INFO_REQUEST);
		MolRequestSubscribe<Mol::Request::NotifierDeviceStatusRequest,REQUEST_CATEGORY>(REQUEST_CATEGORY::NOTIFIER_DEVICE_STATUS_REQUEST);
        MolRequestSubscribe<Mol::Request::DeviceDiagnosticRequest,REQUEST_CATEGORY>(REQUEST_CATEGORY::DEVICE_DIAGNOSTIC_DETAILS);
		MolRequestSubscribe<Mol::Request::MultiObjectQuery,REQUEST_CATEGORY>(REQUEST_CATEGORY::MULTI_OBJECT_QUERY);
	}

    ~ RequestWatcher() = default;
private:
    using REQUEST_CATEGORY = Mol::Request::REQUEST_CATEGORY;
    template<typename request, typename requestType>
    void MolRequestSubscribe(requestType requestTypeId)
    {

        m_communicator.m_request.Subscribe<request>(requestTypeId);
        m_communicator.m_request.getServiceWithApplicationType(requestTypeId)->Connect(this, &RequestWatcher::ReceiveRequest);
    }


    void ReceiveRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, const uint64_t senderID, PROC_ADDRESS address)
    {
        PrintRequest(request,senderID,address);
    }
};

}
#endif //PLATFORM_MOL_REQUEST_WATCHER_H
