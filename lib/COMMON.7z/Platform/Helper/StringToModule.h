/*****************************************************************//**
 *
 * @file    StringToModule.h
 * @brief   Helper functions for string module type to enum
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_HELPER_STRING_TO_MODULE_H
#define PLATFORM_HELPER_STRING_TO_MODULE_H

#include <map>
#include "DOL/Entities/Module.h"

namespace platform
{

struct cmpStr
{
    bool operator()(char const* lsh, char const* rsh) const
    {
        return std::strcmp(lsh,rsh)< 0;
    }
};

std::map<const char*, Dol::Entities::Module::MODULE_TYPE, cmpStr> stodtMap
    { {"CHARGER", Dol::Entities::Module::MODULE_TYPE::CHARGER}
    , {"FARE_FRE", Dol::Entities::Module::MODULE_TYPE::FARE_FRE}
    , {"FAT_FBF", Dol::Entities::Module::MODULE_TYPE::FAT_FBF}
    , {"IDNET_NETWORK_GATEWAY", Dol::Entities::Module::MODULE_TYPE::IDNET_NETWORK_GATEWAY}
    , {"IO", Dol::Entities::Module::MODULE_TYPE::IO}
    , {"MAINCPU", Dol::Entities::Module::MODULE_TYPE::MAINCPU}
    , {"NOTIFIER_EMEA_FIELDBUS_LOOP", Dol::Entities::Module::MODULE_TYPE::NOTIFIER_EMEA_FIELDBUS_LOOP}
    , {"SERIAL_COMMS", Dol::Entities::Module::MODULE_TYPE::SERIAL_COMMS}
    , {"FUSION_ICONIC_NETWORK", Dol::Entities::Module::MODULE_TYPE::FUSION_ICONIC_NETWORK}
    , {"IDNET_NETWORK_GATEWAY", Dol::Entities::Module::MODULE_TYPE::IDNET_NETWORK_GATEWAY}
    , {"NOTIFIER_LOOP_ADAPTER", Dol::Entities::Module::MODULE_TYPE::NOTIFIER_LOOP_ADAPTER}
    };

Dol::Entities::Module::MODULE_TYPE stodt(const char * name)
{
    auto result = stodtMap.find(name);
    if(stodtMap.end() == result)
    {
        return Dol::Entities::Module::MODULE_TYPE::END_OF_LIST;
    }
    return result->second;
}
} // end namespace

#endif
