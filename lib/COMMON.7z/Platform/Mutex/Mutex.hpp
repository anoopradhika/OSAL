/*****************************************************************//**
 *
 * @file    Mutex.hpp
 * @brief   Mutex abstraction class
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
 
#include "Mutex/Mutex.h"
#include "Config/Config.h"

#ifndef PLATFORM_MUTEX_INCLUDE_H
#define PLATFORM_MUTEX_INCLUDE_H

namespace Platform
{

template<typename NativeMutexType = PlatformNative::Mutex>
class Mutex
{
public:
    /** Default constructor */
    Mutex() = default;

    /** Default destructor */
    virtual ~Mutex() = default;

    /**
        Waits until the current thread got the mutex
    */
    void Lock()
    {
        m_nativeMutex.Lock();
    }

    bool LockWait(uint32_t aDelay)
    {
        return m_nativeMutex.LockWait(aDelay);
    }

    /**
        Get lock, if mutex is not used
        @return true if lock is obtained 
    */
    bool TryLock()
    {
        return m_nativeMutex.TryLock();
    }

    /**
        Releases the lock on the mutex
    */
    void Unlock()
    {
        m_nativeMutex.Unlock();
    }

    /**
        Releases the lock on the mutex.
    */   
    void Shutdown()
    {
        m_nativeMutex.Shutdown();
    }
private:
    NativeMutexType m_nativeMutex;
};

} //platform
#endif //PLATFORM_MUTEX_INCLUDE_H
