#ifndef PLATFPRM_TEST_ACT_INCLUDE_H
#define PLATFPRM_TEST_ACT_INCLUDE_H

#include "gtest/gtest.h"
#include "MessageQueue/MessageQueue.hpp"
#include "Application/Application.h"
#include "Timer/Timer.hpp"

namespace platform
{

/**
    Base class for all application and component test
    Remark: please for later tests implementations use ApplicationTest instead of ACT
*/
class ACT: public::testing::Test, public Platform::Application
{
public:
    ACT(PROC_ADDRESS address = PROC_ADDRESS::CMCAPP, uint64_t ID = 0x1010101):
            Application(address,ID),
            m_address(address)
    {

    }

    virtual ~ACT() = default;

    /**
        Create connection to looper queue
    */
    virtual void Init() override
    {
        Platform::Application::Init();

        std::string queue_desc = std::string("LOOPER") + std::to_string((uint32_t)m_address);
        m_Queue = Platform::MessageQueue<>{queue_desc, GlobalDataType::MessageQueue::BlockType::NON_BLOCK};
    }

    /**
        Terminate application
    */
    void Terminate()
    {
        m_Queue.Send("TERM");
    }

    void WaitForResult(uint64_t timeMs)
    {
        if(!mStarted)
        {
            Platform::Notifier notifier;
            notifier.Connect(this,&platform::ACT::Terminate);
            m_timer = Platform::Timer<>(timeMs,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);
            m_timer.Start();
            Start();
            mStarted = true;
        }
        else
        {
            Stop();
            m_timer.Stop();
            m_timer.Start();
            Start();
        }
    }

    void Start() override
    {
        Platform::Application::Start();
    }
    void Uninit() override
    {
        Platform::Application::Uninit();
        m_timer.Shutdown();
    }
protected:
    Platform::MessageQueue<> m_Queue{};
    Platform::Timer<> m_timer{};
    PROC_ADDRESS m_address{};
    bool mStarted {false};
};

}
#endif //PLATFPRM_TEST_ACT_INCLUDE_H
