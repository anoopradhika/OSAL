#ifndef PLATFPRM_TEST_APPLICATION_TEST_INCLUDE_H
#define PLATFPRM_TEST_APPLICATION_TEST_INCLUDE_H

#include "gtest/gtest.h"
#include "MessageQueue/MessageQueue.hpp"
#include "Application/Application.h"
#include "Timer/Timer.hpp"

namespace Platform
{/**
    Generic base class for all application and component test supporting template type for inheritance
*/
template<typename application = Application>
class ApplicationTest: public::testing::Test, public application
{
public:
    ApplicationTest(PROC_ADDRESS address = PROC_ADDRESS::CMCAPP, uint64_t ID = 0x1010101):
        application(address,ID),
            m_address(address)
    {

    }

    virtual ~ApplicationTest() = default;

    /**
        Create connection to looper queue
    */
    virtual void Init() override
    {
        application::Init();

        std::string queue_desc = std::string("LOOPER") + std::to_string((uint32_t)m_address);
        m_Queue = MessageQueue<>{queue_desc, GlobalDataType::MessageQueue::BlockType::NON_BLOCK};
    }

    /**
        Terminate application
    */
    void Terminate()
    {
        m_Queue.Send("TERM");
    }

    void WaitForResult(uint64_t timeMs)
    {
        if(!mStarted)
        {
            Notifier notifier;
            notifier.Connect(this,&ApplicationTest<application>::Terminate);
            m_timer = Timer<>(timeMs,GlobalDataType::Timer::AlarmType::SINGLE_SHOT,notifier);
            m_timer.Start();
            Start();
            mStarted = true;
        }
        else
        {
            application::Stop();
            m_timer.Stop();
            m_timer.Start();
            Start();
        }
    }

    void Start() override
    {
        application::Start();
    }
    void Uninit() override
    {
        application::Uninit();
        m_timer.Shutdown();
    }
protected:
    MessageQueue<> m_Queue{};
    Timer<> m_timer{};
    PROC_ADDRESS m_address{};
    bool mStarted {false};
};
}
#endif //PLATFPRM_TEST_APPLICATION_TEST_INCLUDE_H
