#ifndef PLATFORM_COMMUNICATOR_INCLUDE_H
#define PLATFORM_COMMUNICATOR_INCLUDE_H

#include "ObjectModelCommunicator/ObjectModelCommunicator.h"
#include "MessageTransporter/MessageTransporter.h"

#include "Mol/Monitoring/Monitoring.h"
#include "Mol/Commands/Command.h"
#include "Mol/Events/Event.h"
#include "Mol/Requests/Request.h"
#include "Mol/Responses/Response.h"
#include "DOL/DomainObject/DomainObject.h"

namespace Platform
{

class  Communicator
{

protected:
    using DolType = Dol::DOMAIN_OBJECT_TYPE;
    using DOLCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,DolType,Dol::DomainObject>;

    using EventType = Mol::Event::EVENT_CATEGORY;
    using EventCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,EventType,Mol::Message<EventType>>;

    using CommandType = Mol::Command::COMMAND_CATEGORY;
    using CommandCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,CommandType,Mol::Message<CommandType>>;

    using RequestType = Mol::Request::REQUEST_CATEGORY;
    using RequestCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,RequestType,Mol::Message<RequestType>>;

    using ResponseType = Mol::Response::RESPONSE_CATEGORY;
    using ResponseCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,ResponseType,Mol::Message<ResponseType>>;

    using MonitoringType = Mol::Monitoring::MONITORING_CATEGORY;
    using MonitoringCommunicator = Platform::ObjectModelCommunicator<Platform::MessageTransporter,MonitoringType,Mol::Message<MonitoringType>>;
 private:
    uint64_t m_sourceID =0;

public:

    explicit Communicator(uint64_t SourceID):m_sourceID(SourceID){};
    Communicator() = default;
    ~Communicator() = default;

    MessageTransporter& m_messageTransporter = MessageTransporter::GetMessageTransporter();

    DOLCommunicator& m_dol = DOLCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Message::MessageType::DOL);
    EventCommunicator& m_event = EventCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Message::MessageType::EVENT);
    CommandCommunicator& m_command = CommandCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Message::MessageType::COMMAND);
    RequestCommunicator& m_request = RequestCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Message::MessageType::REQUEST);
    ResponseCommunicator& m_response = ResponseCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Message::MessageType::RESPONSE);
    MonitoringCommunicator& m_monitoring = MonitoringCommunicator::GetObjectModelCommunicator
                                                ( m_messageTransporter,Message::MessageType::MONITOR);
};
} //end of Platform

#endif //PLATFORM_COMMUNICATOR_INCLUDE_H
