
/*****************************************************************//**
 *
 * @file    MainCPUinfo.hpp
 * @brief   MainCPUinfo class used of print formatting.
 *
 *
 * @copyright Copyright 2020 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#ifndef PLATFORM_MAINCPU_INFO_INCLUDE_H
#define PLATFORM_MAINCPU_INFO_INCLUDE_H


#include "Component/Component.h"
#include "GlobalDataType/Error.h"
#include "DOL/Entities/Module/CPUModule.h"
#include "Mol/DeviceUniqueID.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include "Utility.h"
#include "DomainConfiguration/DomainConfiguration.h"
#include "EnumHelper.h"

namespace Platform
{

    /**
    * @brief MainCPUinfo component responsibility is to provide main cpu at startup
    */
class MainCPUinfo: public Platform::Component
{
public:

    /**
     * @brief MainCPUinfo Constructor
     * @param[in] sourceID MainCPU module ID
     * @param[in] ipv6Address IP Address of the Application (Main CPU)
     *
     */
    MainCPUinfo(uint64_t sourceID, const std::string& ipv6Address):
        m_sourceID{sourceID}
    {
        SetInfo(ipv6Address);
    }

    MainCPUinfo(MainCPUinfo& other) = delete;

    MainCPUinfo(MainCPUinfo&& other) = delete;

    ~MainCPUinfo() = default;

protected:

    /**
     * @brief SendInformationEvent it create and send an InformationEvent(NEW_MODULE_CONNECTED)
     * with main cpu domain object type as a parameter
     */
    void SendInformationEvent()
    {
        auto information = std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED);
        information->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, m_mainCPUModule);
        Mol::DataType::ObjectReference source{m_sourceID, Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE};
        information->SetSource(source);
        m_communicator.m_event.Send(information, PROC_ADDRESS::BROADCAST);
    }

    /**
     * @brief Start function is called when the component is created, it call SendInformationEvent
     */
    void Start() override
    {
        m_timer.Start();
        Platform::Component::Start();
    }

    /**
     * @brief Start function is called when the component is created
     */
    void Prepare() override
    {
        Platform::Component::Prepare();
        Platform::Notifier notifier;
        notifier.Connect(this, &MainCPUinfo::SendInformationEvent);
        m_timer = Platform::Timer<>(10000, GlobalDataType::Timer::AlarmType::SINGLE_SHOT, notifier);
    }

    /**
     * @brief Shutdown function is called when the parent application is closed, it clean the component elements
     */
    void Shutdown() override
    {
        Platform::Component::Shutdown();
        m_mainCPUModule = nullptr;
        m_timer.Stop();
        m_timer.Shutdown();
    }

protected:
    /**
     * @brief m_mainCPUModule object holding the main cpu domain object data
     */
    std::shared_ptr<Dol::Entities::CPUModule> m_mainCPUModule{};

    /**
     * @brief m_sourceID main cpu ID
     */
    const uint64_t m_sourceID = 0;

    /**
     * @brief SetInfo function is called in the constructor to fetch all main cpu board info
     * @param[in] ipv6Address IP Address of the Application (Main CPU)
     */
    void SetInfo(const std::string& ipv6Address)
    {
        m_mainCPUModule =  std::make_shared<Dol::Entities::CPUModule>(ipv6Address,m_sourceID);
        m_mainCPUModule->SetType(Dol::Entities::Module::MODULE_TYPE::MAINCPU);
        m_mainCPUModule->SetLabel(EnumHelper::EnumeratorToString(m_mainCPUModule->GetType()));
        std::string value = Utility::GetPanelSerialNumber();
        m_mainCPUModule->SetSerialNumber(value.empty() ? DEFAULT_32BIT_VALUE : value);
        value = Utility::GetPanelHardwareVersion();
        m_mainCPUModule->SetHardwareVersion(value.empty() ? DEFAULT_32BIT_VALUE : value);
        m_mainCPUModule->SetModuleStatus(Dol::Entities::Module::Status::NORMAL_OPERATION);
        auto version = Utility::GetSemanticVersionUsingRegex( (fireSystemState::DomainConfiguration()).GetConfigurationVersion());
        version.SetGitHash(GIT_VERSION);
        m_mainCPUModule->SetConfigurationVersion(std::make_shared<Dol::Entities::SemanticVersion>(version));
        version = Utility::GetSemanticVersionUsingRegex(Utility::GetSoftwareVersion());
        version.SetGitHash(GIT_VERSION);
        m_mainCPUModule->SetSoftwareVersion(std::make_shared<Dol::Entities::SemanticVersion>(version));
    }
    static constexpr const char* DEFAULT_32BIT_VALUE = "0x00000000";
    Platform::Timer<> m_timer;// wait for HMI to be ready
};

}
#endif //PLATFORM_MAINCPU_INFO_INCLUDE_H
