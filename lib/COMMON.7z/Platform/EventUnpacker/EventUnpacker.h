/*****************************************************************//**
 *
 * @file    EventUnpacker.h
 * @brief   EventUnpacker Helper class to unpack bas event type to concrete event
 *
 *
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_EVENT_UNPACKER_INCLUDE_H
#define PLATFORM_EVENT_UNPACKER_INCLUDE_H

#include "Mol/Events/AccessEvent.h"
#include "Mol/Events/ActivationEvent.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/AlarmSignalEvent.h"
#include "Mol/Events/DisablementEvent.h"
#include "Mol/Events/Event.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Events/InputChangeEvent.h"
#include "Mol/Events/MaintenanceEvent.h"
#include "Mol/Events/Reset.h"
#include "Mol/Events/TestOperationEvent.h"
#include "Mol/Events/UserOperationEvent.h"
#include "Mol/Events/WarningEvent.h"
#include "DOL/Helper/Translator.h"

#include "Signals/Delegate.h"
#include "Signals/Signal.h"

namespace Platform
{
class EventUnpacker
{
public:
	/** Default constructor */
	EventUnpacker(const std::string& message, Mol::Event::EVENT_CATEGORY eventCategory)
	{
		CreateEventTypes<Mol::Event::AccessEvent>(Mol::Event::EVENT_CATEGORY::USER_ACCESS);
		CreateEventTypes<Mol::Event::ActivationEvent>(Mol::Event::EVENT_CATEGORY::ACTIVATION);
		CreateEventTypes<Mol::Event::AlarmEvent>(Mol::Event::EVENT_CATEGORY::ALARM);
		CreateEventTypes<Mol::Event::AlarmSignalEvent>(Mol::Event::EVENT_CATEGORY::ALARM_SIGNAL);
		CreateEventTypes<Mol::Event::DisablementEvent>(Mol::Event::EVENT_CATEGORY::DISABLEMENT);
		CreateEventTypes<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
		CreateEventTypes<Mol::Event::FaultEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE);
		CreateEventTypes<Mol::Event::InformationEvent>(Mol::Event::EVENT_CATEGORY::INFORMATION);
		CreateEventTypes<Mol::Event::InputChangeEvent>(Mol::Event::EVENT_CATEGORY::INPUT_CHANGE_IN_STATUS);
		CreateEventTypes<Mol::Event::MaintenanceEvent>(Mol::Event::EVENT_CATEGORY::MAINTENANCE);
		CreateEventTypes<Mol::Event::Reset>(Mol::Event::EVENT_CATEGORY::RESET);
		CreateEventTypes<Mol::Event::TestOperationEvent>(Mol::Event::EVENT_CATEGORY::TEST);
		CreateEventTypes<Mol::Event::UserOperationEvent>(Mol::Event::EVENT_CATEGORY::USER_OPERATION);
		CreateEventTypes<Mol::Event::WarningEvent>(Mol::Event::EVENT_CATEGORY::WARNING);
		m_message = message;
		m_eventCategory = eventCategory;
	}

	/** Default constructor deleted to avoid invoking deserialization with random parameter*/
	EventUnpacker() = delete;

	/** Default destructor */
	~EventUnpacker() = default;

	template<typename EventType>
	void UnpackMessage(const std::string& message)
	{
		Dol::Translator<EventType, Mol::Message<Mol::Event::EVENT_CATEGORY>> eventTranslator;
		m_event = eventTranslator.StringToDomainObjectMessage(message);
	}

	template<typename EventType>
	void CreateEventTypes(Mol::Event::EVENT_CATEGORY eventCategory)
	{
		m_upacker.insert(std::make_pair(eventCategory, std::make_shared<Gallant::Signal1<const std::string&>>()));
		m_upacker[eventCategory]->Connect(this, &EventUnpacker::UnpackMessage<EventType>);
	}

	//It is returning the concrete object, use std::static_pointer_cast < Mol::Event::EventType >
	template<typename EventType>
	std::shared_ptr<EventType> GetEvent()
	{
	    auto search = m_upacker.find(m_eventCategory);
	    if( search != m_upacker.end())
	    {
	        (*(search->second))(m_message);
	        //Check if it's the correct category
	        auto event = std::static_pointer_cast<EventType>(m_event);
	        if (event->GetEventCategory() == m_eventCategory)
	        {
	            return event;
	        }
	    }
	    return std::shared_ptr<EventType>();
	}

private:
	std::map<Mol::Event::EVENT_CATEGORY, std::shared_ptr<Gallant::Signal1<const std::string&>> > m_upacker;
	std::string m_message;
	Mol::Event::EVENT_CATEGORY m_eventCategory = Mol::Event::EVENT_CATEGORY::END_OF_LIST;
	std::shared_ptr <Mol::Message<Mol::Event::EVENT_CATEGORY>> m_event = nullptr;

};
}
#endif //PLATFORM_EVENT_UNPACKER_INCLUDE_H
