
#ifndef MESSAGE_SUBSCRIBER_INCLUDE_H
#define MESSAGE_SUBSCRIBER_INCLUDE_H

#include "Component/Component.h"

#include "Mol/Events/Event.h"
#include "Mol/Commands/Command.h"
#include "Mol/Requests/Request.h"
#include "Mol/Responses/Response.h"


namespace Platform
{

class MessageSubscriber : public Platform::Component
{

public:

    MessageSubscriber() = default;

    virtual ~MessageSubscriber() = default;
    
    virtual void Init()
    {
    	Platform::Component::Init();
    }

    virtual void Prepare() override
    {
    	Platform::Component::Prepare();
    }

    virtual void Start()
    {
    	Platform::Component::Start();
    }

	auto GetService(Platform::Message::MessageType message)
    {
		if (m_sigMap.find(message) != m_sigMap.end())
		{
			m_communicator.m_messageTransporter.m_notifiers[message].Connect(this, &MessageSubscriber::Subscription);
			m_sigMap.emplace(message, std::make_shared<ServiceType>());
		}
    	return *(m_sigMap[message]);
    }

    virtual void Stop()
    {
    	Platform::Component::Stop();
    }
    
    virtual void Shutdown()
    {
    	Platform::Component::Shutdown();
    }

protected:

    void Subscription(std::shared_ptr<Platform::Message> response)
    {
    	(*m_sigMap[response.get()->m_messageType])(response);
    }

private:

    typedef  Gallant::Signal1<std::shared_ptr<Platform::Message> > ServiceType;
    std::map<Platform::Message::MessageType, std::shared_ptr<ServiceType>> m_sigMap;
};
}

#endif //MESSAGE_SUBSCRIBER_INCLUDE_H
