/**
 * @file   ObjectModelCommunicator.h
 * @brief  DomainObject interface
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
 */
 
#ifndef COMMUNICATOR_INCLUDE_H
#define COMMUNICATOR_INCLUDE_H

#include "Signals/Delegate.h"
#include "Signals/Signal.h"

#include "DOL/DomainObject/DomainObject.h"
#include "DOL/Helper/Translator.h"
#include "Message/Message.h"
#include "CommonDefsInCCL.h"
#include <map>
#include "PlatformType/PlatformType.h"

#if IS_FREE_RTOS_PLATFORM()
#include "Guard/Guard.hpp"
#include "Services/PanelConnection/PanelDetails.h"
#include <queue>
#endif
    
namespace Platform
{

/**
    ObjectModelCommunicator class provides the interface for all Module objects to
    publish and subscribe.
    @tparam CommunicatorType: Communication class used with ObjectModelCommunicator
    @tparam ObjectModelKeyType : Object module category 
    @tparam ObjectModelBaseType : Base class of Object module
*/
template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
class ObjectModelCommunicator
{
    public:
        /** ServiceType for DomainObject notification */
        typedef  Gallant::Signal2<std::shared_ptr<ObjectModelBaseType>, uint64_t > ServiceType;
        typedef  Gallant::Signal3<std::shared_ptr<ObjectModelBaseType>, uint64_t, PROC_ADDRESS > ServiceWithApplicationType;

        /**
            ObjectModelCommunicator Singleton implementation. This is to make sure that
            only one instance of ObjectModelCommunicator available per process.
            @param communicator: communication class used for ObjectModelCommunicator
            @param messageType: Message category
            @return ObjectModelCommunicator
        */    
        static ObjectModelCommunicator& GetObjectModelCommunicator(CommunicatorType& communicator, Platform::Message::MessageType messageType);

        /**
            Subscribe domainObject from a publisher
            @param domainObjectType: Type of DomainObject
            @param publisherId: publisher message port ID
            @tparam ObjectModelType: Concrete object module class type 
            @tparam MessageIDType:  Message ID type of Concrete object module class type 
            @return connected endPoint ID, -1 on failure
        */
        template<typename ObjectModelType,typename MessageIDType>
        int32_t Subscribe(ObjectModelKeyType domainObjectType, MessageIDType publisherId);

        /**
            Subscribe domainObject using DOMAIN_OBJECT_TYPE
            @param domainObjectType: Type of DomainObject
            @tparam ObjectModelType: Concrete object module class type 
        */
        template<typename ObjectModelType>
        void Subscribe(ObjectModelKeyType domainObjectType);

        /**
            Unsubscribe domainObject from a publisher
            @param domainObjectType: Type of DomainObject
            @param publisherId: publisher message port ID
            @param endPoint received on connection 
            @tparam ObjectModelType: Concrete object module class type 
            @tparam MessageIDType:  Message ID type of Concrete object module class type
        */
        template<typename ObjectModelType,typename MessageIDType>
        void Unsubscribe(ObjectModelKeyType domainObjectType, MessageIDType publisherId, int32_t SubscribedID = -1);

        /**
            Unsubscribe domainObject using DOMAIN_OBJECT_TYPE
            @param domainObjectType: Type of DomainObject
            @tparam ObjectModelType: Concrete object module class type 
        */
        template<typename ObjectModelType>
        void Unsubscribe(ObjectModelKeyType domainObjectType);

        /**
            Get service and connect to for DomainObject subscription
            @param Id: DomainObject type
            @return sServiceType for DomainObject
        */
        std::shared_ptr< ServiceType > getService(ObjectModelKeyType Id);

        /**
            Get service and connect to for DomainObject subscription
            @param Id: DomainObject type
            @return sServiceType for DomainObject
        */
        std::shared_ptr< ServiceWithApplicationType > getServiceWithApplicationType(ObjectModelKeyType Id);

        /**
            Prepare internal services.
            Connect ObjectModelCommunicator notification method to MessagePort
            service
            @param SourceID: Source ID is the unique ID of the system
        */
        void Prepare(uint64_t SourceID, PROC_ADDRESS processId = PROC_ADDRESS::UNINITIALIZED);

        /**
            Send a DomainObject.
            @param domainObject: DomainObject to send
            @param SubscribedID: Application ID to send
            @param SubscribedID: DestinationID is TargetID(PanelID/ModuleID),
                                 if DestinationID is zero it will multi-casted
            @tparam ObjectModelType: Concrete object module class type 
            @tparam MessageIDType:  Message ID type of Concrete object module class type
            @return true if send successes, else false
            
        */
        template<typename ObjectModelType, typename MessageIDType>
        bool Send(std::shared_ptr<ObjectModelType> domainObject,MessageIDType SubscribedID, uint64_t DestinationID = 0,uint32_t waitTimeMs = 0,bool toFront = false);

        /**
            Receive a DomainObject.
            @tparam ObjectModelType: Concrete object module class type
            @return received DomainObject
        */
        template<typename ObjectModelType>
        std::shared_ptr<ObjectModelType> Receive();

        /**
            Disconnect MessagePort service
        */
        void Shutdown();

    private:
        void DebugMessage(const std::string& message)
        {
            DEBUGPRINT(DEBUG_ERROR,message);
        }
        /**
            Get MessagePort.
            Constructor placed under to private to prevent
            the ObjectModelCommunicator creation
        */
        ObjectModelCommunicator(CommunicatorType& communicator, Platform::Message::MessageType messageType);

        /**  Default destructor */
        ~ObjectModelCommunicator() = default;

        /**
            DomainObject dispatcher. Service connected to MessagePort
            @param domainObjectMessage: String converted DomainObject
        */
        void DispatchDomainObject(std::shared_ptr<Platform::Message> domainObjectMessage);

        /**
            Internal notification service for translate different domain object. Service called on the reception DomainObject.
            @param serializedData: String converted DomainObject
            @param domainObjectType: DomainObject type
            @param SourceID: Source target ID 
        */
        template<typename ObjectModelType>
        void internalNotifier(std::string& serializedData, ObjectModelKeyType domainObjectType,uint64_t SourceID, PROC_ADDRESS processId);

        /** MessagePort instance, initialized in contractor */
        CommunicatorType& m_Communicator;

        /** Map DomainObject type internal serviceType used by internalNotifier */
        std::map< ObjectModelKeyType, std::shared_ptr<Gallant::Signal4<std::string&, ObjectModelKeyType, uint64_t, PROC_ADDRESS> > > m_InternalServices;

        /** Map DomainObject type to service used by software components  */
        std::map< ObjectModelKeyType, std::shared_ptr< ServiceType > > m_Services;
        std::map< ObjectModelKeyType, std::shared_ptr< ServiceWithApplicationType > > m_applicationBasedServices;
        Platform::Message::MessageType m_messageType;
        uint64_t m_SourceID = 0;
        PROC_ADDRESS m_senderProcessId = PROC_ADDRESS::UNINITIALIZED;

#if IS_FREE_RTOS_PLATFORM()
        std::queue<std::shared_ptr<Platform::Message>> m_pendingMsgQueue;
        Platform::Mutex<> m_pendingMsgMutex;
        static constexpr uint8_t m_pendingMsgQueueMaxSize = 10;
#endif
};


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::ObjectModelCommunicator(CommunicatorType& communicator, Platform::Message::MessageType messageType):m_Communicator(communicator),m_messageType(messageType)
{

}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
void ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Prepare(uint64_t SourceID, PROC_ADDRESS processId)
{
    m_SourceID = SourceID;
    m_senderProcessId = processId;
    m_Communicator.m_notifiers[m_messageType].Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DispatchDomainObject);
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
void ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Shutdown()
{
   m_Communicator.m_notifiers[m_messageType].Disconnect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DispatchDomainObject);
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>& ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::GetObjectModelCommunicator(CommunicatorType& communicator, Platform::Message::MessageType messageType)
{
    static ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType> objectModelCommunicator(communicator,messageType);
    return objectModelCommunicator;
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
std::shared_ptr< typename ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::ServiceType >  ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::getService(ObjectModelKeyType Id)
{
    m_Services.insert(std::make_pair(Id,std::make_shared<ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::ServiceType >()));
    return m_Services[Id];
} 

template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
std::shared_ptr< typename ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::ServiceWithApplicationType >  ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::getServiceWithApplicationType(ObjectModelKeyType Id)
{
    m_applicationBasedServices.insert(std::make_pair(Id,std::make_shared<ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::ServiceWithApplicationType >()));
    return m_applicationBasedServices[Id];
}

template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
void ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DispatchDomainObject(std::shared_ptr<Platform::Message> message)
{
    Dol::Translator<ObjectModelBaseType, ObjectModelBaseType> translator;
    translator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
    ObjectModelKeyType  ModuleObjectType =  translator.GetType(message->m_Data);

    auto search = m_InternalServices.find(ModuleObjectType);

    if( search != m_InternalServices.end())
    {
        (*(search->second))(message->m_Data,ModuleObjectType,message->m_SourceUniqueID,message->m_sender);
    }
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType,typename MessageIDType>
bool ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Send(std::shared_ptr<ObjectModelType> domainObject,MessageIDType SubscribedID,uint64_t DestinationID,uint32_t waitTimeMs,bool toFront)
{
    if(domainObject.use_count() == 0)
    {
        return false;
    }

    Dol::Translator<ObjectModelType,ObjectModelBaseType> translator;
    translator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
    Dol::Translator<Platform::Message,Platform::Message> messageTranslator;
    messageTranslator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
    std::string serializedData = translator.DomainObjectMessageToString(domainObject);
    std::shared_ptr<Platform::Message> Message(new Platform::Message(m_messageType,serializedData,serializedData.length()));
    Message->m_SourceUniqueID = m_SourceID;
    Message->m_DestinationUniqueID = DestinationID;
    Message->m_sender = m_senderProcessId;


#if IS_FREE_RTOS_PLATFORM()
    // If panel is not connected, store all messages in the pending queue
    if ((SubscribedID == PROC_ADDRESS::CCL_BROKER) && (DestinationID == 0))
    {
        Platform::Guard guard(m_pendingMsgMutex);
        if (m_pendingMsgQueue.size() == m_pendingMsgQueueMaxSize)
        {
            // Remove the oldest message due to queue size limitation
            // TODO: this solution should be improved
            m_pendingMsgQueue.pop();
        }
        m_pendingMsgQueue.push(Message);
        return true;
    }

    if (PanelDetails::GetInstance().Connected())
    {
        //Sending all messages from the pending queue
        Platform::Guard guard(m_pendingMsgMutex);
        while(not m_pendingMsgQueue.empty())
        {
            auto msg = m_pendingMsgQueue.front();
            m_pendingMsgQueue.pop();
            msg->m_DestinationUniqueID = PanelDetails::GetInstance().GetPanelID();
            std::string packedData = messageTranslator.DomainObjectMessageToString(msg);
            m_Communicator.Send(packedData, SubscribedID);
        }
    }
#endif

    std::string packedData = messageTranslator.DomainObjectMessageToString(Message);

    auto result = m_Communicator.Send(packedData,SubscribedID,waitTimeMs,toFront);
    if(!result)
    {
        DEBUGPRINT(DEBUG_ERROR,"ObjectModelCommunicator::Send error to Application ID[{0}]\n", static_cast<int>(SubscribedID));
    }
    return result;
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType>
std::shared_ptr<ObjectModelType> ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Receive()
{
    Platform::DomainObjectMessage domainObjectMessage;
    Dol::Translator<Platform::Message,Platform::Message> messageTranslator;
    messageTranslator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
    std::shared_ptr<Platform::Message> Message =  messageTranslator.StringToDomainObjectMessage(m_Communicator.Receive());

    Dol::Translator<ObjectModelType,ObjectModelBaseType> translator;
    translator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
    return translator.StringToDomainObjectMessage(Message->m_Data);
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType>
void ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::internalNotifier(std::string& serializedData, ObjectModelKeyType domainObjectType, uint64_t SourceID, PROC_ADDRESS processId)
{
    {
        auto search = m_Services.find(domainObjectType);
        if( search != m_Services.end())
        {
            Dol::Translator<ObjectModelType,ObjectModelBaseType> domainObjectTranslator;
            domainObjectTranslator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
            std::shared_ptr<ObjectModelType> domainObjectReceived = domainObjectTranslator.StringToDomainObjectMessage(serializedData);
            (*(search->second))(domainObjectReceived,SourceID);
        }
    }
    {
        auto search = m_applicationBasedServices.find(domainObjectType);
        if( search != m_applicationBasedServices.end())
        {
            Dol::Translator<ObjectModelType,ObjectModelBaseType> domainObjectTranslator;
            domainObjectTranslator.m_messageSignal.Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::DebugMessage);
            std::shared_ptr<ObjectModelType> domainObjectReceived = domainObjectTranslator.StringToDomainObjectMessage(serializedData);
            (*(search->second))(domainObjectReceived,SourceID,processId);
        }
    }
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType, typename MessageIDType>
int32_t ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Subscribe(ObjectModelKeyType domainObjectType, MessageIDType publisherId)
{
    auto search = m_InternalServices.find(domainObjectType);
    if( search == m_InternalServices.end())
    {
        m_InternalServices.insert(std::make_pair(domainObjectType,std::make_shared<Gallant::Signal2<std::string&, ObjectModelKeyType>>()));
        m_InternalServices[domainObjectType]->Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::internalNotifier<ObjectModelType>);
    }
    return m_Communicator.Connect(publisherId);
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType>
void ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Subscribe(ObjectModelKeyType domainObjectType)
{
    auto search = m_InternalServices.find(domainObjectType);
    if( search == m_InternalServices.end())
    {
        m_InternalServices.insert(std::make_pair(domainObjectType,std::make_shared<Gallant::Signal4<std::string&, ObjectModelKeyType,uint64_t,PROC_ADDRESS>>()));
        m_InternalServices[domainObjectType]->Connect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::internalNotifier<ObjectModelType>);
    }
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType,typename MessageIDType>
void  ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Unsubscribe(ObjectModelKeyType domainObjectType, MessageIDType publisherId, int32_t endPoint)
{
    auto search = m_InternalServices.find(domainObjectType);
    if( search != m_InternalServices.end())
    {
        m_InternalServices[domainObjectType]->Disconnect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::internalNotifier<ObjectModelType>);
    }
    m_Communicator.Disconnect(publisherId,endPoint);
}


template<typename CommunicatorType,typename ObjectModelKeyType,typename ObjectModelBaseType >
template<typename ObjectModelType>
void  ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::Unsubscribe(ObjectModelKeyType domainObjectType)
{
    auto search = m_InternalServices.find(domainObjectType);
    if( search != m_InternalServices.end())
    {
        m_InternalServices[domainObjectType]->Disconnect(this,&ObjectModelCommunicator<CommunicatorType,ObjectModelKeyType,ObjectModelBaseType>::internalNotifier<ObjectModelType>);
    }
}
}
#endif //COMMUNICATOR_INCLUDE_H
