/******************************************************************************//**
* @file  PanelMonitor.h
* @brief PanelMonitor handles panel connection
*
* @copyright Copyright 2018 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#include "Timer/Timer.hpp"
#include "Thread/Thread.hpp"
#include "Mol/Monitoring/HeartBeat.h"
#include "DOL/Entities/Module.h"
#include "Mol/Monitoring/Registration.h"
#include "Mol/DeviceUniqueID.h"
#include "Component/Component.h"
#include "CommonDef.h"
#include "Mol/Events/InformationEvent.h"
#include "Mol/Monitoring/AtuUpdate.h"
#include "Guard/Guard.hpp"
#if IS_FREE_RTOS_PLATFORM()
#include "Services/PanelConnection/PanelDetails.h"
#endif

namespace ModuleRegistration
{

/**
 * @brief    PanelMonitor main responsibilities are
 *           track panel connection and notify the panel state changes.
*/
class PanelMonitor: public Platform::Component
{
public:
    PanelMonitor(std::shared_ptr<Dol::Entities::Module> module, PROC_ADDRESS applicationID, PROC_ADDRESS brokerID, uint32_t monitorIntervalMs) :
            m_module(module),
            m_applicationID{applicationID},
            m_brokerID{brokerID},
            m_monitorIntervalMs{monitorIntervalMs}
    {
    }

    virtual ~PanelMonitor() = default;

    /**
     * @brief    Create timer to retry panel connected
     *           Create message queue to control state change
    */
    virtual void Init() override
    {
        Platform::Component::Init();
        Platform::Notifier workerData;
        workerData.Connect(this, &PanelMonitor::Timeout);
        m_timer = Platform::Timer<>((m_retryInterval * m_monitorIntervalMs), GlobalDataType::Timer::AlarmType::PERIODIC, workerData);
        m_queue = Platform::MessageQueue<>{"Panel Monitor", GlobalDataType::MessageQueue::BlockType::BLOCK};
    }

    /**
     * @brief    Subscribe HEARTBEAT and REGISTRATION_CONFIRMATION
     *           Start thread for panel monitoring
    */
    virtual void Start() override
    {
        Platform::Component::Start();
        m_communicator.m_monitoring.Subscribe<Mol::Monitoring::HeartBeat>(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT);
        m_communicator.m_monitoring.getService(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT)->Connect(this, &PanelMonitor::ReceiveHeartBeat);

        m_communicator.m_monitoring.Subscribe<Mol::Monitoring::ModuleRegistration>(Mol::Monitoring::MONITORING_CATEGORY::REGISTRATION_CONFIRMATION);
        m_communicator.m_monitoring.getService(Mol::Monitoring::MONITORING_CATEGORY::REGISTRATION_CONFIRMATION)->Connect(this, &PanelMonitor::ReceiveModuleRegistrationConfirmation);

        Platform::Notifier workerData;
        workerData.Connect(this,&PanelMonitor::HeartBeatMonitor);
        m_thread = Platform::Thread<>{workerData, "PanelMonitor"};
    }

    /**
     * @brief   Stops panel monitoring
    */
    virtual void Stop() override
    {
        Platform::Component::Stop();
        m_queue.Send(STR_TERMINATE);
        m_thread.Join();
    }

    /**
     * @brief   Shutdown the timer
    */
    virtual void Shutdown() override
    {
        Platform::Component::Shutdown();
        m_timer.Shutdown();
    }

private:
    Platform::Thread<> m_thread;

    Platform::Timer<> m_timer;

    Platform::MessageQueue<> m_queue;

    std::shared_ptr<Dol::Entities::Module> m_module;

    const PROC_ADDRESS m_applicationID;

    const PROC_ADDRESS m_brokerID;

    uint32_t m_monitorIntervalMs = 0;

    const uint8_t m_retryInterval = 4;

    const  std::string STR_REGISTERED {"REGISTERED"};

    const std::string STR_HEARTBEAT {"HEARTBEAT"};

    const std::string STR_DISCONNECTED {"DISCONNECTED"};

    const std::string STR_TERMINATE {"TERM"};

    bool m_registered = false;

    std::string m_panelIpAddress{};

    uint64_t m_panelID = 0u;

    Platform::Mutex<> m_mutex;

    uint8_t m_registrationRetryCount = 0;
    /*
     *@brief    Update CCL ATU table
     *@param[in]    ipAddr IPAddress of module
     *@param[in]    moduleID Module ID
     */
    void UpdateATU(const std::string& ipAddr, const uint16_t moduleID = 0)
    {
        DEBUGPRINT(DEBUG_INFO,"PanelMonitor:UpdateATU: moduleID[%x]  ipAddr[%s]", moduleID, ipAddr.c_str());
        if(moduleID == 0)
        {
            auto updateAtu = std::make_shared<Mol::Monitoring::AtuUpdate>(Mol::Monitoring::ATU_UPDATE_TYPE::DELETE);
            updateAtu->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, ipAddr);
            m_communicator.m_monitoring.Send(updateAtu, m_brokerID, m_module->GetID());
        }
        else
        {
            auto updateAtu = std::make_shared<Mol::Monitoring::AtuUpdate>(Mol::Monitoring::ATU_UPDATE_TYPE::ADD);
            updateAtu->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, ipAddr);
            updateAtu->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, moduleID);
            m_communicator.m_monitoring.Send(updateAtu, m_brokerID, m_module->GetID());
        }
    }

    /*
     *@brief    Validate Heartbeat source
     *@return   true if valid domain and node info,otherwise false
     */
    bool ValidHeartbeat(const uint64_t& senderID)
    {
        Mol::DeviceUniqueID panelUniqueID(senderID);
        Mol::DeviceUniqueID moduleUniqueID(m_module->GetID());
        if((panelUniqueID.GetNodeID() == moduleUniqueID.GetNodeID()) && (panelUniqueID.GetDomainID() == moduleUniqueID.GetDomainID())
                && (panelUniqueID.GetModuleID() != moduleUniqueID.GetModuleID()))
        {
            return true;
        }
        return false;
    }

    /*
     *@brief    Notification on HeartBeat
     *@param[in]    message Received message
     *@param[in]    senderID unique source id of sender
     */
    void ReceiveHeartBeat(std::shared_ptr<Mol::Message<Mol::Monitoring::MONITORING_CATEGORY>> message, uint64_t senderID)
    {
        DEBUGPRINT(DEBUG_INFO,"PanelMonitor:ReceiveHeartBeat: panelID[%s]", std::to_string(senderID).c_str());
        auto receivedHeartBeat = std::static_pointer_cast<Mol::Monitoring::HeartBeat>(message);

        if(!ValidHeartbeat(senderID))
        {
            DEBUGPRINT(DEBUG_ERROR,"PanelMonitor:ReceiveHeartBeat:Invalid Heartbeat panelID[%s] moduleID[%s]", std::to_string(senderID).c_str(),
                     std::to_string(m_module->GetID()).c_str());
            return;
        }

        if(Mol::Monitoring::HEARTBEAT_CODE::PANEL == receivedHeartBeat->GetMonitoringCode())
        {
            {
                Platform::Guard guard(m_mutex);
                if(!m_registered)
                {
                    DEBUGPRINT(DEBUG_INFO,"PanelMonitor:ReceiveHeartBeat: Register panelID[%s]", std::to_string(senderID).c_str());
                    m_panelIpAddress = receivedHeartBeat->GetParameters().at(0).GetValue<std::string>();
                    m_panelID = senderID;
                    Mol::DeviceUniqueID sourceID(senderID);
                    auto moduleID = sourceID.GetModuleID();
                    UpdateATU(m_panelIpAddress, moduleID);
                }
            }
            // HeartBeat send reply (to front of queue)
            m_queue.Send(STR_HEARTBEAT, 0, true);
        }
    }

    /*
     *@brief    Notification on ModuleRegistration
     *@param[in]    message Received message
     *@param[in]    senderID unique source id of sender
     */
    void ReceiveModuleRegistrationConfirmation(std::shared_ptr<Mol::Message<Mol::Monitoring::MONITORING_CATEGORY>> message, uint64_t senderID)
    {
        DEBUGPRINT(DEBUG_INFO,"PanelMonitor:ReceiveModuleRegistrationConfirmation: panelID[%s]", std::to_string(senderID).c_str());
        std::shared_ptr<Mol::Monitoring::ModuleRegistration> moduleRegistration = std::static_pointer_cast<Mol::Monitoring::ModuleRegistration>(message);
        if(Mol::Monitoring::REGISTRATION_CODE::OKAY == moduleRegistration->GetMonitoringCode())
        {
            m_queue.Send(STR_REGISTERED);
        }
        else if(Mol::Monitoring::REGISTRATION_CODE::NOT_OKAY == moduleRegistration->GetMonitoringCode())
        {
            DEBUGPRINT(DEBUG_ERROR,"PanelMonitor: Invalid Panel Registration");
            m_queue.Send(STR_DISCONNECTED);
        }
    }

    /**
     * @brief    Timeout handler for panel disconnection
    */
    void Timeout()
    {
        DEBUGPRINT(DEBUG_ERROR,"PanelMonitor:Timeout called");
        m_queue.Send(STR_DISCONNECTED);
    }

    /*
     * @brief  Notify information event to the submodule.
     * @param[in]  status main cpu connection status
     * @return true message has been queued OK.
     */
    bool Notify(const bool status)
    {
        auto event_code = (status) ?
                Mol::Event::INFORMATION_EVENT_CODE::PANEL_CONNECTED :
                Mol::Event::INFORMATION_EVENT_CODE::PANEL_DISCONNECTED;
        auto event = std::make_shared<Mol::Event::InformationEvent>(event_code);

        event->SetEventApplication(Mol::Event::EVENT_APPLICATION::FIRE);
        if(status)
        {
            event->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, m_panelID);
        }
        return m_communicator.m_event.Send(event, PROC_ADDRESS::MODULE_APP);
    }

    /**
     * @brief   Send Module domain object
    */
    void SendModule()
    {
        DEBUGPRINT(DEBUG_INFO,"PanelMonitor:SendModule: ID [%s]", std::to_string(m_module->GetID()).c_str());
        m_communicator.m_dol.Send(m_module, m_brokerID, m_panelID);
    }

    /**
     * @brief   Panel monitoring state machine.
     * @todo    change to boost::sml
    */
    void HeartBeatMonitor()
    {
        while (true)
        {
            std::string msg = m_queue.Receive(m_monitorIntervalMs);
            if (msg.compare(STR_REGISTERED) == 0)
            {
                Platform::Guard guard(m_mutex);
                m_timer.Stop();
                DEBUGPRINT(DEBUG_INFO,"PanelMonitor:HeartBeatMonitor:STR_REGISTERED Module is registered");
                m_registered = true;
                Notify(true);
                m_timer.Start();
#if IS_FREE_RTOS_PLATFORM()
                //Trigger a one off SNTP update from Main CPU
                PanelDetails::GetInstance().SetPanelIP(m_panelIpAddress);
#endif
            }
            else if (msg.compare(STR_HEARTBEAT) == 0)
            {
                Platform::Guard guard(m_mutex);
                if(!m_registered)
                {
                    DEBUGPRINT(DEBUG_INFO,"PanelMonitor:HeartBeatMonitor:STR_HEARTBEAT & m_registered == false");
                    /** MainCPU sends the heart beat for every 5 seconds. We assume that 3 retries = 15sec, is enough
                     * to get a reply for registration request sent. If its not enough we send a registration request
                     * again, which may result in the COMMUNCATION_STOPPED fault to be displayed and system LED lit.
                    */
                    if (m_registrationRetryCount == 0)
                    {
                        SendModule();
                    }
                    m_registrationRetryCount++;
                    if (m_registrationRetryCount >=3 )
	                    m_registrationRetryCount = 0;

                }
                else
                {
                    m_timer.Stop();
                    DEBUGPRINT(DEBUG_INFO,"PanelMonitor:HeartBeatMonitor:STR_HEARTBEAT");
                    auto heartBeat = std::make_shared<Mol::Monitoring::HeartBeat>(Mol::Monitoring::HEARTBEAT_CODE::MODULE);
                    m_communicator.m_monitoring.Send(heartBeat, m_brokerID, m_panelID);
                    m_timer.Start();
                }
            }
            else if (msg.compare(STR_DISCONNECTED) == 0)
            {
                Platform::Guard guard(m_mutex);
                if (m_registered)
                {
                    DEBUGPRINT(DEBUG_ERROR,"PanelMonitor:HeartBeatMonitor:STR_DISCONNECTED panelIP[%s]", m_panelIpAddress.c_str());
                    UpdateATU(m_panelIpAddress);
                    m_panelID = 0;
                    m_panelIpAddress.clear();
                    m_registered = false;
                }
                Notify(false);
                m_timer.Stop();
            }
            else if (msg.compare(STR_TERMINATE) == 0)
            {
                DEBUGPRINT(DEBUG_INFO,"PanelMonitor:HeartBeatMonitor:STR_TERMINATE");
                return;
            }

        }
    }
};
}
