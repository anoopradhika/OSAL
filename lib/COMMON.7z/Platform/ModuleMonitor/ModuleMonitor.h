/******************************************************************************//**
* @file  ModuleMonitor.h
* @brief ModuleMonitor handles module registration as well as module status
*
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/

#ifndef MODULE_MONITOR_INCLUDE_H
#define MODULE_MONITOR_INCLUDE_H

#include <map>
#include <algorithm>
#include <fstream>

#include "Timer/Timer.hpp"
#include "Mol/Monitoring/HeartBeat.h"
#include "DOL/Entities/Module.h"
#include "Mol/Monitoring/Registration.h"
#include "Mol/DeviceUniqueID.h"
#include "Mol/Events/FaultEvent.h"
#include "Mol/Events/FaultClearedEvent.h"
#include "Mol/Events/AlarmEvent.h"
#include "Mol/Events/InformationEvent.h"
#include "Component/Component.h"
#include "Mol/Monitoring/AtuUpdate.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include "Mol/Responses/SoftwareCenterResponses.h"
#include "Mol/Requests/SoftwareCenterRequests.h"
//#include "FirmwareInfoParser/FirmwareInfoParser.h"
#include "SlotConfigParser/SlotConfigParser.h"
#include "Mol/Commands/Reset.h"
#include "Utility.h"

#include "DomainConfiguration/DomainConfiguration.h"

namespace ModuleRegistration
{

/**
 * @brief   Module Monitor is a component of Common Module Communicator application. 
            It handles the below functions 
            1. Heart Beat Monitoring
            2. Module Registration and Module details broadcasting
            3. ATU mapping of Modules for communication
            4. Module Validation, Missing and Invalid device event notification
            5. Missing heart beat detection and Identification of Module disconnection.
 *          
*/
class ModuleMonitor: public Platform::Component
{

public:

/** 
     @brief The constructor is used to intialize the private members of the class
     * @param[in]  ipv6Address IPv6 Address of the Main CPU
     * @param[in]  sourceID the Module ID of Main CPU
     * @param[in]  procID process ID of Application
     * @param[in]  brokerID process ID of Message Broker
     * @param[in]  monitorIntervalMs Monitoring interval of heart beat
     * @return ModuleMonitor object constructed

*/
    ModuleMonitor(const std::string& ipv6Address, const uint64_t sourceID, const PROC_ADDRESS procID, const PROC_ADDRESS brokerID, const uint64_t monitorIntervalMs) :
        m_ipv6Address{ipv6Address},
        m_sourceID{sourceID},
        m_procID{procID},
        m_brokerID{brokerID},
        m_monitorIntervalMs{monitorIntervalMs}
    {

    }

    virtual ~ModuleMonitor() = default;

/** @brief The init function reads /config/config1/systemconfig.xml file 
           which contains the information about the modules that are configured for the Backpane.
           It maintains the map of module ID and the module object. 
           It creates a timer which sends a heartbeat message for every 5 
           seconds to all the other loop devices.
           It also reads the configuration.xml file to get the managed area.
 * @param[in] Void
 * @return Void
 * 
*/

    virtual void Init() final
    {
        SlotConfigParser configParser{m_moduleConfigMap, m_sourceID};
        std::string configFile = Utility::GetActiveConfigLocation();
        configFile.append(m_systemConfigFileName);

        // Check for Symlink or Hardlink
        if (Utility::IsSymlinkOrHardlink(configFile))
        {
            DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:Init: [{0}] is a Symlink or Hardlink", configFile);
        } 
        else
        {
            if(configParser.LoadFile(configFile) != SUCCESS)
            {  
                DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:Init: Failed to read config file [{}]",configFile);
            }
        }
        
        Platform::Notifier workerData;
        workerData.Connect(this, &ModuleMonitor::HeartBeatMonitor);
        m_timer = Platform::Timer<>(m_monitorIntervalMs, GlobalDataType::Timer::AlarmType::PERIODIC, workerData);
                                                    
        fireSystemState::DomainConfiguration readConfigFile;
        auto uid = Mol::DeviceUniqueID(m_sourceID);
        m_myManagedArea = readConfigFile.FindManagedAreaId(uid.GetPanelId64Bit());
        DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: My Managed Area is[{0}]",m_myManagedArea);

        Platform::Component::Init();
    }

/** @brief Prepare function subscribes and connects to the below services.
1. HEARTBEAT->      This service will enable call back function to receive heart beat 
                    messages from the other modules.   
2. MODULE->         This service will enable call back function to receive 
                    registration messages from other modules.
3. MODULE_DETAILS-> This service will enable call back function to send 
                    DOL message (module details) of all modules after registration.
4. RESET->          This service will enable call back function to send reset 
                    events for all the faults events.  
 * @param[in] Void
 * @return Void
 * 
*/


    virtual void Prepare() final
    {
        m_communicator.m_monitoring.Subscribe<Mol::Monitoring::HeartBeat>(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT);
        m_communicator.m_monitoring.getService(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT)->Connect(this, &ModuleMonitor::ReceiveHeartBeat);

        m_communicator.m_dol.Subscribe<Dol::Entities::Module>(Dol::DOMAIN_OBJECT_TYPE::MODULE);
        m_communicator.m_dol.getService(Dol::DOMAIN_OBJECT_TYPE::MODULE)->Connect(this, &ModuleMonitor::ReceiveModule);
		
        m_communicator.m_request.Subscribe<Mol::Request::ModuleInfo>(Mol::Request::REQUEST_CATEGORY::MODULE_DETAILS);
        m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MODULE_DETAILS)->Connect(this, &ModuleMonitor::ReceiveModuleInfoRequest);

        m_communicator.m_command.Subscribe<Mol::Command::Reset>(Mol::Command::COMMAND_CATEGORY::RESET);
        m_communicator.m_command.getServiceWithApplicationType(Mol::Command::COMMAND_CATEGORY::RESET)->Connect(this, &ModuleMonitor::ResetNotification);

        m_communicator.m_messageTransporter.m_notifiers[Platform::Message::MessageType::COMMAND].Connect(this,&ModuleMonitor::ForceHeartBeat);
		
        Platform::Component::Prepare();
    }

/** @brief Start function starts the timer to send Heart Beat message 
           from MainCPU to other modules. 
           It also broadcasts the event message that MainCPU is now connected as a new module.
 * @param[in] Void
 * @return Void
 * 
*/

    void Start() override
    {
        m_timer.Start();
        Platform::Component::Start();
    }

/** @brief Stop function is used to stop the Module Monitor component. 
 * @param[in] Void
 * @return Void
 * 
*/

    void Stop() override
    {
        m_timer.Stop();
        Platform::Component::Stop();
    }

/** @brief Shutdown functions is used to shutdown the Module Monitor component. 
It also disconnects from all the services subscribed in the prepare function.
 * @param[in] Void
 * @return Void
 * 
*/

    virtual void Shutdown() final
    {
        m_communicator.m_monitoring.Unsubscribe<Mol::Monitoring::HeartBeat>(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT);
        m_communicator.m_monitoring.getService(Mol::Monitoring::MONITORING_CATEGORY::HEARTBEAT)->Disconnect(this, &ModuleMonitor::ReceiveHeartBeat);

        m_communicator.m_dol.Unsubscribe<Dol::Entities::Module>(Dol::DOMAIN_OBJECT_TYPE::MODULE);
        m_communicator.m_dol.getService(Dol::DOMAIN_OBJECT_TYPE::MODULE)->Disconnect(this, &ModuleMonitor::ReceiveModule);

        m_communicator.m_command.Unsubscribe<Mol::Command::Reset>(Mol::Command::COMMAND_CATEGORY::RESET);
        m_communicator.m_command.getServiceWithApplicationType(Mol::Command::COMMAND_CATEGORY::RESET)->Disconnect(this, &ModuleMonitor::ResetNotification);

        m_communicator.m_request.Unsubscribe<Mol::Request::ModuleInfo>(Mol::Request::REQUEST_CATEGORY::MODULE_DETAILS);
        m_communicator.m_request.getServiceWithApplicationType(Mol::Request::REQUEST_CATEGORY::MODULE_DETAILS)->Disconnect(this, &ModuleMonitor::ReceiveModuleInfoRequest);
		
		m_communicator.m_messageTransporter.m_notifiers[Platform::Message::MessageType::COMMAND].Disconnect(this,&ModuleMonitor::ForceHeartBeat);

        m_timer.Shutdown();
        Platform::Component::Shutdown();
    }

protected:
/// m_ipv6Address stores the IPv6 Address of Source Application
    const std::string m_ipv6Address;
/// m_sourceID Stores the module ID of Source Application
    const uint64_t m_sourceID                       = 0;
/// m_procID processID of Parent Application 
    const PROC_ADDRESS m_procID                     = PROC_ADDRESS::UNINITIALIZED;
/// m_brokerID processID of the message broker
    const PROC_ADDRESS m_brokerID                   = PROC_ADDRESS::UNINITIALIZED;
/// m_maxRetryCount Heart Beat retry Count
    const uint8_t m_maxRetryCount                   = 4;
/// m_monitorIntervalMs Heart Beat sending Interval 
    const uint64_t m_monitorIntervalMs              = 0;

    Platform::Timer<> m_timer;
/// m_registeredModules Maintains the map of moduleID and Module object of registered modules
    std::map<uint64_t, std::shared_ptr<Dol::Entities::Module>> m_registeredModules;
/// m_heartBeatMissCount Maintains the map of ModuleID and their heartbeat miss count
    std::map<uint64_t, uint8_t> m_heartBeatMissCount;
/** m_moduleConfigMap Maintains the map of ModuleID and the corresponding
                      Module Object created from the systemconfig.xml file
 */ 
    std::map<uint64_t, std::shared_ptr<Dol::Entities::Module>> m_moduleConfigMap;

/// Adding Map for Persistence of Disablments to send First Heartbeat event
    std::map<uint64_t, Mol::DataType::ObjectReference > m_moduleData;

/// Converts Module Object type to Domain Object type
    Dol::DOMAIN_OBJECT_TYPE m_moduleTypeToDomainObjectType[static_cast<int>(Dol::Entities::Module::MODULE_TYPE::REDUNDANT_MAINCPU) + 1] = { Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE, Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE,
            Dol::DOMAIN_OBJECT_TYPE::IO_MODULE, Dol::DOMAIN_OBJECT_TYPE::FIRE_BRIGADE_CONTROL_PANEL, Dol::DOMAIN_OBJECT_TYPE::SERIAL_COMM_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE,
            Dol::DOMAIN_OBJECT_TYPE::FARE_FRE_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE,
            Dol::DOMAIN_OBJECT_TYPE::CHARGER_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE,
            Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE,
            Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE,
            Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::LOOP_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE,
            Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE, Dol::DOMAIN_OBJECT_TYPE::NETWORK_MODULE,
            Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE, Dol::DOMAIN_OBJECT_TYPE::CPU_MODULE, Dol::DOMAIN_OBJECT_TYPE::MODULE};
/** m_moduleFaultMap Maintains the multi map of Module ID and faults for the 
                     corresponding modules
*/                     
    std::multimap<uint64_t, Mol::Event::FAULT_EVENT_CODE> m_moduleFaultMap;
/// m_ipv6Addresses set of ipv6 address of connected modules
    std::set<std::string>    m_ipv6Addresses;
    const char* m_systemConfigFileName = "systemconfig.xml";
/// Stores the reference for configuration.xml file
    tinyxml2::XMLDocument m_doc;
/// Stores the managed ares to which the CPU belongs
    uint64_t m_myManagedArea        = 0;
    uint8_t m_noReplayTimeout = 0;
    /**
     *@brief    UpdateATU function adds the Module registered to the 
                ATU table maintained by CCL for future communication with the modules. 
                It can also delete the entry from the ATU table 
                if the heart beat messages are missed and the module is disconnected.
     *
     *@param[in]    ipAddr IPAddress of module
     *@param[in]    moduleID module ID
     *@return Void 
     *
     */
    void UpdateATU(const std::string& ipAddr, const uint16_t moduleID = 0)
    {
        DEBUGPRINT(DEBUG_INFO,"ModuleMonitor:UpdateATU: moduleID[{0:#x}]  ipAddr[{1}]", moduleID, ipAddr.c_str());
        if(moduleID == 0)
        {
            auto updateAtu = std::make_shared<Mol::Monitoring::AtuUpdate>(Mol::Monitoring::ATU_UPDATE_TYPE::DELETE);
            updateAtu->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, ipAddr);
            m_communicator.m_monitoring.Send(updateAtu, m_brokerID, m_sourceID);
        }
        else if(moduleID != 0)
        {
            auto updateAtu = std::make_shared<Mol::Monitoring::AtuUpdate>(Mol::Monitoring::ATU_UPDATE_TYPE::ADD);
            updateAtu->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, ipAddr);
            updateAtu->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, moduleID);
            m_communicator.m_monitoring.Send(updateAtu, m_brokerID, m_sourceID);
        }
        else
        {
            DEBUGPRINT(DEBUG_INFO,"ModuleMonitor:UpdateATU:DONothing");
        }
    }

    /**
     * @brief SendFaultEvent function broadcasts any fault events like module mismatch, 
              invalid device or No device etc., to all connected process in the main CPU.
     * @param[in]    code fault code
     * @param[in]    moduleID Module ID
     * @param[in]    domainObjectType Domain Object Type corresponding to ModuleID
     * @return Void 
     * 
    */
    void SendFaultEvent(const Mol::Event::FAULT_EVENT_CODE code, const uint64_t moduleID, const Dol::DOMAIN_OBJECT_TYPE domainObjectType = Dol::DOMAIN_OBJECT_TYPE::MODULE, bool updateMap=true, bool forceSend = false)
    {
        if((false == forceSend) && IsFaultSent(code,moduleID))
        {
            return;
        }

        auto faultEvent = std::make_shared<Mol::Event::FaultEvent>(code);
        Mol::DataType::ObjectReference source{moduleID, domainObjectType};
        faultEvent->SetSource(source);
        // Add fault to multimap for checking Fault cleared
        if(updateMap)
        {
            m_moduleFaultMap.emplace(moduleID, code);
        }
        m_communicator.m_event.Send(faultEvent, PROC_ADDRESS::FIRE_DOMAIN_APP);
        DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:SendFaultEvent moduleID[{0:#x}]  code [{1:#x}]",moduleID, static_cast<int>(code));
    }

    /**
     * @brief    Clear FaultEvent generated previosuly.
     * @param[in]   moduleID module ID of the respective module
     * @param[in]    code Fault code that needs to be cleared
     * @param[in]   domainObjectType Type of the module
     * @return Void 
     * 

    */
    void clearFaultEvent(const uint64_t moduleID,const Mol::Event::FAULT_EVENT_CODE code,const Dol::DOMAIN_OBJECT_TYPE domainObjectType = Dol::DOMAIN_OBJECT_TYPE::MODULE, bool updateMap=true)
    {
        auto faultClearedEvent = std::make_shared<Mol::Event::FaultClearedEvent>(code);
        Mol::DataType::ObjectReference source{moduleID, domainObjectType};
        faultClearedEvent->SetSource(source);
        m_communicator.m_event.Send(faultClearedEvent, PROC_ADDRESS::BROADCAST);
        if (updateMap)
         {
            m_moduleFaultMap.erase(moduleID);
         }
        DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:clearFaultEvent SendFaultClearedEvent moduleID[{0:#x}]  code [{1:#x}]",moduleID, static_cast<int>(code));
    }
    /**
     * @brief ResetNotification is used to reset the notification previously sent. 
              This function checks if the previous faults raised have been corrected. 
              If the same are corrected, then the fault clear event are sent to remove the faults. 
              New faults if any are raised by validating all the registered modules once again.
     * @param[in] command reset command
     * @param[in] senderID command sender ID
     * @return Void 
     * 
     */
    void ResetNotification(std::shared_ptr<Mol::Message<Mol::Command::COMMAND_CATEGORY>> command, const uint64_t senderID,PROC_ADDRESS senderProcessId)
    {
        if(command == nullptr)
        {
            DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor: Reset command nullptr");
            return;
        }
        auto eventResetMode = Utility::GetEventResetMode();
        auto resetCommand = std::static_pointer_cast<Mol::Command::Reset>(command);
        auto resetCommandTarget = resetCommand->GetCommandTarget();
        DEBUGPRINT(DEBUG_INFO,"ModuleMonitor:The managed area is [{0:#x}]",resetCommandTarget.GetObjectId());

        if(resetCommandTarget.GetObjectId() != m_myManagedArea)
        {
            DEBUGPRINT(DEBUG_INFO,"ModuleMonitor:return from ResetNotification as managed area does not match");
            return;
        }

        if (PROC_ADDRESS::FIRE_DOMAIN_APP != senderProcessId)
        {
            DEBUGPRINT(DEBUG_INFO, "ModuleMonitor: Reset command not sent by FDA so do not proceed");
            return;
        }

        VerifyFaultCleared();
		
		//traverse fault map find whether duplicate address fault exists
		//traversing fault map is better compared to traversing in m_registeredModules map in ValidateModule method
		bool duplicateadressfaultexists = false;
		for (auto itr = m_moduleFaultMap.begin(); itr != m_moduleFaultMap.end();itr++)
        {
            if(itr->second == Mol::Event::FAULT_EVENT_CODE::DUPLICATE_ADDRESS_DETECTED)
			{
				duplicateadressfaultexists = true;
			}
		}

        if(EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE == eventResetMode)
        {
            m_moduleFaultMap.clear();
        }
        //m_ipv6Addresses.clear(); //observed malloc issues while emplacing ipaddress on reset... added different logic to find duplicate address fault

        m_noReplayTimeout = 0;
        for (auto it = m_registeredModules.begin(); it != m_registeredModules.end(); ++it)
        {
            ValidateModule((*it).second,true,duplicateadressfaultexists);
        }

    }
    
    /**
     * @brief  VerifyFaultCleared function is used to verify if the faults events 
               previously sent are cleared, if the faults are corrected then “fault clear event” 
               is sent to clear the fault in the HMI.
     * @param[in] Void
     * @return Void
     * 
    */
    void VerifyFaultCleared()
    {
        auto eventResetMode = Utility::GetEventResetMode();
        for (auto itr = m_moduleFaultMap.begin(); itr != m_moduleFaultMap.end();)
        {
            bool isFaultCleared = CheckFaultStatus(itr->first, itr->second);
            DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: VerifyFaultCleared moduleID[{0:#x}]  code [{1:#x}]",itr->first, static_cast<int>(itr->second));

            std::shared_ptr<Dol::Entities::Module> theModule = nullptr;
            if (m_moduleConfigMap.find(itr->first) != m_moduleConfigMap.end())
            {
                theModule = m_moduleConfigMap.find(itr->first)->second;
            }
            if(theModule != nullptr)
            {
                DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: SendFaultClearedEvent moduleID[{0:#x}]  code [{1:#x}]",itr->first, static_cast<int>(itr->second));
                DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: GetType [{0:#x}]", static_cast<int> (theModule->GetType()));
                if( static_cast<int> (theModule->GetType()) <= static_cast<int>(Dol::Entities::Module::MODULE_TYPE::REDUNDANT_MAINCPU))
                {

                    if(isFaultCleared)
                    {
                        // Bypass IsFaultSent check for legacy panel by setting forceSend set to true
                        if(EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE != eventResetMode)
                        {
                            SendFaultEvent(itr->second,itr->first,m_moduleTypeToDomainObjectType[static_cast<int> (theModule->GetType())],false);
                        }
                        else
                        {
                            SendFaultEvent(itr->second,itr->first,m_moduleTypeToDomainObjectType[static_cast<int> (theModule->GetType())],false,true);
                        }
                        itr++;
                    }
                    else
                    {
                        // For legacy panels, HMI clears faults on its own, so no need to send faultCleared event here
                        if(EventResetMode::LEGACY_NOTIFIER_HBS_MODE_TYPE != eventResetMode)
                        {
                           clearFaultEvent(itr->first,itr->second,m_moduleTypeToDomainObjectType[static_cast<int> (theModule->GetType())],false);
                        }
                        else
                        {
							//@todo this line of code shall be removed
                           clearFaultEvent(itr->first,itr->second,m_moduleTypeToDomainObjectType[static_cast<int> (theModule->GetType())],false);
                        }
                        itr=m_moduleFaultMap.erase(itr);
                    }
                }
            }else
            {
                itr++;
            }
        }
    }

    /**
     * @brief Check for communication fault of module by checking if the module is not registered.
     * @param[in] moduleID module unique ID
     * @return true for fault present, otherwise false
     *      
     */
    bool CheckCommunicationFault(const uint64_t moduleID)
    {
        auto moduleObj = m_registeredModules.find(moduleID);
        if (moduleObj == m_registeredModules.end())
        {
            return true;
        }
        return false;
    }

    /**
     * @brief Check if the module is currently configured.
     *
     * @param[in] moduleID module unique ID
     * @return true for fault present, otherwise false
     *      
     */
    bool CheckModuleUnconfigured(const uint64_t moduleID)
    {
        auto moduleConfig = m_moduleConfigMap.find(moduleID);
        if(moduleConfig == m_moduleConfigMap.end())
        {
            return true;
        }
        return false;
    }

    /**
     * @brief Check for invalid module type connected. It also checks that the connected
     *        module is of valid type as per the configuration.
     *
     * @param[in] moduleID module unique ID
     * @return true for fault present, otherwise false
     *      
     */
    bool CheckInvalidModuleType(const uint64_t moduleID)
    {
        auto moduleObj = m_registeredModules.find(moduleID);
        if (moduleObj != m_registeredModules.end())
        {
            if (moduleObj->second->GetType() == Dol::Entities::Module::MODULE_TYPE::BASE_MODULE)
            {
                // SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::CONFIGURATION_MISMATCHED_WITH_HARDWARE, module->GetID());
                return true;
            }
            else
            {
                return CheckInvalidModuleType(moduleID, moduleObj->second->GetType());
            }
        }
        return false;
    }
    /**
     * @brief Check for invalid module type connected. It also checks that the connected
     *        module is of valid type as per the configuration.
     *
     * @param[in] moduleID module unique ID
     * @param[in] moduleType Type of module
     * @return true for fault present, otherwise false
     *      
     */

    bool CheckInvalidModuleType(const uint64_t moduleID, Dol::Entities::Module::MODULE_TYPE moduleType)
    {
        auto moduleConfig = m_moduleConfigMap.find(moduleID);
        if(moduleConfig != m_moduleConfigMap.end())
        {
            if(moduleType != moduleConfig->second->GetType())
            {
                DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:CheckInvalidModuleType Invalid module with ID [{0:#x}], type [{1:#x}], actual Module type is [{2:#x}]", moduleID,(int)moduleType,(int)moduleConfig->second->GetType());
                return true;
            }
        }
        return false;
    }
    /**
     * @brief IsFaultSent is used to check if a particular fault event is already sent 
              for a particular Module. If module fault multimap has already an entry for 
              the particular fault code, then this function returns true else returns false.
     *
     * @param[in] code FAULT CODE
     * @param[in] moduleID Module ID
     * @return true for if already sent, false if not
     * 
     */

    bool IsFaultSent(const Mol::Event::FAULT_EVENT_CODE code, const uint64_t moduleID)
    {
        auto searchModules = m_moduleFaultMap.equal_range(moduleID);
        int count = std::distance(searchModules.first, searchModules.second);

        if(count <= 0) 
        {
            return false;
        }

        for(auto itrModule = searchModules.first; itrModule != searchModules.second; itrModule++)
        {
            if(itrModule->second == code)
            {
                return true; 
            }
        }
        return false;
    }
    /**
     * @brief Check if the fault code is valid for the given moduleID.
     *
     * @param[in] code fault code
     * @param[in] moduleID module unique ID
     * @return true for fault present, otherwise false
     * 
     */
    bool CheckFaultStatus(const uint64_t moduleID, const Mol::Event::FAULT_EVENT_CODE code)
    {
        auto retCode = false;
        switch (code)
        {
            case Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED:
            case Mol::Event::FAULT_EVENT_CODE::COMMUNICATION_ERROR_OR_TRANSMISSION_FAULT:
                retCode = CheckCommunicationFault(moduleID);
                break;

            case Mol::Event::FAULT_EVENT_CODE::DUPLICATE_ADDRESS_DETECTED:
            case Mol::Event::FAULT_EVENT_CODE::NO_REPLY:
            case Mol::Event::FAULT_EVENT_CODE::UNCONFIGURED_DEVICE_FOUND:
            case Mol::Event::FAULT_EVENT_CODE::CONFIGURATION_MISMATCHED_WITH_HARDWARE:
                retCode = true;                //For duplicate address fault, we always cleared the fault
                break;

            default:
                DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: Unhandled Fault event for module ID[{0:#x}]", moduleID);
                break;
        }
        return retCode;
    }

    /**
     * @brief This function is used when new requests for module registration are received. 
              This function is used to validate if the module is currently available in the 
              systemconfiguration and If the module is connected to correct slot as per the configuration. 
              If any conditions fail, respective events are sent from Module Monitor. 
              This function is also used to check if the same module has sent request 
              multiple times, by checking if the IP Address of the module is already 
              available in the registered list. If there is no duplicate the module 
              is added to the registered map. 
     *
     * @param[in]   module Domain object for module
     * @return  true if module is registered successfully, false if the ipaddress is already registered  
     * 
    */
    bool ValidateModule(const std::shared_ptr<Dol::Entities::Module> module_ptr,bool calledFromReset = false,bool duplicateadressfaultexists = false)
    {
		if(module_ptr == nullptr)
		{
			return false;
		}
        auto moduleID = module_ptr->GetID();
        // Check for unconfigured modules
        if(CheckModuleUnconfigured(moduleID))
        {
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::UNCONFIGURED_DEVICE_FOUND, moduleID,m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]);
            DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: UNCONFIGURED_DEVICE_FOUND ID [{0:#x}]", moduleID);
        }

        // Check for wrong module type
        if(CheckInvalidModuleType(moduleID, module_ptr->GetType()))
        {
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::CONFIGURATION_MISMATCHED_WITH_HARDWARE, moduleID,m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]);
            DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: CONFIGURATION_MISMATCHED_WITH_HARDWARE ID [{0:#x}]", moduleID);
        }

        //Check for duplicate Ipv6 Address
		if(false == calledFromReset)
		{
			if((m_ipv6Addresses.find(module_ptr->GetIpv6Address()) != m_ipv6Addresses.end()))
			{
				SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::DUPLICATE_ADDRESS_DETECTED, moduleID,m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]);
				DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: DUPLICATE_ADDRESS_DETECTED [{0:#x}]", moduleID);

				auto moduleWithError = m_moduleFaultMap.find(moduleID);
				if (moduleWithError != m_moduleFaultMap.end())
				{
					if (moduleWithError->second == Mol::Event::FAULT_EVENT_CODE::NO_REPLY)
					{
						clearFaultEvent(moduleID,Mol::Event::FAULT_EVENT_CODE::NO_REPLY,m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]);
					}
				}
				return false;
			}
			m_ipv6Addresses.emplace(module_ptr->GetIpv6Address());
		}
		else
		{
			if(true == duplicateadressfaultexists)
			{
				//Check for duplicate Ipv6 Address: note...m_ipv6Addresses is not cleared on reset
				uint16_t counter = 0;
				for (auto it = m_registeredModules.begin(); it != m_registeredModules.end(); ++it)
				{
					auto module = (*it).second;
					if(module_ptr->GetIpv6Address() == module->GetIpv6Address())
					{
						counter++;
						if(counter > 1)
						{
							SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::DUPLICATE_ADDRESS_DETECTED, moduleID,m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]);
							break;
						}
					}
				}
			}
		}
        auto moduleWithError = m_moduleFaultMap.find(moduleID);
        if (moduleWithError != m_moduleFaultMap.end())
        {
            if (moduleWithError->second == Mol::Event::FAULT_EVENT_CODE::NO_REPLY)
            {
                clearFaultEvent(moduleID,Mol::Event::FAULT_EVENT_CODE::NO_REPLY,m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]);
            }
        }

//@todo: FirmwareInfoParser  can use after it moved as component
#if 0
        std::string serialNumber = module->GetSerialNumber();
        if (std::count_if(serialNumber.begin(), serialNumber.end(),  [](unsigned char c){ return !std::isxdigit(c);}) > 0)
        {
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::CONFIGURATION_MISMATCHED_WITH_HARDWARE);
            return false;
        }

        std::string moduleHardwareVersion = module->GetHardwareVersion();
        if (std::count_if(moduleHardwareVersion.begin(), moduleHardwareVersion.end(),  [](unsigned char c)
            {
                return ((!std::isxdigit(c)) && (!std::isalpha(c)));  //@TODO check if this is right, this would mean only ABCDEF and abcdef is allowed
            }) > 0)
        {
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::MISMATCHED_HARDWARE_TYPE);
            return false;
        }

        FirmwareInfoParser& firmwareInfoFileParser = FirmwareInfoParser::GetParserHandle();

        if (SUCCESS != firmwareInfoFileParser.RetrieveFirmwareInfoFile(m_firmwareInfoFile.c_str(), module->GetType()))
        {
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::CONFIGURATION_MISMATCHED_WITH_HARDWARE);
            return false;
        }

        std::string hardwareVersion = firmwareInfoFileParser.GetModuleHardwareVersion();
        std::string packageVersion = firmwareInfoFileParser.GetModulePackageVersion();
        std::stringstream softwareVersion;
        softwareVersion << module->GetSoftwareVersion().GetMajor() << "."
                        << module->GetSoftwareVersion().GetMinor() << "."
                        << module->GetSoftwareVersion().GetPatch();

        if ((softwareVersion.str() != packageVersion) || (hardwareVersion != moduleHardwareVersion))
        {
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::INCOMPATIBLE_DEVICE_DETECTED);
            return false;
        }
 #endif
    return true;
    }

    /**
     *@brief This function is a callback function whenever heart beat event is received 
             by CCL from other modules. This function checks if the heartbeat is received 
             from correctly registered module. If the module is already registered, then 
             the missed heart count is reset. If the heart beat is from non-registered module, 
             then registered confirmation not okay message is sent to modules.
     *          
     *@param[in]    event Received message
     *@param[in]    senderID unique source id of sender
     *@return Void   
     */
    void ReceiveHeartBeat(std::shared_ptr<Mol::Message<Mol::Monitoring::MONITORING_CATEGORY>> event, const uint64_t senderID)
    {
        auto receivedHeartBeat = std::static_pointer_cast<Mol::Monitoring::HeartBeat>(event);
        if(Mol::Monitoring::HEARTBEAT_CODE::MODULE == receivedHeartBeat->GetMonitoringCode())
        {
            if (m_heartBeatMissCount.find(senderID) != m_heartBeatMissCount.end())
            {
                DEBUGPRINT(DEBUG_INFO,"******HEARTBEAT MESSAGE - ModuleMonitor:ReceiveHeartBeat from Module [{:#x}]", senderID);
                m_heartBeatMissCount[senderID] = 0;
    
                //code to send FIRST_HERATBEAT_RECEIVED Information Event for persistence of Disablement
                if (m_moduleData.find(senderID) != m_moduleData.end())
                {
                    Mol::DataType::ObjectReference target = m_moduleData[senderID];
                    if(target.GetObjectType() != Dol::DOMAIN_OBJECT_TYPE::INVALID)
                    {
                        auto information = std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::FIRST_HERATBEAT_RECEIVED);
                        information->SetSource(target);
                        m_communicator.m_event.Send(information, PROC_ADDRESS::BROADCAST);
                        DEBUGPRINT(DEBUG_INFO, "ModuleMonitor:ReceiveHeartBeat POD Send Heartbeat Info Event to ActiveEvents for Module [{}]",senderID);
                        target.SetObjectType(Dol::DOMAIN_OBJECT_TYPE::INVALID);
                        m_moduleData[senderID] = target;
                    }        
                }
            }
            else
            {
                DEBUGPRINT(DEBUG_INFO,"******HEARTBEAT MESSAGE ModuleMonitor:ReceiveHeartBeat from unknown Module [{:#x}]", senderID);
                auto registrationConfirmation = std::make_shared<Mol::Monitoring::ModuleRegistration>(Mol::Monitoring::REGISTRATION_CODE::NOT_OKAY);
                m_communicator.m_monitoring.Send(registrationConfirmation, m_brokerID, senderID);
            }
        }
        else
        {
            DEBUGPRINT(DEBUG_INFO,"ModuleMonitor:ReceiveHeartBeat: SenderID[{0:#x}] invalid code [{1}]:", senderID, (int)receivedHeartBeat->GetMonitoringCode());
        }
    }

    /**
     *@brief This function checks if the module is already registered, 
             if not then it validates the module, initializes the heart beat 
             count for the module, updates the ATU table for the module. 
             It sends the registration Ok message to the module and sends a 
             NEW_MODULE_CONNECTED broadcast to the other applications. 
             If the already registered module sends request again, then 
             registration OK message is replied without any validation.
     *@param[in]    message Received message
     *@param[in]    senderID unique source id of sender
     *@return Void
     *    
     */
    void ReceiveModule(std::shared_ptr<Dol::DomainObject> message, const uint64_t senderID)
    {
        auto module_ptr = std::static_pointer_cast<Dol::Entities::Module>(message);
		
		if(module_ptr == nullptr)
		{
			return;
		}
        //@todo module validation needed here
        if (m_registeredModules.end() != m_registeredModules.find(senderID))
        {
            DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:ReceiveModule: Module with ID [{0:#x}] Reconnecting, something is wrong, erase old memories and ReRegister", senderID);
            auto information = std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::MODULE_DISCONNECTED);
            information->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, m_registeredModules[senderID]);
            Mol::DataType::ObjectReference source{module_ptr->GetID(), m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]};
            information->SetSource(source);
            m_communicator.m_event.Send(information, PROC_ADDRESS::BROADCAST);
            SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::COMMUNICATIONS_STOPPED, senderID, m_moduleTypeToDomainObjectType[static_cast<int> (m_registeredModules[senderID]->GetType())]);
            m_ipv6Addresses.erase(m_registeredModules[senderID]->GetIpv6Address());
            m_registeredModules.erase(senderID);
            m_heartBeatMissCount.erase(senderID);
            // Updaing Code for Persistence of Disablement
            m_moduleData.erase(senderID);
            
        }

        if((senderID == m_sourceID) || (senderID != module_ptr->GetID()))
        {
            DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:ReceiveModule: Invalid Module Sender ID [{0:#x}] moduleID [{0:#x}] ",  senderID,
                    module_ptr->GetID());
            return;
        }

        if(!ValidateModule(module_ptr))
        {
            DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:ReceiveModule: ValidateModule is failed for  Module Sender ID [{0:#x}] moduleID ", senderID, module_ptr->GetID());
            return;
        }
        
        DEBUGPRINT(DEBUG_INFO, "ModuleMonitor:ReceiveModule: Adding module[{:#x}]", senderID);
        m_registeredModules[senderID] = module_ptr;
        m_heartBeatMissCount[senderID] = 0; 

        // Add Module to ATU
        Mol::DeviceUniqueID sourceID(senderID);
        auto moduleID = sourceID.GetModuleID();
        UpdateATU(module_ptr->GetIpv6Address(), moduleID);

        auto registrationConfirmation = std::make_shared<Mol::Monitoring::ModuleRegistration>(Mol::Monitoring::REGISTRATION_CODE::OKAY);
        Mol::DeviceUniqueID destinationAddress(senderID);
        m_communicator.m_monitoring.Send(registrationConfirmation, m_brokerID, destinationAddress.Get());

        // Send module connected event
        auto information = std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::NEW_MODULE_CONNECTED);
        information->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, module_ptr);
        Mol::DataType::ObjectReference source{module_ptr->GetID(), m_moduleTypeToDomainObjectType[static_cast<int> (module_ptr->GetType())]};
        information->SetSource(source);
        //Updating Map for Persistence of Disablement with ObjectId and connected Modules Object
        m_moduleData.emplace(senderID,source);
        DEBUGPRINT(DEBUG_INFO, "ModuleMonitor:ReceiveModule: POD updating ModuleData map with id [{}]",senderID);

        m_communicator.m_event.Send(information, PROC_ADDRESS::BROADCAST);
		m_communicator.m_event.Send(information, PROC_ADDRESS::NETWORK);
        DEBUGPRINT(DEBUG_INFO, "ModuleMonitor:ReceiveModule: MODULE ID [{:#x}] CONNECTED", senderID);    
}

    /**
     *@brief This function loop on existing modules list populated from the systemconfig.xml file and check for each module if it's already registered, if not send NO_REPLY fault to the system
     *@brief @param[in] Void
     *@return Void
     */
    void SendNoReplayFaultForUnavailableModule ()
    {
        // Send NO_REPLY fault for devices not currently available
        for (auto it = m_moduleConfigMap.begin(); it != m_moduleConfigMap.end(); ++it)
        {
            auto index = static_cast<uint32_t> (it->second->GetType());
            if(index >= sizeof(m_moduleTypeToDomainObjectType)/sizeof(Dol::DOMAIN_OBJECT_TYPE))
            {
                DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: SendNoReplayFaultForUnavailableModule() index out of boundary [{}]", index);
                continue;
            }
            if (it->first!=m_sourceID)
            {
                if (CheckCommunicationFault(it->first))
                {
                    DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor:ResetNotification:send NO_REPLY for module with Object type [{0:#x}] ID[{1:#x}]",(int)it->second->GetType(),it->first);
                    SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::NO_REPLY, it->first,m_moduleTypeToDomainObjectType[index]);
                }
            }
            else
            {
                if(CheckInvalidModuleType(m_sourceID,Dol::Entities::Module::MODULE_TYPE::MAINCPU))
                {
                    DEBUGPRINT(DEBUG_ERROR,"ModuleMonitor: Main CPU is in invalid slot ID [{0:#x}]", m_sourceID);
                    SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::CONFIGURATION_MISMATCHED_WITH_HARDWARE, m_sourceID,m_moduleTypeToDomainObjectType[index]);
                }
            }

        }
    }

    /**
     * @brief HeartBeatMonitor function regularly (every 10 seconds) sends 
              heart beat message as broadcast to all modules and applications. 
              This function checks if any module has missed the heart beat for 
              consecutive 3 times i.e. 30 seconds. If the heart beat is stopped 
              it indicates the module is dead or removed 😊. 
              In this case MODULE_DISCONNECTED event message is broadcasted and 
              Communication stopped (COMMUNICATIONS_STOPPED) fault event is raised. 
              The module is removed from the registered list and all maps like 
              heartbeatmisscount, ipv6address. 
              If the heart beat message is not missed for consecutive 3 times, 
              then only an ERROR log is printed to indicate the missed beat. 
     * @param[in] Void
     * @return Void   
     *     
    */
    void HeartBeatMonitor()
    {
        if (m_noReplayTimeout == 2) // 2 x m_monitorIntervalMs ms time elapsed, current implementation is 10000*3(0,1,2) = 30000ms (30s)
        {
            DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:HeartBeatMonitor - SendNoReplayFaultForUnavailableModule()");
            SendNoReplayFaultForUnavailableModule();
            m_noReplayTimeout++;
        }
        else if(m_noReplayTimeout < 2)
        {
            m_noReplayTimeout++;
        }
        else
        {
            //Donothing.
        }
        auto heartBeat = std::make_shared<Mol::Monitoring::HeartBeat>(Mol::Monitoring::HEARTBEAT_CODE::PANEL);
        heartBeat->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, m_ipv6Address);
        Mol::DeviceUniqueID destinationAddress(m_sourceID);
        destinationAddress.SetModuleID(Mol::DeviceUniqueID::MODULE_MULTICAST_ID);
        m_communicator.m_monitoring.Send(heartBeat, m_brokerID, destinationAddress.Get());
		DEBUGPRINT(DEBUG_INFO,"******HEARTBEAT MESSAGE - ModuleMonitor::HeartBeatMonitor heartBeat sent");
		m_command_sent = 0; //Once heart beat is sent wait for next 60 commands

        for(auto& heartBeatMissCount : m_heartBeatMissCount)
        {
            if(heartBeatMissCount.second >= m_maxRetryCount)
            {
                if(m_registeredModules.end() != m_registeredModules.find(heartBeatMissCount.first))
                {
                    DEBUGPRINT(DEBUG_FATAL, "ModuleMonitor:HeartBeatMonitor:MODULE ID [{:#x}] DISCONNECTED.", heartBeatMissCount.first);
//                    UpdateATU(m_registeredModules[heartBeatMissCount.first]->GetIpv6Address());
                    auto information = std::make_shared<Mol::Event::InformationEvent>(Mol::Event::INFORMATION_EVENT_CODE::MODULE_DISCONNECTED);
                    information->AddParameter(Mol::DataType::Parameter::CATALOG::DOMAIN_OBJECT, m_registeredModules[heartBeatMissCount.first]);
                    Mol::DataType::ObjectReference source{heartBeatMissCount.first, m_moduleTypeToDomainObjectType[static_cast<int> (m_registeredModules[heartBeatMissCount.first]->GetType())]};
                    information->SetSource(source);

                    m_communicator.m_event.Send(information, PROC_ADDRESS::BROADCAST);
					m_communicator.m_event.Send(information, PROC_ADDRESS::NETWORK);
                    SendFaultEvent(Mol::Event::FAULT_EVENT_CODE::COMMUNICATION_ERROR_OR_TRANSMISSION_FAULT, heartBeatMissCount.first, m_moduleTypeToDomainObjectType[static_cast<int> (m_registeredModules[heartBeatMissCount.first]->GetType())]);
                    m_ipv6Addresses.erase(m_registeredModules[heartBeatMissCount.first]->GetIpv6Address());
                    m_registeredModules.erase(heartBeatMissCount.first);
                    m_heartBeatMissCount.erase(heartBeatMissCount.first);
                    // Updaing Code for Persistence of Disablement
                    m_moduleData.erase(heartBeatMissCount.first);
                }
            }
            else
            {
                if(heartBeatMissCount.second > 1)
                {
                    DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:HeartBeatMonitor:ModuleID[{0:#x}] Miss count[{1}]", heartBeatMissCount.first,
                        heartBeatMissCount.second);
                }
                ++(heartBeatMissCount.second);
            }
        }
    }


    /*
     *@brief This function broadcasts the information of all the modules registered, 
             as a DOL message.  The broadcasted message is Dol::Entities::Module ptr 
             containing all details of the module. In order to indicate the completion 
             of the data transmission Mol::Response::MODULE_INFO_RESPONSE_CODE::COMPLETED 
             response message is broadcasted.
     *
     *@param[in]    message Received message
     *@param[in]    senderID unique source id of sender
     *@return Void 
     *   
     */
    void ReceiveModuleInfoRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> message, const uint64_t senderID,PROC_ADDRESS procid)
    {
        if(!message)
        {
            DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: null message");
            return;
        }

		DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: Request came from PROC_ADDRESS [{}]",(static_cast<uint16_t>(procid)));//not an eror but display all times
        DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: Sending Connected Modules..number of modules connected are [{}]",m_registeredModules.size());//not an eror but display all times
        if(m_registeredModules.size() == 0)
        {
            DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: No modules connected");//not an eror but display all times
        }
        else
        {
            for(auto &moduleRegistered : m_registeredModules)                         // Send all connected modules
            {
                DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: Sending module [{:#x}]", moduleRegistered.first);//not an eror but display all times
                if(!m_communicator.m_dol.Send(moduleRegistered.second, procid))
                {
                    DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: Failed to send module[{:#x}]", moduleRegistered.first);
                }
				DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: ip address [{}]", moduleRegistered.second->GetIpv6Address());//not an eror but display all times
				DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: module type [{}]", (uint16_t)moduleRegistered.second->GetType());//not an eror but display all times
				DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: module id [{:#x}]", moduleRegistered.second->GetID());//not an eror but display all times
				usleep(1000);
            }
        }
        DEBUGPRINT(DEBUG_ERROR, "ModuleMonitor:ReceiveModuleInfoRequest: Sending module MODULE_INFO_RESPONSE_CODE::COMPLETED");//not an eror but display all times
        auto moduleDetails = std::make_shared<Mol::Response::ModuleInfo>(Mol::Response::MODULE_INFO_RESPONSE_CODE::COMPLETED);
        m_communicator.m_response.Send(moduleDetails, procid);
    }

	 /*
     *@brief This function broadcasts the heartbeat to all modules after 60 commands sent,
             to avoid Module_Disconnected message in case of flood of commands to module
			 and module takes more than 21 seconds to process those commands 
     */
	void ForceHeartBeat(const std::shared_ptr<Platform::Message> message)
	{
		DEBUGPRINT(DEBUG_INFO,"Command received in MM counter[{}]",m_command_sent);
		m_command_sent++;

		if(m_command_sent > 50)
		{
			DEBUGPRINT(DEBUG_INFO,"******HEARTBEAT MESSAGE - ModuleMonitor::ForceHeartBeat heartBeat sent");
			m_command_sent = 0;
			auto heartBeat = std::make_shared<Mol::Monitoring::HeartBeat>(Mol::Monitoring::HEARTBEAT_CODE::PANEL);
            heartBeat->AddParameter(Mol::DataType::Parameter::CATALOG::DESCRIPTION, m_ipv6Address);
            Mol::DeviceUniqueID destinationAddress(m_sourceID);
            destinationAddress.SetModuleID(Mol::DeviceUniqueID::MODULE_MULTICAST_ID);
            m_communicator.m_monitoring.Send(heartBeat, m_brokerID, destinationAddress.Get());
			DEBUGPRINT(DEBUG_INFO,"Heartbeat sent from MM ****************");
		}
	}
	
	uint16_t m_command_sent = 0;
   
};

//const std::string  ModuleMonitor::m_firmwareInfoFile{"/userdata/firmware1/FirmwareInformation.xml"};
}

#endif //MODULE_MONITOR_INCLUDE_H
