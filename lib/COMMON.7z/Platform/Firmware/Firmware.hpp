/*****************************************************************//**
 *
 * @file    Firmware.hpp
 * @brief   Firmware abstraction class
 *
 ********************************************************************/

#ifndef PLATFORM_FIRMWARE_INCLUDE_H
#define PLATFORM_FIRMWARE_INCLUDE_H

#include"Firmware/Firmware.h"
#include"Config/Config.h"

namespace platform
{

class Firmware
{
public:
    /** Default constructor */
    Firmware(): m_nativeFirmware() {};

    /** Default destructor */
    ~Firmware() {};

    //
    void Run()
    {
        m_nativeFirmware.Run();
    }

    void SetFilename(const char * filename)
    {
        m_nativeFirmware.SetFilename(filename);
    }

    uint8_t GetModuleType()
    {
        return m_nativeFirmware.GetModuleType();
    }

    void RebootModule()
    {
        m_nativeFirmware.RebootModule();
    }

    void RevertModule()
    {
        m_nativeFirmware.RevertModule();
    }

    void DeleteFirmware()
    {
        m_nativeFirmware.DeleteFirmware();
    }

private:
    PlatformNative::Firmware m_nativeFirmware;


};

} //platform
#endif //PLATFORM_FIRMWARE_INCLUDE_H
