/*****************************************************************//**
 *
 * @file Looper.hpp
 * @brief Looper runs the event loop until there are no more active and
 * referenced handles or requests.
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_LOOPER_INCLUDE_H
#define PLATFORM_LOOPER_INCLUDE_H

#include "Component/Component.h"
#include"Looper/Looper.h"
#include"Config/Config.h"

namespace Platform
{
/**
 *  @brief Looper is used to hold application, once it starts
 */

class Looper : public Platform::Component
{
public:
    explicit Looper(PROC_ADDRESS address) : m_looper(address) { }
    virtual ~Looper() = default;
    void Init() override
    {
        Platform::Component::Init();
        m_looper.Init();
    }

    bool WaitForTermination()
    {
        return m_looper.WaitForTermination();
    }
    bool Terminate()
    {
        return m_looper.Terminate();
    }

private:
    PlatformNative::Looper m_looper;
};

} //end of Platfrom

#endif //PLATFORM_LOOPER_INCLUDE_H
