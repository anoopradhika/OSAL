/*****************************************************************//**
 *
 * @file Component.cpp
 * @brief All SW Component shall be derived from Component class
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include"Component/Component.h"
#include "Guard/Guard.hpp"

namespace Platform
{
    void Component::Init()
    {
        Platform::State::Init();
    }

    void Component::Prepare()
    {
        Platform::State::Prepare();
    }

    void Component::Start()
    {
        Platform::State::Start();
    }

    void Component::Stop()
    {
        Platform::State::Stop();
    }

    void Component::Shutdown()
    {
        Platform::State::Shutdown();
    }

    void Component::Uninit()
    {
        Platform::State::Uninit();
    }

    void Component::SetRunStatus(GlobalDataType::RunStatus runstatus)
    {
        Platform::Guard gard{m_mutex};
        m_runstatus = runstatus;
    }

    GlobalDataType::RunStatus Component::GetRunStatus()
    {
        Platform::Guard gard{m_mutex};
        return m_runstatus;
    }

}
