/*****************************************************************//**
 *
 * @file Component.h
 * @brief All SW Component shall be derived from Component class
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_COMPONET_INCLUDE_H
#define PLATFORM_COMPONET_INCLUDE_H

#include "State/State.hpp"
#include "Communicator/Communicator.hpp"
#include "GlobalDataType/Runstatus.h"
#include "Mutex/Mutex.hpp"


namespace Platform
{

class Component: public Platform::State
{
public:
    Component() = default;
    virtual ~Component() = default;
    virtual void Init() override;
    virtual void Prepare() override;
    virtual void Start() override;
    virtual void Stop() override;
    virtual void Shutdown() override;
    virtual void Uninit() override;

    void SetRunStatus(GlobalDataType::RunStatus runstatus);

    GlobalDataType::RunStatus GetRunStatus();

protected:
    Platform::Communicator m_communicator;

private:
    GlobalDataType::RunStatus m_runstatus = GlobalDataType::RunStatus::END_OF_LIST;
    Platform::Mutex<> m_mutex{};

};

} //end of Platform

#endif //PLATFORM_COMPONET_INCLUDE_H
