/*****************************************************************//**
 *
 * @file ComponentManager.cpp
 * @brief Application uses ComponentManager for Component Management
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include "ComponentManager/ComponentManager.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

namespace Platform
{

void ComponentManager::InitAllComponents()
{
    ForAllComponentsDo( [](std::shared_ptr<Platform::Component> ptr){ ptr->Init();} );
}


void ComponentManager::PrepareAllComponents()
{
    ForAllComponentsDo( [](std::shared_ptr<Platform::Component> ptr){ ptr->Prepare();} );
}

void ComponentManager::StartAllComponents()
{
    ForAllComponentsDo( [](std::shared_ptr<Platform::Component> ptr){ ptr->Start();} );
}

void ComponentManager::StopAllComponents()
{
    ForAllComponentsDo( [](std::shared_ptr<Platform::Component> ptr){ ptr->Stop();} );
}

void ComponentManager::ShutdownAllComponents()
{
    ForAllComponentsDo( [](std::shared_ptr<Platform::Component> ptr){ ptr->Shutdown();} );
}

void ComponentManager::UninitAllComponents()
{
    ForAllComponentsDo( [](std::shared_ptr<Platform::Component> ptr){ ptr->Uninit();} );
}

void ComponentManager::AddComponent(std::shared_ptr<Platform::Component>& component)
{
    Platform::Guard gard{m_mutex};
    m_components.push_back(component);
}

bool ComponentManager::IsStatusGood()
{
    Platform::Guard gard{m_mutex};

    for (std::shared_ptr<Platform::Component> component : m_components)
    {
        if( GlobalDataType::RunStatus::NOT_OKAY == component->GetRunStatus())
        {
            return false;

        }
    }
    return true;
}

} //end of Platform
