/*****************************************************************//**
 *
 * @file ComponentManager.h
 * @brief Application uses ComponentManager for Component Management
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_COMPONENT_MANAGER_INCLUDE_H
#define PLATFORM_COMPONENT_MANAGER_INCLUDE_H

#include "CommonDef.h"
#include "Guard/Guard.hpp"
#include "Component/Component.h"

#include <memory>

namespace Platform
{

/** @class ComponentManager
* @brief ComponentManager provides thread safe services for
* @li run diffrent stages of component
* @li add component
* @li component status verification
*/


class ComponentManager
{
public:
    ComponentManager() = default;

    virtual ~ComponentManager() = default;

    void InitAllComponents() ;

    void PrepareAllComponents();

    void StartAllComponents();

    void StopAllComponents();

    void ShutdownAllComponents();

    void UninitAllComponents();

    void AddComponent(std::shared_ptr<Platform::Component>& component);

    bool IsStatusGood();

private:
    template < typename T >
    void ForAllComponentsDo(T func)
    {
        Platform::Guard guard{m_mutex};
        for (auto& component : m_components)
        {
            func( component );
        }

    }
    std::vector<std::shared_ptr<Platform::Component>> m_components;

    Platform::Mutex<> m_mutex{};
};

} //end of Platform

#endif // PLATFORM_COMPONENT_MANAGER_INCLUDE_H
