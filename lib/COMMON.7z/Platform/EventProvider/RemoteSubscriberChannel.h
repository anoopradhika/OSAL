/**********************************************************************************
 * @file RemoteCommsModule .h
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#ifndef PLATFORM_MOL_REMOTE_CHANNEL_H
#define PLATFORM_MOL_REMOTE_CHANNEL_H

#include "Mol/DataType/ObjectReference.h"
#include "SubscriberListHelper/SubscriberListHelper.h"
#include "Component/Component.h"
#include "Mol/Requests/ActiveEventRequest.h"
#include "Mol/Responses/ActiveEventResponse.h"
#include "EventUnpacker/EventUnpacker.h"
#include "GlobalDataType/Error.h"
#include "Timer/Timer.hpp"
#include "Mol/Events/EventTypeList.h"
#include <chrono>
#include <queue>

#define MAX_TIMEOUT 1000
#define MAX_EVENTS_QUEUE_SIZE (uint64_t)2000
#define noop (void)0
namespace Platform
{
/**
 * @brief  RemoteSubscriberChannel main responsibility is to
 * represent remote channels as a separate entities even if for the moment they are handled by module.
 * it is handling all requests and response to/from ActiveEventList and providing the state machine for remote subscriber
 */
class RemoteSubscriberChannel
{
public:

    RemoteSubscriberChannel(Mol::DataType::ObjectReference& channelID, std::shared_ptr<Platform::Communicator> communicator) :
            m_channelSenderID(channelID), m_communicator(communicator)
    {
        if(Mol::DeviceUniqueID{m_channelSenderID.GetObjectId()}.GetModuleID() == 0)
        {
            throw ERROR::INVALID_PARAMETER;
        }
        if(m_communicator == nullptr)
        {
            throw ERROR::NULL_PARAMETER;
        }
        m_communicator->m_response.Subscribe < Mol::Response::ActiveEventResponse > (Mol::Response::RESPONSE_CATEGORY::ACTIVE_EVENT_RESPONSE);
        m_communicator->m_response.getService(Mol::Response::RESPONSE_CATEGORY::ACTIVE_EVENT_RESPONSE)->Connect(this, &RemoteSubscriberChannel::ActiveEventGetEvent);
        Platform::Notifier notifier;
        notifier.Connect(this,&RemoteSubscriberChannel::UpdateEventsTimer);
        m_timer = Platform::Timer<>(MAX_TIMEOUT,GlobalDataType::Timer::AlarmType::PERIODIC,notifier);
        m_timer.Start();
    }

    ~RemoteSubscriberChannel()
    {
        m_timer.Stop();
        m_timer.Shutdown();
        while(!m_eventsQueue.empty())
        {
          m_eventsQueue.pop();
        }
    }

    /**
     * @brief ServiceRequest called by EventProviderService to service the incoming request,
     * it is first do some sanity checks, and then depending on the request it also
     * may send a request to EventLog or ActiveEventList to get the next event.
     *
     * @param request: the request to execute.
     *
     */
    void ServiceRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request)
    {
        auto commsRequest = std::static_pointer_cast < Mol::Request::EventProviderService > (request);
        if(commsRequest == nullptr)
        {
            throw ERROR::NULL_PARAMETER;
        }
        if(m_channelSenderID != commsRequest->GetSourceTarget())
        {
            throw ERROR::INVALID_DEVICE_ID;
        }
        m_requestCode = commsRequest->GetRequestCode();
        DEBUGPRINT(DEBUG_INFO, "EventProvider: ServiceRequest m_subscriberID[{0:#x}] and m_channelSenderID[{1:#x}]", m_channelSenderID.GetDNM64Bit(), m_channelSenderID.GetObjectId());
        m_requestInProgress = true;

        if (m_requestCode != Mol::Request::EVENT_PROVIDER_SERVICE_CODE::START_COMMUNICATION)
        {
            if (m_currentCommunicationStep == COMMUNICATION_STEP::START_COMMUNICATION)
            {
                try
                {
                    DEBUGPRINT(DEBUG_INFO, "EventProvider : Comms not started yet [{0}]",(int)m_requestCode);
                    SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::COMMUNICATION_NOT_STARTED);
                } catch (Platform::ERROR& error)
                {
                    DEBUGPRINT(DEBUG_INFO, "EventProvider : Cannot send COMMUNICATION_NOT_STARTED error");
                }
                // Comms has not been started, just exit
                return;
            }
        }

        switch (m_requestCode)
        {
        case Mol::Request::EVENT_PROVIDER_SERVICE_CODE::START_COMMUNICATION:
            if (m_currentCommunicationStep == COMMUNICATION_STEP::START_COMMUNICATION)
            {
                ClearParameters();
            }
            try
            {
                SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::COMMUNICATION_STARTED);
                m_currentCommunicationStep = COMMUNICATION_STEP::COMMUNICATION_STARTED;
            }catch(Platform::ERROR& error)
            {
                DEBUGPRINT(DEBUG_INFO, "EventProvider : Cannot send COMMUNICATION_STARTED");
            }
            break;
        case Mol::Request::EVENT_PROVIDER_SERVICE_CODE::SYNC:
            if(!m_communicator->m_request.Send(CreateActiveEventLogGetAllEventRequest(), PROC_ADDRESS::EVENT_PROVIDERAPP))
            {
                DEBUGPRINT(DEBUG_INFO, "EventProvider : ActiveEventGetFirstEvent send to ACTIVE EVENTLIST APP failed ");
                SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::SYNC_FAILURE);
                m_currentCommunicationStep = COMMUNICATION_STEP::COMMUNICATION_STARTED;
                throw ERROR::SEND_ERROR;
            }
            else
            {
                SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::SYNC_SUCCESS);
                m_currentCommunicationStep = COMMUNICATION_STEP::ACTIVE_EVENT_LIST;
            }
            break;
        case Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT:
            SendBufferedEvents();
            break;
        default:
            try
            {
                SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::NOT_SUPPORTED);
            } catch (Platform::ERROR& error)
            {
                DEBUGPRINT(DEBUG_INFO, "EventProvider : Request code not supported [{0}]",(int)m_requestCode);
            }
            break;
        }
    }

    /**
     * @brief   BufferNewEvent callback is called if a new event is available so we can notify FAT/FB and comms module.
     * @param 1 - not used
     * @param 2 - not used
     */
    void BufferNewEvent(std::shared_ptr<std::string> event, const uint64_t senderID)
    {
        if(m_currentCommunicationStep != COMMUNICATION_STEP::BUFFERED_EVENTS)
        {
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel : BufferNewEvent() ignore if it is not COMMUNICATION_STEP::BUFFERED_EVENTS");
            return;
        }
        if(m_requestCode != Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT)
        {
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel : BufferNewEvent() ignore if it is not Mol::Request::EVENT_PROVIDER_SERVICE_CODE::GET_EVENT");
            return;
        }
        m_newEventAvailebel = true;
        BufferEvent(event);
    }
    /**
     * @brief Less than operator overriding
     *
     * @param otherObject  The ObjectReference to compare with.
     * @return @c true if this is lesser than otherObject.
     */
    bool operator <(const std::shared_ptr<RemoteSubscriberChannel> otherObject) const
    {
        if (m_channelSenderID.GetObjectType() < otherObject->m_channelSenderID.GetObjectType())
        {
            return true;
        }
        else if (m_channelSenderID.GetObjectType() == otherObject->m_channelSenderID.GetObjectType())
        {
            return (m_channelSenderID.GetObjectId() < otherObject->m_channelSenderID.GetObjectId());
        }
        else
        {
            return false;
        }
    }

    /**
     * @brief getChannelSenderId return the current channel ID
     */
    const Mol::DataType::ObjectReference& getChannelSenderId() const
    {
        return m_channelSenderID;
    }

protected:

    /**
     * @brief Enumeration holding different possible communication steps
     */
    enum class COMMUNICATION_STEP : uint8_t
    {
        ACTIVE_EVENT_LIST = 0,          //start sending form ActiveEventList
        BUFFERED_EVENTS,                      //sending next event from EventLog buffered
        START_COMMUNICATION,             //communication is not started
        COMMUNICATION_STARTED
    };

    /**
     * @brief SendReponse used locally to simplify sending messages to external modules passing throw CMCAPP by crating the
     *
     * Mol::Response::EventProviderServiceResponse object message to be sent to locally saved channel ID.
     *
     * @param code  is the response code (COMMUNICATION_STARTED, EVENT_SENT, ...)
     *
     * @param message  the string message received from EventLog or ActiveEventListe
     */
    void SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE code, std::shared_ptr<std::string> message = std::shared_ptr<std::string>{})
    {
        auto response = std::make_shared < Mol::Response::EventProviderServiceResponse > (code);
        response->SetResponseTarget(m_channelSenderID);
        response->SetMessage(message.get()?*message.get():"");
        if(!m_communicator->m_response.Send(response, PROC_ADDRESS::CMCAPP, m_channelSenderID.GetDNM64Bit()))
        {
            throw ERROR::SEND_ERROR;
        }
        DEBUGPRINT(DEBUG_INFO, "EventProvider: Send response to subscriber ID[{0:#x}] and Channel target ID[{1:#x}]", m_channelSenderID.GetDNM64Bit(), m_channelSenderID.GetObjectId());
        try
        {
            if(message.get())
            {
                PrintResponse(*message.get());
            }
        } catch (Platform::ERROR& error) {
            DEBUGPRINT(DEBUG_ERROR, "PrintResponse :Exception error[{}]",(int)error);
			noop;	//To fix sonarqube vulnerability
        }
        m_requestInProgress = false;

    }
    /*this is a work around because the platform Object module communicator is not handling try catch exceptions
     *later when this catching part in Object module communicator is implemented this function should be removed
     */
    void ActiveEventGetEventValidateParameters(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> messageBase)
    {
        if (!messageBase)
        {
            DEBUGPRINT(DEBUG_ERROR, "EventProvider :ActiveEventListResponseReceived nullptr message");
            throw ERROR::NULL_PARAMETER;
        }

        auto response = std::static_pointer_cast < Mol::Response::ActiveEventResponse > (messageBase);
        if (Mol::ActiveEventQueryType::GET_ALL_EVENT != response->GetQueryType())
        {
            throw ERROR::INVALID_PARAMETER;
        }

        if (m_channelSenderID != response->GetResponseTarget())
        {
            DEBUGPRINT(DEBUG_INFO, "EventProvider : ActiveEventGetFirstEvent ResponseTarget ID[{0:#x}] is not sent to us ID[{1:#x}]", static_cast<uint64_t>(response->GetResponseTarget().GetObjectId()), m_channelSenderID.GetDNM64Bit());
            throw ERROR::INVALID_DEVICE_ID;
        }
    }

    /**
     * @brief ActiveEventGetNextEvent is the callback method used to receive the Mol::ActiveEventQueryType::GET_ALL_EVENT response,
     * it validate the parameters and get called for all events present in ActiveEventList and if the response is success it buffered the event.
     *
     * @param messageBase  is the response base type Mol::Response::RESPONSE_CATEGORY to by type casted to Mol::Response::ActiveEventResponse and check the result.
     *
     * @param senderID  the EventProvider Application ID, not used in this method
     */
    void ActiveEventGetEvent(std::shared_ptr<Mol::Message<Mol::Response::RESPONSE_CATEGORY>> messageBase, uint64_t senderID)
    {
        try
        {
            ActiveEventGetEventValidateParameters(messageBase);
        } catch (ERROR e)
        {
            return;
        }
        auto response = std::static_pointer_cast < Mol::Response::ActiveEventResponse > (messageBase);
        DEBUGPRINT(DEBUG_INFO, "EventProvider : ActiveEventGetNextEvent ResponseTarget ID[{:#x}]", m_channelSenderID.GetDNM64Bit());
        if (response->GetStatus() == Mol::Response::ActiveEventQueryStatus::RESPONSE_SUCCESS)
        {
            Dol::Translator<Mol::Message<Mol::Event::EVENT_CATEGORY>,Mol::Message<Mol::Event::EVENT_CATEGORY>> eventTranslator;
            BufferEvent(std::make_shared<std::string>(response->GetData()));
            auto event = eventTranslator.StringToDomainObjectMessage(response->GetData());
        }
        else//in all other cases it should be prepared for reading from eventlog
        {
            DEBUGPRINT(DEBUG_INFO, "EventProvider : ActiveEventListResponseReceived REQUESTED_DATA_LAST_ENTRY");
            m_currentCommunicationStep = COMMUNICATION_STEP::BUFFERED_EVENTS;
        }

    }

    /**
     * @brief PrintResponse is used internally to unpack the base message to a concrete Event message using the EventUnpacker class helper.
     *
     * @param message  the serialized message to unpack and print.
     */
    void PrintResponse(const std::string& message)
    {
        Dol::Translator<Mol::Message<Mol::Event::EVENT_CATEGORY>,Mol::Message<Mol::Event::EVENT_CATEGORY>> eventTranslator;
        auto event = eventTranslator.StringToDomainObjectMessage(message);
        if (event != nullptr)
        {
            Mol::Event::EVENT_CATEGORY eventType = event->GetObjectType();
            auto realEvent = EventUnpacker(message, eventType).GetEvent<Mol::Event::AlarmEvent>();
            if (realEvent != nullptr)
            {
                DEBUGPRINT(DEBUG_INFO, "EventProvider: "
                        "event->GetEventCode()[{0}] "
                        "alarm->GetEventApplication()[{1}], "
                        "alarm->GetEventType()[{2}] "
                        "source id [{3:#x}, source type [{4}]]", (int) realEvent->GetEventCode(), (int) realEvent->GetEventApplication(), (int) realEvent->GetObjectType(), realEvent->GetSource().GetObjectId(), (int) realEvent->GetSource().GetObjectType());
            }
            else
            {
                DEBUGPRINT(DEBUG_ERROR, "Failed to deserialize alarm event EventUnpacker.GetEvent() nullptr");
                throw ERROR::NULL_PARAMETER;
            }
        }
        else
        {
            DEBUGPRINT(DEBUG_ERROR, "Failed to deserialize null alarm event.");
            throw ERROR::NULL_PARAMETER;
        }
    }

    /**
     * @brief ClearParameters is used internally to reinitialize the communication step parameters when the subscriber resends a START_COMMUNICATION.
     */
    void ClearParameters()
    {
        m_currentCommunicationStep = COMMUNICATION_STEP::START_COMMUNICATION;
        while(!m_eventsQueue.empty())
        {
          m_eventsQueue.pop();
        }
        m_newEventAvailebel = false;
        DEBUGPRINT(DEBUG_INFO, "RemoteCommsModule ClearParameters");
    }

    /**
     * @brief CreateActiveEventLogGetFirsEventRequest is a in place crate and return a request of type Mol::Request::ActiveEventRequest
     * requesting for the Mol::ActiveEventQueryType::GET_FIRST_EVENT.
     * @return m_activeEventListRequest of type Mol::Request::ActiveEventRequest
     */
    std::shared_ptr<Mol::Request::ActiveEventRequest> CreateActiveEventLogGetAllEventRequest()
    {
        auto filter = Mol::CompleteEventCode { Mol::Event::EVENT_APPLICATION::END_OF_LIST, Mol::Event::EVENT_CATEGORY::END_OF_LIST, 0 };
        m_activeEventListRequest = std::make_shared < Mol::Request::ActiveEventRequest > (Mol::ActiveEventQueryType::GET_ALL_EVENT, filter);
        m_activeEventListRequest->SetSourceTarget(m_channelSenderID);
        m_activeEventListRequest->SetEndCount(0);
        DEBUGPRINT(DEBUG_INFO, "**********RemoteCommsModule CreateActiveEventLogGetMessageCountRequest");
        return m_activeEventListRequest;
    }

    /**
     * @brief   Timer call back called each 1s to reduce the frequency sending new events notification to module.
     */
    void UpdateEventsTimer()
    {
        if(!m_requestInProgress && m_newEventAvailebel)
        {
            //update FAT-FBF/comms module
            try
            {
                SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::NEW_EVENT);
                DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel : DoSendNewEventNotification() send NEW_EVENT to module");
            }
            catch (Platform::ERROR &error)
            {
                DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel : DoSendNewEventNotification send to CMCAPP failed error[{}]", (int) error);
            }
            m_newEventAvailebel = false;
        }
    }

    /**
     * @brief   Read one event from the queue if available and send it to the subscriber channel, if not send END_OF_LIST code
     */
    void SendBufferedEvents()
    {
        if (!m_eventsQueue.empty())
        {
            auto event = m_eventsQueue.front();
            try
            {
                SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::EVENT_SENT, event);
            }catch (Platform::ERROR& error)
            {
                DEBUGPRINT(DEBUG_INFO, "EventProvider : SendBufferedEvents send to CMCAPP failed error[{}]",(int)error);
            }
            m_eventsQueue.pop();
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel: SendBufferedEvents() reading from queue size [{0}] elements", m_eventsQueue.size());
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel: SendBufferedEvents() debug reference count for event address [{0}]--> [{1}]", event,event.use_count());
            //DebugSentEvent(event);
        }
        else
        {
            SendReponse(Mol::Response::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST);
            DEBUGPRINT(DEBUG_INFO, "EventProvider : SendBufferedEvents empty queue");
        }
    }

    /**
     * @brief buffer the provided event if the queue is still not full yet MAX_EVENTS_QUEUE_SIZE
     * @param event: is the event to be buffered
     */
    void BufferEvent(std::shared_ptr<std::string> event)
    {
        if((uint64_t)m_eventsQueue.size() < MAX_EVENTS_QUEUE_SIZE && nullptr != event)
        {
            m_eventsQueue.push(event);
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel: BufferEvent(), queuing[{}] elements ", m_eventsQueue.size());
        }
        else
        {
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel: BufferEvent(), max queue reached [{}] elements ", MAX_EVENTS_QUEUE_SIZE);
        }
    }

     /**
     * @brief m_currentCommunicationStep save the current communication step START_COMMUNICATION, read from EVENT_LOG or read from ACTIVE_EVENT_LIST.
     */
    COMMUNICATION_STEP m_currentCommunicationStep = COMMUNICATION_STEP::START_COMMUNICATION;
    /**
     * @brief m_channelSenderID save the chnnel ID and is used as a reference while comparing RemoteSubscriberChannel Objects.
     */
    Mol::DataType::ObjectReference m_channelSenderID = { 0, Dol::DOMAIN_OBJECT_TYPE::INVALID };
    /**
     * @brief m_requestCode to be replaced by a temporary variable
     */
    Mol::Request::EVENT_PROVIDER_SERVICE_CODE m_requestCode = Mol::Request::EVENT_PROVIDER_SERVICE_CODE::END_OF_LIST;
    /**
     * @brief m_activeEventListRequest the request used to request form ActiveEventListe.
     */
    std::shared_ptr<Mol::Request::ActiveEventRequest> m_activeEventListRequest = { };
    /**
     * @brief m_communicator is passed by EventProviderService to send messages to CMCAPP.
     */
    std::shared_ptr<Platform::Communicator> m_communicator = { };
    /**
     * @brief timer used to notify the external subscriber channel of new event available.
     */
    Platform::Timer<> m_timer;
    /**
     * @brief m_requestInProgress is used to check if the current request is still in progress.
     */
    bool m_requestInProgress = false;
    /**
     * @brief m_newEventAvailebel is to be set when new event is sent to the queue, and in timer event it will be checked.
     */
    bool m_newEventAvailebel = false;
    /**
     * @brief m_eventsQueue is main queue to enqueue all incoming events, first ActiveEventList are queued then each new event in the system is queued.
     */
    std::queue<std::shared_ptr<std::string>> m_eventsQueue;
};

}
#endif //PLATFORM_MOL_REMOTE_CHANNEL_H
