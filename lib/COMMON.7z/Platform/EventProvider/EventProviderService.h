/**********************************************************************************
 * @file EventProviderService .h
 * @copyright Copyright 2019 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#ifndef PLATFORM_MOL_EVENT_PROVIDER_H
#define PLATFORM_MOL_EVENT_PROVIDER_H

#include "Mol/Responses/EventProviderServiceResponse.h"
#include "Component/Component.h"
#include "Mol/Requests/EventProviderService.h"
#include "EventProvider/RemoteSubscriberChannel.h"
#include "Mol/Commands/Reset.h"
#include "Mol/Helper/ResetTypes.h"
#include "GlobalDataType/Error.h"
#include "Mol/Events/EventTypeList.h"

namespace Platform
{

/**
 * @brief    EventProviderService is a platform service component started by EventProvider Application, main role is listen to FAT/FBF and comms modules to subscribe to it events providing service and respond to their requests.
 *
 * EventProviderService use tow MOL interface to handle request/response coming from/to subscriber using CMCAPP:
 *
 * Mol::Request::EventProviderService: is the request interface
 *
 * Mol::Response::EventProviderServiceResponse: is the response interface used to encapsulate the response to be sent to FAT/FBF and comms modules
 *
 * EventProviderService is also handling Reset command coming form panel and generate a Reset Event and send it to EventLog in the goal to help external modules to have sequential events and clear operation
 *
 * Note: current EventProviderService is ignoring requests coming from external backplan
 *
 */
/**
@startuml
//
//class Platform::EventProviderService {
//m_panelId
// +EventProviderService()
// +~EventProviderService()
// +Prepare()
// #EventProviderServiceRequest()
// #CommandReceived()
// #SendResetEvent()
//}
//Platform::Component <|--  Platform::EventProviderService
//Platform::EventProviderService "1" *-- "many" RemoteSubscriberChannel : list of channels
//
//@enduml
 *
 */

class EventProviderService: public Platform::Component
{
public:
    /**
     * @brief    Construct EventProviderService by passing:
     * \param panelId: as the local main panel ID
     */
   explicit EventProviderService(uint64_t panelId) :
            m_panelId { panelId }
    {
        if(Mol::DeviceUniqueID{panelId}.GetModuleID() == 0)
        {
            throw ERROR::INVALID_PARAMETER;
        }
    }

    /**
     * @brief    Prepare EventProviderService to :
     *
     * - Crate the service to be used by FAT/FBF and comms modules and passe the servicing callback method to the platform communication layer
     * - Subscribe to Mol::Command::Reset to receive Reset command coming from panel
     */
    void Prepare() override
    {
        Platform::Component::Prepare();

        m_communicator.m_request.Subscribe<Mol::Request::EventProviderService>(Mol::Request::REQUEST_CATEGORY::EVENT_PROVIDER_SERVICE_REQUEST);
        m_communicator.m_request.getService(Mol::Request::REQUEST_CATEGORY::EVENT_PROVIDER_SERVICE_REQUEST)->Connect(this, &EventProviderService::EventProviderServiceRequest);
        RegisterForNeededEvents();
        DEBUGPRINT(DEBUG_INFO, "EventProvider started up and running m_panelId = {:#x}", m_panelId);
    }

    ~EventProviderService() override = default;
protected:

    /**
     * @brief    service request method callback main function is to receive requests coming from modules, execute some sanity checks,
     * and crate an instance of RemoteSubscriberChannel if it is the first time and invoke its ServiceRequest method,
     * or if it is already in the list it directly invoice its ServiceRequest method
     * \param request: is the request of type Mol::Request::EventProviderService sent by the module, values may be START_COMMUNICATION, or GET_EVENT
     * \param commsSenderID: is the requester module point ID.
     * Note:  EventProviderService is handling subscriber by their channels IDs and not by the requester module point ID, channels ID is unpacked inside the request its self
     * by this way it is projecting to the future if the panel will directly deal with final IOTs end point without passing by modules
     */
    void EventProviderServiceRequest(std::shared_ptr<Mol::Message<Mol::Request::REQUEST_CATEGORY>> request, const uint64_t commsSenderID)
    {
        DEBUGPRINT(DEBUG_INFO, "EventProvider: EventProviderServiceRequest called");
        if(request == nullptr)
        {
            throw ERROR::NULL_PARAMETER;
        }
        auto commsRequest = std::static_pointer_cast < Mol::Request::EventProviderService > (request);
        if ((Mol::DeviceUniqueID { m_panelId }.GetDomainID() != Mol::DeviceUniqueID { commsSenderID }.GetDomainID()) || (Mol::DeviceUniqueID { m_panelId }.GetNodeID() != Mol::DeviceUniqueID { commsSenderID }.GetNodeID()))
        {
            DEBUGPRINT(DEBUG_INFO, "EventProvider: EventProviderServiceRequestTest not same  DomainID[{0:#x}] or NodeID[{1:#x}]", Mol::DeviceUniqueID { commsSenderID }.GetDomainID(), Mol::DeviceUniqueID { commsSenderID }.GetNodeID());
            throw ERROR::INVALID_DEVICE_ID;
        }
        auto reference = commsRequest->GetSourceTarget();
        reference.PrepareDeviceUniqueID();
        // @todo searching by SourceTarget is don in this way for the moment but we can later spend some times to incorporate it as comparator.
        auto serach = [&reference](auto subscriberChannelObject)->bool
        {
            if(subscriberChannelObject != nullptr)
            {
                return ( subscriberChannelObject->getChannelSenderId() == reference );
            }
            else
            {
                return false;
            }
        };
        auto comms = std::find_if(m_commsSubscriber.begin(), m_commsSubscriber.end(), serach);
        try // RemoteSubscriberChannel() and ServiceRequest() may throw an Exception
        {
            if (comms != m_commsSubscriber.end())
            {
                DEBUGPRINT(DEBUG_INFO, "EventProvider: EventProviderServiceRequest ID[{:#x}] already carted lets service the request", commsSenderID);
                (*comms)->ServiceRequest(request);
            }
            else
            {

                auto subscriber = m_commsSubscriber.emplace(std::make_shared < RemoteSubscriberChannel > (reference, std::make_shared < Platform::Communicator > (m_communicator)));
                if (subscriber.second)
                {
                    (*subscriber.first)->ServiceRequest(request);
                }
                else
                {
                    DEBUGPRINT(DEBUG_ERROR, "EventProvider: unexpected error cannot emplace new objects in std::set!");
                }

            }
        } catch (Platform::ERROR& error)
        {
            DEBUGPRINT(DEBUG_ERROR, "EventProvider: EventProviderServiceRequest Exception raised error[{}]", (int) error);
            return ;
        }
    }

    /**
     * @brief   register for all the events needed by FAT/FBF and comms modules
     */
    void RegisterForNeededEvents()
    {
        m_communicator.m_event.Subscribe<Mol::Event::AlarmEvent>(Mol::Event::EVENT_CATEGORY::ALARM);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::ALARM)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::AlarmEvent>);
        m_communicator.m_event.Subscribe<Mol::Event::DisablementEvent>(Mol::Event::EVENT_CATEGORY::DISABLEMENT);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::DISABLEMENT)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::DisablementEvent>);
        m_communicator.m_event.Subscribe<Mol::Event::FaultEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::TROUBLE)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::FaultEvent>);
        m_communicator.m_event.Subscribe<Mol::Event::FaultClearedEvent>(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::TROUBLE_CLEARED)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::FaultClearedEvent>);
        m_communicator.m_event.Subscribe<Mol::Event::FunctionDisable>(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::FUNCTION_DISABLE)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::FunctionDisable>);
        m_communicator.m_event.Subscribe<Mol::Event::FunctionEnable>(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::FUNCTION_ENABLE)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::FunctionEnable>);
        m_communicator.m_event.Subscribe<Mol::Event::WarningEvent>(Mol::Event::EVENT_CATEGORY::WARNING);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::WARNING)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::WarningEvent>);
        m_communicator.m_event.Subscribe<Mol::Event::Reset>(Mol::Event::EVENT_CATEGORY::RESET);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::RESET)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::Reset>);
        m_communicator.m_event.Subscribe<Mol::Event::TestOperationEvent>(Mol::Event::EVENT_CATEGORY::TEST);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::TEST)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::TestOperationEvent>);
        RegisterForCloud();
    }

    /**
     * @brief   register for the rest of the events needed by the cloud
     * @NOTE this is not the correct solution! we need to distinguish the subscriber, if it is the legacy Repeater panel then the list should be only RegisterForNeededEvents() function,
     * if it is the cloud then register for all the possible events
     */
    void RegisterForCloud()
    {
        m_communicator.m_event.Subscribe<Mol::Event::InformationEvent>(Mol::Event::EVENT_CATEGORY::INFORMATION);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::INFORMATION)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::InformationEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::UserOperationEvent>(Mol::Event::EVENT_CATEGORY::USER_OPERATION);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::USER_OPERATION)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::UserOperationEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::ActivationEvent>(Mol::Event::EVENT_CATEGORY::ACTIVATION);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::ACTIVATION)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::ActivationEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::AccessEvent>(Mol::Event::EVENT_CATEGORY::USER_ACCESS);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::USER_ACCESS)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::AccessEvent>);

        //m_communicator.m_event.Subscribe<Mol::Event::DelayStartedEvent>(Mol::Event::EVENT_CATEGORY::DELAY_STARTED_EVENT);
        //m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::DELAY_STARTED_EVENT)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::DelayStartedEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::InputChangeEvent>(Mol::Event::EVENT_CATEGORY::INPUT_CHANGE_IN_STATUS);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::INPUT_CHANGE_IN_STATUS)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::InputChangeEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::MaintenanceEvent>(Mol::Event::EVENT_CATEGORY::MAINTENANCE);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::MAINTENANCE)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::MaintenanceEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::RemoteLedEvent>(Mol::Event::EVENT_CATEGORY::REMOTE_LED);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::REMOTE_LED)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::RemoteLedEvent>);

        m_communicator.m_event.Subscribe<Mol::Event::UserRole>(Mol::Event::EVENT_CATEGORY::USER_ROLE);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::USER_ROLE)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::UserRole>);

        m_communicator.m_event.Subscribe<Mol::Event::WarningEvent>(Mol::Event::EVENT_CATEGORY::WARNING);
        m_communicator.m_event.getService(Mol::Event::EVENT_CATEGORY::WARNING)->Connect(this, &EventProviderService::BufferNewEvent<Mol::Event::WarningEvent>);
    }

    /**
     * @brief   BufferNewEvent callback is called if a new event is available so we can notify FAT/FB and comms module.
     * @param event - event to be buffered
     * @param senderID - Module ID is not used, instead channel ID is used internally in each channel object
     */
    template<typename EVENT_TYPE>
    void BufferNewEvent(std::shared_ptr<Mol::Message<Mol::Event::EVENT_CATEGORY>> event, const uint64_t senderID)
    {
        auto validevent = std::static_pointer_cast < EVENT_TYPE > (event);
        if(nullptr == validevent)
        {
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel : BufferNewEvent() Invalid Event 1!!");
            return;
        }
        Dol::Translator<EVENT_TYPE, EVENT_TYPE> eventTranslator;
        auto message = eventTranslator.DomainObjectMessageToString(validevent);
        if(nullptr == validevent)
        {
            DEBUGPRINT(DEBUG_INFO, "RemoteSubscriberChannel : BufferNewEvent() Invalid Event 2!!");
            return;
        }
        //making the new incoming event shared between all channels to optimize the memory usage
        auto sameEvent = std::make_shared < std::string > (message);
        for(auto m_commsSub : m_commsSubscriber) {
            m_commsSub->BufferNewEvent(sameEvent, senderID);
        }
    }

    /**
     * @brief A set list of the channel subscribers
     */
    std::set<std::shared_ptr<RemoteSubscriberChannel>> m_commsSubscriber;
    /**
     * @brief the panel ID passed form EventProvider class and used locally to check if the request is coming from the same back plan board
     */
    uint64_t m_panelId;
};

}
#endif //PLATFORM_MOL_EVENT_ROUTER_H
