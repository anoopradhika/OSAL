/*****************************************************************//**
 *
 * @file    Semaphore.h
 * @brief   Semaphore class provides a wrapper library for using Semaphore
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef PLATFORM_FREERTOS_SEMAPHORE_H
#define PLATFORM_FREERTOS_SEMAPHORE_H

#include "FreeRTOS.h"
#include "semphr.h"

namespace PlatformFreeRTOS
{

/**
 * @brief Semaphore class
 *
 * Provides wrapper class for using Semaphore functionality.
 */
class Semaphore
{
public:
    /* Member initialization */
    Semaphore() = default;

    /* Default destructor */
    virtual ~Semaphore();

    /**
        Used for counting events
        Event handler will 'give' the semaphore each time an event occurs
        A handler task will 'take' the semaphore each time it process an event
        count value = events that have occurred - events that have been processed.
        It is desirable for the initial count to be zero.

        Used for resource management
        The count value indicates the number of resources available.
        When the count value reaches zero there are no free resources
        Task obtains the control of a resource by decrementing the semaphore count (take the semaphore)
        When the task finishes with the resource it 'gives' the semaphore back (increment the semaphore count)
        It is desirable for the initial count to be equal to the maximum count value.

    */
    bool Create(UBaseType_t maxCount, UBaseType_t initialCount);

    /**
        Waits until the requested thread got the mutex
    */
    bool Lock(UBaseType_t count);

    /**
        Releases the lock on the semaphore
    */
    void Unlock();

    /**
        Releases the lock on the semaphore
    */
    void Shutdown();

private:
    Semaphore(const Semaphore &) = delete;

    Semaphore & operator =(const Semaphore &) = delete;

    /** Semaphore used for lock operation */
    SemaphoreHandle_t xSemaphore = nullptr;
};

}
#endif /* PLATFORM_FREERTOS_SEMAPHORE_H */
