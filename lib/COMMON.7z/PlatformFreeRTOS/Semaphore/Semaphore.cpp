/*****************************************************************//**
 *
 * @file    Semaphore.cpp
 * @brief   Semaphore class provides a wrapper library for using Semaphore
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include <string.h>
#include "Semaphore.h"

namespace PlatformFreeRTOS
{

Semaphore::~Semaphore()
{
    Shutdown();
}

// Create counting semaphore
bool Semaphore::Create(UBaseType_t maxCount, UBaseType_t initialCount)
{
    // wrong values when trying to create semaphore!
    if( (xSemaphore == nullptr) && (maxCount >= initialCount) && (maxCount != 0) )
    {
        xSemaphore = xSemaphoreCreateCounting(maxCount, initialCount);

        if(xSemaphore != nullptr)
        {
            // Semaphore was created successfully
            return true;
        }
    }

    return false;
}

// Used for counting events
bool Semaphore::Lock(UBaseType_t count)
{
    if(xSemaphore == nullptr)
    {
       return false;
    }

    // decrement semaphore count value
    return xSemaphoreTake(xSemaphore, count) == pdTRUE;
}

void Semaphore::Unlock()
{
    if( xSemaphore != nullptr )
    {
        // Increment semaphore count value
        xSemaphoreGive(xSemaphore);
    }
}

void Semaphore::Shutdown()
{
   if(xSemaphore)
   {
       Unlock();
       vSemaphoreDelete(xSemaphore);
       xSemaphore = nullptr;
   }

}

} // end of PlatformFreeRTOS




