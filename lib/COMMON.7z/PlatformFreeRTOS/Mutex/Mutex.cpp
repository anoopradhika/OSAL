/*****************************************************************//**
 *
 * @file    Mutex.cpp
 * @brief   Mutex class provides a wrapper library for using Mutex. This class
 *          also provides portable std::mutex apis which can be used across
 *          different platforms.
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#include <string.h>
#include "Mutex.h"
#include "task.h"

namespace PlatformFreeRTOS
{

Mutex::~Mutex()
{
    Shutdown();
}

void Mutex::Lock()
{
    constexpr TickType_t semaphoreWaitTime = 10;
    constexpr TickType_t semaphoreDelayTime = 5;

    if(xSemaphore == nullptr)
    {
       xSemaphore = xSemaphoreCreateMutex();
    }

    do
    {
        if (xSemaphoreTake(xSemaphore, semaphoreWaitTime) == pdTRUE)
        {
            break;
        }
        // Allow other tasks with lower priority to run in case one of them has the semaphore.
        ::vTaskDelay (semaphoreDelayTime);
    } while (1);
}

bool Mutex::LockWait(uint32_t aDelay)
{
    constexpr TickType_t semaphoreWaitTime = 10;
    constexpr TickType_t semaphoreDelayTime = 5;

    if(xSemaphore == nullptr)
    {
       xSemaphore = xSemaphoreCreateMutex();
    }

    do
    {
        TickType_t thisDelay = aDelay;
        if (thisDelay > semaphoreWaitTime)
        {
            thisDelay = semaphoreWaitTime;
        }
        if (xSemaphoreTake(xSemaphore, thisDelay) == pdTRUE)
        {
            return (true);
        }
        // Allow other tasks with lower priority to run in case one of them has the semaphore.
        ::vTaskDelay (semaphoreDelayTime);
        aDelay -= thisDelay;
        if (aDelay < semaphoreDelayTime)
        {
            break;
        }
        aDelay -= semaphoreDelayTime;
    } while (aDelay);

    return (false);
}

void Mutex::Unlock()
{
    xSemaphoreGive(xSemaphore);
}

bool Mutex::TryLock()
{
    if(xSemaphore == nullptr)
    {
       xSemaphore = xSemaphoreCreateMutex();
    }
    return xSemaphoreTake(xSemaphore, 0) == pdTRUE;
}

void Mutex::Shutdown()
{
   if(xSemaphore)
   {
       Unlock();
       vSemaphoreDelete(xSemaphore);
       xSemaphore = nullptr;
   }
}

}//end of PlatformFreeRTOS
