/*****************************************************************//**
 *
 * @file    Mutex.h
 * @brief   Mutex class provides a wrapper library for using Mutex. This class
 *          also provides portable std::mutex apis which can be used across
 *          different platforms.
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_FREERTOS_MUTEX_H
#define PLATFORM_FREERTOS_MUTEX_H

#include "FreeRTOS.h"
#include "semphr.h"

namespace PlatformFreeRTOS
{
    
/**
 * @brief Mutex class
 *
 * Provides wrapper class for using Mutex functionality.
 */
class Mutex
{
public:
    /** Member initialization */
    Mutex() = default;

    /** Default destructor */
    virtual ~Mutex();

    /**
        Get lock, if mutex is not used
        @return true if lock is obtained 
    */ 
    bool TryLock();

    /**
        Waits until the requested thread got the mutex
    */
    void Lock();

    /**
        Waits 'aDelay' for the requested thread to take the mutex
    */
    bool LockWait(uint32_t aDelay);

    /**
        Releases the lock on the mutex.
    */
    void Unlock();

    /**
        Releases the lock on the mutex.
    */        
    void Shutdown();

private:
    Mutex(const Mutex &) = delete;

    Mutex & operator =(const Mutex &) = delete;

    /** Semaphore used for lock operation */
    SemaphoreHandle_t xSemaphore = nullptr;
};

}
#endif /* PLATFORM_FREERTOS_MUTEX_H */
