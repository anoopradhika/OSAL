

#include "DEBUGPRINT/DEBUGPRINT.h"
#include <cstdarg>
#include <string>
#include <vector>

namespace PlatformFreeRTOS
{

const std::string DEBUGPRINT::localFormat(const std::string format, ...)
{
	// initialize use of the variable argument array
	va_list vlArgs{};
	va_start(vlArgs, format);

	// Acquire the size from a copy of
	// the variable argument array
	va_list copy{};
	va_copy(copy, vlArgs);
	const int iLen = std::vsnprintf(NULL, 0, format.c_str(), copy);
	va_end(copy);

	// return a formatted string without
	std::vector<char> arguments(iLen + 1);
	std::vsnprintf(arguments.data(), arguments.size(), format.c_str(), vlArgs);
	va_end(vlArgs);
	return std::string(arguments.data(), arguments.size());
}

}//end of PlatformFreeRTOS

