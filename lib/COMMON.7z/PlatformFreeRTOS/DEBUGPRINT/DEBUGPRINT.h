
/*****************************************************************//**
 *
 * @file    DEBUGPRINT.hpp
 * @brief   DEBUGPRINT class used of print formatting.
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
 #ifndef PLATFORM_FREE_RTOS_DEBUGPRINT_INCLUDE_H
 #define PLATFORM_FREE_RTOS_DEBUGPRINT_INCLUDE_H

#include "GlobalDataType/DEBUGPRINT.hpp"
#include "Services/DebugCLI/DebugTask.h"

namespace PlatformFreeRTOS
{
/**
    Class to use CPP formatter
*/
class DEBUGPRINT: public GlobalDataType::DEBUGPRINT
{
public:
    template <typename... Args>
    DEBUGPRINT(DebugLevel debugLevel, const std::string& format, const Args & ... args)
    {
    	//fmt support is currently removed from CMS because of Flash size
        const std::string printfKey{"%"};
        if (std::string::npos == format.find(printfKey))
        {
        	debug_printf("Format not supported\n");
        	return;
        }

        if(m_globalDebugLevel >= debugLevel)
        {
            debug_printf(localFormat(format,args...).c_str());
            debug_printf("\n");
        }
    }

    DEBUGPRINT(DEBUGPRINT& other) = delete;

    DEBUGPRINT(DEBUGPRINT&& other) = delete;

    ~DEBUGPRINT() = default;

    /**
        format arguments to specified format
        @param format: format information for arguments
        @param args: arguments
        @return formatted string
    */
    template <typename... Args>
    static std::string format(const std::string& format, const Args & ... args)
    {
    	return localFormat(format,args...);
    }

    const std::string localFormat(const std::string format, ...);

};

}
#endif //PLATFORM_FREE_RTOS_DEBUGPRINT_INCLUDE_H
