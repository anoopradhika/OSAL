/*****************************************************************//**
 *
 * @file    FtpServer.h
 * @brief   FtpServer abstraction class
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_FREERTOS_FTPSERVER_INCLUDE_H
#define PLATFORM_FREERTOS_FTPSERVER_INCLUDE_H

#include "Mol/Commands/SoftwareCenterCommands.h"

namespace PlatformFreeRTOS
{
/**
    FtpServer  provides the interface to 
    access FTPserver in Fnet
*/
class FtpServer
{
public:
    /** 
        Default constructor 
        @todo port
    */
    FtpServer(int port) {};

    /** Default destructor */
    ~FtpServer() = default;

    /** Run FTP server */
    void Run(Mol::Command::FTP_START_MODE mode);

    /**Stop FTP server */
    void Stop();

    /**Check FTP server status */
    bool CheckStatus();

};

} //PlatformFreeRTOS
#endif //PLATFORM_FREERTOS_FTPSERVER_INCLUDE_H
