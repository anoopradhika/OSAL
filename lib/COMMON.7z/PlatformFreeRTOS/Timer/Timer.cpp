/******************************************************************************//**
* @file  Timer.cpp
* @brief This module implements timer function required for the application
*        software.
*
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <assert.h>
#include "Timer.h"

namespace PlatformFreeRTOS
{
Timer::Timer(const uint32_t mS, GlobalDataType::Timer::AlarmType alarmType, const Platform::Notifier& notifier)
        : m_mS(mS)
        , m_alarmType(alarmType)
        , m_notifier(notifier)
{
}

Timer::~Timer()
{
    Shutdown();
}

Timer& Timer::operator=(Timer&& other)
{
    // Neither timer MUST not be created.
    assert (m_id == nullptr);
    assert (other.m_id == nullptr);

    m_alarmType = other.m_alarmType;
    m_mS = other.m_mS;
    m_lastExpirationTime = other.m_lastExpirationTime;
    m_notifier = other.m_notifier;

    return *this;
}


void Timer::Start()
{
    if (m_id == nullptr)
    {
        m_id = xTimerCreate("timer", pdMS_TO_TICKS(m_mS), m_alarmType == GlobalDataType::Timer::AlarmType::PERIODIC, (void *)this, TimerExpiryNotification);

        assert(m_id);

        m_lastExpirationTime = xTaskGetTickCount();

    }

    xTimerChangePeriod(m_id, pdMS_TO_TICKS(m_mS), portMAX_DELAY);
}

void Timer::Shutdown()
{
    if (m_id)
    {
        xTimerDelete(m_id, portMAX_DELAY);
        m_id = nullptr;
    }
}


void Timer::Stop()
{
    if (m_id) xTimerStop(m_id, 0);
}

uint32_t Timer::Elapsed() const
{
    return (xTaskGetTickCount() - m_lastExpirationTime);
}

void Timer::TimerExpiryNotification(TimerHandle_t Id)
{
    Timer &tmr = *(Timer *)pvTimerGetTimerID(Id);

    tmr.m_lastExpirationTime = xTaskGetTickCount();
    tmr.m_notifier();
}

bool Timer::Running(void) const
{
    if (m_id == nullptr) return false;
    return xTimerIsTimerActive(m_id);
}

}//end of PlatformFreeRTOS
