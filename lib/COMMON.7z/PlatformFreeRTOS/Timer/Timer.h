/******************************************************************************//**
* @file  Timer.h
* @brief Header file for class Timer.cpp
*
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#ifndef UTILITIES_TIMER_H
#define UTILITIES_TIMER_H

#include "GlobalDataType/Timer.h"
#include "Notifier/Notifier.hpp"
#include "FreeRTOS.h"
#include "timers.h"
#include "list.h"

/**
 * Timer class declaration
 */
namespace PlatformFreeRTOS
{

class Timer
{
public:
    /**
      default constructor
    */
    Timer() = default;

    Timer(const uint32_t mS, GlobalDataType::Timer::AlarmType alarmType, const Platform::Notifier& notifier);

    Timer& operator=(const Timer& timer) = delete;

    Timer(const Timer& other) = delete;

    virtual ~Timer();

    Timer& operator=(Timer&& timer);
    void Start();
    void Stop();
    void Shutdown();
    void Resume()
    {
        //@TODO Implementation needs to be added for freertos
    }
    bool Running() const;
    uint32_t Elapsed() const;

private:
    /**
        Method is Linux signal callback. It is used for calling m_notifier.
        @param signal: Signal number
    */
    static void TimerExpiryNotification(TimerHandle_t);
    /**
        Timer  id.
    */
    TimerHandle_t m_id = nullptr;

    /**
        Time specified in constructor
    */
    uint32_t m_mS = 0;

    /**
        Type alarm specified in constructor
    */
    GlobalDataType::Timer::AlarmType m_alarmType = GlobalDataType::Timer::AlarmType::PERIODIC;

    /**
        Last expiration time.
    */
    uint32_t m_lastExpirationTime = 0;

    /**
        Holds the notifier provided from caller
    */
    Platform::Notifier m_notifier;

};

}// end of PlatformFreeRTOS
#endif  /* UTILITIES_TIMER_H */
