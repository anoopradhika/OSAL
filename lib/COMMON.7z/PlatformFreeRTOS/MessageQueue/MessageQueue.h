/*****************************************************************//**
 *
 * @file    MessageQueue.h
 * @brief   MessageQueue class provides a wrapper library for using message queue.
 *          This class also provides message queue api on free rtos
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#ifndef PLATFORM_FREERTOS_MESSAGEQUEUE_INCLUDE_H
#define PLATFORM_FREERTOS_MESSAGEQUEUE_INCLUDE_H

#include <map>
#include <cassert>
#include <FreeRTOS.h>

#include "GlobalDataType/MessageQueue.h"
#include "queue.h"
#include "Thread/Thread.h"
#include "Guard/Guard.hpp"

namespace PlatformFreeRTOS
{
/**
 * @brief MessageQueue class
 *
 * Provides wrapper class for using MessageQueues functionality.
 */
class MessageQueue : public GlobalDataType::MessageQueue
{
public:
    MessageQueue() = default;

    /** Member initialization */
    MessageQueue(const std::string& queueName, BlockType type = BlockType::BLOCK);

    /** Destructor close the queue*/
    ~MessageQueue();


    /**
         Sends the given data into the queue
         @param[in]   data              : original data part to be sent
         @param[in]   dataLength        : length of the data to be sent
         @param[in]   waitTime          : optional wait time in case of timedsend
         @return status code 0 on success -1 on failure
    */

     bool Send(const std::string& data, const uint32_t waitTime = 0, const bool toFront = false);


    /**
         Receives the given data from the queue
         @param[in]   data              : original data part to be received
         @param[in]   dataLength        : length of the data to be received
         @param[in]   waitTime          : optional wait time in case of timedreceive
         @param[in]   toFront           : optional add message to front of queue flag
         @return status code 0 on success -1 on failure
    */

     std::string Receive(const uint32_t waitTime = 0);

     /**
        copy other valid MessageQueue.
        Method generate assert if assigned MessageQueue has
        a valid OS Queue handle
    */
    MessageQueue& operator = (const MessageQueue& otherMessageQueue)
    {
        if(this != &otherMessageQueue)
        {
            //MessageQueue copy is not allowed, if the
            // host MessageQueue object has valid queue
            //Otherwise host MessageQueue data is lost.
            assert( nullptr == m_QueueID );

            // Assert if otherMessageQueue dont have valid Queue handle
            // Copy a MessageQueue object with invalid handle is and
            //invalid operation
            assert( nullptr != otherMessageQueue.m_QueueID );

            m_QueueID = otherMessageQueue.m_QueueID;
            m_blockType = otherMessageQueue.m_blockType;
            m_queueName = otherMessageQueue.m_queueName;

            auto search = m_queues.find(m_queueName);
            if(search != m_queues.end())
            {
                search->second.instance_count++;
            }

        }
       return *this;
    }

    void Registration(std::function<void(const std::string&)> notification);
private:

    QueueHandle_t m_QueueID;
    BlockType m_blockType;
    std::string m_queueName;

    struct QueueData_t
    {
    	QueueData_t(QueueHandle_t handle) : handle(handle) {}
    	QueueHandle_t handle;
    	size_t instance_count = 1;
    };

    static std::map<std::string, QueueData_t> m_queues;
    static const uint32_t MaxQueueSize;
    static const uint32_t MaxMessageSize;
    static const TickType_t QUEUE_WAIT_MS = 1000;
    std::function<void(const std::string&)> m_userNotification;
    bool m_terminateQueueWork = false;
    void QueueWork();
    Platform::Mutex<> m_mutex{};
};


} //end  of PlatformFreeRTOS

#endif // PLATFORM_FREERTOS_MESSAGEQUEUE_INCLUDE_H
