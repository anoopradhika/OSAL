
/*****************************************************************//**
 *
 * @file    MessageQueue.cpp
 * @brief   MessageQueue class provides a wrapper library for using MessageQueue. This class
 *          provides linux based api fucntionality for message queues
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include <memory>

#include "MessageQueue.h"
#include "Notifier/Notifier.hpp"
#include "CommonDef.h"

namespace PlatformFreeRTOS
{
std::map<std::string, MessageQueue::QueueData_t> MessageQueue::m_queues;
#ifdef MAX_QUEUE_SIZE
const uint32_t MessageQueue::MaxQueueSize = MAX_QUEUE_SIZE;
#else
const uint32_t MessageQueue::MaxQueueSize = 20;
#endif
const uint32_t MessageQueue::MaxMessageSize = 400;

/**
    Message wrapper used for sending and receiving data
    pointer and data size.
    !! It is only for internal usage !!
*/
struct QueueData
{
    QueueData() = default;
    QueueData(std::string message) : m_size(message.size()),
                                     m_data(new char[message.size()])
    {
        message.copy(m_data, m_size);
    }
    ~QueueData()
    {
    }
    size_t m_size = 0;
    char* m_data = nullptr;
};


MessageQueue ::MessageQueue(const std::string& queueName, BlockType type):m_blockType(type),m_queueName(queueName)
{
    auto search = m_queues.find(m_queueName);
    if(search == m_queues.end())
    {
        m_QueueID = xQueueCreate(MaxQueueSize, sizeof(QueueData));
        if(nullptr != m_QueueID)
        {
            QueueData_t data(m_QueueID);
            m_queues.insert(std::make_pair(m_queueName, data));
        }
    }
    else
    {
        search->second.instance_count++;
        m_QueueID = search->second.handle;
    }
}


MessageQueue :: ~MessageQueue()
{
    Platform::Guard gard{m_mutex};
    m_terminateQueueWork = true;
    auto search = m_queues.find(m_queueName);
    if(search != m_queues.end())
    {
        if (--search->second.instance_count == 0)
        {
            vQueueDelete(m_QueueID);
            m_queues.erase(search);
        }
    }
}


bool MessageQueue :: Send(const std::string &data, const uint32_t waitTimeMs, const bool toFront)
{
    BaseType_t result;
    if(data.size() > MaxMessageSize)
    {
        DEBUGPRINT(DEBUG_ERROR, " > %03u %s message too big @ %u", data.size(), m_queueName.c_str(), ::xTaskGetTickCount());
        return false;
    }
    else
    {
        DEBUGPRINT(DEBUG_NOTICE, " > %03u %s @ %u", data.size(), m_queueName.c_str(), ::xTaskGetTickCount());
    }

    QueueData message{data};

    TickType_t locatWaitTimeMs;
    if(BlockType::BLOCK != m_blockType)
    {
        const TickType_t noWait = 0;
        locatWaitTimeMs = noWait;
    }
    else
    {
        locatWaitTimeMs = (TickType_t)waitTimeMs;
    }

    if (toFront)
    {
        // Add to front of queue
        result = xQueueSendToFront(m_QueueID, (void*)(&message),locatWaitTimeMs);
    }
    else
    {
        // Add to end of queue
        result = xQueueSend(m_QueueID, (void*)(&message),locatWaitTimeMs);
    }
    if (result != pdPASS)
    {
        // Failed to queue
        DEBUGPRINT(DEBUG_ERROR, " > %03u %s failed to %u @ %u", data.size(), m_queueName.c_str(), MaxQueueSize, ::xTaskGetTickCount());
        delete[] message.m_data;
        return false;
    }
    return true;
}

std::string MessageQueue::Receive(const uint32_t waitTimeMs)
{

    TickType_t localWaitTimeMs;
    if(BlockType::BLOCK != m_blockType)
    {
        const TickType_t noWait = 0;
        localWaitTimeMs = noWait;
    }
    else
    {
        localWaitTimeMs = (TickType_t)waitTimeMs;
    }

    QueueData message;
    if (::xQueueReceive(m_QueueID, (void*)&message, localWaitTimeMs))
    {
        if (message.m_data)
        {
            std::string receivedMessage(message.m_data, message.m_size);
            delete[] message.m_data;
            DEBUGPRINT(DEBUG_NOTICE, " < %03u %s @ %u", receivedMessage.size(), m_queueName.c_str(), ::xTaskGetTickCount());
            return receivedMessage;
        }
    }

    return std::string("");
}

void MessageQueue::QueueWork()
{
    QueueData message;
    while(m_terminateQueueWork == false)
    {
        {
            Platform::Guard gard{m_mutex};
            auto message = Receive(QUEUE_WAIT_MS);
            if(!message.empty())
            {
                m_userNotification(message);
            }
        }
    }
}
void MessageQueue::Registration(std::function<void(const std::string&)> notification)
{
    m_userNotification = notification;
    Platform::Notifier work;
    work.Connect(this,&MessageQueue::QueueWork);
    Thread(work,m_queueName,Thread::DEFAULT_STACK,Thread::DEFAULT_PRIORITY).Detach();
}

}
