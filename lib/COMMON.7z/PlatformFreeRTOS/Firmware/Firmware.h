/*****************************************************************//**
 *
 * @file    Firmware.h
 * @brief   Firmware abstraction class
 *
 ********************************************************************/

#ifndef PLATFORM_FREERTOS_FIRMWARE_INCLUDE_H
#define PLATFORM_FREERTOS_FIRMWARE_INCLUDE_H

#include "Services/ProductVersion/ProductVersion.h"
#include "Services/FlashMemory/FirmwareUpdate.h"

namespace PlatformFreeRTOS
{
/**
    Firmware provides the interface to
    access FirmwareUpdate in CMS
*/
class Firmware
{
public:
    /**
        Default constructor
    */
    Firmware() = default;

    /** Default destructor */
    ~Firmware() = default;

    /** Run Firmware upgrade */
    void Run()
    {
        ::FirmwarePerformUpgrade();
    }

    /** Set filename */
    void SetFilename(const char * filename)
    {
        ::FirmwareSetFilename(filename);
    }

    void RebootModule()
    {
        ::FirmwareRebootModule();
    }

    void RevertModule()
    {
        ::FirmwareRevertModule();
    }

    void DeleteFirmware()
    {
        ::FirmwareDeleteFirmware();
    }

    /** Get module type */
    uint8_t GetModuleType()
    {
        return ::productVersion.CardType;
    }
};

} //PlatformFreeRTOS
#endif //PLATFORM_FREERTOS_FIRMWARE_INCLUDE_H
