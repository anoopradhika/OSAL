/*****************************************************************//**
 *
 * @file Looper.h
 * @brief Lopper helps application to hold sate, wait form application termination.
 * @copyright Copyright 2017 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_FREERTOS_LOOPER_INCLUDE_H
#define PLATFORM_FREERTOS_LOOPER_INCLUDE_H

#include "Thread/Thread.hpp"
#include "MessageQueue/MessageQueue.hpp"

namespace PlatformFreeRTOS
{
/**
 *  @brief Once appliction is started, Looper puts the application thread in block mode
 */

 class Looper
 {
 public:
    Looper(PROC_ADDRESS address) : m_address(address) { }
    ~Looper() = default;
    void Init()
    {
        std::string queue_desc = std::string("LOOPER") + std::to_string((uint32_t)m_address);
        m_Queue = Platform::MessageQueue<>{queue_desc, GlobalDataType::MessageQueue::BlockType::BLOCK};
    }

    bool WaitForTermination()
    {
        Platform::Notifier workerData;
        workerData.Connect(this,&Looper::Worker);
        m_Thread = Platform::Thread<>{workerData, "Looper"};
        m_Thread.Join();
        return true;
    }

    bool Terminate()
    {
        return  m_Queue.Send("TERM");
    }

    void Worker()
    {
        while (m_Queue.Receive(m_queueReceiveIntervalMs) != "TERM")
        {
        }
    }
 protected:
    ///It is used for  m_Queue.Receive.  This the block thread
    //for 10sec if there is no message available.
    const uint32_t m_queueReceiveIntervalMs  = 10*1000;;
    Platform::Thread<> m_Thread;

 private:
    PROC_ADDRESS m_address;
    Platform::MessageQueue<> m_Queue;
 };

} //end of PlatformFreeRTOS

#endif //PLATFORM_FREERTOS_LOOPER_INCLUDE_H
