/*!
 * @file    Thread.h
 * @brief   Thread class provides a wrapper library for FreeRTOS 
 *          threading. It provides similar functionality to the
 *          standard C++11 std:threading.
 */

#ifndef _FREERTOS_THREAD_H_
#define _FREERTOS_THREAD_H_

#include <string>
#include <forward_list>
#include <algorithm>
#include "Notifier/Notifier.hpp"
#include "FreeRTOS.h"
#include "task.h"

namespace PlatformFreeRTOS
{
    
/**
 * @brief Thread class
 * 
 */
class Thread
{
public:

    static const int DEFAULT_PRIORITY = 5;
    static const size_t DEFAULT_STACK = 1024;

	Thread() = default;

    Thread(Platform::Notifier &worker, std::string name, size_t stack_size, int priority);

    virtual ~Thread();

    Thread(const Thread&) = delete;

    Thread& operator = (Thread& other) = delete;

    Thread& operator = (Thread && other)
    {
        task = other.task;

		// Override the constant and remove reference to thread from other task.
        Task **ptr = (Task **)(&other.task);
        *ptr = nullptr;

        return *this;
    }

    bool Joinable() const;
    TaskHandle_t GetId() const { return task->id; }
    void Join();
    void Detach();

private:

    // Note: Separate structure required to allow the task to be detached.
    struct Task
	{
    	Task(Platform::Notifier &worker, const char *thread_name, int priority, size_t stack_size);
    	~Task();
    	bool detached = false;
    	TaskHandle_t id = nullptr;
    	std::forward_list<void *> list;
    	Platform::Notifier worker;

    	static void RunTask(void *object);
	} *task = nullptr;

};

namespace this_thread
{
    /*!
     * Reschedule the execution of threads, allowing other threads to run.
     */
    void Yield();
    void Sleep(uint32_t milliseconds);
}

}
#endif /* _CPP_THREAD_H_ */

