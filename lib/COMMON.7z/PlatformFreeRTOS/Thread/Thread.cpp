/*!
 * @file    Thread.cpp
 * @brief   Thread class provides a wrapper library for FreeRTOS 
 *          threading. It provides similar functionality to the
 *          standard C++11 std:threading.
 */
 
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "Thread.h"
#include "ThreadPriorities.h"

extern "C" void *pxCurrentTCB;

namespace PlatformFreeRTOS
{

/*!
 * @brief constructor
 */
Thread::Thread(Platform::Notifier &worker, std::string name, size_t stack_size, int priority)
	: task(new Task(worker, name.c_str(), priority, stack_size))
{
}

/*!
 * @brief destructor
 */
Thread::~Thread()
{
	portENTER_CRITICAL();

	Task *t = task;
	task = nullptr;

	portEXIT_CRITICAL();

	if (t) delete t;
}

/*!
 * @brief Checks if the thread object identifies an active thread of execution. Specifically, 
 *        returns true if get_id() != std::thread::id(). So a default constructed thread is 
 *        not joinable.
 */
bool Thread::Joinable() const
{ 
    bool status = false;
    
    portENTER_CRITICAL();
    if (task)
    {    
        if (pxCurrentTCB != task->id)
        {
            status = true;
        }
    }
	portEXIT_CRITICAL();

    return status;
}
    
/*!
 * @brief Blocks the current thread until the thread identified by *this finishes its execution.
 * @note  This function will throw an exception if the RTOS is not running.
 */
void Thread::Join()
{
	// Check if detached...
	if (task != nullptr)
	{
	    QueueHandle_t sem = xSemaphoreCreateBinary();
		task->list.push_front(sem);
		xSemaphoreTake(sem, portMAX_DELAY);
        vSemaphoreDelete(sem);

        // Task deleted
        task = nullptr;
	}
}

/*!
 * @brief Separates the thread of execution from the thread object, allowing execution to continue 
 *        independently. Any allocated resources will be freed once the thread exits.
 */
void Thread::Detach()
{
    portENTER_CRITICAL();

    if (task)
    {
        task->detached = true;
        task = nullptr;
    }
    
    portEXIT_CRITICAL();
}

/*!
 * @brief Creates the task and a semaphore required for safe shutdown.
 * @param f  entry specification for task.
 * @param thread_name  task description
 * @param thread_priority  starting thread priority for task
 * @param stack_size  size of stack to allocate to task.
 */
Thread::Task::Task(Platform::Notifier &worker, const char *thread_name, int priority, size_t stack_size)
	: worker(worker)
{
    // Customise CCL thread stack sizes for module requirements (reducing RAM usage on modules)
    // Vulnerable to thread name changes
    K66Thread::getModulePreferences(thread_name, stack_size, priority);
	::xTaskCreate(RunTask, thread_name, static_cast<uint16_t>(stack_size), static_cast<void*>(this), priority, &id);
}

/*!
 * @brief deletes the semaphore and tasks. 
 */
Thread::Task::~Task()
{
    for (auto sem : list)
    {
        xSemaphoreGive(sem);
    }
}

/*!
 * @brief Runs the task.
 * @param object - pointer to this task object
 */
void Thread::Task::RunTask(void *object)
{
	auto task = reinterpret_cast<Task *>(object);

	task->worker();

    // Save task id for later deletion
	TaskHandle_t id = task->id;

	// Delete task - freeing up heap - before deleting task.
    delete task;

	vTaskDelete(id);

	// Does not return to the point - task is DEAD!!!
}

/*!
 * @brief Reschedule the execution of threads, allowing other threads to run.
 */
void this_thread::Yield(void)
{
    taskYIELD();
}

void this_thread::Sleep(uint32_t milliseconds)
{
	vTaskDelay(pdMS_TO_TICKS(milliseconds));
}

}
