
#include "SharedMemory/SharedMemory.h"
#include <unistd.h>
#include "gmock/gmock.h"
#include "Platform/SharedMemory/SharedMemory.hpp"

namespace PlatformLinux
{
    class SharedMemoryTest : public :: testing::Test
    {
        //const std::string SharedMem {"value_shm"};


    };

    TEST_F(SharedMemoryTest,write_data)
    {
        bool Shm_create_status;
        uint16_t Write_buff;
        static auto sharedMemory = Platform::SharedMemory("Shm_mem_test",1024);
        Shm_create_status = sharedMemory.Create();
        EXPECT_TRUE(Shm_create_status);
        std::string message = "Writting_data_to_Shared_Memory";
        Write_buff = sharedMemory.WriteData(message);
        EXPECT_EQ(Write_buff,message.length());
    }
    TEST_F(SharedMemoryTest,read_data)
    {
        bool open_status;
        static auto sharedMemory = Platform::SharedMemory("Shm_mem_test");
        open_status = sharedMemory.Open();
        EXPECT_TRUE(open_status);
        uint32_t g_data,panelID = 0u;
        g_data = sharedMemory.GetData((char *)&panelID, sizeof(panelID));
        EXPECT_EQ(g_data,sizeof(panelID));
    }
    TEST_F(SharedMemoryTest,Dummy_Read_write)
        {
            bool Write_buff,create_status,open_status;
            uint16_t g_data;
            static auto sharedMemory = Platform::SharedMemory("",8);
            create_status = sharedMemory.Create();
            EXPECT_FALSE(create_status);
            open_status = sharedMemory.Open();
            EXPECT_FALSE(open_status);
            std::string message = "";
            Write_buff = sharedMemory.WriteData(message);
            EXPECT_FALSE(Write_buff);
            uint32_t* panelID = nullptr;
            g_data = sharedMemory.GetData((char *)&panelID, sizeof(panelID));
            EXPECT_EQ(g_data,0);
        }
}
