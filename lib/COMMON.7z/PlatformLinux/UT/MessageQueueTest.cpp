#include"MessageQueueTest.h"
#include "CommonDef.h"


namespace platformTest{

const std::string MessageQueueBLockType::m_queueName{"TestBlockQueue"};

const std::string MessageQueueNonBlockType::m_queueName{"TestBlockQueue"};

MessageQueueBLockType::MessageQueueBLockType()
{
}



void MessageQueueBLockType::SetUp()
{
    m_blockQueue = Platform::MessageQueue<>{m_queueName,
                    GlobalDataType::MessageQueue::BlockType::BLOCK};
}


void MessageQueueBLockType::TearDown()
{
}



MessageQueueNonBlockType::MessageQueueNonBlockType()
{
}



void MessageQueueNonBlockType::SetUp()
{
    m_nonBlockQueue = Platform::MessageQueue<>{m_queueName,
                    GlobalDataType::MessageQueue::BlockType::NON_BLOCK};
}


void MessageQueueNonBlockType::TearDown()
{
}

/**

*/
TEST_F(MessageQueueNonBlockType, Receive_blank)
{
    auto ReceivedData = m_nonBlockQueue.Receive();
    if(ReceivedData.empty())
    {
            std::cout<<"Received Data is empty"<<std::endl;
    }
    else
    {
        std::cout<<"Received Data is "<< ReceivedData <<std::endl;
    }
}
TEST_F(MessageQueueNonBlockType, SendAndReceive)
{
    const std::string SendData{"SendAndReceive"};
    std::cout<<"Send Data = "<< SendData <<std::endl;
    auto status = m_nonBlockQueue.Send(SendData);
    EXPECT_TRUE(status);
    std::cout<<"Send status = "<< status <<std::endl;
    auto ReceivedData = m_nonBlockQueue.Receive();
    if(ReceivedData.empty())
    {
            std::cout<<"Received Data is empty"<<std::endl;
    }
    else
    {
        std::cout<<"Received Data is "<< ReceivedData <<std::endl;
    }
}

TEST_F(MessageQueueNonBlockType, Send)
{
    Platform::Notifier workerData;
    std::function<void(const std::string&)> m_userNotification;
    m_nonBlockQueue.Registration(m_userNotification);
    const std::string SendData{"MessageQueueNonBlockTypeData"};
    std::cout<<"Send Data = "<< SendData <<std::endl;
    auto status = m_nonBlockQueue.Send(SendData);
    EXPECT_TRUE(status);
    std::cout<<"Send status = "<< status <<std::endl;

}

TEST_F(MessageQueueNonBlockType, Receive)
{
    auto ReceivedData = m_nonBlockQueue.Receive();
    if(ReceivedData.empty())
    {
            std::cout<<"Received Data is empty"<<std::endl;
    }
    else
    {
        std::cout<<"Received Data is "<< ReceivedData <<std::endl;
    }
}

TEST_F(MessageQueueBLockType, Send)
{
    const std::string SendData{"MessageQueueBlockTypeData"};
    std::cout<<"Send Data = "<< SendData <<std::endl;
    auto status = m_blockQueue.Send(SendData,10000);
    EXPECT_TRUE(status);
    std::cout<<"Send status = "<< status <<std::endl;

}

TEST_F(MessageQueueBLockType, Receive)
{
    auto ReceivedData = m_blockQueue.Receive(100*100);
    if(ReceivedData.empty())
    {
            std::cout<<"Received Data is empty"<<std::endl;
    }
    else
    {
        std::cout<<"Received Data is "<< ReceivedData <<std::endl;
    }
}

}
