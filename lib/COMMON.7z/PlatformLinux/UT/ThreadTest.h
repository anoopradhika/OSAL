#ifndef PLATFPRM_TEST_TIMER_INCLUDE_H
#define PLATFPRM_TEST_TIMER_INCLUDE_H
#include "gmock/gmock.h"
#include "Thread/Thread.hpp"
#include "Thread/Thread.h"
#include "Mutex/Mutex.h"

namespace platformTest{

/**
    Thread test to test Platform::Thread functionality
*/
    class Thread: public:: testing::Test
    {
        public:

            /** Default constructor */
            Thread() = default;

            /** Default destructor */
            ~Thread() = default;

            /** Add test Setup here */
            virtual void SetUp();

            /** Add test cleanup here */
            virtual void TearDown();

            /** Thread for testing */
            Platform::Thread<> m_Thread,m_Thread1;
            PlatformLinux::Mutex m_mutex_test;

            /**
                Worker expected to call from thread
                @param data: data pass to worker
            */
            void worker(uint32_t data);
            void worker_thread2(uint32_t data);

    };

}
#endif //PLATFPRM_TEST_TIMER_INCLUDE_H
