/******************************************************************************//**
 * @file    CppThreadTest.cpp
 * @brief   Unit test cases for functions implemented in CppThread class
 *
 * @copyright Copyright 2016 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/

#include "gmock/gmock.h"
#include "Thread/Thread.h"

bool retPos = true;
bool retNeg = false;

class ThreadHandler : public PlatformLinux::Thread
{
public:
    void* Run(void* const args)
    {

        while(!terminated)
        {
            sleep(1);
        }
        return(nullptr);
    }
};

class CppThreadTest : public ::testing::Test
{
public:
    ThreadHandler           m_threadHandlerObj1,m_threadHandlerObj2,m_threadHandlerObj3;
    ThreadHandler           *m_threadHandlerPtr1,*m_threadHandlerPtr2,*m_threadHandlerPtr3;
    static ThreadHandler    m_staticThreadHandlerObj1;
    static ThreadHandler    m_staticThreadHandlerObj2;
    static ThreadHandler    m_staticThreadHandlerObj3;
    static ThreadHandler    m_staticThreadHandlerObj4;

    CppThreadTest():m_threadHandlerObj1(),
            m_threadHandlerObj2(),
            m_threadHandlerObj3(),
            m_threadHandlerPtr1(new ThreadHandler()),
            m_threadHandlerPtr2(new ThreadHandler()),
            m_threadHandlerPtr3(new ThreadHandler())
    {
    }
    ~CppThreadTest()
    {
        if(m_threadHandlerPtr1)
        {
            delete m_threadHandlerPtr1;
            m_threadHandlerPtr1=nullptr;
        }
        if(m_threadHandlerPtr2)
        {
            delete m_threadHandlerPtr1;
            m_threadHandlerPtr2=nullptr;
        }
        if(m_threadHandlerPtr3)
        {
            delete m_threadHandlerPtr3;
            m_threadHandlerPtr3=nullptr;
        }
    }

protected:

    virtual void SetUp()
    {
        std::cout<<"CppThreadTest SetUp called\n";
        m_staticThreadHandlerObj1.Start();
        m_staticThreadHandlerObj2.Start();
        m_staticThreadHandlerObj3.Start();
        m_staticThreadHandlerObj4.Start();
    }

    virtual void TearDown()
    {
        std::cout<<"CppThreadTest TearDown called\n";
        m_staticThreadHandlerObj1.Stop();
        m_staticThreadHandlerObj2.Stop();
        m_staticThreadHandlerObj3.Stop();
        m_staticThreadHandlerObj4.Stop();
    }
};

ThreadHandler CppThreadTest::m_staticThreadHandlerObj1;
ThreadHandler CppThreadTest::m_staticThreadHandlerObj2;
ThreadHandler CppThreadTest::m_staticThreadHandlerObj3;
ThreadHandler CppThreadTest::m_staticThreadHandlerObj4;

TEST_F(CppThreadTest, TestStaticStopThread)
{
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    sleep(1);   // Sleep for thread to start running

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

    CppThreadTest::m_staticThreadHandlerObj1.Stop();
    CppThreadTest::m_staticThreadHandlerObj2.Stop();
    CppThreadTest::m_staticThreadHandlerObj3.Stop();
    CppThreadTest::m_staticThreadHandlerObj4.Stop();

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());
}

TEST_F(CppThreadTest, TestStaticTerminateDetachThread)
{
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    sleep(1);   // Sleep for thread to start running

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    CppThreadTest::m_staticThreadHandlerObj1.Detach();
    CppThreadTest::m_staticThreadHandlerObj2.Detach();
    CppThreadTest::m_staticThreadHandlerObj3.Detach();
    CppThreadTest::m_staticThreadHandlerObj4.Detach();

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

    CppThreadTest::m_staticThreadHandlerObj1.Terminate();
    CppThreadTest::m_staticThreadHandlerObj2.Terminate();
    CppThreadTest::m_staticThreadHandlerObj3.Terminate();
    CppThreadTest::m_staticThreadHandlerObj4.Terminate();

    sleep(2);

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());
}

TEST_F(CppThreadTest, TestStaticStopDetachThread)
{
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    sleep(1);   // Sleep for thread to start running

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

    CppThreadTest::m_staticThreadHandlerObj1.Detach();
    CppThreadTest::m_staticThreadHandlerObj2.Detach();
    CppThreadTest::m_staticThreadHandlerObj3.Detach();
    CppThreadTest::m_staticThreadHandlerObj4.Detach();


    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

    CppThreadTest::m_staticThreadHandlerObj1.Stop();
    CppThreadTest::m_staticThreadHandlerObj2.Stop();
    CppThreadTest::m_staticThreadHandlerObj3.Stop();
    CppThreadTest::m_staticThreadHandlerObj4.Stop();

    sleep(2);

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
    EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
    EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());
}

TEST_F(CppThreadTest, TestStaticRestartStoppedDetachThread)
{
    int counter = 0;

    while(counter<3)
    {
        counter++;
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

        sleep(1);   // Sleep for thread to start running

        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

        CppThreadTest::m_staticThreadHandlerObj1.Detach();
        CppThreadTest::m_staticThreadHandlerObj2.Detach();
        CppThreadTest::m_staticThreadHandlerObj3.Detach();
        CppThreadTest::m_staticThreadHandlerObj4.Detach();


        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

        CppThreadTest::m_staticThreadHandlerObj1.Stop();
        CppThreadTest::m_staticThreadHandlerObj2.Stop();
        CppThreadTest::m_staticThreadHandlerObj3.Stop();
        CppThreadTest::m_staticThreadHandlerObj4.Stop();

        sleep(2);

        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsRunning());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsRunning());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsRunning());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsRunning());

        //These Threads will be stopped inside tearDown
        CppThreadTest::m_staticThreadHandlerObj1.Start();
        CppThreadTest::m_staticThreadHandlerObj2.Start();
        CppThreadTest::m_staticThreadHandlerObj3.Start();
        CppThreadTest::m_staticThreadHandlerObj4.Start();
    }

}

TEST_F(CppThreadTest, TestStaticRestartStoppedJoinedThread)
{
    int counter = 0;

    while(counter<3)
    {
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

        sleep(1);   // Sleep for thread to start running

        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

        CppThreadTest::m_staticThreadHandlerObj1.Stop();
        CppThreadTest::m_staticThreadHandlerObj2.Stop();
        CppThreadTest::m_staticThreadHandlerObj3.Stop();
        CppThreadTest::m_staticThreadHandlerObj4.Stop();

        sleep(2);

        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj1.IsCreated());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj2.IsCreated());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj3.IsCreated());
        EXPECT_EQ(retNeg,CppThreadTest::m_staticThreadHandlerObj4.IsCreated());

        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj1.IsFinished());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj2.IsFinished());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj3.IsFinished());
        EXPECT_EQ(retPos,CppThreadTest::m_staticThreadHandlerObj4.IsFinished());

        //These Threads will be stopped inside tearDown
        CppThreadTest::m_staticThreadHandlerObj1.Start();
        CppThreadTest::m_staticThreadHandlerObj2.Start();
        CppThreadTest::m_staticThreadHandlerObj3.Start();
        CppThreadTest::m_staticThreadHandlerObj4.Start();

        counter++;
    }
}

TEST_F(CppThreadTest, TestJoinThread)
{
    int counter=0;

    while(counter<3)
    {
        counter++;
        m_threadHandlerObj1.Start();
        m_threadHandlerObj2.Start();
        m_threadHandlerObj3.Start();

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsCreated());

        sleep(1);

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsRunning());

        EXPECT_EQ(retNeg,m_threadHandlerObj1.IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerObj2.IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerObj3.IsFinished());

        EXPECT_NE(m_threadHandlerObj1.GetId(),m_threadHandlerObj2.GetId());
        EXPECT_NE(m_threadHandlerObj2.GetId(),m_threadHandlerObj3.GetId());

        m_threadHandlerObj1.Stop();
        m_threadHandlerObj2.Stop();
        m_threadHandlerObj3.Stop();

        EXPECT_EQ(retNeg,m_threadHandlerObj1.IsRunning());
        EXPECT_EQ(retNeg,m_threadHandlerObj2.IsRunning());
        EXPECT_EQ(retNeg,m_threadHandlerObj3.IsRunning());

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsFinished());
    }
}

TEST_F(CppThreadTest, TestDetachThread)
{
    int counter=0;

    while(counter<3)
    {
        counter++;
        m_threadHandlerObj1.Start();
        m_threadHandlerObj2.Start();
        m_threadHandlerObj3.Start();

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsCreated());

        sleep(1);

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsRunning());

        m_threadHandlerObj1.Detach();
        m_threadHandlerObj2.Detach();
        m_threadHandlerObj3.Detach();

        EXPECT_EQ(retNeg,m_threadHandlerObj1.IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerObj2.IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerObj3.IsFinished());

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsRunning());

        EXPECT_NE(m_threadHandlerObj1.GetId(),m_threadHandlerObj2.GetId());
        EXPECT_NE(m_threadHandlerObj2.GetId(),m_threadHandlerObj3.GetId());

        m_threadHandlerObj1.Terminate();
        m_threadHandlerObj2.Terminate();
        m_threadHandlerObj3.Terminate();

        sleep(2);

        EXPECT_EQ(retPos,m_threadHandlerObj1.IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerObj2.IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerObj3.IsFinished());

        EXPECT_EQ(retNeg,m_threadHandlerObj1.IsRunning());
        EXPECT_EQ(retNeg,m_threadHandlerObj2.IsRunning());
        EXPECT_EQ(retNeg,m_threadHandlerObj3.IsRunning());

    }
}

TEST_F(CppThreadTest, TestPointerJoinThread)
{
    int counter=0;

    while(counter<3)
    {
        counter++;
        m_threadHandlerPtr1->Start();
        m_threadHandlerPtr2->Start();
        m_threadHandlerPtr3->Start();

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsCreated());

        sleep(1);

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsRunning());

        EXPECT_EQ(retNeg,m_threadHandlerPtr1->IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerPtr2->IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerPtr3->IsFinished());

        EXPECT_NE(m_threadHandlerPtr1->GetId(),m_threadHandlerPtr2->GetId());
        EXPECT_NE(m_threadHandlerPtr2->GetId(),m_threadHandlerPtr3->GetId());

        m_threadHandlerPtr1->Stop();
        m_threadHandlerPtr2->Stop();
        m_threadHandlerPtr3->Stop();

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsFinished());
    }
}

TEST_F(CppThreadTest, TestPointerDetachThread)
{
    int counter=0;

    while(counter<3)
    {
        counter++;
        m_threadHandlerPtr1->Start();
        m_threadHandlerPtr2->Start();
        m_threadHandlerPtr3->Start();

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsCreated());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsCreated());

        sleep(1);

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsRunning());

        m_threadHandlerPtr1->Detach();
        m_threadHandlerPtr2->Detach();
        m_threadHandlerPtr3->Detach();

        EXPECT_EQ(retNeg,m_threadHandlerPtr1->IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerPtr2->IsFinished());
        EXPECT_EQ(retNeg,m_threadHandlerPtr3->IsFinished());

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsRunning());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsRunning());

        EXPECT_NE(m_threadHandlerPtr1->GetId(),m_threadHandlerPtr2->GetId());
        EXPECT_NE(m_threadHandlerPtr2->GetId(),m_threadHandlerPtr3->GetId());

        m_threadHandlerPtr1->Terminate();
        m_threadHandlerPtr2->Terminate();
        m_threadHandlerPtr3->Terminate();

        sleep(2);

        EXPECT_EQ(retPos,m_threadHandlerPtr1->IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerPtr2->IsFinished());
        EXPECT_EQ(retPos,m_threadHandlerPtr3->IsFinished());

        EXPECT_EQ(retNeg,m_threadHandlerPtr1->IsRunning());
        EXPECT_EQ(retNeg,m_threadHandlerPtr2->IsRunning());
        EXPECT_EQ(retNeg,m_threadHandlerPtr3->IsRunning());
    }
}
