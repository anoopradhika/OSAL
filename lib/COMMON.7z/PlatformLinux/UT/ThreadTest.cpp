/******************************************************************************//**
 * @file    ThreadTest.cpp
 * @brief   Unit test cases for functions implemented in Platform::Thread class
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/


#include "ThreadTest.h"
#include"Notifier/Notifier.hpp"
#include <chrono>
#include <stdexcept>
#include "Mutex/Mutex.h"


namespace platformTest{

void Thread::worker(uint32_t data)
{
    m_mutex_test.TryLock();
    for (int i = 0; i < 5; ++i) {
        std::cout << "Thread 1 executing\n";
        ++data;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    m_mutex_test.Shutdown();
    m_mutex_test.Unlock();
}
void Thread::worker_thread2 (uint32_t data)
{
    m_mutex_test.Lock();
    for(int i =0; i<5; ++i)
    {
        std::cout<<"thread 2 is running\n";
        std::cout<<"data value = "<<data<<std::endl;
    }
    m_mutex_test.Unlock();
}

void Thread::SetUp()
{}


void Thread::TearDown()
{}

TEST_F(Thread, ThreadJoin)
{
    bool Joinable;
    const uint32_t m_data =2;
    Platform::Notifier workerData;
    workerData.Connect(this,&platformTest::Thread::worker,m_data);
    m_Thread = Platform::Thread<>{workerData};
    Joinable = m_Thread.Joinable();
    EXPECT_TRUE(Joinable);
    m_Thread.Join();
    m_Thread.Detach();
}

TEST_F(Thread, ThreadDetach)
{
    bool Joinable;
    const uint32_t m_data =225;
    Platform::Notifier workerData;
    workerData.Connect(this,&platformTest::Thread::worker_thread2,m_data);
    m_Thread1 = Platform::Thread<>{workerData};
    Joinable = m_Thread1.Joinable();
    EXPECT_TRUE(Joinable);
    m_Thread1.Detach();
    m_Thread1.Join();
}


}