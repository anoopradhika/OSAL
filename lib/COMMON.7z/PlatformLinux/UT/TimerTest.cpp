#include"TimerTest.h"
#include "CommonDef.h"


namespace platformTest{

int32_t debugLevel = DEBUG_INFO;

Timer::Timer()
{
    m_timer.Stop();
}



void Timer::SetUp()
{
    Platform::Notifier notifier;
    m_data =225;
    notifier.Connect(this,&platformTest::Timer::testNotification);
    m_timer = Platform::Timer<>((uint64_t)2000,GlobalDataType::Timer::AlarmType::PERIODIC,notifier); // Timer has two Alram Type (1) SINGLE_SHOT and (2) PERIODIC
}


void Timer::TearDown()
{
  m_timer.Shutdown();
}


void Timer::testNotification()
{
    std::cout<<" is received"<<std::endl;
}

/**

*/
TEST_F(Timer, Timer_Check)
{
    bool val;
    uint16_t lapsed_val;
    m_timer.Start();
    val = m_timer.IsStopped();
    EXPECT_FALSE(val);
    sleep(10);
    m_timer.Stop();
    val = m_timer.IsStopped();
    EXPECT_TRUE(val);
    lapsed_val = m_timer.Elapsed();
    EXPECT_GT(lapsed_val,0);
    sleep(2);
    m_timer.Resume();
    m_timer.Shutdown();
}

}