/******************************************************************************//**
 * @file     CppUartTest.cpp
 * @brief    Unit test cases for Uart Config/Read/Write
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, reengineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 **********************************************************************************/


#include "UARTHandler/UARTHandler.h"
#include "DOL/Entities/Point/SerialPort.h"
#include "gmock/gmock.h"

namespace PlatformLinux
{
  class CppUartTest : public :: testing::Test//, public UARTHandler :: Uart
  {
    public:
      using BAUD_RATE = Dol::Entities::SerialPort::BAUD_RATE;
      using PARITY = Dol::Entities::SerialPort::PARITY;
      using FLOW_CONTROL = Dol::Entities::SerialPort::FLOW_CONTROL;
      using PORT_TYPES = Dol::Entities::SerialPort::PORT_TYPES;
      /*virtual void SetUp() {
      }

      virtual void TearDown() {
      }*/

      std::shared_ptr<Dol::Entities::SerialPort> GetConfig()
    {
        auto config = std::make_shared<Dol::Entities::SerialPort>(1);     // Keeping domainObjectID as 1
        config->SetBaudRate(BAUD_RATE::RATE_115200);
        config->SetParity(PARITY::NONE);
        config->SetStopBit(1);
        config->SetDataBits(8);
        config->SetFlowControl(FLOW_CONTROL::NONE);
        config->SetPortType(PORT_TYPES::RS232);
        return config;
    }


  };



    /**
     * @brief   File transfer client test
     */
      TEST_F(CppUartTest, Add_Configs)
      {
          auto config = GetConfig();
          config->SetParity(PARITY::NONE);
          config->SetStopBit(2);
          config->SetDataBits(7);
          config->SetFlowControl(FLOW_CONTROL::XON_XOFF);
          const std::string port = "/dev/ttyS0";
          UARTHandler Uart(config,port);
          EXPECT_TRUE(Uart.IsOpen());
          ASSERT_EQ("/dev/ttyS0",Uart.GetPort());
          Uart.DiscardBufferedData();
          Uart.Flush();
        }

      TEST_F(CppUartTest, write_byte)
      {
        auto config = GetConfig();
        config->SetStopBit(1);
        config->SetDataBits(8);
        config->SetParity(PARITY::EVEN);
        const std::string port = "/dev/ttyS0";
        int i=10;
        UARTHandler Uart(config,port);
        int return_val;
        return_val = Uart.Write(uint8_t(i));
        EXPECT_TRUE(return_val);
        EXPECT_TRUE(Uart.IsOpen());
        ASSERT_EQ("/dev/ttyS0",Uart.GetPort());
        Uart.DiscardBufferedData();
        Uart.Flush();
        }
        TEST_F(CppUartTest, Read_data)
      {
        auto config = GetConfig();
        const std::string port = "/dev/ttyS0";
        uint8_t val;
        uint8_t *const ptr = &val;
        UARTHandler Uart(config,port);
        EXPECT_TRUE(Uart.IsOpen());
        int read_data;
        read_data = Uart.Read(ptr,sizeof(uint8_t));
        EXPECT_FALSE(read_data);
        ASSERT_EQ("/dev/ttyS0",Uart.GetPort());
        Uart.DiscardBufferedData();
        Uart.Flush();
        }

      TEST_F(CppUartTest, write_vector)
      {
        auto config = GetConfig();
        config->SetParity(PARITY::ODD);
        config->SetFlowControl(FLOW_CONTROL::RTS_CTS);
        const std::string port = "/dev/ttyS0";
        std::vector<uint8_t> vect(2,10);
        UARTHandler Uart(config,port);
        Uart.Write(vect);
        EXPECT_TRUE(Uart.IsOpen());
        ASSERT_EQ("/dev/ttyS0",Uart.GetPort());
        Uart.DiscardBufferedData();
        }



      TEST_F(CppUartTest, False_Condition)
      {
        auto config = GetConfig();
        config->SetParity(PARITY::NONE);
        config->SetFlowControl(FLOW_CONTROL::XON_XOFF);
        const std::string port = "";
        UARTHandler Uart(config,port);
        EXPECT_FALSE(Uart.IsOpen());
        ASSERT_EQ("",Uart.GetPort());
        Uart.DiscardBufferedData();
        Uart.Flush();
       }

}
