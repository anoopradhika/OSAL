/*****************************************************************//**
 *
 * @file Thread.cpp
 * @brief   Thread class provides a wrapper library for using thread. This class
 *          also provides portable std::thread which can be used across
 *          different platforms.This has responsibility
 *          of thread creation, processing and graceful termination of thread
 *          which can be used across application.
 *
 *
 * @copyright Copyright 2016 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include "Thread.h"
#include <cstring>
#include <iostream>

namespace PlatformLinux
{

Thread::Thread(Platform::Notifier& worker, std::string name, size_t stack_size, int priority)
{
    mThread = std::thread{Thread::InternalThreadBody,worker};
    mThreadId = mThread.get_id();
};

void Thread::Join(void)
{
    if (mThread.joinable())
    {
        try
        {
            mThread.join();
        }
        catch (std::exception& ex)
        {
             std::cerr << "Thread::Join: Thread Join Failed." << ex.what() << std::endl;
        }
        catch(...)
        {
            std::cerr << "Thread::Join:Unknown failure occurred." << std::endl;
        }
    }
    else
    {
         std::cerr << "Thread::Join: Cant not join" << std::endl;
    }

}


auto Thread::GetId() const
{
    return mThreadId;
}


bool Thread::Joinable() const
{
    return mThread.joinable();
}


void Thread::Detach(void)
{
    if (mThread.joinable())
    {
        try
        {
            mThread.detach();
        }
        catch (std::exception& ex)
        {
             std::cerr << "Thread::Detach: Thread Detach failed" << ex.what() << std::endl;
        }
        catch(...)
        {
            std::cerr << "Thread::Detach:Unknown failure occurred." << std::endl;
        }
    }
}


void Thread::InternalThreadBody(Platform::Notifier worker)
{
    worker();
}

namespace this_thread
{
    /**
      Reschedule the execution of threads, allowing other threads to run.
    */
    void Yield()
    {
        std::this_thread::yield();
    }
}//end of this_thread

} //end of platformLinux
