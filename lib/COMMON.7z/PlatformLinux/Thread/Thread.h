/*****************************************************************//**
 *
 * @file    Thread.h
 * @brief   Thread class provides a wrapper library for using thread. This class
 *          also provides portable std::thread which can be used across different
 *          platforms.This has responsibility of thread creation, processing and
 *          graceful termination of thread which can be used across applications.
 *
 * @copyright Copyright 2020 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#ifndef PLATFORM_LINUX_THREAD_INCLUDE_H
#define PLATFORM_LINUX_THREAD_INCLUDE_H

#include <thread>
#include <climits>
#include<string>
#include"Notifier/Notifier.hpp"
#include <cassert>

namespace PlatformLinux
{
    
/**
 * @brief Thread class
 *
 * C++-Thread class wrapping std::thread interface.
 */
class Thread
{
public:
    /*!
     * Defaults required for interface.
     */
	static const int DEFAULT_PRIORITY = 0;
	static const size_t DEFAULT_STACK = 0;

    /**
        A default constructor
    */
    Thread()= default;

    /**
        Constructor create the thread
        @param worker: takes the thread and it argument.
        @param name: Not need for Linux
        @param StatckSize: Not need for Linux
        @param Priority: Not need for Linux
    */
    Thread(Platform::Notifier& worker, std::string name = "", size_t stack_size = DEFAULT_STACK, int priority = DEFAULT_PRIORITY);

    /**
        A default destructor
    */
    ~Thread() = default;

    /**
        Constant copy constructor not allowed.
    */
    Thread(Thread const& thread) = delete;

    /**
        Thread copy is never allowed
    */
    Thread& operator = (Thread& other) = delete;

    /**
        move other execution thread.
        Method generate assert if the host thread is
        joinable
    */
    Thread& operator = (Thread && other ) noexcept
    {
        if(this != &other)
        {
            //Thread copy is not allowed, if the 
            // host thread object is joinable 
            //Otherwise host thread data is lost.
            assert( ! mThread.joinable() );
            mThreadId = other.mThreadId;
            std::thread ThreadTest;
            mThread  = std::move(other.mThread);
        }
       return *this;
    }
    
    /** Wait for a thread to finished its execution */
    void Join();

    /** 
        Get thread id
        @return threadID
    */
    auto GetId() const;

    /**
        Permits the thread execute independently
        from the thread handle
    */
    void Detach();
    
    /**
        Checks if the thread object identifies an active thread
        of execution. Specifically, returns true
    */
    bool Joinable() const;

private:
     // For storing thread id
    std::thread::id mThreadId;

    // thread body to start. This internally calls Run method implemented by derived class
    static void InternalThreadBody(Platform::Notifier worker);

    std::thread mThread;
};
namespace this_thread
{
    extern void Yield();

    inline void Sleep(uint32_t timeMs)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(timeMs));
    }
}
}
#endif // PLATFORM_LINUX_THREAD_INCLUDE_H

