#!/bin/bash
# runs the PlatformLinux unit tests. Run from the PlatformLinux directory.
# make sure that its been built for coverage first - make PLATFORM=PC COV=YES and PLATFORM=PC COV=YES ut  (or build from RECIPES with COV=YES)
# results are created in ../BUILD/CoverageReports/PlatformLinux


#set -x

TEST="ut_platformLinux.out"
base=../..


cov=true
covfile='covfile'

# Kill if any application already running
#pkill $APP > /dev/null

# Kill if any ut application already running
pkill $TEST > /dev/null

# kill any other applications too
echo kill other apps
#pkill Network.out > /dev/null

sleep 1


rm -f /dev/mqueue/LOOPER* > /dev/null
rm -f /dev/mqueue/Proc* > /dev/null

sleep 1

sudo sysctl fs.mqueue.msg_max=2000
sudo sysctl fs.mqueue.msg_default=2000
sudo sysctl fs.mqueue.msgsize_max=2000
#cp -f UT/systemconfig.xml .
# clear coverage counters
echo clear coverage counters
pushd ../../../BUILD/OBJ/PC/COMMON/PlatformLinux
lcov --gcov-tool /usr/bin/gcov --base-directory . --directory . --zerocounters -q
popd

# Start application
echo start app


#sleep 10

echo Running PlatformLinux Tests
../../../BUILD/BIN/PC/$TEST

#sleep 1

#pkill $APP > /dev/null

if [ $cov = true ]
then
	echo lcov
	pushd ../../../BUILD/OBJ/PC/COMMON/PlatformLinux/
	lcov --directory . --base-directory ../../../../../LIBRARIES/COMMON/PlatformLinux/ -c -o coverage.info
	echo lcov remove
	lcov --remove coverage.info "*/DOMAINOBJECTLIBRARY/*" -o coverage.info
	lcov --remove coverage.info "*/fmt/*" -o coverage.info
	lcov --remove coverage.info "*/Platform/*" -o coverage.info
	lcov --remove coverage.info "*/DEBUGPRINT/*" -o coverage.info
	lcov --remove coverage.info "*/DebugPrint/*" -o coverage.info
	lcov --remove coverage.info "*/Mol/*" -o coverage.info
	lcov --remove coverage.info "*/usr/*" -o coverage.info
	lcov --remove coverage.info "*gtest*" -o coverage.info
	lcov --remove coverage.info "*/UT/*" -o coverage.info
	echo genhtml
	pwd
	genhtml coverage.info -o ../../../../CoverageReports/PlatformLinux
	popd
fi


echo End of Tests - killing processes


rm -f /dev/mqueue/LOOPER* > /dev/null
rm -f /dev/mqueue/Proc* > /dev/null
rm -rf systemconfig.xml

# Kill if any ut application already running
pkill $TEST > /dev/null

