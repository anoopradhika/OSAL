/*****************************************************************//**
 *
 * @file    FtpServer.h
 * @brief   FtpServer abstraction class
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_LINUX_FTPSERVER_INCLUDE_H
#define PLATFORM_LINUX_FTPSERVER_INCLUDE_H


#include"ftp-master/src/FTPServer.h"
#include "Mol/Commands/SoftwareCenterCommands.h"

namespace PlatformLinux
{

class FtpServer
{
public:
    /** Default constructor */
    explicit FtpServer(int port): m_FtpServer(port) {};

    /** Default destructor */
    ~FtpServer() = default;

    //
    void Run(Mol::Command::FTP_START_MODE mode);
	void Stop();
    bool CheckStatus();

private:
    FTPServer m_FtpServer;
    bool m_running = false;
};

} //platform
#endif //PLATFORM_LINUX_FTPSERVER_INCLUDE_H
