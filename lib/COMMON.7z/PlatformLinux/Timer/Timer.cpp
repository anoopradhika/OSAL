/******************************************************************************//**
* @file  Timer.cpp
* @brief This module implements timer function required for the application
*        software.
*
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#include <string.h>
#include <errno.h>
#include <time.h>
#include "CommonDef.h"
#include "Timer.h"
#include <map>

namespace PlatformLinux
{

Timer::Timer(const uint32_t timeMs, GlobalDataType::Timer::AlarmType alarmType,
                    Platform::Notifier& notifier):
                    m_timeMs(timeMs),
                    m_alarmType(alarmType),
                    m_notifier(notifier)

{
    uv_timer_init(uv_default_loop(), m_timer.get());
}


Timer::~Timer()
{
    if(m_timeValid)
    {
        Stop();
        Shutdown();
    }
}


void Timer::Start()
{
    m_timer->data = this;
    uint32_t repeatTime = 0;
    if(GlobalDataType::Timer::AlarmType::PERIODIC == m_alarmType)
    {
        repeatTime = m_timeMs;
    }
    uv_timer_start(m_timer.get()
                    , [](uv_timer_t* timer) {
                        auto self = (Timer*)timer->data;
                        self->m_notifier();
                    }
                    ,m_timeMs
                    ,repeatTime);
    m_timerStopped = false;
}


void Timer::Shutdown()
{
    if(!m_timerStopped)
    {
        m_timerStopped = true;
        Stop();
    }
}


void Timer::Stop()
{
    if(!m_timerStopped)
    {
        m_timerStopped = true;
        uv_timer_stop(m_timer.get());
    }

}


void Timer::Resume()
{
    m_timerStopped = false;
    uv_timer_again(m_timer.get());
}


bool Timer::IsStopped() const
{
    return m_timerStopped;
}


GlobalDataType::Timer::AlarmType Timer::GetAlarmType()
{
    return m_alarmType;
}

uint32_t Timer::Elapsed() const
{
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    typedef std::chrono::duration<int,std::milli> millisecs_t ;
    millisecs_t duration( std::chrono::duration_cast<millisecs_t>(end-start) ) ;
    if(m_timeMs < (uint32_t)duration.count())
    {
        return (duration.count() - m_timeMs);
    }
    else
    {
         return 0;
    }
}

}//end of PlatformLinux
