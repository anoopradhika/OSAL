/******************************************************************************//**
* @file  Timer.h
* @brief Header file for class Timer.cpp
*
* @copyright Copyright 2017 by Honeywell International Inc.
* All rights reserved.  This software and code comprise proprietary
* information of Honeywell International Inc.  This software and code
* may not be reproduced, used, altered, reengineered, distributed or
* disclosed to others without the written consent of Honeywell.
**********************************************************************************/
#ifndef UTILITIES_TIMER_H
#define UTILITIES_TIMER_H

#include <iostream>
#include <map>
#include <chrono>
#include "GlobalDataType/Timer.h"
#include "Notifier/Notifier.hpp"
#include"uv.h"

/**
 * Timer class declaration
 */
namespace PlatformLinux
{

class Timer
{
public:
    /**
      default constructor
    */
    Timer() = default;

    /**
      constructor to set alarm type and time
      @param alarmType: Set type from Interface::Timer::AlarmType
      @param timeMs: Time in invoke timer notification.
    */
    Timer(const uint32_t timeMs, GlobalDataType::Timer::AlarmType alarmType,
                    Platform::Notifier& notifier);


    Timer& operator=(const Timer& timer) = delete;

    Timer(const Timer& other) = delete;

    /**
      default destructor
    */
     ~Timer() ;

    /**
      copy operator is used for timer copy operation
      @param timer: Source timer
    */
    Timer& operator=(Timer&& timer) noexcept
    {
       m_alarmType = timer.m_alarmType;
       m_timeMs = timer.m_timeMs;
       m_notifier = timer.m_notifier;
       m_timeValid = timer.m_timeValid;
       m_timer = timer.m_timer;
       timer.m_timeValid = false;
       return *this;
    }

    /**
      A verification method to check whether time is still running.
      @return return true if timer is stopped, else false
    */
    virtual bool IsStopped() const ;

    /**
      A verification method to check how much time it is elapsed form expected
      notification.
      @return return elapsed time in millisecond, if timer is not elapsed
              return zero
    */
    virtual uint32_t Elapsed() const ;

    /**
        Start the timer based on the alarm type and time
    */
    virtual void Start() ;

    /**
        Stop currently running timer.
    */
    virtual void Stop() ;

    /**
         It can resume both PERIODIC and SINGLE_SHOT timer
    */
    virtual void Resume();

    /**
       Cleanup activity taken care in this method.
    */
    virtual void Shutdown() ;

    /**
        Obtain the current alarm type. It used in notification get
        alarmtype.
        @return Interface::Timer::AlarmType
    */
    virtual GlobalDataType::Timer::AlarmType GetAlarmType() ;

private:
    std::shared_ptr<uv_timer_t> m_timer = std::make_unique<uv_timer_t>();

    /**
        Time specified in constructor
    */
    uint32_t m_timeMs;

    /**
        Type alarm specified in constructor
    */
    GlobalDataType::Timer::AlarmType m_alarmType;

    /**
        Holds the notifier provided from caller
    */
    Platform::Notifier m_notifier;

    /**
        Bool to check whether this timer is stopped.
    */
    bool m_timerStopped = true;

    bool m_timeValid = false;
    /**
        Used for find the elapsed time
    */
    std::chrono::steady_clock::time_point start;
};

}//end of PlatformLinux
#endif  /* UTILITIES_TIMER_H */
