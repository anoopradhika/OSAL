/*****************************************************************//**
 *
 * @file Looper.h
 * @brief Lopper helps application to hold sate, wait form application termination.
 * @copyright Copyright 2017 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_LINUX_LOOPER_INCLUDE_H
#define PLATFORM_LINUX_LOOPER_INCLUDE_H

#include "Thread/Thread.hpp"
#include "MessageQueue/MessageQueue.hpp"

#include"uv.h"

namespace PlatformLinux
{
/**
 *  @brief Looper is used to hold application, once it starts
 */

class Looper
{
public:
    explicit Looper(PROC_ADDRESS address) : m_address(address)
    {
        m_handle = ::uv_default_loop();
    }
    ~Looper()
    {
          ::uv_loop_close(m_handle);
    }
    Looper(const Looper &loop) = default;
    Looper(Looper &&loop) = default;
    void Init()
    {
        std::string queue = std::string("LOOPER") + std::to_string(static_cast<uint32_t>(m_address));
        m_Queue = Platform::MessageQueue<>{queue, GlobalDataType::MessageQueue::BlockType::BLOCK};
        m_Queue.Registration([this](const std::string& message)
                            {
                                if((0 == message.compare("TERM")) && m_handle)
                                {
                                    ::uv_stop(m_handle);
                                }
                            }
                            );
    }

    bool WaitForTermination()
    {
        if(m_handle)
        {
            ::uv_run(m_handle,m_runOption);
            return true;
        }
        return false;
    }

    bool Terminate()
    {
        if(m_handle)
        {
            ::uv_stop(m_handle);
            return true;
        }
        return false;
    }

private:
    PROC_ADDRESS m_address;
    static const uv_run_mode m_runOption = UV_RUN_DEFAULT;
    uv_prepare_t prepare_handle;
    uv_loop_t* m_handle{nullptr};
    Platform::MessageQueue<> m_Queue;
};

} //end of PlatformLinux

#endif //PLATFORM_LINUX_LOOPER_INCLUDE_H
