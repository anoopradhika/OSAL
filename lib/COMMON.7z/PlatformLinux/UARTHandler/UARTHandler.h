/*****************************************************************//**
 *
 * @file    UARTHandler.h
 * @brief   UART Handler class for serial communication
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_LINUX_UART_HANDLER_INCLUDE_H
#define PLATFORM_LINUX_UART_HANDLER_INCLUDE_H

// Standard C (POSIX) libraries.
#include <termios.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>

#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

// Standard C++ libraries.
#include <iostream>
#include <string>

#include "DOL/Entities/Point/SerialPort.h"
#include "DebugPrint/DEBUGPRINT.hpp"
#include "CommonDef.h"
namespace PlatformLinux
{

/**
 * Class used for implementing the UART I/O functionality.
 */
class UARTHandler
{

public:

    using BAUD_RATE = Dol::Entities::SerialPort::BAUD_RATE;
    using PARITY = Dol::Entities::SerialPort::PARITY;
    using FLOW_CONTROL = Dol::Entities::SerialPort::FLOW_CONTROL;
    using PORT_TYPES = Dol::Entities::SerialPort::PORT_TYPES;

    /**
     * @brief      constructor, used for constructing a valid `UARTHandler` object.
     * @param[in]  port: A `std::string` object that represents the location of the UART-mapped tty* file.
     * @param[in]  config: Serial config details
     * @remark     If the UART-mapped tty*-like file can't be opened, `std::ios_base::failure` will be thrown.
     */
    UARTHandler(std::shared_ptr<Dol::Entities::SerialPort> config, const std::string& port) :
        m_UARTPort{port},
        m_fileDescriptor{-1},
        m_config{config}
    {
        if(!config)
        {
            Platform::DEBUGPRINT(DEBUG_ERROR,"UARTHandler: Invalid config.");
            return;
        }

        /* O_RDWR   - Read/Write access to serial port       */
        /* O_NOCTTY - No terminal will control the process   */
        if (-1 == (m_fileDescriptor = open(port.c_str(), O_RDWR | O_NOCTTY)))
        {
            auto errornumber = errno;
            Platform::DEBUGPRINT(DEBUG_ERROR,"UARTHandler: Error Opening Serial Port [{0}] code [{1}]",
                port, strerror(errornumber));
            m_openStatus = false;
            return;
        }

        if(0 == isatty(m_fileDescriptor))
        {
            Platform::DEBUGPRINT(DEBUG_ERROR,"UARTHandler: file descriptor is not pointing to a TTY device.");
            return;
        }

        bzero(&m_termSetting, sizeof(m_termSetting));
        tcgetattr(m_fileDescriptor, &m_termSetting);

        /** apply terminos Setting **/
        if (!SetBaudRate() || !SetStopBit() || !SetDataBit() || !SetParity()
            || !SetFlowControl() || !SetInputControlFlags() || !SetLineControlFlags())
        {
            m_openStatus = false;
            return;
        }

        m_openStatus = true;
        m_termSetting.c_oflag = 0;  /*No Output Processing*/
        m_termSetting.c_cc[VMIN] = 32;
        m_termSetting.c_cc[VTIME] = 0;
        ApplySettings();
    }

    /**
     * @brief    Destructor, will perform all the necessary cleanup.
     */
    ~UARTHandler()
    {
        if(m_fileDescriptor > -1)
        {
            close(m_fileDescriptor);
        }
    }

    /**
     * @brief     Method used for sending data out over a communication channel.
     *
     * @param[in] A pointer to a constant C-like array of bytes where the data is stored.
     * @param[in] A `int` value that represents the size of `data` C-like array.
     * @return Same as the standard UNIX `write()` function (check `man 3 write` for details).
     */
    int Write(const uint8_t *data, int size)
    {
        if (nullptr == data)
        {
            return ERROR_VALUE;
        }
        return write(m_fileDescriptor, data, size);
    }

    /**
     * @brief     Method used for sending one byte over a communication channel.
     *
     * @param[in] A `uint8_t` value which represent the data which should be sent.
     * @return    1 if the byte was successfully sent, 0 otherwise.
     */
    int Write(uint8_t byte)
    {
        return Write(&byte, 1);
    }

    /**
     * @brief     Method used for sending data out over a communication channel.
     *
     * @param[in] data: A reference to a const `std::vector<uint8_t>` object that represents the vector of values.
     * @return    Same as the standard UNIX `write()` function (check `man 3 write` for details).
     */
    int Write(const std::vector<uint8_t> &data)
    {
        return Write(&data[0], data.size());
    }

    /**
     * @brief      Method used for receiving data over a communication channel.
     *
     * @param[out] data: A const pointer to a `uint8_t` object (C-like array of `uint8_t`s) where the
     *             received data will be stored.
     * @param[in]  size: A `int` value which represents the number of maximum bytes to be read.
     * @return     Same as the standard UNIX `read()` function (check `man 3 read` for details).
     */
    int Read(uint8_t *const data, int size)
    {
        fd_set rfds;
        struct timeval tv;
        int retval;

        if((data == nullptr) || (-1 == m_fileDescriptor))
        {
            return ERROR_VALUE;
        }

        /* Watch m_fileDescriptor to see when it has input. */
        FD_ZERO(&rfds);
        FD_SET(m_fileDescriptor, &rfds);

        /* Wait up to three seconds. */
        tv.tv_sec = 3;
        tv.tv_usec = 0;
        retval = select(m_fileDescriptor+1, &rfds, nullptr, nullptr, &tv);

        if (retval == ERROR_VALUE)
        {
            Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:Read() select() call error");
            return ERROR_VALUE;
        }
        else if (retval)
        {
            //Data is available
            return read(m_fileDescriptor, data, size);
        }
        else
        {
            Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:Read() No Data");
            return 0;
        }
    }

    /**
     * @brief    Getter, will get the location of the tty*-like UART-mapped file.
     * @return   A `std::string` value that represents the file's location and name.
     */
    std::string GetPort() const
    {
        return m_UARTPort;
    }

    /**
     * @brief    Discards data written to the object referred to by fd but not transmitted,
     *           or data received but not read, depending on the value of queue_selector.
     */
    void DiscardBufferedData() const
    {
        tcflush(m_fileDescriptor, TCIOFLUSH);
    }

    /**
     * @brief    Status of communication ready for read/write
     * @return   A `bool` value that represents if the Handler is ready for read/write operation.
     */
    bool IsOpen() const
    {
        return m_openStatus;
    }

    /**
     * @brief    Method used to waits until all output written to the object referred
     *           to by fd has been transmitted.
     */
    void Flush()
    {
        tcdrain(m_fileDescriptor);
    }

    /**
     * @brief    Apply settings and Flush any data written but not transmitted.
     */
    void ApplySettings()
    {
        tcsetattr(m_fileDescriptor, TCSANOW, &m_termSetting); //TCSANOW the change occurs immediately.
        tcflush(m_fileDescriptor, TCOFLUSH);
    }

private:

    /** Status to check if Handler is ready for read/write operation **/
    bool m_openStatus = false;

    // tty*-like file that's mapped to the UART peripheral.
    std::string m_UARTPort {};

    // File descriptor used for performing `read\write(...)` operations.
    int m_fileDescriptor = -1;

    // Structure used for setting the port's baud rate.
    struct termios m_termSetting {};

    // UART config settings
    std::shared_ptr<Dol::Entities::SerialPort> m_config;

    /**
     * @brief    Method used for setting the UART communication baud rate.
     * @return   true for success, false for failure
     */
    bool SetBaudRate()
    {
        if(m_config->GetBaudRate() != BAUD_RATE::END_OF_LIST)
        {
            cfsetospeed(&m_termSetting, m_config->GetBaudRateValue());
            return true;
        }
        Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:SetBaudRate(): failed");
        return false;
    }

    /**
     * @brief    Method used for setting the UART communication stop bit.
     * @return   true for success, false for failure
     */
    bool SetStopBit()
    {
        if(m_config->GetStopBit() == 1)
        {
            m_termSetting.c_cflag &= ~( CSTOPB );
        }
        else if(m_config->GetStopBit() == 2)
        {
            m_termSetting.c_cflag |= CSTOPB;
        }
        else
        {
            Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:SetStopBit() failed ");
            return false;
        }
        return true;
    }

    /**
     * @brief    Method used for setting the UART communication data bits.
     * @return   true for success, false for failure
     */
    bool SetDataBit()
    {
        //! Mask data size bit
        m_termSetting.c_cflag &= ~(CSIZE );
        auto databit = m_config->GetDataBits();
        if(databit == 6)
        {
            m_termSetting.c_cflag |= CS6;
        }
        else if(databit == 7)
        {
            m_termSetting.c_cflag |= CS7;
        }
        else if(databit == 8)
        {
            m_termSetting.c_cflag |= CS8;
        }
        else
        {
            Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:SetDataBit() error ");
            return false;
        }
        return true;
    }

    /**
     * @brief    Method used for setting the UART communication parity bit.
     * @return   true for success, false for failure
     */
    bool SetParity()
    {
        switch(m_config->GetParity())
        {
            case PARITY::NONE :
                //Parity Disabled
                m_termSetting.c_iflag &= ~PARENB;
                break;

            case PARITY::EVEN :
                m_termSetting.c_cflag |= PARENB;
                m_termSetting.c_cflag &= ~( PARODD );
                break;

            case PARITY::ODD:
                m_termSetting.c_cflag |= ( PARENB | PARODD );
                break;

            default:
                Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:SetParity() error ");
                return false;
        }
        return true;
    }

    /**
     * @brief    Method used for setting the UART communication flow control.
     * @return   true for success, false for failure
     */
    bool SetFlowControl()
    {
        //disable s/w & hardware flow control
        m_termSetting.c_iflag &= ~( IXON | IXOFF | CRTSCTS );
        switch(m_config->GetFlowControl())
        {
            case FLOW_CONTROL::NONE :
                m_termSetting.c_cflag |= CLOCAL;
                break;

            case FLOW_CONTROL::XON_XOFF :
                m_termSetting.c_cflag |= ( IXON | IXOFF );
                break;

            case FLOW_CONTROL::RTS_CTS :
                m_termSetting.c_cflag |= CRTSCTS;
                break;

            default:
                Platform::DEBUGPRINT(DEBUG_ERROR, "UARTHandler:SetFlowControl() error ");
                return false;
        }
        return true;
    }

    /**
     * @brief  set input control flags.
     */
    bool SetInputControlFlags()
    {
        m_termSetting.c_iflag &= ~( IXANY | INPCK | IGNBRK | IGNBRK | INLCR | PARMRK | INPCK | BRKINT | ISTRIP);
        return true;
    }

    /**
     * @brief  set line control flags.
     */
    bool SetLineControlFlags()
    {
        /* Non Cannonical mode */
        m_termSetting.c_lflag &= ~( ICANON | ECHO | ECHONL| ECHOE | ISIG | IEXTEN);
        return true;
    }
};

} //end of PlatformLinux

#endif //PLATFORM_LINUX_SERIAL_INCLUDE_H
