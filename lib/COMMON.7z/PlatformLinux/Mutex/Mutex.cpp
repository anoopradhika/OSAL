/*****************************************************************//**
 *
 * @file    Mutex.cpp
 * @brief   Mutex class provides a wrapper library for using Mutex. This class
 *          also provides portable std::mutex apis which can be used across
 *          different platforms.
 *
 *
 * @copyright Copyright 2016 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/


#include "Mutex.h"
#include <iostream>
namespace PlatformLinux
{

bool Mutex::TryLock()
{
    if(!this->islocked)
    {
        this->islocked = m_mutex.try_lock();
    }

    return this->islocked;
}

void Mutex::Lock()
{
    m_mutex.lock();
    this->islocked = true;
}

void Mutex::Unlock()
{

    if (this->islocked)
    {
        m_mutex.unlock();
        this->islocked = false;
    }
}

void Mutex::Shutdown()
{
    if (this->islocked)
    {
        m_mutex.unlock();
        this->islocked = false;
    }
}

} // end of PlatformLinux
