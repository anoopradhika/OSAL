/*****************************************************************//**
 *
 * @file    Mutex.h
 * @brief   Mutex class provides a wrapper library for using Mutex. This class
 *          also provides portable std::mutex apis which can be used across
 *          different platforms.
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_LINUX_MUTEX_H
#define PLATFORM_LINUX_MUTEX_H

#include<mutex>

namespace PlatformLinux
{
    
/**
 * @brief Mutex class
 *
 * Provides wrapper class for using Mutex functionality.
 */
class Mutex
{
public:
    /** Member initialization */
    Mutex() = default;

    /** Default destructor */
    virtual ~Mutex() = default;

    /**
        Get lock, if mutex is not used
        @return true if lock is obtained 
    */ 
    bool TryLock();

    /**
        Waits until the current thread got the mutex
    */
    void Lock();

    /**
        Releases the lock on the mutex.
    */
    void Unlock();

    /**
        Releases the lock on the mutex.
    */        
    void Shutdown();

private:
    Mutex(const Mutex &) = delete;
    Mutex & operator =(const Mutex &) = delete;

    /** Mutex used for lock operation */
    std::mutex m_mutex;

    /** Mutex lock status*/
    bool islocked = false;
};

}
#endif /* PLATFORM_LINUX_MUTEX_H */

