/*****************************************************************//**
 *
 * @file    SharedMemory.h
 * @brief   Header file for Shared Memory class
 *
 * @todo    Explore boost library for Shared Memory
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#ifndef PLATFORM_LINUX_SHARED_MEMORY_INCLUDE_H
#define PLATFORM_LINUX_SHARED_MEMORY_INCLUDE_H

#include <string>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <semaphore.h>
#include <string.h>
#include<unistd.h>
#include "DebugPrint/DEBUGPRINT.hpp"

namespace PlatformLinux
{

/**
 * Enumerations used while creating shared memory.
 */

enum class SM_CREATE_MODE : uint8_t
{
    C_READ_ONLY  = O_RDONLY,
    C_READ_WRITE = O_RDWR,
    END_OF_LIST
};

/**
* Enumerations used while attaching shared memory.
*/

enum class SM_ATTACH_MODE : uint8_t
{
    A_READ  = PROT_READ,
    A_WRITE = PROT_WRITE,
    END_OF_LIST
};

/**
 * Class for implementing shared memory.
 */

class SharedMemory
{
public:

    /**
     * @brief   constructor function
     *
     * @param[in]   sharedMemoryName  Name given to Shared Memory
     * @param[in]   sharedMemorySize  size of shared memory
     */

    SharedMemory(const std::string& sharedMemoryName, uint16_t sharedMemorySize)
    {
        m_shSize = sharedMemorySize;
        m_sharedMemoryName = "/" + sharedMemoryName;
        m_semphoreName = "/semaphore" + sharedMemoryName;
        m_SemID = sem_open(m_semphoreName.c_str(), O_CREAT, S_IRUSR | S_IWUSR, 1);

    }

    /**
     * @brief   Destructor function
     *
     */

    ~SharedMemory()
    {
        Clear();
    }

    /**
     * @brief   creates and opens a new, or opens an existing, POSIX shared memory object.
     *
     * @return  true or false
     */

    bool Create()
    {
        bool returnValue = false;

        Lock();

        m_ID = shm_open(m_sharedMemoryName.c_str(), O_CREAT | O_RDWR, S_IRWXU | S_IRWXG);

        if(-1 == m_ID)
        {
            UnLock();
            auto errornumber = errno;
            Platform::DEBUGPRINT(DEBUG_ERROR,"SharedMemory: Error Opening Shared Memory [{0}]",
                strerror(errornumber));
            return (returnValue);
        }

        /* adjusting mapped file size (make room for the whole segment to map) --  ftruncate() */
        if (-1 == ftruncate(m_ID, m_shSize))
        {
            Clear();
            UnLock();
            auto errornumber = errno;
            Platform::DEBUGPRINT(DEBUG_ERROR,"SharedMemory: Error truncating Shared Memory [{0}]",
                strerror(errornumber));
            return (returnValue);
        }

        returnValue = Attach();

        UnLock();

        return (returnValue);
    }

    /**
     * @brief   opens opens an existing, POSIX shared memory object.
     *
     * @return  true or false
     */

    bool Open()
    {
        bool returnValue = false;

        Lock();

        m_ID = shm_open(m_sharedMemoryName.c_str(), O_RDWR, S_IRWXU | S_IRWXG);

        if(m_ID < 0)
        {
            UnLock();
            auto errornumber = errno;
            Platform::DEBUGPRINT(DEBUG_ERROR,"SharedMemory: Error opening Shared Memory [{0}]",
                strerror(errornumber));
            return (returnValue);
        }

        returnValue = Attach();

        UnLock();

        return (returnValue);
    }

    /**
     * @brief   Writes to shared memory
     *
     * @param[in]  stringShmValue  copies string to shared memory
     * @return  number of bytes written
     */

    uint16_t WriteData(const std::string &stringShmValue)
    {
        uint16_t strSize = stringShmValue.size();

        if ((0 == strSize) || (nullptr == m_ptrSharedMemory))
        {
            return 0u;
        }
        else if (strSize > m_shSize)
        {
            strSize = m_shSize;
        }
        else
        {
            //Do nothing
        }

        return (WriteData(stringShmValue.c_str(), strSize));
    }

    /**
     * @brief   Writes to shared memory
     *
     * @param[in]  ptrBuffer copies content of character buffer to shared memory
     * @param[in]  bufferSize size of character buffer
     * @return  number of bytes written
     */

    uint16_t WriteData(const char *ptrBuffer, const uint16_t bufferSize)
    {
        if ((nullptr == ptrBuffer) || (bufferSize > m_shSize) || (nullptr == m_ptrSharedMemory))
        {
            return 0u;
        }

        Lock();
        memset(m_ptrSharedMemory, 0u, m_shSize);
        memcpy(m_ptrSharedMemory, static_cast<const void *> (ptrBuffer), bufferSize);
        UnLock();

        return (bufferSize);
    }

    /**
     * @brief   Reads shared memory content to a character buffer
     *
     * @param[out]  ptrBuffer   copies shared memory content to a character buffer
     * @param[in]   bufferSize  size of character buffer
     * @return  number of bytes read
     */

    uint16_t GetData(char *ptrBuffer, const uint16_t bufferSize)
    {
        if ((nullptr == ptrBuffer) || (bufferSize > m_shSize) || (nullptr == m_ptrSharedMemory))
        {
            return 0u;
        }

        Lock();
        memcpy(ptrBuffer, m_ptrSharedMemory, bufferSize);
        UnLock();

        return (bufferSize);
    }


private:
    std::string m_semphoreName      = "";
    std::string m_sharedMemoryName  = "";
    int32_t     m_ID                = -1;
    sem_t*      m_SemID             = nullptr;
    void*       m_ptrSharedMemory   = nullptr;
    uint16_t    m_shSize            = 0u;

    /**
     * @brief   Attaches shared memory segment
     *
     * @param[in]   mode  attach mode
     * @return  true or false
     */

    bool Attach(int mode = static_cast<int> (SM_ATTACH_MODE::A_READ) | static_cast<int> (SM_ATTACH_MODE::A_WRITE))
    {
        if (-1 == m_ID)
        {
            return false;
        }
        /* requesting the shared segment --  mmap() */
        m_ptrSharedMemory = mmap(nullptr, m_shSize, mode, MAP_SHARED, m_ID, 0);
        if (m_ptrSharedMemory == nullptr)
        {
            Clear();
            auto errornumber = errno;
            Platform::DEBUGPRINT(DEBUG_ERROR,"SharedMemory: Error allocating Shared Memory segment [{0}]",
                strerror(errornumber));
            return false;
        }

        return true;
    }

    /**
     * @brief   Detaches shared memory segment
     *
     */

    void Detach()
    {
        if (nullptr != m_ptrSharedMemory)
        {
            munmap(m_ptrSharedMemory, m_shSize);
        }
    }

    /**
     * @brief   Clears shared memory and semaphore
     *
     */

    void Clear()
    {
        if(m_ID != -1)
        {
            Detach();
            shm_unlink(m_sharedMemoryName.c_str());
        }

        if(m_SemID != nullptr)
        {
            sem_close(m_SemID);
            sem_unlink(m_semphoreName.c_str());
        }
    }

    /**
     * @brief   Locks semaphore
     *
     */

    void Lock()
    {
        if(m_SemID != nullptr)
        {
            sem_wait(m_SemID);
        }
    }

    /**
     * @brief   Unlocks semaphore
     *
     */

    void UnLock()
    {
        if(m_SemID != nullptr)
        {
            sem_post(m_SemID);
        }
    }

};

} //end of PlatformLinux

#endif //PLATFORM_LINUX_SHARED_MEMORY_INCLUDE_H
