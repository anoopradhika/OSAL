
/*****************************************************************//**
 *
 * @file    DEBUGPRINT.hpp
 * @brief   DEBUGPRINT class used of print formatting.
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
 #ifndef PLATFORM_LINUX_DEBUGPRINT_INCLUDE_H
 #define PLATFORM_LINUX_DEBUGPRINT_INCLUDE_H

#include <iostream>
#include <syslog.h>

#include <sstream>
#include <iomanip>
#include <ctime>

#include "fmt/format.h"
#include "fmt/printf.h"
#include "GlobalDataType/DEBUGPRINT.hpp"

namespace PlatformLinux
{
/**
    @brief Class to use CPP formatter
*/
class DEBUGPRINT: public GlobalDataType::DEBUGPRINT
{
public:
    template <typename... Args>
    DEBUGPRINT(DebugLevel debugLevel, const std::string& format, const Args & ... args)
    {
        //check for printf format
        const std::string printfKey{"%"};
        if (std::string::npos != format.find(printfKey))
        {
            if(OutStream::LOGFILE == m_outstream)
            {
                syslog((int)debugLevel,format.c_str(), args...);
            }
            else if(OutStream::STDOUT == m_outstream)
            {
                std::string timeInfoWithFormat = CurrentTime();
                timeInfoWithFormat.append(" ");
                timeInfoWithFormat.append(format);
                fmt::printf(timeInfoWithFormat, args...);
                fmt::printf("\r\n");
            }
            else
            {
               fmt::printf("Do Nothing\n");
            }

        }
        else
        {
            const std::string& fmtlog = fmt::format(format,args...);

            if(OutStream::LOGFILE == m_outstream)
            {
                syslog((int)debugLevel,"%s", fmtlog.c_str());
            }
            else if(OutStream::STDOUT == m_outstream)
            {
                std::cout<<CurrentTime()<<" "<<fmtlog<<std::endl;
            }
            else
            {
               std::cout<<"Do Nothing"<<std::endl;
            }
        }

    }
    DEBUGPRINT(DEBUGPRINT& other) = delete;
    DEBUGPRINT(DEBUGPRINT&& other) = delete;
    ~DEBUGPRINT() = default;
    /**
        format arguments to specified format
        @param format: format information for arguments
        @param args: arguments
        @return formatted string
    */
    template <typename... Args>
    static std::string format(const std::string& format, const Args & ... args)
    {
        return fmt::format(format,args...);
    }

protected:

    std::string CurrentTime()
    {
        std::stringstream wss;
        std::time_t now_a = std::time(nullptr);
        wss<<std::put_time(std::localtime(&now_a),"%F %T");
        return  wss.str();
    }
};

}
#endif //PLATFORM_LINUX_DEBUGPRINT_INCLUDE_H
