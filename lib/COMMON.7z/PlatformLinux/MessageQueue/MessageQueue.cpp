/*****************************************************************//**
 *
 * @file    MessageQueue.cpp
 * @brief   MessageQueue class provides a wrapper library for using MessageQueue. This class
 *          provides linux based api fucntionality for message queues
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/

#include <iostream>
#include <unistd.h>
 
#include "MessageQueue.h"
#include "CommonDef.h"

namespace PlatformLinux
{

const char* MessageQueue::MESSAGE_QUEUE_PATH = "/dev/mqueue";
//@note: MaxQueueSize is maximum number of messages that message queue can hold
const uint32_t MessageQueue::MAX_BUFFERING_SIZE = 2000;
const uint32_t MessageQueue::MaxQueueSize = 200;
const uint32_t MessageQueue::LimitReached = ((90*MaxQueueSize)/100);
//@note: MaxMessageSize number should be set to size of the message structure sent over message queue
const uint32_t MessageQueue::MaxMessageSize = 400;
const uint32_t MessageQueue::MAX_TIME = 1000;


 MessageQueue::MessageQueue(const std::string& queueName, BlockType type):m_blockType(type),m_queueName("/"+queueName)
{
    q_attributes.mq_flags    = 0u;
    q_attributes.mq_maxmsg   = MaxQueueSize;
    q_attributes.mq_msgsize  = MaxMessageSize;
    q_attributes.mq_curmsgs  = 0u;

    int flags = O_RDWR|O_CREAT;

    if(m_blockType == BlockType::NON_BLOCK)
    {
        flags |= O_NONBLOCK;
    }
    m_QueueID = mq_open(m_queueName.c_str(),flags,S_IRUSR|S_IWUSR,&q_attributes);
}


MessageQueue::~MessageQueue()
{
    if(-1 != m_QueueID)
    {
        mq_close(m_QueueID);
    }
    m_timer.Stop();
    m_timer.Shutdown();
    if (m_isTimerCreated)
    {
        m_Queuetimer.Stop();
        m_Queuetimer.Shutdown();
    }
}

bool MessageQueue :: Send(const std::string &data, const uint32_t waitTimeMs, const bool toFront)
{
    struct timespec queueWaitTimer;
    clock_gettime(CLOCK_REALTIME, &queueWaitTimer);
    //Written in a generic way to handle any milliseconds value
    queueWaitTimer.tv_sec += (time_t)(waitTimeMs/1000);
    queueWaitTimer.tv_nsec += (waitTimeMs % 1000) * 1000 * 1000;
    const unsigned int priority = toFront ? 1 : 0; // Higher priority number should push it to front
    int result = mq_getattr(m_QueueID, &q_attributes);
    if(0 ==  result && q_attributes.mq_curmsgs == LimitReached)
    {
        DEBUGPRINT(DEBUG_ERROR, "PlatformLinux::MessageQueue::{0} size limit warning [{1}] --> max [{2}]",m_queueName,q_attributes.mq_curmsgs, MaxQueueSize);
    }
    if (!m_messegeQueue.empty())//if we had a linux mqueue overflow already, we need to keep send only to buffer
    {
        return BufferMessage(std::make_shared<std::string>(data));
    }
    else//we try to send to mqueue
    {
        auto result = mq_timedsend(m_QueueID, data.c_str(), data.size(), priority, &queueWaitTimer); //Blocking timed send
        if (0 != result && (m_queueName.find("Mol") == std::string::npos)) //if we have a linux mqueue overflow only we start buffering on memory
        {
            if(!m_isTimerCreated) //only first time when necessary, we create the timer to handle buffered messages
            {
                Platform::Notifier messageCheck;
                messageCheck.Connect(this,&MessageQueue::QueueBufferingNotification);
                m_Queuetimer = Timer{1,GlobalDataType::Timer::AlarmType::PERIODIC,messageCheck};
                m_Queuetimer.Start();
                m_isTimerCreated = true;
                DEBUGPRINT(DEBUG_ERROR, "PlatformLinux::MessageQueue::{0} size max reached[{1}], buffering will take place",m_queueName,q_attributes.mq_curmsgs);
            }
            //we buffer the message, and if success we return truly sent
            return BufferMessage(std::make_shared<std::string>(data));
        }
        else//no need for buffering
        {
            return true;
        }
    }
}


std::string MessageQueue::Receive(const uint32_t waitTimeMs)
{

    char buffer[MaxMessageSize+1]{}; //should be greater than msgsize
    int32_t returnCode = -1;
    struct timespec queueWaitTimer{};
    ::clock_gettime(CLOCK_REALTIME, &queueWaitTimer);
    //Written in a generic way to handle any milliseconds value
    queueWaitTimer.tv_sec += static_cast<time_t>(waitTimeMs/MAX_TIME);
    queueWaitTimer.tv_nsec += (waitTimeMs % MAX_TIME) * MAX_TIME * MAX_TIME;
    returnCode = ::mq_timedreceive(m_QueueID, buffer, MaxMessageSize+1, nullptr,&queueWaitTimer);  //Blocking timed receive
    if(returnCode >  -1)
    {
        return std::string(buffer,returnCode);
    }
    else
    {
        return "";
    }
}

void MessageQueue::Registration(std::function<void(const std::string&)> notification)
{
    m_userNotification = notification;
    Platform::Notifier messageCheck;
    messageCheck.Connect(this,&MessageQueue::LocalNotification);
    const uint32_t m_notificationIntervalMs = 10;
    m_timer = Timer{m_notificationIntervalMs,GlobalDataType::Timer::AlarmType::PERIODIC,messageCheck};
    m_timer.Start();
}

void MessageQueue::LocalNotification()
{
    auto recivedData = Receive();
    if(!recivedData.empty())
    {
        m_userNotification(recivedData);
    }
}

void MessageQueue::QueueBufferingNotification()
{
    int result = ::mq_getattr(m_QueueID, &q_attributes);
    //if we have some buffered messages and the linux mqueue have some space, we push the data
    if ((!m_messegeQueue.empty()) && (0 ==  result) && (static_cast<uint32_t>(q_attributes.mq_curmsgs) < MaxQueueSize))
    {
        auto message = m_messegeQueue.front();
        std::string data = message.get()?*message.get():"";
        if(!data.empty())
        {
            result = ::mq_send(m_QueueID, data.c_str(), data.size(), 0);
            if(0 ==  result)
            {
                m_messegeQueue.pop();//Delete it form the queue
                message = nullptr;//free shared pointer string memory
            }
        }
    }
}

bool MessageQueue::BufferMessage(std::shared_ptr<std::string> message)
{
    if(static_cast<uint64_t>(m_messegeQueue.size()) < (MAX_BUFFERING_SIZE) && (nullptr != message))
    {
        m_messegeQueue.push(message);
        return true;
    }
    else
    {
        DEBUGPRINT(DEBUG_ERROR, "PlatformLinux::MessageQueue::{0}, max buffering reached [{1}] elements ", m_queueName, MAX_BUFFERING_SIZE);
        return false;
    }
}

}// end of PlatformLinux
