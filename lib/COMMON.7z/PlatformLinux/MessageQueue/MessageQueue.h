/*****************************************************************//**
 *
 * @file    MessageQueue.h
 * @brief   MessageQueue class provides a wrapper library for using message queue.
 *          This class also provides message queue api on linux
 *
 *
 * @copyright Copyright 2018 by Honeywell International Inc.
 * All rights reserved.  This software and code comprise proprietary
 * information of Honeywell International Inc.  This software and code
 * may not be reproduced, used, altered, re-engineered, distributed or
 * disclosed to others without the written consent of Honeywell.
 ********************************************************************/
#ifndef PLATFORM_LINUX_MESSAGEQUEUE_INCLUDE_H
#define PLATFORM_LINUX_MESSAGEQUEUE_INCLUDE_H

#include"GlobalDataType/MessageQueue.h"
#include"GlobalDataType/FileNotification/FileNotification.h"
#include "mqueue.h"
#include <cassert>
#include <iostream>
#include "Timer/Timer.h"
#include <queue>
namespace PlatformLinux
{
/**
 * @brief MessageQueue class
 *
 * Provides wrapper class for using MessageQueues functionality.
 */
class MessageQueue : public GlobalDataType::MessageQueue
{
public:
    MessageQueue() = default;
    /** Member initialization */
    MessageQueue(const std::string& queueName, BlockType type = GlobalDataType::MessageQueue::BlockType::NON_BLOCK);

    /** Default destructor */
    ~MessageQueue();

    /**
         Sends the given data into the queue
         @param[in]   data              : original data part to be sent
         @param[in]   waitTime          : optional wait time in case of timedsend, Valid if queue created in Block mode
         @return status code true on success, else false
    */

    bool Send(const std::string& data, const uint32_t waitTimeMs = 0, const bool toFront = false) ;


    /**
         Receives the given data from the queue
         @param[in]   waitTime          : optional wait time in case of timedreceive,Valid if queue created in Block mode
         @param[in]   toFront           : Unused in PlatformLinux
         @return receive data
    */
    std::string Receive(const uint32_t waitTimeMs = 0) ;

    /**
     * @brief buffer the provided message if the queue is still not full yet MAX_BUFFERING_SIZE
     * @param message: is the message to be buffered
     */
    bool BufferMessage(std::shared_ptr<std::string> message);

    /**
     * @brief send buffered messages to Linux queue
     */
    void QueueBufferingNotification();


    /**
        copy other valid MessageQueue.
        Method generate assert if assigned MessageQueue has
        a valid OS Queue handle
    */
    MessageQueue& operator = (const MessageQueue& otherMessageQueue)
    {
        if(this != &otherMessageQueue)
        {
            //MessageQueue copy is not allowed, if the
            // host MessageQueue object has valid queue
            //Otherwise host MessageQueue data is lost.
            assert( -1 == m_QueueID );

            // Assert if otherMessageQueue dont have valid Queue handle
            // Copy a MessageQueue object with invalid handle is and
            //invalid operation
            std::cout<<otherMessageQueue.m_queueName<< otherMessageQueue.m_QueueID<<std::endl;
            assert( -1 != otherMessageQueue.m_QueueID );

            m_QueueID = otherMessageQueue.m_QueueID;
            const_cast<int&>(otherMessageQueue.m_QueueID) =-1;
            m_blockType = otherMessageQueue.m_blockType;
            m_queueName = otherMessageQueue.m_queueName;
        }
       return *this;
    }

    void Registration(std::function<void(const std::string&)> notification);
private:
    int32_t m_QueueID = -1;
    BlockType m_blockType;
    std::string m_queueName;
    static const uint32_t MaxQueueSize;
    static const uint32_t MaxMessageSize;
    static const uint32_t LimitReached;
    static const char* MESSAGE_QUEUE_PATH;
    static const uint32_t MAX_BUFFERING_SIZE;
    static const uint32_t MAX_TIME;

    Timer m_timer;
    Timer m_Queuetimer;
    std::function<void(const std::string&)> m_userNotification;
    int32_t m_messageCount{0};
    void LocalNotification();
    struct mq_attr q_attributes;
    std::queue<std::shared_ptr<std::string>> m_messegeQueue;
    bool m_isTimerCreated = false;
};


}// end  of PlatformLinux

#endif //PLATFORM_LINUX_MESSAGEQUEUE_H
